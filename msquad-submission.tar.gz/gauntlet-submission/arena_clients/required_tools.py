"""Required-tools gate: which tools the server requires that a run has not called.

A required tool that is never called zeroes the quality score, so every
submit path checks this list first.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any


def required_tool_names(raw: Any) -> list[str]:
    """Normalize a ``required_tools`` payload to unique, non-empty names."""
    if not isinstance(raw, (list, tuple)):
        return []
    names: list[str] = []
    for item in raw:
        name = str(item or "").strip()
        if name and name not in names:
            names.append(name)
    return names


def missing_required_tools(required: Iterable[str], called: Iterable[str]) -> list[str]:
    """Return required tool names that do not appear in ``called``, in order."""
    done = {str(name).strip() for name in called if str(name or "").strip()}
    return [name for name in required_tool_names(list(required)) if name not in done]
