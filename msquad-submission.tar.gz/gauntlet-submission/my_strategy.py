"""Competitor strategy definition for starter-kit agents.

Edit this class to customize behavior without touching runtime code.

Model policy (see OPT_models.md for the matrix behind it):
- Candidates come from the live /models roster, never a hardcoded list.
- Image-only aliases are dropped for text challenges.
- Each challenge type (logic, math, reasoning, retrieval, structured) has its own
  measured card order (msquad/model_cards.json); unseen names use family defaults.
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext, ExtractedAnswer, output_contract, strip_named_unit
from msquad import image_constraints
from msquad.math_expr import evaluate_reply

# Capability table: msquad/model_cards.json (built by tools/build_model_cards.py from
# our sweeps). A roster name with a card uses its measured numbers; an unseen name
# uses its family default row; anything else is unknown and ranks last.
CARDS_PATH = Path(__file__).resolve().parent / "msquad" / "model_cards.json"
CARDS: dict[str, Any] = json.loads(CARDS_PATH.read_text(encoding="utf-8")) if CARDS_PATH.exists() else {}
SPEED_WEIGHT = 2.0  # points lost per second of median latency
NEUTRAL_RATE = 0.5  # used when a model has no accuracy for the task
UNKNOWN_LATENCY_S = 6.0

# Never used for text challenges: image generation/edit aliases. Gemini text
# models stay in the roster; gemini-3.6-flash is ranked only where it scored well.
EXCLUDED_PATTERNS: list[str] = [r"-image"]

# Non-chat aliases (embeddings, speech, moderation, rerank, video) never answer text.
NON_CHAT_PATTERNS: list[str] = [r"embed", r"tts", r"whisper", r"audio", r"speech", r"moderat", r"rerank", r"video", r"transcri"]

# Unknown-roster heuristic: larger or faster-looking names rank first.
HEURISTIC_BONUS: list[tuple[str, int]] = [
    (r"\bmax\b|ultra|\bpro\b|opus", 3),
    (r"plus|flash|sonnet|large", 2),
    (r"\blite\b|nano|mini|small|tiny", -1),
]


# Output caps. Non-logic keeps the full 8192 budget (the contract test expects it).
LOGIC_MAX_TOKENS = 2500
NON_LOGIC_MAX_TOKENS = 8192


def _alias(model_id: str) -> str:
    return str(model_id or "").strip().rsplit("/", 1)[-1].casefold()


def _matches_any(alias: str, patterns: list[str]) -> bool:
    return any(re.search(pattern, alias) for pattern in patterns)


def _heuristic_score(alias: str) -> int:
    score = 0
    for pattern, bonus in HEURISTIC_BONUS:
        if re.search(pattern, alias):
            score += bonus
    return score


def _family_of(alias: str) -> str:
    for family in ("nemotron", "qwen", "gemini", "gpt"):
        if alias.startswith(family):
            return family
    return alias.split("-")[0]


def _task_cell(model_id: str, task: str) -> tuple[float | None, float | None, str]:
    """Return (accuracy rate, median seconds, source) for a model on a task."""
    alias = _alias(model_id)
    card = CARDS.get("models", {}).get(alias)
    if card:
        cell = card.get("tasks", {}).get(task)
        if cell and cell.get("n"):
            return cell["correct"] / cell["n"], cell.get("median_s"), "measured"
    defaults = CARDS.get("family_defaults", {}).get(_family_of(alias), {}).get(task)
    if defaults and defaults.get("n"):
        return defaults["correct"] / defaults["n"], defaults.get("median_s"), "family-default"
    return None, None, "unknown"


def _supports_low_effort(model_id: str) -> bool:
    alias = _alias(model_id)
    card = CARDS.get("models", {}).get(alias)
    if card and card.get("supports_reasoning_param") is False:
        return False
    return alias.startswith("gemini-") and "-flash" in alias


def _task_kind(ctx: ChallengeContext) -> str:
    """Map a challenge's type/description to a task name (default: logic)."""
    text = f"{ctx.challenge_type} {ctx.description}".casefold()
    if "retriev" in text or "search" in text:
        return "retrieval"
    if "struct" in text or "json" in text or "schema" in text:
        return "structured"
    if "math" in text or "arithmetic" in text:
        return "math"
    if "reason" in text:
        return "reasoning"
    return "logic"


def _log_path(path: str, ctx: ChallengeContext, has_expr: bool, answer: Any, reply: str) -> None:
    """Diagnostic only: append which finalize path answered, when MSQUAD_PATH_LOG is set."""
    target = os.environ.get("MSQUAD_PATH_LOG", "")
    if not target:
        return
    record = {
        "path": path,
        "has_expr": has_expr,
        "answer": answer,
        "rules": ctx.rules,
        "task": _task_kind(ctx),
        "description": ctx.description,
        "reply": reply,
    }
    with open(target, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def _is_numeric_answer(answer: str) -> bool:
    """True when an ANSWER line is a plain number, allowing a currency sign, thousands commas, or a unit word."""
    text = answer.strip("`").replace("$", "").replace(",", "").strip()
    text = re.sub(r"\s*(?:[a-zA-Z%]+\.?)$", "", text)  # 32 apples -> 32
    return bool(re.fullmatch(r"-?\d+(?:\.\d+)?", text))


def _wants_numeric_expr(ctx: ChallengeContext) -> bool:
    """True for math challenges whose rules ask for an integer or plain number.

    Dates, weekdays and text answers keep the model's ANSWER line; an EXPR value
    would only be a number there.
    """
    if _task_kind(ctx) != "math":
        return False
    rules = ctx.rules or ""
    if re.search(r"yyyy|date|weekday|word|name", rules, re.IGNORECASE):
        return False
    return bool(re.search(r"\b(integer|number)\b", rules, re.IGNORECASE))


class MyStrategy(BaseStrategy):
    """Default competitor strategy template."""

    # Team identity (shown in Organizer/Dashboard)
    agent_id = "msquad"
    agent_name = "Msquad"

    # Text challenge strategy
    text_system_prompt = (
        "You are a text challenge solver. "
        "Your first line must always be: ANSWER: <final answer>. "
        "Return nothing except the required ANSWER line and optional brief reasoning lines after it. "
        "Follow challenge rules exactly, including strict output formats. "
        "Do not output <think> tags. "
        "If you add reasoning, keep it to at most 2 short lines after the ANSWER line. "
        "Never output 'unknown'."
    )
    text_strategy_notes = "Keep reasoning concise and always include an ANSWER line."

    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        """Strict contract first: the final line is `ANSWER: <bare answer>`."""
        return (
            f"{str(self.text_system_prompt).strip()}\n\n"
            "Never write the answer as prose, arrows, or a sentence. "
            "Never wrap the answer in quotes or code fences.\n"
            f"{output_contract(ctx.rules, ctx.clues)}"
        )

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        """Solver prompt with the same contract, derived from this challenge."""
        if _wants_numeric_expr(ctx):
            return (
                f"{super().build_solver_prompt(ctx)}\n\n"
                "Write one line `EXPR: <expression>` that computes the final answer to the question from the "
                "given numbers, with every step of the problem inside it. Use only numbers, "
                "+ - * / ( ) and no words. Then end with the line `ANSWER: <bare answer>`."
            )
        return (
            f"{super().build_solver_prompt(ctx)}\n\n"
            "Reminder: the last line of your reply is `ANSWER: <bare answer>` and nothing after it."
        )

    def finalize_answer(self, raw_reply: str, ctx: ChallengeContext) -> ExtractedAnswer:
        """Integer math: the evaluated EXPR wins when the ANSWER line is a number too."""
        has_expr = bool(re.search(r"^\s*EXPR:", raw_reply or "", re.IGNORECASE | re.MULTILINE))
        if _wants_numeric_expr(ctx):
            answers = re.findall(r"^\s*ANSWER:\s*(\S.*?)\s*$", raw_reply or "", re.IGNORECASE | re.MULTILINE)
            value = evaluate_reply(raw_reply)
            numeric_answer = not answers or _is_numeric_answer(answers[-1])
            if value is not None and numeric_answer:
                _log_path("EXPR", ctx, has_expr, value, raw_reply)
                return ExtractedAnswer(value, True, "", [value])
            if not answers and value is None and re.search(r"^\s*EXPR:", raw_reply or "", re.MULTILINE):
                _log_path("EXPR_INVALID", ctx, has_expr, "", raw_reply)
                return ExtractedAnswer("", False, "EXPR does not evaluate to a whole number", [])
        result = super().finalize_answer(raw_reply, ctx)
        if re.search(r"EXPR:", result.answer or "", re.IGNORECASE):
            _log_path("EXPR_LINE_REJECTED", ctx, has_expr, "", raw_reply)
            return ExtractedAnswer("", False, "EXPR line is not an answer", result.tokens)
        if _task_kind(ctx) == "math" and (not (result.answer or "").strip() or len(result.answer) > 200):
            # No bare number came out: an empty reply, or a long working text with no ANSWER line.
            _log_path("NO_BARE_ANSWER", ctx, has_expr, "", raw_reply)
            return ExtractedAnswer("", False, "no bare answer line", result.tokens)
        stripped = strip_named_unit(result.answer, ctx.description, ctx.rules, ctx.challenge_type)
        if stripped != result.answer:
            # The question names the unit or label ("in Celsius", "route number"): the number alone.
            result = ExtractedAnswer(stripped, result.valid, result.reason, [stripped])
        _log_path("ANSWER", ctx, has_expr, result.answer, raw_reply)
        return result

    text_temperature = 0.0
    # Reasoning models spend most of this budget thinking before they answer;
    # 1024 cut the roster's default model off before it wrote an answer.
    text_max_tokens = 8192

    # Image challenge strategy
    image_strategy_notes = (
        "Prefer image_edit when an input image is available. Keep rationale concise. "
        "Request standard-resolution output only and avoid HD or 4K images."
    )

    def fastest_model(self, models: list[str], challenge_type: str, exclude: str) -> str:
        """The roster model with the lowest measured median latency on this task, or "" if none is measured."""
        best, best_seconds = "", None
        for model in models:
            if model == exclude:
                continue
            _, median, _ = _task_cell(model, challenge_type)
            if median is None:
                continue
            if best_seconds is None or median < best_seconds:
                best, best_seconds = model, median
        return best

    def rank_models(
        self,
        ctx: ChallengeContext,
        available_models: list[str],
    ) -> list[str]:
        """Rank live roster aliases for this challenge; best first, fallbacks after."""
        if self.is_image_challenge(ctx):
            preferred = self.prefer_image_models(available_models)
            if preferred:
                return preferred
            return list(available_models)

        text_models = [
            model
            for model in available_models
            if str(model or "").strip()
            and not _matches_any(_alias(model), EXCLUDED_PATTERNS)
            and not _matches_any(_alias(model), NON_CHAT_PATTERNS)
        ]
        self._task = _task_kind(ctx)
        scored = []
        for index, model in enumerate(text_models):
            rate, latency, source = _task_cell(model, self._task)
            accuracy = (rate if rate is not None else NEUTRAL_RATE) * 100
            seconds = latency if latency is not None else UNKNOWN_LATENCY_S
            score = accuracy - SPEED_WEIGHT * seconds
            tie = _heuristic_score(_alias(model))
            scored.append((-score, -tie, index, model, source, rate, latency))
        scored.sort()
        ranked = [row[3] for row in scored]
        self._reasons = {row[3]: (row[4], row[5], row[6]) for row in scored}
        if scored:
            _, _, _, top, source, rate, latency = scored[0]
            rate_text = "n/a" if rate is None else f"{rate:.2f}"
            latency_text = "n/a" if latency is None else f"{latency}s"
            reason = f"source={source} accuracy={rate_text} median={latency_text}"
        else:
            reason = "no text models"
            top = ""
        print(
            f"[route] task={self._task} roster={len(available_models)} text={len(text_models)} "
            f"pick={top or '-'} reason=({reason})",
            file=sys.stderr,
            flush=True,
        )
        return ranked

    def pick_model(
        self,
        stage: str,
        ranked_models: list[str],
        ctx: ChallengeContext,
    ) -> str:
        """Take the top-ranked model; the runtime falls back down the list on retry."""
        _ = stage
        _ = ctx
        self._picked = ranked_models[0] if ranked_models else ""
        return self._picked

    def get_llm_params(self, ctx: ChallengeContext) -> dict[str, Any]:
        """Deterministic solve: temperature 0 and the full output budget.

        A time-linked cap (60 tokens per second) was tried and reverted: on logic
        easy, nemotron-3.5-lightning spent its whole budget thinking and never
        wrote the ANSWER line (Practice runs 8 and 10 scored 70.8 and 14.8).
        """
        if getattr(self, "_task", "") == "logic":
            # Every logic route is capped: a long think on the full 8192 budget
            # ends without an ANSWER line. Gemini Flash also gets low reasoning,
            # which it supports (reasoning none returns HTTP 400).
            params: dict[str, Any] = {"temperature": 0.0, "max_tokens": LOGIC_MAX_TOKENS}
            if _supports_low_effort(getattr(self, "_picked", "")):
                params["reasoning_effort"] = "low"
            return params
        params = {"temperature": 0.0, "max_tokens": NON_LOGIC_MAX_TOKENS}
        if _supports_low_effort(getattr(self, "_picked", "")):
            params["reasoning_effort"] = "low"
        return params

    def should_submit_early(self, answer: str, ctx: ChallengeContext) -> bool:
        """Submit as soon as an answer exists and the clock is nearly out.

        Speed is 15% of the score and a late answer scores as a loss, so once
        an answer is in hand with under 15s left, do not spend more time on it.
        """
        return bool(answer and answer.strip()) and ctx.time_remaining_s < 15.0

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        """Restate the challenge's constraints for the image model.

        The image judge scores accuracy, quality, preservation and compliance,
        so the prompt names each one: follow the instruction, keep what the
        instruction does not change, and add no unrequested text or marks.
        """
        base = super().build_image_prompt(ctx).strip()
        if ctx.image_url:
            guard = (
                "Edit the provided source image. Apply exactly the change requested "
                "and keep everything else from the source unchanged: subject, "
                "composition, framing, colors and lighting."
            )
        else:
            # The no-text rule leads the generate prompt: the live output still had kanji and
            # lettering on signs (constraints 50) when the rule came last.
            guard = (
                "Generate exactly one image that fulfils the request below. Absolutely no text "
                "anywhere in the image unless the request itself asks for specific text: no "
                "lettering, no kanji, no signage words, no logos, no numbers. Compose the scene "
                "without signs, billboards, labels, captions, screens or writing; if one is "
                "essential, leave it blank."
            )
        if ctx.image_url:
            from msquad import image_edit_keep

            if image_edit_keep.enabled():
                # A/B arm (MSQUAD_EDIT_KEEPLIST): the notes' "keep ..." items as a list.
                listed = image_edit_keep.keep_list(ctx.challenge_text or ctx.description or "", ctx.rules or "")
                if listed:
                    base = f"{base}\n\n{listed}"
        if not ctx.image_url and image_constraints.enabled():
            # A/B arm (MSQUAD_GENERATE_CHECKLIST): counts, colour limits and negatives as a checklist.
            listed = image_constraints.checklist(f"{ctx.challenge_text or ''} {ctx.description or ''}")
            if listed:
                base = f"{base}\n\n{listed}"
        constraints = (
            "Hard constraints: follow every explicit requirement in the instruction; "
            "add no text, captions, watermarks, logos or borders unless the instruction "
            "asks for them; output a single image; keep the result clean and free of "
            "artifacts."
        )
        return f"{guard}\n\n{base}\n\n{constraints}"
