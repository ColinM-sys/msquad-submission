"""Competitor strategy definition for starter-kit agents.

Edit this class to customize behavior without touching runtime code.

Model policy (see OPT_models.md for the matrix behind it):
- Candidates come from the live /models roster, never a hardcoded list.
- Image-only aliases are dropped for text challenges.
- Each challenge type (logic, math, reasoning, retrieval, structured) has its own
  measured card order (msquad/model_cards.json); unseen names use family defaults.
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext, ExtractedAnswer, asks_prose, asks_quotes, output_contract, strip_named_unit
from msquad import clause_negation, image_constraints, output_contract_dedup
from msquad.math_expr import evaluate_reply, has_labelled_line, labelled_groups

# Capability table: msquad/model_cards.json (built by tools/build_model_cards.py from
# our sweeps). A roster name with a card uses its measured numbers; an unseen name
# uses its family default row; anything else is unknown and ranks last.
CARDS_PATH = Path(__file__).resolve().parent / "msquad" / "model_cards.json"
CARDS: dict[str, Any] = json.loads(CARDS_PATH.read_text(encoding="utf-8")) if CARDS_PATH.exists() else {}
SPEED_WEIGHT = 2.0  # points lost per second of median latency
NEUTRAL_RATE = 0.5  # used when a model has no accuracy for the task
UNKNOWN_LATENCY_S = 6.0

# Never used for text challenges: image generation/edit aliases. Gemini text
# models stay in the roster; gemini-3.6-flash is ranked only where it scored well.
EXCLUDED_PATTERNS: list[str] = [r"-image"]

# Non-chat aliases (embeddings, speech, moderation, rerank, video) never answer text.
NON_CHAT_PATTERNS: list[str] = [r"embed", r"tts", r"whisper", r"audio", r"speech", r"moderat", r"rerank", r"video", r"transcri"]

# Unknown-roster heuristic: larger or faster-looking names rank first.
HEURISTIC_BONUS: list[tuple[str, int]] = [
    (r"\bmax\b|ultra|\bpro\b|opus", 3),
    (r"plus|flash|sonnet|large", 2),
    (r"\blite\b|nano|mini|small|tiny", -1),
]


# Output caps. Non-logic keeps the full 8192 budget (the contract test expects it).
LOGIC_MAX_TOKENS = 2500
NON_LOGIC_MAX_TOKENS = 8192


def _alias(model_id: str) -> str:
    return str(model_id or "").strip().rsplit("/", 1)[-1].casefold()


def _matches_any(alias: str, patterns: list[str]) -> bool:
    return any(re.search(pattern, alias) for pattern in patterns)


def _heuristic_score(alias: str) -> int:
    score = 0
    for pattern, bonus in HEURISTIC_BONUS:
        if re.search(pattern, alias):
            score += bonus
    return score


def _family_of(alias: str) -> str:
    for family in ("nemotron", "qwen", "gemini", "gpt"):
        if alias.startswith(family):
            return family
    return alias.split("-")[0]


def _task_cell(model_id: str, task: str) -> tuple[float | None, float | None, str]:
    """Return (accuracy rate, median seconds, source) for a model on a task."""
    alias = _alias(model_id)
    card = CARDS.get("models", {}).get(alias)
    if card:
        cell = card.get("tasks", {}).get(task)
        if cell and cell.get("n"):
            return cell["correct"] / cell["n"], cell.get("median_s"), "measured"
    defaults = CARDS.get("family_defaults", {}).get(_family_of(alias), {}).get(task)
    if defaults and defaults.get("n"):
        return defaults["correct"] / defaults["n"], defaults.get("median_s"), "family-default"
    return None, None, "unknown"


def _supports_low_effort(model_id: str) -> bool:
    alias = _alias(model_id)
    card = CARDS.get("models", {}).get(alias)
    if card and card.get("supports_reasoning_param") is False:
        return False
    return alias.startswith("gemini-") and "-flash" in alias


# A/B arm (MSQUAD_LOW_EFFORT_CARD): on non-logic tasks, low reasoning for every model whose
# card says it takes the reasoning parameter (gpt-5.4 for structured), not only gemini flash.
# Structured spends ~515 of ~754 tokens thinking for a ~22-token JSON answer.
LOW_EFFORT_CARD_ENV = "MSQUAD_LOW_EFFORT_CARD"
LOW_EFFORT_CARD_DEFAULT = False


def _card_effort_arm_enabled() -> bool:
    value = os.environ.get(LOW_EFFORT_CARD_ENV, "").strip().lower()
    if not value:
        return LOW_EFFORT_CARD_DEFAULT
    return value in {"1", "true", "yes", "on"}


def _card_supports_reasoning(model_id: str) -> bool:
    card = CARDS.get("models", {}).get(_alias(model_id))
    return bool(card) and card.get("supports_reasoning_param") is True


def _task_kind(ctx: ChallengeContext) -> str:
    """Map a challenge's type/description to a task name (default: logic)."""
    text = f"{ctx.challenge_type} {ctx.description}".casefold()
    if "retriev" in text or "search" in text:
        return "retrieval"
    if "struct" in text or "json" in text or "schema" in text:
        return "structured"
    if "math" in text or "arithmetic" in text:
        return "math"
    if "reason" in text:
        return "reasoning"
    return "logic"


def _log_path(path: str, ctx: ChallengeContext, has_expr: bool, answer: Any, reply: str) -> None:
    """Diagnostic only: append which finalize path answered, when MSQUAD_PATH_LOG is set."""
    target = os.environ.get("MSQUAD_PATH_LOG", "")
    if not target:
        return
    record = {
        "path": path,
        "has_expr": has_expr,
        "answer": answer,
        "rules": ctx.rules,
        "task": _task_kind(ctx),
        "description": ctx.description,
        "reply": reply,
    }
    with open(target, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")


_EVERY_RE = re.compile(r"\b(?:every|all|each)\b", re.IGNORECASE)
_COUNT_WORDS = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
# "list the three ...", "return 4 ...", "exactly five ...": an item count stated in the request.
_STATED_COUNT_RE = re.compile(
    r"\b(?:list|return|extract|give|name|find|exactly)\b(?:\s+(?:the|all|exactly))?\s+(\d+|"
    + "|".join(_COUNT_WORDS) + r")\b",
    re.IGNORECASE,
)
# Item kinds whose source form can be counted in the clues, recognised by schema pattern or field name.
_KINDS = {
    # A run of digits with phone separators: (415) 555-0137, +44 20 7946 0958, 415.555.0137
    "phone numbers": (re.compile(r"\+?\(?\d[\d\s().\-]{8,}\d"), lambda m: re.sub(r"\D", "", m),
                      lambda d: 10 <= len(d) <= 15),
    # The local part is at most 64 characters (RFC 5321) and starts a run: unbounded, a 100 KB run with no "@" was quadratic.
    "email addresses": (re.compile(r"(?<![\w.+-])[\w.+-]{1,64}@[\w-]+(?:\.[\w-]+)+"), str.lower, lambda d: True),
    "URLs": (re.compile(r"https?://[^\s,;)\]]+"),
             lambda m: re.sub(r"^https?://(?:www\.)?", "", m.strip().rstrip(".").lower()).rstrip("/"), lambda d: True),
}


def _item_kind(schema) -> str:
    """The countable kind of an array item's field (phone, email, URL), or "" when there is none."""
    if not isinstance(schema, dict) or schema.get("type") != "array":
        return ""
    # "items" may be a list (tuple form) or a bool in a schema; only an object describes one item.
    items = schema.get("items") or {}
    if not isinstance(items, dict):
        return ""
    props = items.get("properties") or {}
    if not isinstance(props, dict):
        return ""
    for name, spec in props.items():
        pattern = str((spec if isinstance(spec, dict) else {}).get("pattern", ""))
        key = str(name).lower()
        if pattern.startswith(r"^\+[0-9]") or key in {"phone", "e164", "phone_number"}:
            return "phone numbers"
        if "@" in pattern or key in {"email", "email_address"}:
            return "email addresses"
        if key in {"url", "href", "link"}:
            return "URLs"
    return ""


def _missing_items(answer: str, ctx: ChallengeContext) -> str:
    """A reason when a JSON array answer clearly lists fewer items than asked for, else "".

    Two unambiguous signals only: a single item count stated in the request ("list the three
    ..."), or, for an "every / all / each" request, the number of distinct phone numbers, email
    addresses or URLs in the clues when the item field is of that kind. The answer is never
    edited; the caller's one repair re-asks.
    """
    from base_strategy import _schema_from_text

    schema = _schema_from_text(f"{ctx.rules}\n{ctx.description}")
    try:
        items = json.loads(answer)
    except (ValueError, RecursionError):
        items = None
    if not isinstance(items, list):
        if _item_kind(schema):
            # The schema asks for an array of phone/email/URL items; prose or an object fails it anyway,
            # and must never replace a JSON first answer through the repair.
            return "the answer is not the JSON array the schema asks for"
        return ""
    request = f"{ctx.challenge_text or ''} {ctx.description or ''}"
    stated = {m.lower() for m in _STATED_COUNT_RE.findall(request)}
    if len(stated) == 1:
        word = stated.pop()
        expected = int(word) if word.isdigit() else _COUNT_WORDS[word]
        if 1 < expected != len(items):
            return f"the request asks for {expected} items but the answer lists {len(items)}"
        return ""
    if not _EVERY_RE.search(request):
        return ""
    kind = _item_kind(_schema_from_text(f"{ctx.rules}\n{ctx.description}"))
    if not kind:
        return ""
    regex, norm, keep = _KINDS[kind]
    sources = {}  # normalised value -> how it is written in the clues, with the words just before it
    text = " ".join(str(c) for c in ctx.clues or [])
    for match in regex.finditer(text):
        raw = match.group(0)
        if keep(norm(raw)):
            before = " ".join(text[max(0, match.start() - 40):match.start()].split()[-4:])
            sources.setdefault(norm(raw), f"...{before} {raw.strip()}" if before else raw.strip())
    if not sources:
        return ""
    listed = [norm(str(v)) for item in items if isinstance(item, dict) for v in item.values() if regex.search(str(v))]

    def grounded(value: str) -> bool:
        # E.164 adds a country code the clue may omit: (415) 555-0137 -> +14155550137.
        return any(value == s or value.endswith(s) or s.endswith(value) for s in sources)

    invented = [v for v in listed if not grounded(v)]
    if invented:
        # A value in the answer that no clue contains (a re-ask once produced +442079460959).
        return f"the answer lists {kind} that are not in the clues ({len(invented)}); use only the ones the clues give"
    missing = [raw for norm_value, raw in sources.items() if not any(
        v == norm_value or v.endswith(norm_value) or norm_value.endswith(v) for v in listed)]
    if not missing or len(sources) <= len(items):
        return ""
    return (f"incomplete: the clues contain {len(sources)} {kind} but the answer lists {len(items)}; "
            f"missing: {'; '.join(missing)}. Give every one, labelled as the clues label it, in the order the clues give")


_GIVEN_ORDER_RE = re.compile(r"\b(?:in the order (?:given|they appear|listed|mentioned)|order given)\b", re.IGNORECASE)


def _in_clue_order(answer: str, ctx: ChallengeContext) -> str:
    """``answer`` with its items in the order their values first appear in the clues, else unchanged.

    Only for requests that ask for the given order, an array of phone/email/URL items, and only
    when every item has exactly one grounded value: then the reorder changes nothing but order.
    """
    from base_strategy import _schema_from_text

    if not _GIVEN_ORDER_RE.search(f"{ctx.challenge_text or ''} {ctx.description or ''}"):
        return answer
    kind = _item_kind(_schema_from_text(f"{ctx.rules}\n{ctx.description}"))
    if not kind:
        return answer
    try:
        items = json.loads(answer)
    except (ValueError, RecursionError):
        return answer
    if not isinstance(items, list) or len(items) < 2 or not all(isinstance(i, dict) for i in items):
        return answer
    regex, norm, keep = _KINDS[kind]
    text = " ".join(str(c) for c in ctx.clues or [])
    first_seen: dict[str, int] = {}
    for match in regex.finditer(text):
        value = norm(match.group(0))
        if keep(value):
            first_seen.setdefault(value, match.start())
    positions = []
    for item in items:
        values = [norm(str(v)) for v in item.values() if regex.search(str(v))]
        hits = {pos for v in values for s, pos in first_seen.items() if v == s or v.endswith(s) or s.endswith(v)}
        if len(hits) != 1:
            return answer  # an item with no grounded value, or an ambiguous one: leave the order alone
        positions.append(hits.pop())
    if len(set(positions)) != len(positions):
        return answer
    ordered = [item for _, item in sorted(zip(positions, items), key=lambda pair: pair[0])]
    if ordered == items:
        return answer
    return json.dumps(ordered, ensure_ascii=False, separators=(",", ":"))


_ASCII_LETTERS = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")


def _drop_trailing_unit(text: str) -> str:
    """Remove a unit word at the end, with the spaces before it and an optional final dot.

    The same as re.sub(r"\\s*(?:[a-zA-Z%]+\\.?)$", "", text), found by walking back from the end:
    the one-pattern form rescans from every start position (quadratic on a long run of spaces or letters).
    """
    body = text[:-1] if text.endswith(".") else text
    start = len(body)
    while start and (body[start - 1] in _ASCII_LETTERS or body[start - 1] == "%"):
        start -= 1
    if start == len(body):
        return text
    return body[:start].rstrip()


def _is_numeric_answer(answer: str) -> bool:
    """True when an ANSWER line is a plain number, allowing a currency sign, thousands commas, or a unit word."""
    text = answer.strip("`").replace("$", "").replace(",", "").strip()
    text = _drop_trailing_unit(text)  # 32 apples -> 32
    return bool(re.fullmatch(r"-?\d+(?:\.\d+)?", text))


# A requested format the bare EXPR value cannot show: separators, currency, percent, a unit, decimals.
_EXPR_FORMAT_RE = re.compile(
    # Not "dollars", "units": they name what is counted ("an integer number of units"), not a format (Fable on #445).
    r"%|\$|€|£|\b(?:thousands?|separators?|commas?|percent(?:age)?|currency|decimals?)\b",
    re.IGNORECASE,
)


# "Commas are not allowed": a negation after the format word, in the same clause.
_FORMAT_REFUSED_AFTER_RE = re.compile(r"^\s*(?:are|is)\s+not\s+(?:allowed|permitted|needed|wanted|required)\b", re.IGNORECASE)
_CLAUSE_ENDS = ",.;:\n"


def _asks_expr_format(rules: str) -> bool:
    """True when a format word in the rules is asked for, not negated ("no commas or units", "do not use commas").

    The clause runs to a comma, full stop, semicolon, colon or newline, so "use commas, no units" still asks.
    """
    for hit in _EXPR_FORMAT_RE.finditer(rules):
        start = max(rules.rfind(c, 0, hit.start()) for c in _CLAUSE_ENDS) + 1
        end = min((i for i in (rules.find(c, hit.end()) for c in _CLAUSE_ENDS) if i >= 0), default=len(rules))
        if re.search(rf"\b{clause_negation.NEGATOR}\b", rules[start:hit.start()], re.IGNORECASE):
            continue
        if _FORMAT_REFUSED_AFTER_RE.match(rules[hit.end():end]):
            continue
        return True
    return False


def _keeps_formatted_answer(answer: str, value: str, ctx: ChallengeContext) -> bool:
    """True when the rules ask for such a format and the ANSWER line is the EXPR value, formatted."""
    if not _asks_expr_format(ctx.rules or ""):
        return False
    bare = _drop_trailing_unit(answer.strip("`").replace("$", "").replace(",", "").strip())
    try:
        return bare != answer.strip() and float(bare) == float(value)
    except ValueError:
        return False


def _wants_numeric_expr(ctx: ChallengeContext) -> bool:
    """True for math challenges whose rules ask for an integer or plain number.

    Dates, weekdays and text answers keep the model's ANSWER line; an EXPR value
    would only be a number there.
    """
    if _task_kind(ctx) != "math":
        return False
    rules = ctx.rules or ""
    if re.search(r"yyyy|date|weekday|word|name", rules, re.IGNORECASE):
        return False
    return bool(re.search(r"\b(integer|number)\b", rules, re.IGNORECASE))


def _image_instructions(ctx: ChallengeContext) -> list[str]:
    """Where the image request may be: the first line of rules, then challenge_text.

    The live agent builds the image context with challenge_text = description (a generic "Generate an
    original image from a prompt ...") and puts the real prompt and notes in rules, prompt first. Bench
    and test contexts put the prompt in challenge_text. Arms that only read challenge_text never fired live.
    """
    rules = (ctx.rules or "").strip()
    found = [rules.splitlines()[0].strip()] if rules else []
    for text in (ctx.challenge_text, ctx.description):
        if (text or "").strip() and text.strip() not in found:
            found.append(text.strip())
    return found


def _first_rule(rule, ctx: ChallengeContext, *, whole: bool = False) -> str:
    """The arm's text for the first place the request can be. ``whole`` adds the rest after it, for arms that
    need the subject to open the text but also scan the notes."""
    rest = " ".join(p for p in (ctx.rules, ctx.challenge_text, ctx.description) if p)
    for instruction in _image_instructions(ctx):
        text = rule(f"{instruction} {rest}" if whole else instruction)
        if text:
            return text
    return ""


class MyStrategy(BaseStrategy):
    """Default competitor strategy template."""

    # Team identity (shown in Organizer/Dashboard)
    agent_id = "msquad"
    agent_name = "Msquad"

    # Text challenge strategy
    text_system_prompt = (
        "You are a text challenge solver. "
        "Your first line must always be: ANSWER: <final answer>. "
        "Return nothing except the required ANSWER line and optional brief reasoning lines after it. "
        "Follow challenge rules exactly, including strict output formats. "
        "Do not output <think> tags. "
        "If you add reasoning, keep it to at most 2 short lines after the ANSWER line. "
        "Never output 'unknown'."
    )
    text_strategy_notes = "Keep reasoning concise and always include an ANSWER line."

    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        """Keep the full contract in the user prompt when deduplication is enabled."""
        prompt = (
            f"{str(self.text_system_prompt).strip()}\n\n"
            + ("Never write the answer as arrows. " if asks_prose(ctx.rules)
               else "Never write the answer as prose, arrows, or a sentence. ")
            + ("Never wrap the answer in code fences.\n" if asks_quotes(ctx.rules)
               else "Never wrap the answer in quotes or code fences.\n")
        )
        if output_contract_dedup.enabled():
            return prompt
        return f"{prompt}{output_contract(ctx.rules, ctx.clues)}"

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        """Solver prompt with the same contract, derived from this challenge."""
        if _wants_numeric_expr(ctx):
            return (
                f"{super().build_solver_prompt(ctx)}\n\n"
                "Write one line `EXPR: <expression>` that computes the final answer to the question from the "
                "given numbers, with every step of the problem inside it. Use only numbers, "
                "+ - * / ( ) and no words. Then end with the line `ANSWER: <bare answer>`."
            )
        return (
            f"{super().build_solver_prompt(ctx)}\n\n"
            "Reminder: the last line of your reply is `ANSWER: <bare answer>` and nothing after it."
        )

    def finalize_answer(self, raw_reply: str, ctx: ChallengeContext) -> ExtractedAnswer:
        """Integer math: the evaluated EXPR wins when the ANSWER line is a number too."""
        has_expr = has_labelled_line(raw_reply or "", "EXPR")
        # EXPR is exact and cannot enforce requested rounding or precision.
        if _wants_numeric_expr(ctx) and not re.search(
            r"\b(?:round(?:ed|ing)?|nearest|precision|decimal (?:places?|digits?)"
            r"|significant (?:figures?|digits?))\b",
            f"{ctx.description or ''}\n{ctx.rules or ''}",
            re.IGNORECASE,
        ):
            answers = labelled_groups(raw_reply or "", "ANSWER", nonspace_start=True)
            value = evaluate_reply(raw_reply)
            numeric_answer = not answers or _is_numeric_answer(answers[-1])
            if value is not None and numeric_answer and answers and _keeps_formatted_answer(answers[-1], value, ctx):
                # The rules ask for a format the bare EXPR value lacks ("456,250"), and the model's ANSWER is that
                # same number in that format: EXPR only verifies it (fresh-mix fm_math_sep; the #438 principle).
                _log_path("EXPR_VERIFIED_FORMAT", ctx, has_expr, value, raw_reply)
                value = None
            if value is not None and numeric_answer:
                _log_path("EXPR", ctx, has_expr, value, raw_reply)
                return ExtractedAnswer(value, True, "", [value])
            if not answers and value is None and has_labelled_line(raw_reply or "", "EXPR", ignore_case=False):
                _log_path("EXPR_INVALID", ctx, has_expr, "", raw_reply)
                return ExtractedAnswer("", False, "EXPR does not evaluate to a whole number", [])
        result = super().finalize_answer(raw_reply, ctx)
        if _wants_numeric_expr(ctx) and re.search(r"EXPR:", result.answer or "", re.IGNORECASE):
            _log_path("EXPR_LINE_REJECTED", ctx, has_expr, "", raw_reply)
            return ExtractedAnswer("", False, "EXPR line is not an answer", result.tokens)
        if _task_kind(ctx) == "math" and (not (result.answer or "").strip() or len(result.answer) > 200):
            # No bare number came out: an empty reply, or a long working text with no ANSWER line.
            _log_path("NO_BARE_ANSWER", ctx, has_expr, "", raw_reply)
            return ExtractedAnswer("", False, "no bare answer line", result.tokens)
        stripped = strip_named_unit(result.answer, ctx.description, ctx.rules, ctx.challenge_type)
        if stripped != result.answer:
            # The question names the unit or label ("in Celsius", "route number"): the number alone.
            result = ExtractedAnswer(stripped, result.valid, result.reason, [stripped])
        missing = _missing_items(result.answer, ctx) if result.valid else ""
        if missing:
            # Never edited: the one repair re-asks; if it fails, this answer is still submitted.
            result = ExtractedAnswer(result.answer, False, missing, result.tokens)
        elif result.valid:
            ordered = _in_clue_order(result.answer, ctx)
            if ordered != result.answer:
                # Same items, in the order the clues give them ("in the order given").
                result = ExtractedAnswer(ordered, True, "", [ordered])
        _log_path("ANSWER", ctx, has_expr, result.answer, raw_reply)
        return result

    text_temperature = 0.0
    # Reasoning models spend most of this budget thinking before they answer;
    # 1024 cut the roster's default model off before it wrote an answer.
    text_max_tokens = 8192

    # Image challenge strategy
    image_strategy_notes = (
        "Prefer image_edit when an input image is available. Keep rationale concise. "
        "Request standard-resolution output only and avoid HD or 4K images."
    )

    def fastest_model(self, models: list[str], challenge_type: str, exclude: str) -> str:
        """The roster model with the lowest measured median latency on this task, or "" if none is measured."""
        best, best_seconds = "", None
        for model in models:
            if model == exclude:
                continue
            _, median, _ = _task_cell(model, challenge_type)
            if median is None:
                continue
            if best_seconds is None or median < best_seconds:
                best, best_seconds = model, median
        return best

    def rank_models(
        self,
        ctx: ChallengeContext,
        available_models: list[str],
    ) -> list[str]:
        """Rank live roster aliases for this challenge; best first, fallbacks after."""
        from model_selector import clean_roster, is_image_family

        available_models = clean_roster(available_models)
        if self.is_image_challenge(ctx):
            preferred = self.prefer_image_models(available_models)
            if preferred:
                return preferred
            return list(available_models)

        text_models = [
            model
            for model in available_models
            if str(model or "").strip()
            and not _matches_any(_alias(model), EXCLUDED_PATTERNS)
            and not is_image_family(model)
            and not _matches_any(_alias(model), NON_CHAT_PATTERNS)
        ]
        self._task = _task_kind(ctx)
        cells = [(model, *_task_cell(model, self._task)) for model in text_models]
        known = [
            (rate * 100 - SPEED_WEIGHT * (latency if latency is not None else UNKNOWN_LATENCY_S), rate)
            for _, rate, latency, _ in cells
            if rate is not None
        ]
        # A name we know nothing about must not outrank the models measured on this task (coordinator, after the
        # 30-model roster picked vendor0/model-0-chat for structured, where every measured rate is below NEUTRAL_RATE).
        # When the best known rate is below NEUTRAL_RATE, an unknown model's score is capped at the best known
        # model's score, and the known model wins the tie. With no known model, or a best known rate at or above
        # NEUTRAL_RATE, unknown models score as before.
        best_rate = max((rate for _, rate in known), default=None)
        cap = max(score for score, _ in known) if best_rate is not None and best_rate < NEUTRAL_RATE else None
        scored = []
        for index, (model, rate, latency, source) in enumerate(cells):
            accuracy = (rate if rate is not None else NEUTRAL_RATE) * 100
            seconds = latency if latency is not None else UNKNOWN_LATENCY_S
            score = accuracy - SPEED_WEIGHT * seconds
            unknown_capped = rate is None and cap is not None
            if unknown_capped:
                score = min(score, cap)
            tie = _heuristic_score(_alias(model))
            scored.append((-score, unknown_capped, -tie, index, model, source, rate, latency))
        scored.sort()
        ranked = [row[4] for row in scored]
        self._reasons = {row[4]: (row[5], row[6], row[7]) for row in scored}
        if scored:
            _, _, _, _, top, source, rate, latency = scored[0]
            rate_text = "n/a" if rate is None else f"{rate:.2f}"
            latency_text = "n/a" if latency is None else f"{latency}s"
            reason = f"source={source} accuracy={rate_text} median={latency_text}"
        else:
            reason = "no text models"
            top = ""
        print(
            f"[route] task={self._task} roster={len(available_models)} text={len(text_models)} "
            f"pick={top or '-'} reason=({reason})",
            file=sys.stderr,
            flush=True,
        )
        return ranked

    def pick_model(
        self,
        stage: str,
        ranked_models: list[str],
        ctx: ChallengeContext,
    ) -> str:
        """Take the top-ranked model; the runtime falls back down the list on retry."""
        _ = stage
        _ = ctx
        self._picked = ranked_models[0] if ranked_models else ""
        return self._picked

    def get_llm_params(self, ctx: ChallengeContext) -> dict[str, Any]:
        """Deterministic solve: temperature 0 and the full output budget.

        A time-linked cap (60 tokens per second) was tried and reverted: on logic
        easy, nemotron-3.5-lightning spent its whole budget thinking and never
        wrote the ANSWER line (Practice runs 8 and 10 scored 70.8 and 14.8).
        """
        if getattr(self, "_task", "") == "logic":
            # Every logic route is capped: a long think on the full 8192 budget
            # ends without an ANSWER line. Gemini Flash also gets low reasoning,
            # which it supports (reasoning none returns HTTP 400).
            params: dict[str, Any] = {"temperature": 0.0, "max_tokens": LOGIC_MAX_TOKENS}
            if _supports_low_effort(getattr(self, "_picked", "")):
                params["reasoning_effort"] = "low"
            return params
        params = {"temperature": 0.0, "max_tokens": NON_LOGIC_MAX_TOKENS}
        if _supports_low_effort(getattr(self, "_picked", "")):
            params["reasoning_effort"] = "low"
        return params

    def llm_params_for_model(self, ctx: ChallengeContext, model: str) -> dict[str, Any]:
        """get_llm_params, plus the low-effort card arm keyed to the model actually called.

        Keyed to ``model``, not the first pick, so a fallback model never inherits a
        reasoning parameter its card does not declare (review on #219).
        """
        params = self.get_llm_params(ctx)
        params.pop("reasoning_effort", None)
        if _supports_low_effort(model):
            params["reasoning_effort"] = "low"
        if (
            getattr(self, "_task", "") != "logic"
            and "reasoning_effort" not in params
            and _card_effort_arm_enabled()
            and _card_supports_reasoning(model)
        ):
            params = {**params, "reasoning_effort": "low"}
        return params

    def should_submit_early(self, answer: str, ctx: ChallengeContext) -> bool:
        """Submit as soon as an answer exists and the clock is nearly out.

        Speed is 15% of the score and a late answer scores as a loss, so once
        an answer is in hand with under 15s left, do not spend more time on it.
        """
        return bool(answer and answer.strip()) and ctx.time_remaining_s < 15.0

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        """Restate the challenge's constraints for the image model.

        The image judge scores accuracy, quality, preservation and compliance,
        so the prompt names each one: follow the instruction, keep what the
        instruction does not change, and add no unrequested text or marks.
        """
        from msquad import image_compact

        if image_compact.enabled():
            # A/B arm (MSQUAD_IMAGE_COMPACT): the request, the enabled arms' rules once, one output line.
            return self._compact_image_prompt(ctx)
        from msquad import image_request

        base = super().build_image_prompt(ctx).strip()
        request = ctx.rules or ""
        if ctx.image_url:
            # Only what the edit does not change is kept: a black-and-white, sunset or season edit changes the
            # colours and lighting, and a removal changes the subject (image_request).
            kept = ["subject", "composition", "framing", "colors and lighting"]
            if image_request.removes_everyone(request):
                # every person goes ("remove all the people"): no person is kept (fresh-request audit)
                kept.remove("subject")
            elif image_request.removes_subject(request):
                # the removed person goes, everyone else stays ("remove the person in the background")
                kept[kept.index("subject")] = "the remaining people"
            if image_request.global_edit(request):
                kept.remove("colors and lighting")
            guard = (
                "Edit the provided source image. Apply exactly the change requested "
                "and keep everything else from the source unchanged: "
                # "subject, composition, framing, colors and lighting" when nothing is dropped (the shipped text)
                + (", ".join(kept) if kept[-1] == "colors and lighting" else ", ".join(kept[:-1]) + " and " + kept[-1])
                + "."
            )
            from msquad import image_edit_preserve

            if image_edit_preserve.enabled():
                # A/B arm (MSQUAD_EDIT_PRESERVE): the edit framed as local, with the drift axes named.
                guard = image_edit_preserve.guard_for(request)
        else:
            # The no-text rule leads the generate prompt: the live output still had kanji and
            # lettering on signs (constraints 50) when the rule came last.
            guard = (
                "Generate exactly one image that fulfils the request below. Absolutely no text "
                "anywhere in the image unless the request itself asks for specific text: no "
                "lettering, no kanji, no signage words, no logos, no numbers. Compose the scene "
                "without signs, billboards, labels, captions, screens or writing; if one is "
                "essential, leave it blank."
            )
            if image_request.asks_for_text(request):
                # The request wants a logo, label, sign or headline: the blank-sign rule would forbid it.
                guard = (
                    "Generate exactly one image that fulfils the request below. Render the text the request "
                    "asks for exactly as written and clearly legible; add no other text, lettering or "
                    "captions anywhere in the image."
                )
            from msquad import image_positive_render

            if image_positive_render.enabled():
                # A/B arm (MSQUAD_GENERATE_POSITIVE_RENDER): a positive instruction for text-free requests.
                guard = image_positive_render.guard_for(ctx.rules or "") or guard
            from msquad import image_text_traps

            if image_text_traps.enabled():
                # A/B arm (MSQUAD_GENERATE_TEXT_TRAPS): name the trap surfaces for a banned lettering-prone object.
                trap = image_text_traps.sentence_for(
                    ctx.rules or "", ctx.rules or "", positive_render=image_positive_render.enabled()
                )
                if trap:
                    guard = f"{guard} {trap}"
        if ctx.image_url:
            from msquad import image_edit_keep

            if image_edit_keep.enabled():
                # A/B arm (MSQUAD_EDIT_KEEPLIST): the notes' "keep ..." items as a list.
                listed = _first_rule(lambda i: image_edit_keep.keep_list(i, ctx.rules or ""), ctx)
                if listed:
                    base = f"{base}\n\n{listed}"
            from msquad import image_no_occlude

            if image_no_occlude.enabled():
                # A/B arm (MSQUAD_EDIT_NO_OCCLUDE): an item added to a person must not cover the face.
                rule = _first_rule(image_no_occlude.rule_for, ctx)
                if rule:
                    base = f"{base}\n\n{rule}"
            from msquad import image_eyes_clear

            if image_eyes_clear.enabled():
                # A/B arm (MSQUAD_EDIT_EYES_CLEAR): headwear above the brows, eyes visible through eyewear.
                rule = _first_rule(image_eyes_clear.rule_for, ctx)
                if rule:
                    base = f"{base}\n\n{rule}"
            from msquad import image_edit_added_material

            if image_edit_added_material.enabled():
                # A/B arm (MSQUAD_EDIT_ADDED_MATERIAL): an added coloured object in its own material and colour.
                rule = _first_rule(image_edit_added_material.rule_for, ctx)
                if rule:
                    base = f"{base}\n\n{rule}"
        if not ctx.image_url and image_constraints.enabled():
            # A/B arm (MSQUAD_GENERATE_CHECKLIST): counts, colour limits and negatives as a checklist.
            listed = _first_rule(image_constraints.checklist, ctx, whole=True)
            if listed:
                base = f"{base}\n\n{listed}"
        if not ctx.image_url:
            from msquad import image_no_signage

            if image_no_signage.enabled():
                # A/B arm (MSQUAD_GENERATE_NO_SIGNAGE): how to draw light sources without glyphs.
                rule = _first_rule(image_no_signage.rule_for, ctx, whole=True)
                if rule:
                    base = f"{base}\n\n{rule}"
            from msquad import image_defocus

            if image_defocus.enabled():
                # A/B arm (MSQUAD_GENERATE_DEFOCUS): background as bokeh so stray glyphs are not legible.
                rule = _first_rule(image_defocus.rule_for, ctx, whole=True)
                if rule:
                    base = f"{base}\n\n{rule}"
            from msquad import image_sole_subject

            if image_sole_subject.enabled():
                # A/B arm (MSQUAD_GENERATE_SOLE_SUBJECT): a named vehicle unoccupied, no unrequested rider.
                rule = _first_rule(image_sole_subject.rule_for, ctx, whole=True)
                if rule:
                    base = f"{base}\n\n{rule}"
        constraints = (
            "Hard constraints: follow every explicit requirement in the instruction; "
            "add no text, captions, watermarks, logos or borders unless the instruction "
            "asks for them; output a single image; keep the result clean and free of "
            "artifacts."
        )
        prompt = f"{guard}\n\n{base}\n\n{constraints}"
        if ctx.image_url:
            from msquad import image_edit_change_first

            if image_edit_change_first.enabled():
                # A/B arm (MSQUAD_EDIT_CHANGE_FIRST, astra IM3): the same blocks, the request moved to the front.
                prompt = image_edit_change_first.reorder(prompt, ctx.rules or "")
        return prompt

    def _compact_image_prompt(self, ctx: ChallengeContext) -> str:
        """MSQUAD_IMAGE_COMPACT: the request verbatim, each enabled arm's rule once, and one output line."""
        from msquad import image_compact

        request = (ctx.rules or "").strip() or (ctx.challenge_text or ctx.description or "").strip()
        rules: list[str] = []
        if ctx.image_url:
            from msquad import image_edit_keep, image_eyes_clear, image_no_occlude

            if image_edit_keep.enabled():
                rules.append(_first_rule(lambda i: image_edit_keep.keep_list(i, ctx.rules or ""), ctx))
            if image_no_occlude.enabled():
                rules.append(_first_rule(image_no_occlude.rule_for, ctx))
            if image_eyes_clear.enabled():
                rules.append(_first_rule(image_eyes_clear.rule_for, ctx))
            from msquad import image_edit_added_material

            if image_edit_added_material.enabled():
                rules.append(_first_rule(image_edit_added_material.rule_for, ctx))
        else:
            from msquad import image_constraints, image_defocus, image_no_signage, image_sole_subject

            if image_constraints.enabled():
                rules.append(_first_rule(image_constraints.checklist, ctx, whole=True))
            if image_no_signage.enabled():
                rules.append(_first_rule(image_no_signage.rule_for, ctx, whole=True))
            if image_defocus.enabled():
                rules.append(_first_rule(image_defocus.rule_for, ctx, whole=True))
            if image_sole_subject.enabled():
                rules.append(_first_rule(image_sole_subject.rule_for, ctx, whole=True))
        if ctx.image_url:
            lead = (
                "Edit the provided source image: change only what the request requires and keep everything else the "
                "same, except where the request itself changes it."
            )
        else:
            from msquad import image_positive_render

            lead = "Generate one image."
            if image_positive_render.enabled():
                # A/B arm (MSQUAD_GENERATE_POSITIVE_RENDER): its guard leads when it applies to the request.
                lead = image_positive_render.guard_for(ctx.rules or "") or lead
        parts = [lead, request]
        for rule in rules:
            if rule and rule not in parts:
                parts.append(rule)
        parts.append(image_compact.OUTPUT_LINE)
        return "\n\n".join(parts)
