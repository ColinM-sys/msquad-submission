#!/usr/bin/env python3
"""Simple Agent Gauntlet competitor agent.

This is a minimal example showing how to connect to Agent Gauntlet from any Python code.
It uses:
- HTTP client for Agent Gauntlet coordination (REST API)
- MCP client for challenge tools
- OpenAI SDK for LLM calls via the proxy

Usage:
    cd examples/python_simple
    python agent.py

This example loads `.env` from the repository root automatically.
"""

import asyncio
import concurrent.futures
import contextlib
from collections.abc import Callable
import importlib.util
import threading
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

from dotenv import load_dotenv

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path: 
    sys.path.insert(0, str(REPO_ROOT))

load_dotenv(REPO_ROOT / ".env")

from arena_clients.config import agent_id_problem
from arena_clients import (
    build_image_tool_arguments,
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.display import (
    ReasoningTicker,
    challenge_record,
    print_challenge,
    save_run_record,
    summary_lines,
)
from arena_clients.outputs import (
    bounded,
    image_facts,
    missing_tools_note,
    save_submitted_image,
    submission_summary_lines,
)
from arena_clients.required_tools import missing_required_tools, required_tool_names
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from base_strategy import (
    ChallengeContext,
    choose_final_answer,
    salvage_final_answer,
    is_logic_refusal,
    logic_answer_before_reasoning,
    collapse_single_value,
    ensure_tool_coverage,
    extract_final_answer,
    format_asks_for_unit,
    is_json_answer_shape,
    natural_order,
    normalize_entity_answer,
    repair_prompt,
)
from model_selector import (
    ModelSelectionError,
    fetch_available_models,
    require_explicit_model,
)
from my_strategy import MyStrategy
from msquad import answer_format_rules
from msquad import cut_stream_salvage
from msquad import answer_normalise, finalize_clock, image_composite
from msquad import early_challenge, evidence_window, keep_evidence_answer, modality_overlap, order_from_rules, parallel_doc_reads, resilience, submit_before_close, tool_trace
from msquad import modality_warm
from msquad.budget import SUBMIT_MARGIN_S, Budget, call_with_one_retry, fallback_answer
from msquad.image_text_check import recheck_for_text
from msquad.image_rationale import rationale_for as image_rationale_for
from msquad.clue_fetch import read_clues
from msquad.image_models import image_tool_model, prefer_live_default
from msquad.stage_timer import StageTimer
from msquad.shape_check import resolve_shape_answer
from msquad.clock import ClockReader
from msquad import grounding
from msquad.big_logic import solve_big_choice
from msquad.knights_solver import solve_knights
from msquad.sequence_solver import solve_sequence
from msquad.numeric_solver import solve_numeric
from msquad.zebra_solver import solve_zebra
from msquad.logic_solver import solve_first_mention, solve_logic_from_challenge
from msquad.model_fallback import solve_with_model_fallback
from msquad.code_eval import run_code_challenge
from msquad.presolve import presolve_challenge
from msquad import first_token_watchdog, layered_decode
from msquad.entities import (
    RESOLVE_MIN_REMAINING_S,
    entities_from_challenge,
    entity_note,
    is_placeholder,
    accepts_literal_empty,
    needs_resolve,
    outside_names,
)
from msquad.verify import (
    pick_verifier_model,
    should_verify,
    verify_and_maybe_resolve,
    verify_enabled,
)

# Use OpenAI SDK for LLM calls through the proxy. Not imported at module load: the import
# costs ~0.7 s, so main() runs it in a worker thread that overlaps register and the MCP connect.
HAS_OPENAI = importlib.util.find_spec("openai") is not None


def _openai_class():
    """The OpenAI client class. A seam: tests patch this instead of the import."""
    from openai import OpenAI

    return OpenAI


def _warm_submit(fn, *args) -> concurrent.futures.Future:
    """Run ``fn(*args)`` on a daemon thread and return its Future.

    Not a ThreadPoolExecutor: Python joins pool workers at exit, so a warm-up still
    running when main() returns would hold the process open. A daemon thread never does.
    """
    future: concurrent.futures.Future = concurrent.futures.Future()

    def _run() -> None:
        if not future.set_running_or_notify_cancel():
            return
        try:
            future.set_result(fn(*args))
        except BaseException as exc:  # handed to whoever awaits the future
            future.set_exception(exc)

    threading.Thread(target=_run, name="llm-warm", daemon=True).start()
    return future


# Background thought/draft posts in flight at once; more are dropped (they are telemetry).
MAX_BACKGROUND_POSTS = 8
_BACKGROUND_POSTS = {"in_flight": 0}
_BACKGROUND_LOCK = threading.Lock()


def _post_in_background(fn, *args) -> bool:
    """Send a thought or draft on a daemon thread and do not wait for it. False if dropped.

    These REST calls never raise (#188) but each can block for the client's 30 s timeout. Made
    in line, a slow thought endpoint pushed a 60 s challenge's submit to 128 s (text hang audit).
    A thought counts only once its POST returns True (track_thoughts), so one still in flight
    never satisfies ensure_thought, which sends its own, bounded, before the submit. At most
    MAX_BACKGROUND_POSTS threads are in flight, so a slow endpoint cannot pile up threads.
    """
    with _BACKGROUND_LOCK:
        if _BACKGROUND_POSTS["in_flight"] >= MAX_BACKGROUND_POSTS:
            return False
        _BACKGROUND_POSTS["in_flight"] += 1

    def done(_future) -> None:
        with _BACKGROUND_LOCK:
            _BACKGROUND_POSTS["in_flight"] -= 1

    _warm_submit(fn, *args).add_done_callback(done)
    return True


def _in_daemon(fn, *args) -> "asyncio.Future":
    """Await ``fn(*args)`` from a daemon thread: asyncio.to_thread's executor is waited for at exit.

    asyncio.run shuts the default executor down with a join, so a hung HTTP call (the model
    list, a thought, the input fetch, a usage read) held the finished run open for its whole
    timeout after the submit (gym image-hang-* faults).
    """
    return asyncio.wrap_future(_warm_submit(fn, *args))


BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)


MIN_IMAGE_SIDE_PX = 16


def _png_side_lengths(uri: str) -> tuple[int, int] | None:
    """(width, height) from a PNG data URI's IHDR chunk, or None when it is not a PNG."""
    import base64
    import struct

    prefix = "data:image/png;base64,"
    if not uri.startswith(prefix):
        return None
    try:
        head = base64.b64decode(uri[len(prefix):len(prefix) + 64] + "===")
    except ValueError:
        return None
    if len(head) < 24 or head[12:16] != b"IHDR":
        return None
    return struct.unpack(">II", head[16:24])


# Below this much time left, the resize is skipped: the submit must not wait on it.
RESIZE_MIN_BUDGET_S = 15.0
# Total time allowed for the input fetch (applies to connect, read and write together).
RESIZE_FETCH_TIMEOUT_S = 3.0


def _fetch_input_bytes(uri: str) -> bytes:
    import httpx

    response = httpx.get(uri, timeout=httpx.Timeout(RESIZE_FETCH_TIMEOUT_S), follow_redirects=True)
    response.raise_for_status()
    return response.content


def start_input_prefetch(uri: str) -> "asyncio.Task | None":
    """Start fetching an edit's input image now, so the resize after the edit does not wait for it.

    The fetch (250-500 ms to the challenge image host) used to start only after the edit came
    back, in series before the submit. Returns None for a data URI or no URI. The task never
    raises: a failed fetch resolves to None and the resize falls back to its own fetch.
    """
    if not uri or not uri.startswith(("http://", "https://")):
        return None

    async def fetch() -> bytes | None:
        try:
            return await _in_daemon(_fetch_input_bytes, uri)
        except Exception:
            return None

    return asyncio.ensure_future(fetch())


async def _match_input_size(output_uri: str, input_uri: str, budget, prefetched=None, instruction: str = "") -> str:
    """Resize an edited image to the input's exact width and height, if they differ.

    Returns the output unchanged when there is less than RESIZE_MIN_BUDGET_S left, when the
    sizes already match, or when either image cannot be read (no Pillow, an unreachable input
    URL after RESIZE_FETCH_TIMEOUT_S, not an image). No crop: the aspect ratio is kept by the
    input's own size, so a mismatch is only a resampling step.
    """
    if budget is None or budget.remaining() < RESIZE_MIN_BUDGET_S:
        return output_uri
    try:
        import base64
        import io

        import httpx  # noqa: F401  (the fetch needs it; without it the resize is skipped)
        from PIL import Image
    except ImportError:
        return output_uri

    async def load(uri: str, early=None) -> "Image.Image":
        # One RESIZE_FETCH_TIMEOUT_S deadline for the input, shared by the prefetch wait and any
        # fresh fetch: a slow host never holds the submit longer than without the prefetch.
        deadline = time.monotonic() + RESIZE_FETCH_TIMEOUT_S
        raw = None
        if early is not None:
            # A timeout here raises (output kept, no re-fetch); a prefetch that failed fast
            # (resolved to None) falls back to a fresh fetch in what is left of the deadline.
            raw = await asyncio.wait_for(asyncio.shield(early), timeout=RESIZE_FETCH_TIMEOUT_S)
        if raw is not None:
            pass
        elif uri.startswith("data:image/"):
            raw = base64.b64decode(uri.split(",", 1)[1])
        else:
            # The fetch runs in a worker thread with its own cap, so a slow host cannot hold the submit.
            left = deadline - time.monotonic()
            if left <= 0:
                raise TimeoutError("input fetch deadline passed")
            raw = await asyncio.wait_for(_in_daemon(_fetch_input_bytes, uri), timeout=left)
        return Image.open(io.BytesIO(raw)).convert("RGB")

    try:
        source = await load(input_uri, prefetched)
        edited = await load(output_uri)
    except Exception:
        return output_uri
    if image_composite.enabled():
        # Arm: the source's own pixels outside the region the edit changed (resizes too).
        result, note = image_composite.composite(source, edited, instruction)
        print(f"   Edit composite: {note}")
    elif edited.size == source.size:
        return output_uri
    else:
        result = edited.resize(source.size, Image.LANCZOS)
    buffer = io.BytesIO()
    result.save(buffer, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode("ascii")


def judge_reason_of(score: dict) -> str | None:
    """The judge's reason text from a score payload, if it has one."""
    judge = score.get("judge")
    return judge.get("reason") if isinstance(judge, dict) else None


_IMAGE_MAGIC = (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff", b"GIF87a", b"GIF89a")


def _decodes_as_image(uri: str) -> bool:
    """True when ``uri`` is an image data URI whose bytes are a real (verifiable) image."""
    import base64
    import io

    if not uri.startswith("data:image/") or ";base64," not in uri:
        return False
    try:
        raw = base64.b64decode(uri.split(",", 1)[1], validate=False)
    except ValueError:
        return False
    is_webp = raw[:4] == b"RIFF" and raw[8:12] == b"WEBP"
    if len(raw) < 64 or not (raw.startswith(_IMAGE_MAGIC) or is_webp):
        return False
    try:
        from PIL import Image
    except ImportError:  # header check only
        return True
    try:
        Image.open(io.BytesIO(raw)).verify()
    except Exception:
        return False
    return True


def _usable_image_uri(result: dict) -> str:
    """The generated image, or "" when the result is blank, tiny or a failure."""
    uri = str(result.get("image_uri") or "").strip()
    if not uri or uri == BLANK_PNG_DATA_URI:
        return ""
    if uri.startswith(("https://", "http://")):
        return uri
    if not _decodes_as_image(uri):
        return ""  # empty, corrupt or not an image: let the retry or next model try
    sides = _png_side_lengths(uri)
    if sides is not None and min(sides) < MIN_IMAGE_SIDE_PX:
        return ""  # a 1x1 PNG is a valid file, not a picture
    return uri


def _failure_reason(result: dict) -> str:
    """Short reason for the log: a 402/403/429 model failure, or a blank result."""
    text = str(result.get("error") or "")
    match = re.search(r"\b(402|403|429)\b", text)
    return f"HTTP {match.group(1)}" if match else "blank result"


def _plan_image_tool_sequence(
    strategy: MyStrategy,
    ctx: ChallengeContext,
    available_tools: list[str],
) -> list[str]:
    """Expand an analysis-first choice into a usable image-output plan."""
    selected_tool = strategy.plan_image_tool(ctx, available_tools)
    if not selected_tool:
        return []
    sequence = [selected_tool]
    if selected_tool != "image_analyze":
        return sequence
    if ctx.image_url and "image_edit" in available_tools:
        sequence.append("image_edit")
    elif "image_generate" in available_tools:
        sequence.append("image_generate")
    return sequence

# Pre-LLM calls (usage scope, model list, thought) run before the solve budget's
# guard. Each gets a short bound so a stalled proxy cannot eat the answer time.
PRE_STAGE_TIMEOUT_S = 5.0
MODEL_LIST_TIMEOUT_S = 15.0
# The image path waits at most this long for /models. Live latency (upper bound from the text
# path's clue stage, 107 runs): p50 0.9 s, p95 1.05 s, p99 1.84 s, max 4.1 s. On a timeout the
# model cards stand in, led by the live default image model, so a cut-short fetch costs nothing.
IMAGE_MODEL_LIST_TIMEOUT_S = 3.0
# Text path: MCP reads that never answer must not lose the run (live clue reads take ~0.9 s).
TEXT_CLUES_TIMEOUT_S = 15.0
TEXT_COVERAGE_TIMEOUT_S = 5.0
# Time kept after the clue read to solve and submit, on top of the submit margin.
TEXT_SOLVE_RESERVE_S = 20.0


async def _bounded(awaitable, timeout_s: float, default, label: str):
    """Await ``awaitable`` for at most ``timeout_s``; on a timeout or error, cancel it and return ``default``.

    asyncio.wait, not wait_for: wait_for waits for a cancelled call to unwind, and a transport
    slow to cancel would hold the run anyway.
    """
    task = asyncio.ensure_future(awaitable)
    done, _ = await asyncio.wait({task}, timeout=max(0.0, timeout_s))
    if not done:
        task.cancel()
        task.add_done_callback(lambda t: t.cancelled() or t.exception())
        print(f"   ⚠️  {label} did not answer in {timeout_s:.1f}s; continuing without it")
        return default
    try:
        return task.result()
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        print(f"   ⚠️  {label} failed ({exc!r}); continuing without it")
        return default
# An MCP image submit normally answers in ~2 s. If the transport hangs at submit time, nothing is
# submitted and the run is lost when the harness kills it, so the MCP submit is bounded (this cap,
# and never past the guard minus the time a REST submit needs) and then retried over REST.
IMAGE_SUBMIT_MCP_TIMEOUT_S = 8.0  # live MCP submits take ~2 s; a stacked dead-transport case was 28.5 s at 20 s
IMAGE_SUBMIT_REST_RESERVE_S = 8.0
# Floor: a healthy MCP submit is the fast path even with almost no time left; a late REST submit
# still lands, a missing one scores nothing.
IMAGE_SUBMIT_MCP_MIN_S = 2.0


def _settle(future: asyncio.Future, result, error) -> None:
    if not future.done():
        future.set_result((result, error))


async def _pre_stage(label: str, fn, default, timeout_s: float = PRE_STAGE_TIMEOUT_S):
    """Run a blocking call on a daemon thread, wait at most timeout_s, else return default.

    A daemon thread (not the default executor) so a stuck call cannot hold up exit.
    """
    loop = asyncio.get_running_loop()
    future: asyncio.Future = loop.create_future()

    def run() -> None:
        try:
            outcome = (fn(), None)
        except Exception as exc:
            outcome = (None, exc)
        try:
            loop.call_soon_threadsafe(_settle, future, *outcome)
        except RuntimeError:  # the stage timed out and the run's loop has closed: drop the late result
            pass

    threading.Thread(target=run, daemon=True).start()
    try:
        result, error = await asyncio.wait_for(future, timeout=timeout_s)
    except asyncio.TimeoutError:
        print(f"   ⚠️  {label} timed out after {timeout_s:.0f}s; continuing.")
        return default
    if error is not None:
        print(f"   ⚠️  {label} failed ({error}); continuing.")
        return default
    return result


def _fallback_models() -> list[str]:
    """Every model in msquad/model_cards.json (image ones included), for when the live list is unavailable."""
    import json

    try:
        cards = json.loads((REPO_ROOT / "msquad" / "model_cards.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    # Card order would put gemini-3-pro-image first; the live default image model goes first instead.
    return prefer_live_default(list(cards.get("models", {})))


def _fallback_text_models() -> list[str]:
    """Text models from msquad/model_cards.json, used when the live list is unavailable."""
    import json

    try:
        cards = json.loads((REPO_ROOT / "msquad" / "model_cards.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return [name for name in cards.get("models", {}) if "image" not in name]


def extract_answer(raw_response: str) -> str:
    """Extract the answer line from the LLM response."""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", raw_response, flags=re.DOTALL).strip()

    # Accept either "ANSWER:" or "Final answer:" on its own line.
    for line in cleaned.splitlines():
        match = re.match(
            r"^\s*(?:answer|final answer)\s*:\s*(.+?)\s*$",
            line,
            flags=re.IGNORECASE,
        )
        if match:
            answer = match.group(1).strip().strip("`\"'")
            if answer:
                return answer

    return ""


def _challenge_text_blob(
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
) -> str:
    return " ".join(
        [challenge_type or "", description or "", rules or "", extra_context or ""]
    ).lower()


_DOC_CUE_RE = re.compile(
    r"\b(documents?|docs?|records?|corpus|archives?|memos?|rosters?|directory|catalogue?|database)\b"
)


def _required_runtime_tools(
    available_tool_names: list[str],
    *,
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
    server_required: list[str] | None = None,
) -> list[str]:
    blob = _challenge_text_blob(challenge_type, description, rules, extra_context)
    from msquad import skip_prohibited_tools

    skip_prohibited = skip_prohibited_tools.enabled()
    required: list[str] = []
    for tool_name in available_tool_names:
        normalized = str(tool_name or "").strip()
        if not normalized:
            continue
        if normalized.lower() in blob and not (skip_prohibited and skip_prohibited_tools.prohibited(normalized, blob)):
            required.append(normalized)
    if challenge_type.strip().lower() in {"web-search", "market-research"}:
        for tool_name in available_tool_names:
            normalized = str(tool_name or "").strip()
            if "search" in normalized.lower() and normalized not in required:
                required.append(normalized)
    # A question that asks about documents, records or a corpus must search them, even when
    # it never names the tool and the server did not list it as required.
    if challenge_type.strip().lower() == "retrieval" or _DOC_CUE_RE.search(blob):
        for tool_name in available_tool_names:
            normalized = str(tool_name or "").strip()
            if normalized.lower().startswith("docs.") and normalized not in required and not (
                skip_prohibited and skip_prohibited_tools.prohibited(normalized, blob)
            ):
                required.append(normalized)
    # The server's own required_tools list is authoritative: a missed one zeroes quality.
    available = {str(name or "").strip() for name in available_tool_names}
    from msquad import call_unlisted_required

    for tool_name in required_tool_names(server_required):
        if tool_name in available and tool_name not in required:
            required.append(tool_name)
        elif call_unlisted_required.enabled() and tool_name not in available and tool_name not in required:
            # A/B arm (MSQUAD_CALL_UNLISTED_REQUIRED): the server requires it though tools/list omits it.
            required.append(tool_name)
    return required


def _fallback_with_evidence(challenge, clues: list[str], rules: str, evidence_lines: list[str] | None) -> str:
    """The last-resort answer: from the tool evidence when the arm finds one there, else fallback_answer."""
    return _evidence_fallback(challenge, list(evidence_lines or [])) or fallback_answer(
        challenge.challenge_type, clues, challenge.description, rules
    )


def _cut_stream_answer(answer: str, raw_response: str, challenge) -> str:
    """MSQUAD_CUT_STREAM_SALVAGE: after a deadline cut with no answer text, a JSON-shaped answer is the last valid JSON
    in the reasoning, else an empty value of the described shape; never the reasoning prose. Otherwise unchanged."""
    if not cut_stream_salvage.consume():
        return answer
    kind, rules = str(challenge.challenge_type or ""), str(challenge.rules or "")
    if not is_json_answer_shape(kind, rules, str(challenge.description or "")):
        return answer
    shape_text = f"{getattr(challenge, 'answer_format', '') or ''}\n{rules}"
    if cut_stream_salvage.is_valid_json(answer, shape_text):
        return answer  # the normal path (or the shape re-ask) already produced a valid JSON answer
    salvaged = cut_stream_salvage.salvage(raw_response, shape_text)
    print(f"   ⏱  Stream cut before any answer; JSON salvage: {salvaged[:80]!r}")
    return salvaged


def _last_resort_answer(raw_response: str, challenge, clues: list[str], solve_ctx, strategy,
                        evidence_lines: list[str] | None) -> str:
    """No valid ANSWER: normalize the reply's last line, else the evidence or clue fallback."""
    lines = raw_response.strip().splitlines()
    last_line = lines[-1].strip().strip("`\"'") if lines else ""
    if is_logic_refusal(last_line, str(challenge.challenge_type or "")):
        last_line = ""
    # Same normalizer as the main path, so spaces and prose never reach submit.
    fallback = strategy.finalize_answer(last_line, solve_ctx)
    if fallback.answer and not _is_invalid_answer_candidate(fallback.answer) and fallback.reason != "reasoning, not a short answer":
        return fallback.answer
    return _fallback_with_evidence(challenge, clues, getattr(challenge, "rules", ""), evidence_lines)


def _evidence_fallback(challenge, evidence_lines: list[str]) -> str:
    """A/B arm (MSQUAD_EVIDENCE_FALLBACK): with no usable reply, answer from the tool evidence, not the question."""
    from msquad import evidence_fallback

    kind = str(getattr(challenge, "challenge_type", "") or "").lower()
    if not evidence_fallback.enabled() or "image" in kind or "json" in str(getattr(challenge, "rules", "") or "").lower():
        return ""
    return evidence_fallback.answer_from_evidence(str(getattr(challenge, "description", "") or ""), evidence_lines,
                                                  str(getattr(challenge, "rules", "") or ""))


def _best_search_query(description: str, rules: str, clues: list[str] | None) -> str:
    text = (description or "").strip()
    if text:
        return text
    if clues:
        for clue in clues:
            if isinstance(clue, str) and clue.strip():
                return clue.strip()
    return (rules or "").strip()


def _query_candidates(
    description: str,
    rules: str,
    clues: list[str] | None,
    extra_context: str = "",
) -> list[str]:
    candidates: list[str] = []
    primary = _best_search_query(description, rules, clues)
    if primary:
        candidates.append(primary)
    for clue in clues or []:
        if isinstance(clue, str) and clue.strip():
            candidates.append(clue.strip())
    if isinstance(rules, str) and rules.strip():
        split_parts = re.split(r"[.;\n]+", rules)
        for part in split_parts:
            part = part.strip()
            if 8 <= len(part) <= 220:
                candidates.append(part)
    for text in [description, rules, extra_context, *(clues or [])]:
        if not isinstance(text, str):
            continue
        for url in re.findall(r"https?://[^\s)>\"]+", text):
            cleaned = url.strip().rstrip(".,);")
            if cleaned:
                candidates.append(cleaned)
    deduped: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped[:5]


# _tool_result_text: a non-content string field longer than this keeps its head and a short note.
OVERSIZED_FIELD_CHARS = 4000
OVERSIZED_FIELD_KEEP = 1500
CONTENT_KEYS = frozenset({"text", "content", "body", "snippet", "description"})


async def _follow_search_pages(
    mcp_client: McpArenaClient,
    tool_name: str,
    payload: dict,
    rendered: str,
    stage_left: Callable[[], float],
    budget: Budget | None,
) -> list[str]:
    """Ids from the extra pages of a search reply (MSQUAD_SEARCH_PAGINATION): at most two, no repeated cursor."""
    from msquad import search_pagination

    ids: list[str] = []
    seen: set[str] = set()
    text = rendered
    for _ in range(search_pagination.MAX_EXTRA_PAGES):
        cursor = search_pagination.next_cursor(text)
        if not cursor or cursor in seen or stage_left() <= 0:
            break
        seen.add(cursor)
        result = await asyncio.wait_for(
            mcp_client.call_tool(tool_name, {**payload, "cursor": cursor}),
            timeout=_call_timeout(stage_left(), budget),
        )
        text = _tool_result_text(result)
        ids.extend(re.findall(r'"id"\s*:\s*"([^"]+)"', text))
    return ids


def _tool_result_text(result: object) -> str:
    if result is None:
        return ""
    if isinstance(result, str):
        return result.strip()
    if isinstance(result, (int, float, bool)):
        return str(result)
    if isinstance(result, list):
        parts = [_tool_result_text(item) for item in result]
        return "\n".join(part for part in parts if part).strip()
    if isinstance(result, dict):
        cleaned: dict[str, object] = {}
        for key, value in result.items():
            key_lower = str(key).lower()
            if "image" in key_lower and isinstance(value, str) and len(value) > 256:
                continue
            # An oversized string that is not a known content key keeps its first OVERSIZED_FIELD_KEEP
            # chars plus a note: a document under an unknown key ("passage", "page") still reads, and a
            # megabyte padding field no longer fills the line (gym huge-fields: 81% junk, #327).
            if (isinstance(value, str) and len(value) > OVERSIZED_FIELD_CHARS
                    and key_lower not in CONTENT_KEYS):
                cleaned[str(key)] = (f"{evidence_window.clip(value, OVERSIZED_FIELD_KEEP)} "
                                     f"[{len(value) - OVERSIZED_FIELD_KEEP} more chars omitted: {key}]")
                continue
            cleaned[str(key)] = value
        try:
            return json.dumps(cleaned, ensure_ascii=False)
        except Exception:
            return str(cleaned)
    return str(result)


def _is_invalid_answer_candidate(value: str) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    lowered = text.lower()
    if lowered.startswith(("<toolcall", "toolcall", "<think", "reasoning:", "analysis:", "action:")):
        return True
    # A truncated reply such as "{" or "[" has no letters or digits: never submit it.
    if not any(ch.isalnum() for ch in text):
        return True
    blocked_tokens = ("<toolcall", "</toolcall", '"tool_calls"', "function_call")
    if any(token in lowered for token in blocked_tokens):
        return True
    return False


def _derive_answer_from_evidence(
    *,
    llm_client,
    model_name: str,
    challenge_description: str,
    challenge_rules: str,
    evidence_lines: list[str],
    max_tokens: int = 8192,
) -> str:
    if not evidence_lines:
        return ""
    evidence_block = "\n".join(f"- {line}" for line in evidence_lines if line.strip())
    if not evidence_block:
        return ""
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Use the provided tool evidence to answer the challenge. "
                        "Return only one final answer line that follows the challenge rules."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Question: {challenge_description}\n"
                        f"Rules: {challenge_rules}\n\n"
                        f"Tool evidence:\n{evidence_block}\n\n"
                        "Return only the final answer line."
                    ),
                },
            ],
            max_tokens=max_tokens,
            temperature=0.0,
        )
    except Exception:
        return ""
    raw = (response.choices[0].message.content or "").strip()
    answer = extract_answer(raw)
    if answer:
        return answer
    first_line = raw.splitlines()[0].strip().strip("`\"'") if raw.strip() else ""
    return "" if _is_invalid_answer_candidate(first_line) else first_line


def _call_timeout(stage_left: float, budget: Budget | None) -> float:
    """Per-call timeout inside the tool stage; the stage cap is already in stage_left."""
    if budget is None:
        return max(0.1, min(stage_left, 6.0))
    return max(0.1, budget.tool_call_timeout(stage_left))


# Discourse openers that are capitalised only because they start a sentence. Articles and possessives
# ("The Hague", "Her Majesty Theatre") are names' parts, so they are never stripped.
_SENTENCE_STARTERS = frozenset({
    "However", "Since", "After", "Before", "Each", "Every", "Today", "Yesterday", "Tomorrow", "According",
    "Also", "Then", "Later", "Earlier", "Meanwhile", "Finally", "Still", "Once", "During", "Because",
    "Although", "Thus", "Therefore", "Instead",
})
_PHRASE_RE = re.compile(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b")
_NUMBER_WITH_WORD_RE = re.compile(r"^(-?\d[\d,]*(?:\.\d+)?)\s+[A-Za-z][A-Za-z ]*\.?$")


def _normalize_answer_shape(answer: str, answer_format: str) -> str:
    """A bare-number format keeps only the number: "255 units" -> "255".

    Not when the format asks for the unit ("number with unit, e.g. 4.2 m"): the same guard as strip_named_unit
    (#443), else the unit it kept is cut here (fresh-mix fm_ret_units).
    """
    text = str(answer or "").strip()
    if not str(answer_format or "").strip().lower().startswith(("integer", "number")):
        return text
    if format_asks_for_unit(answer_format):
        return text
    match = _NUMBER_WITH_WORD_RE.match(text)
    return match.group(1) if match else text


_SECOND_ENTITY_RE = re.compile(
    r"\b(person|one|team|lead|owner|author|carrier|supplier|company|project|office|member)\s+(who|that|which|whose)\b"
    r"|\bwhose\b|\bled by\b|\bowned by\b|\bwritten by\b|\b(lead|owner|author) of the\b"
    r"|\bthat (shipped|wrote|leads|led|owns|runs|delivered|maintains)\b"
    r"|\b(the|that|this)\s+\w+\s+(that|who|which|whose)\s+\w+\b",
    re.IGNORECASE,
)


def _needs_second_entity(question: str) -> bool:
    """True when the question names a person or thing through another ("the lead of", "the carrier that")."""
    return bool(_SECOND_ENTITY_RE.search(str(question or "")))


def _hop_phrases(question: str, evidence_lines: list[str], limit: int = 4) -> list[str]:
    """Two-or-more-word capitalised names from fetched documents the question did not already name, most frequent first."""
    from msquad import hop_single_word

    single_word = hop_single_word.enabled()
    lowered_question = str(question or "").lower()
    counts: dict[str, int] = {}
    singles: dict[str, int] = {}
    single_unordered: set[str] = set()
    for line in evidence_lines:
        line = str(line)
        for match in _PHRASE_RE.finditer(line):
            phrase = match.group(0)
            words = phrase.split()
            if len(words) == 1 and single_word:
                # A/B arm (MSQUAD_HOP_SINGLE_WORD): a single name counts once two-plus occurrences show it.
                if hop_single_word.eligible(phrase) and phrase.lower() not in lowered_question:
                    singles[phrase] = singles.get(phrase, 0) + 1
                    if not hop_single_word.is_sentence_initial(line, match.start()):
                        single_unordered.add(phrase)
                continue
            if len(words) > 2 and words[0] in _SENTENCE_STARTERS:
                # "However Ada Lovelace" is a sentence starter plus a name: as a query the starter matches every
                # "however" document. A starter left with fewer than two words keeps the phrase as it was.
                words = words[1:]
                phrase = " ".join(words)
            if len(words) < 2 or phrase.lower() in lowered_question or any(len(word) <= 2 for word in words):
                continue
            counts[phrase] = counts.get(phrase, 0) + 1
    for word in single_unordered:
        if singles[word] >= 2:
            counts[word] = singles[word]
    return [phrase for phrase, _ in sorted(counts.items(), key=lambda pair: (-pair[1], pair[0]))][:limit]


async def _second_hop_evidence(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    available_tool_names: list[str],
    question: str,
    evidence_lines: list[str],
    budget: Budget | None,
    stage_end: float,
    phrases: list[str] | None = None,
) -> list[str]:
    """Follow names found in the first documents with one more docs.search, then fetch what it returns."""
    search_tool = next((n for n in available_tool_names if str(n).lower() == "docs.search"), "")
    get_tool = next((n for n in available_tool_names if str(n).lower() == "docs.get"), "")
    if not (search_tool and get_tool and evidence_lines and budget is not None):
        return []
    new_ids: list[str] = []
    already_fetched = _fetched_doc_ids(evidence_lines)
    for phrase in phrases if phrases is not None else _hop_phrases(question, evidence_lines):
        left = stage_end - time.monotonic()
        if left <= 0:
            break
        try:
            result = await asyncio.wait_for(
                mcp_client.call_tool(search_tool, {"agent_id": agent_id, "query": phrase}),
                timeout=budget.tool_call_timeout(left),
            )
        except Exception:
            continue
        for doc_id in re.findall(r'\\?"id\\?"\s*:\s*\\?"([^"\\]+)', _tool_result_text(result)):
            if doc_id not in new_ids and doc_id not in already_fetched:
                new_ids.append(doc_id)
    found: list[str] = []
    for doc_id in new_ids[:3]:
        left = stage_end - time.monotonic()
        if left <= 0:
            break
        try:
            result = await asyncio.wait_for(
                mcp_client.call_tool(get_tool, {"agent_id": agent_id, "doc_id": doc_id}),
                timeout=budget.tool_call_timeout(left),
            )
        except Exception:
            continue
        rendered = _tool_result_text(result)
        if rendered and not any(rendered[:120] in line for line in evidence_lines):
            found.append(f"{get_tool}: {evidence_window.clip(rendered, 2000)}")
    return found


_QUANTITY_RE = re.compile(
    r"\bhow (much|many)\b|\b(total|remaining|balance|difference|sum|left|net|average|combined)\b", re.IGNORECASE
)
# JSON keys of the docs tools' results and words too common to steer a search.
_FEEDBACK_SKIP = {"id", "title", "text", "results", "doc", "the", "and", "for", "with", "from", "that", "this",
                  "are", "was", "were", "has", "have", "its", "not", "but", "all", "any"}


def _fetched_doc_ids(evidence_lines: list[str]) -> set[str]:
    ids: set[str] = set()
    for line in evidence_lines:
        if str(line).lower().startswith("docs.get:"):
            ids.update(re.findall(r'"id"\s*:\s*"([^"]+)"', str(line))[:1])
    return ids


def _wants_feedback_search(question: str, answer_format: str, evidence_lines: list[str]) -> bool:
    """A quantity question whose searches fetched a single document: the other operand may sit in a
    document that shares no word with the question (the invoice total behind "remaining balance")."""
    numeric = str(answer_format or "").strip().lower().startswith(("integer", "number", "decimal"))
    if not (numeric or _QUANTITY_RE.search(str(question or ""))):
        return False
    return len(_fetched_doc_ids(evidence_lines)) == 1


def _feedback_query(question: str, evidence_lines: list[str], limit: int = 8) -> str:
    """The fetched documents' own words that the question does not use (no numbers), most frequent first."""
    asked = set(re.findall(r"[a-z0-9]+", str(question or "").lower()))
    counts: dict[str, int] = {}
    for line in evidence_lines:
        body = str(line).split(":", 1)[-1]
        for word in re.findall(r"[a-z]+", body.lower()):
            if len(word) > 2 and word not in asked and word not in _FEEDBACK_SKIP:
                counts[word] = counts.get(word, 0) + 1
    return " ".join(word for word, _ in sorted(counts.items(), key=lambda pair: -pair[1])[:limit])


async def _feedback_evidence(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    available_tool_names: list[str],
    question: str,
    answer_format: str,
    evidence_lines: list[str],
    budget: Budget | None,
    stage_end: float,
) -> list[str]:
    """Searches built from the fetched documents, then fetch the new documents.

    First the codes they name on the way to the answer ("sale code S-58" -> "S-58"; fresh-mix-2 id hop), for any
    retrieval question. Then, for a quantity question that fetched one document, that document's own terms.
    """
    from msquad import id_hop, table_hop

    id_lines: list[str] = []
    codes = id_hop.ids_to_follow(question, evidence_lines)
    if codes:
        id_lines = await _second_hop_evidence(
            mcp_client=mcp_client,
            agent_id=agent_id,
            available_tool_names=available_tool_names,
            question=question,
            evidence_lines=evidence_lines,
            budget=budget,
            stage_end=stage_end,
            phrases=codes,
        )
        print(f"   id hop {codes}: +{len(id_lines)} documents", flush=True)
    # MSQUAD_TABLE_HOP: the row a superlative picks in a fetched table names the entity whose asked attribute
    # (extension, room, email...) is in another document (fresh-mix-4 fm4_ret_table_hop). Off by default.
    entities = table_hop.entities_to_follow(question, evidence_lines)
    if entities:
        table_lines = await _second_hop_evidence(
            mcp_client=mcp_client,
            agent_id=agent_id,
            available_tool_names=available_tool_names,
            question=question,
            evidence_lines=list(evidence_lines) + id_lines,
            budget=budget,
            stage_end=stage_end,
            phrases=entities,
        )
        print(f"   table hop {entities}: +{len(table_lines)} documents", flush=True)
        id_lines = id_lines + table_lines
    # The quantity search decides on the documents fetched before the id hop, as it did without it.
    if not _wants_feedback_search(question, answer_format, evidence_lines):
        return id_lines
    query = _feedback_query(question, evidence_lines)
    if not query:
        return id_lines
    return id_lines + await _second_hop_evidence(
        mcp_client=mcp_client,
        agent_id=agent_id,
        available_tool_names=available_tool_names,
        question=question,
        evidence_lines=list(evidence_lines) + id_lines,  # skip documents the id hop already fetched
        budget=budget,
        stage_end=stage_end,
        phrases=[query],
    )


# Transport failures worth one retry when fetching a document by id (OSError covers ConnectionError).
_TRANSIENT_FETCH_ERRORS = (OSError, TimeoutError)


def _clue_tools_used(clue_ids: list) -> set[str]:
    """Tools the run has used by the time it reaches the required-tool check.

    The clue tools count only when the clue read completed (clue_ids came back). A timed-out read
    falls back to the challenge's own clues, which were never fetched through the tools.
    """
    used = {"arena.get_challenge"}
    if clue_ids:
        used |= {"arena.clues.list", "arena.clues.get"}
    return used


async def _enforce_required_tool_calls(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None,
    available_tool_names: list[str],
    http_client: HttpArenaClient,
    extra_context: str = "",
    server_required: list[str] | None = None,
    budget: Budget | None = None,
    stage_end: float | None = None,
    already_used: set[str] | None = None,
) -> list[str]:
    evidence_window.set_question(description)
    required_runtime_tools = _required_runtime_tools(
        available_tool_names,
        challenge_type=challenge_type,
        description=description,
        rules=rules,
        extra_context=extra_context,
        server_required=server_required,
    )
    # A tool the run already called (get_challenge, clues.list/get) counts as used. Calling it
    # again with search payloads only fails, one round trip per payload variant (about 2.3 s live).
    required_runtime_tools = [name for name in required_runtime_tools if name not in (already_used or set())]
    if not required_runtime_tools:
        return []

    evidence_lines: list[str] = []
    if stage_end is None:
        stage_end = time.monotonic() + (budget.tool_stage_s() if budget is not None else 30.0)

    def _stage_left() -> float:
        return max(0.0, stage_end - time.monotonic())

    queries = _query_candidates(description, rules, clues, extra_context)
    if not queries:
        queries = [""]
    # Search tools run first so the ids they return can feed fetch-by-id tools (docs.get).
    search_ids: list[str] = []
    search_buckets: list[list[str]] = []  # the ids each search query returned, for the round-robin arm
    ordered_tools = sorted(required_runtime_tools, key=lambda name: name.lower().endswith(".get"))
    for tool_name in ordered_tools:
        is_search_like = "search" in tool_name.lower()
        fetch_by_id = tool_name.lower().endswith(".get") and bool(search_ids)
        from msquad import fetch_round_robin

        fetch_ids = fetch_round_robin.round_robin(search_buckets) if fetch_round_robin.enabled() else search_ids
        if fetch_by_id:
            target_calls = min(len(fetch_ids), 3)
        else:
            target_calls = min(len(queries), 3) if is_search_like else 1
        calls_made = 0
        if fetch_by_id and parallel_doc_reads.enabled():
            # astra P (arm, off by default): the reads run at once; evidence keeps the id order.
            ids = fetch_ids[:target_calls]

            async def _read(doc_id: str, tool_name: str = tool_name):
                # the same one retry on a transient transport failure as the serial loop below
                for attempt in (1, 2):
                    try:
                        return await asyncio.wait_for(
                            mcp_client.call_tool(tool_name, {"agent_id": agent_id, "doc_id": doc_id}),
                            timeout=_call_timeout(_stage_left(), budget),
                        )
                    except _TRANSIENT_FETCH_ERRORS:
                        if attempt == 2 or _stage_left() <= 0:
                            raise

            if _stage_left() > 0:
                for result in await parallel_doc_reads.read_all(ids, _read):
                    if isinstance(result, BaseException):
                        continue
                    rendered = _tool_result_text(result)
                    if rendered:
                        evidence_lines.append(f"{tool_name}: {evidence_window.clip(rendered, 2000)}")
                    calls_made += 1
        elif fetch_by_id:
            for doc_id in fetch_ids[:target_calls]:
                if _stage_left() <= 0:
                    break
                try:
                    # one retry on a transient transport failure; a tool error is the server's answer, not retried
                    for attempt in (1, 2):
                        try:
                            result = await asyncio.wait_for(
                                mcp_client.call_tool(tool_name, {"agent_id": agent_id, "doc_id": doc_id}),
                                timeout=_call_timeout(_stage_left(), budget),
                            )
                            break
                        except _TRANSIENT_FETCH_ERRORS:
                            if attempt == 2 or _stage_left() <= 0:
                                raise
                    rendered = _tool_result_text(result)
                    if rendered:
                        evidence_lines.append(f"{tool_name}: {evidence_window.clip(rendered, 2000)}")
                    calls_made += 1
                except Exception:
                    continue
        else:
            for query in queries[:target_calls]:
                bucket: list[str] = []
                search_buckets.append(bucket)
                payload_variants = [
                    {"agent_id": agent_id, "query": query},
                    {"query": query},
                    {"agent_id": agent_id, "search_query": query},
                    {"search_query": query},
                    {"agent_id": agent_id, "text": query},
                    {"text": query},
                    {"agent_id": agent_id, "url": query},
                    {"url": query},
                    {"agent_id": agent_id, "video_url": query},
                    {"video_url": query},
                    {"agent_id": agent_id},
                    {},
                ]
                for payload in payload_variants:
                    if _stage_left() <= 0:
                        break
                    done = False
                    for attempt in range(2 if is_search_like and challenge_type.strip().lower() == "retrieval" else 1):  # a search fault is retried once, retrieval only
                        try:
                            result = await asyncio.wait_for(
                                mcp_client.call_tool(tool_name, payload),
                                timeout=_call_timeout(_stage_left(), budget),
                            )
                            rendered = _tool_result_text(result)
                            if rendered:
                                evidence_lines.append(f"{tool_name}: {evidence_window.clip(rendered, 2000)}")
                                if is_search_like:
                                    from msquad import search_pagination

                                    found_ids = re.findall(r'"id"\s*:\s*"([^"]+)"', rendered)
                                    if search_pagination.enabled():
                                        # A/B arm (MSQUAD_SEARCH_PAGINATION): ids from the continuation pages too.
                                        with contextlib.suppress(Exception):
                                            found_ids += await _follow_search_pages(
                                                mcp_client, tool_name, payload, rendered, _stage_left, budget
                                            )
                                    for found in found_ids:
                                        if found not in bucket:
                                            bucket.append(found)
                                        if found not in search_ids:
                                            search_ids.append(found)
                            calls_made += 1
                            done = True
                            break
                        except Exception:
                            continue
                    if done:
                        break
            from msquad import empty_search_retry

            retry = empty_search_retry.retry_query(description) if is_search_like else ""
            if empty_search_retry.enabled() and is_search_like and calls_made and not search_ids:
                # A/B arm (MSQUAD_EMPTY_SEARCH_RETRY): every query came back empty. One more search with the content
                # words; if that is empty too (or was the primary query again), each key noun on its own, all of
                # them, so docs.get gets real ids and a two-document question gets both (gym chaos-text-docs-miss).
                # Every extra search shares one time cap.
                tried = {q.lower() for q in queries}
                plan = [retry] if retry and retry.lower() not in tried else []
                tried.add(retry.lower())
                nouns = [n for n in empty_search_retry.noun_queries(description) if n.lower() not in tried]
                retry_end = time.monotonic() + empty_search_retry.RETRY_BUDGET_S
                for i, query in enumerate(plan + nouns):
                    by_noun = i >= len(plan)
                    if i == len(plan) and search_ids:
                        break  # the content-word retry found ids: no noun searches, as before
                    left = min(_stage_left(), retry_end - time.monotonic())
                    if left <= 0:
                        break
                    try:
                        result = await asyncio.wait_for(
                            mcp_client.call_tool(tool_name, {"agent_id": agent_id, "query": query}),
                            timeout=_call_timeout(left, budget),
                        )
                    except Exception:
                        continue
                    rendered = _tool_result_text(result)
                    found_ids = re.findall(r'"id"\s*:\s*"([^"]+)"', rendered or "")
                    if not rendered or (by_noun and not found_ids):
                        continue
                    evidence_lines.append(f"{tool_name}: {evidence_window.clip(rendered, 2000)}")
                    search_buckets.append(list(dict.fromkeys(found_ids)))  # the round-robin arm reads buckets
                    for found in found_ids:
                        if found not in search_ids:
                            search_ids.append(found)
        status_note = (
            f"Required tool coverage: {tool_name} ({calls_made}/{target_calls})"
            if target_calls > 1
            else f"Required tool called: {tool_name}"
            if calls_made
            else f"Could not call required tool: {tool_name}"
        )
        try:
            _post_in_background(http_client.broadcast_thought, agent_id, status_note)
        except Exception:
            pass
    return evidence_lines


def _build_context(
    *,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None = None,
    max_time_s: int = 0,
    available_models: list[str] | None = None,
    time_remaining_s: float = 0.0,
    tokens_used: int = 0,
    image_url: str | None = None,
) -> ChallengeContext:
    return ChallengeContext(
        challenge_type=challenge_type,
        difficulty="unknown",
        challenge_text=description,
        description=description,
        rules=rules,
        clues=list(clues or []),
        time_remaining_s=time_remaining_s,
        max_time_s=max_time_s,
        available_models=list(available_models or []),
        tools_used=[],
        tokens_used=tokens_used,
        required_tools=[],
        image_url=image_url,
    )


def _coerce_nonnegative_int(value: object, default: int = 0) -> int:
    try:
        return max(0, int(value if value is not None else default))
    except (TypeError, ValueError):
        return default


def _fetch_proxy_usage(
    llm_host: str,
    api_key: str,
    agent_id: str,
    scope_id: str | None = None,
) -> dict[str, int] | None:
    """Best-effort fetch of proxy usage for one agent, scoped when possible."""
    if not llm_host or not api_key or not agent_id:
        return None
    encoded_agent_id = quote(agent_id, safe="")

    def _read_usage(url: str) -> dict[str, int] | None:
        request = Request(
            url,
            headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"},
            method="GET",
        )
        with urlopen(request, timeout=1.0) as response:
            payload = json.loads(response.read().decode("utf-8"))
        usage = payload.get("usage")
        if not isinstance(usage, dict):
            return None
        return {
            "prompt_tokens": _coerce_nonnegative_int(usage.get("prompt_tokens")),
            "completion_tokens": _coerce_nonnegative_int(usage.get("completion_tokens")),
            "total_tokens": _coerce_nonnegative_int(usage.get("total_tokens")),
        }

    if scope_id:
        encoded_scope_id = quote(scope_id, safe="")
        scoped_url = f"{llm_host.rstrip('/')}/usage/{encoded_scope_id}/{encoded_agent_id}"
        try:
            return _read_usage(scoped_url)
        except HTTPError as exc:
            if exc.code not in {400, 404}:
                raise

    aggregate_url = f"{llm_host.rstrip('/')}/usage/{encoded_agent_id}"
    return _read_usage(aggregate_url)


def _build_live_metrics(model_name: str, usage: dict[str, int] | None, elapsed_ms: int) -> dict[str, object]:
    usage = usage or {}
    prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
    completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
    total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))
    return {
        "model_name": str(model_name or "").strip(),
        "total_tokens": str(total_tokens),
        "prompt_tokens": str(prompt_tokens),
        "completion_tokens": str(completion_tokens),
        "total_time_ms": int(max(0, elapsed_ms)),
    }


# A retry with another model needs time to think and answer.
RETRY_MIN_REMAINING_S = 30.0


def _next_ranked_model(ranked_models: list[str], current: str) -> str:
    """The first ranked model after ``current``, or "" when there is none."""
    remaining = [model for model in ranked_models if model != current]
    if current in ranked_models:
        after = ranked_models[ranked_models.index(current) + 1 :]
        remaining = [model for model in after if model != current] or remaining
    return remaining[0] if remaining else ""


_TOKEN_LIMIT_REASONS = frozenset({"length", "max_tokens", "max_token", "token_limit", "token limit", "max_output_tokens"})


def _is_token_limit(reason: object) -> bool:
    """True when a model stopped because it ran out of tokens, whatever its provider calls it."""
    text = str(reason or "").strip().lower().replace("-", "_")
    return text in _TOKEN_LIMIT_REASONS or text.endswith("max_tokens")


async def _retry_after_length_stop(result, *, ranked_models, remaining_s, solve_with):
    """Retry once with the next ranked model when the first ran out of tokens.

    ``result`` is solve_challenge's tuple. A reasoning model that spends its
    whole token budget thinking returns no answer with finish_reason
    "length"; asking it again would do the same, so another model gets one
    try while enough time remains. Token usage and time add up across both.
    """
    answer, _raw, model_name, usage, _ttft, total_time_ms = result
    if _is_invalid_answer_candidate(answer):
        answer = ""
    if (answer or not _is_token_limit(usage.get("finish_reason"))):
        return result
    tokens_spent = int(usage.get("completion_tokens", 0) or 0)
    print(f"   ⚠️  {model_name} used all {tokens_spent} tokens thinking and gave no answer.")
    retry_model = _next_ranked_model(ranked_models, model_name)
    left_s = await remaining_s()
    if not retry_model or left_s < RETRY_MIN_REMAINING_S:
        print(f"   Not retrying ({left_s:.0f}s left). Tune text_max_tokens or rank_models in my_strategy.py.")
        return result
    print(f"   Retrying with {retry_model}. Tune text_max_tokens or rank_models in my_strategy.py.")
    retried = await solve_with(retry_model)
    r_answer, r_raw, r_model, r_usage, r_ttft, r_time_ms = retried
    merged_usage = dict(r_usage)
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        merged_usage[key] = int(r_usage.get(key, 0) or 0) + int(usage.get(key, 0) or 0)
    return r_answer, r_raw, r_model, merged_usage, r_ttft, total_time_ms + r_time_ms


# A dropped connection mid-stream is retried through the non-streaming call only with this much left.
STREAM_DROP_RETRY_MIN_S = 20.0


def _connection_dropped(exc: BaseException) -> bool:
    """A raw connection reset, abort or truncated response, as raised by the socket or httpx layer."""
    import httpx

    return isinstance(exc, (ConnectionResetError, ConnectionAbortedError, httpx.RemoteProtocolError))


def _retryable_llm_error(exc: Exception) -> bool:
    """Transient proxy failures: rate limit, connection, timeout, 5xx, and a dropped connection."""
    import openai

    if isinstance(exc, (openai.RateLimitError, openai.APIConnectionError, openai.APITimeoutError)):
        return True
    # A proxy reply cut off mid-body (or not JSON at all) is a dropped reply, not a final answer.
    if isinstance(exc, json.JSONDecodeError):
        return True
    if _connection_dropped(exc):
        return True
    return isinstance(exc, openai.APIStatusError) and exc.status_code >= 500


# The grounded re-ask runs only with at least this much time left before the submit margin.
GROUNDING_REASK_MIN_S = 10.0


def _single_answer_call(llm_client, model_name: str, prompt: str) -> str:
    """One short non-streaming call for a bare answer; "" on any failure."""
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1024,
            temperature=0.0,
        )
    except Exception:
        return ""
    return (response.choices[0].message.content or "").strip()


def _repair_answer(llm_client, model_name: str, bad_reply: str, ctx: ChallengeContext, reason: str) -> str:
    """One short non-streaming call that restates only the bare answer."""
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": repair_prompt(bad_reply, ctx.rules, ctx.clues, reason)}],
            max_tokens=1024,
            temperature=0.0,
        )
    except Exception:
        return ""
    return (response.choices[0].message.content or "").strip()


def _evidence_prompt(evidence_lines: list[str] | None, limit: int = 4000) -> str:
    """Tool evidence for the solve prompt: the solver must answer from it, not from memory."""
    lines = [str(line).strip() for line in (evidence_lines or []) if str(line).strip()]
    if not lines:
        return ""
    items = [f"- {line}" for line in lines]
    if sum(len(item) + 1 for item in items) > limit:
        # Over budget: share it fairly instead of first come, first served. Two long docs.search lines
        # used to fill the whole block and cut both docs.get lines out (gym huge-fields, #327).
        # Short items keep everything; the rest of the budget is split evenly among the long ones.
        allowance = {}
        pending = sorted(range(len(items)), key=lambda i: len(items[i]))
        left = limit - len(items)  # one newline per item
        while pending:
            share = max(0, left // len(pending))
            i = pending[0]
            if len(items[i]) <= share:
                allowance[i] = len(items[i])
                left -= len(items[i])
                pending.pop(0)
            else:
                for j in pending:
                    allowance[j] = share
                break
        # MSQUAD_EVIDENCE_WINDOW: a cut item keeps its question-matching sentences (item[:allowance] when off).
        items = [evidence_window.clip(item, allowance[i]) for i, item in enumerate(items)]
    body = "\n".join(items)[:limit]
    return (
        "Tool evidence:\n"
        f"{body}\n"
        "Answer from the tool evidence; it overrides your own knowledge."
    )


async def solve_challenge(
    challenge,
    clues: list[str],
    llm_client,
    model_name: str,
    strategy: MyStrategy,
    ctx: ChallengeContext,
    *,
    http_client=None,
    agent_id: str = "",
    broadcast_thought: bool = True,
    evidence_lines: list[str] | None = None,
    ticker: ReasoningTicker | None = None,
    budget: Budget | None = None,
):
    """Solve the challenge using the selected LLM model.
    
    When http_client and agent_id are provided, streams reasoning to Agent Gauntlet in real time.
    
    Returns:
        tuple: (extracted_answer, raw_response, model_name, usage_dict, ttft_ms, total_time_ms)
    """
    
    print(f"   solve_challenge: type={getattr(challenge, 'challenge_type', None)!r} clues={len(clues)}", flush=True)
    # Deterministic path: skip the LLM when the logic solver finds a unique answer.
    solved = solve_knights(
        f"{getattr(challenge, 'description', '')}\n{getattr(challenge, 'rules', '')}\n"
        f"{getattr(challenge, 'answer_format', '')}",
        clues,
    ) or solve_sequence(str(getattr(challenge, "description", "") or ""), clues) or solve_numeric(str(getattr(challenge, "description", "") or ""), clues) or solve_zebra(str(getattr(challenge, "description", "") or ""), clues) or solve_big_choice(str(getattr(challenge, "description", "") or ""), clues) or solve_logic_from_challenge(
        f"{getattr(challenge, 'description', '')}\n{getattr(challenge, 'rules', '')}\n"
        f"{getattr(challenge, 'answer_format', '')}",
        clues,
    ) or solve_first_mention(
        # 2-3 valid orders: the one in first-mention order, when exactly one is (0 tokens).
        f"{getattr(challenge, 'description', '')}\n{getattr(challenge, 'rules', '')}\n"
        f"{getattr(challenge, 'answer_format', '')}",
        clues,
    )
    solved = normalize_entity_answer(solved, str(getattr(challenge, "rules", "") or ""))
    if solved:
        # The reply must carry an ANSWER line, or the empty-reply retry calls the LLM.
        return solved, f"ANSWER: {solved}", model_name, {}, 0, 0
    # A code challenge's clue is a program; running it in the sandbox gives the answer.
    executed = run_code_challenge(getattr(challenge, "challenge_type", ""), clues)
    if executed:
        return executed, f"ANSWER: {executed}", model_name, {"finish_reason": "code_eval"}, 0, 0
    from msquad import code_in_text

    if code_in_text.enabled():
        # A/B arm (MSQUAD_CODE_IN_TEXT): a program quoted in the question runs in the same code sandbox.
        quoted = code_in_text.run_any(
            getattr(challenge, "challenge_type", ""),
            (str(getattr(challenge, "description", "") or ""), str(getattr(challenge, "rules", "") or "")),
        )
        if quoted:
            return quoted, f"ANSWER: {quoted}", model_name, {"finish_reason": "code_in_text"}, 0, 0
    # Math rules answer only when they parse the whole question; otherwise the model answers.
    presolved = presolve_challenge(
        getattr(challenge, "challenge_type", ""),
        getattr(challenge, "description", ""),
        getattr(challenge, "rules", ""),
    )
    if presolved:
        return presolved, f"ANSWER: {presolved}", model_name, {"finish_reason": "presolve"}, 0, 0
    from msquad import presolve_time

    if presolve_time.enabled():
        # A/B arm (MSQUAD_PRESOLVE_TIME): clock, duration, decimal-hour, speed, weekday and sig-fig questions.
        timed = presolve_time.presolve_time_challenge(
            getattr(challenge, "challenge_type", ""),
            getattr(challenge, "description", ""),
            getattr(challenge, "rules", ""),
        )
        if timed:
            return timed, f"ANSWER: {timed}", model_name, {"finish_reason": "presolve_time"}, 0, 0
    prompt = strategy.build_solver_prompt(ctx)
    evidence_block = _evidence_prompt(evidence_lines)
    if evidence_block:
        prompt = f"{evidence_block}\n\n{prompt}"
    if str(ctx.challenge_type or "").strip().lower() == "retrieval" and evidence_lines:
        prompt = (
            f"{prompt}\n\nDocuments carry dates. Use the latest revision that applies; earlier, withdrawn or "
            "superseded values do not count. If the question asks for a total, difference or count, compute it "
            "from the document values and answer the result only."
        )
    prompt = (
        f"{prompt}\n\n"
        "Output guardrails:\n"
        "- Return only your final answer line.\n"
        "- Do not output tool-call markup, XML tags, or thinking traces."
    )
    system_msg = strategy.build_system_prompt(ctx)
    # Parameters for the model actually being called (a fallback model is not the first pick).
    params_for_model = getattr(strategy, "llm_params_for_model", None)
    llm_params = params_for_model(ctx, model_name) if callable(params_for_model) else strategy.get_llm_params(ctx)
    max_tokens = int(llm_params.get("max_tokens", 8192))
    temperature = float(llm_params.get("temperature", 0.0))
    # Strategy pass-through: reasoning controls go straight to chat.completions.
    extra_params = {k: llm_params[k] for k in ("reasoning_effort", "extra_body") if k in llm_params}
    
    # Track timing
    start_ms = time.time() * 1000
    ttft_ms = 0
    first_token_ms: int | None = None  # measured only; ttft_ms may later fall back to an estimate
    raw_content_parts = []
    # Kept apart so the answer comes from the final reply, as in the
    # non-streaming path; reasoning can hold draft "ANSWER:" lines.
    reply_parts: list[str] = []
    reasoning_parts: list[str] = []
    # MSQUAD_FIRST_TOKEN_WATCHDOG: set only around the streamed solve (see msquad/first_token_watchdog.py)
    watch_first_token = False

    def _timed_client():
        # Each attempt gets the time left now, with SDK retries off: a retry
        # reuses the old timeout, so one slow attempt could run it twice.
        if budget is None:
            return llm_client
        timeout = budget.llm_timeout()
        if timeout <= 0:
            raise RuntimeError("no time left for an LLM call")
        if watch_first_token:
            timeout = first_token_watchdog.stream_timeout(timeout)
        return llm_client.with_options(timeout=timeout, max_retries=0)

    def _should_retry(exc: Exception) -> bool:
        # Under the watchdog a timeout goes to the fastest other model, not the same one again.
        return _retryable_llm_error(exc) and not (watch_first_token and first_token_watchdog.is_timeout(exc))

    def _create(**kwargs):
        # One explicit retry for transient proxy errors, with time to spare.
        try:
            return call_with_one_retry(
                lambda: _timed_client().chat.completions.create(**kwargs), budget, _should_retry
            )
        except Exception as exc:
            # A model that rejects the reasoning parameter (HTTP 400) gets the same call once
            # without it, rather than losing the answer to the next model or the clue guess.
            if "reasoning_effort" not in kwargs or getattr(exc, "status_code", None) != 400:
                raise
            print(f"   ⚠️  {kwargs.get('model')} rejected reasoning_effort (HTTP 400); retrying without it.")
            plain = {k: v for k, v in kwargs.items() if k != "reasoning_effort"}
            return call_with_one_retry(
                lambda: _timed_client().chat.completions.create(**plain), budget, _should_retry
            )

    stream_enabled = os.getenv("LLM_STREAM", "1").lower() not in {"0", "false", "no"}
    usage = None
    finish_reason = ""
    streamed = bool(stream_enabled and http_client and agent_id)
    if stream_enabled and http_client and agent_id:
        # Stream and broadcast in real time
        watch_first_token = budget is not None and first_token_watchdog.enabled()
        try:
            stream = _create(
                model=model_name,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=temperature,
                stream=True,
                **extra_params,
            )
            header_sent = False
            for chunk in stream:
                # Per-read timeouts never fire while tokens keep arriving, so
                # the deadline is checked here; the submit margin stays free.
                if budget is not None and budget.remaining() <= budget.margin_s:
                    print("   ⏱  Deadline reached mid-stream; stopping and submitting the best draft.")
                    cut_stream_salvage.note_cut("".join(reply_parts))
                    stream.close()
                    break
                if chunk.choices and getattr(chunk.choices[0], "finish_reason", None):
                    finish_reason = str(chunk.choices[0].finish_reason)
                if chunk.choices and chunk.choices[0].delta:
                    delta = chunk.choices[0].delta
                    content = delta.content or ""
                    reasoning = getattr(delta, "reasoning_content", None) or getattr(delta, "reasoning", None) or ""
                    text = reasoning or content
                    if ticker is not None:
                        ticker.feed(reasoning=reasoning, answer=content)
                    if reasoning:
                        reasoning_parts.append(reasoning)
                    if content:
                        reply_parts.append(content)
                    if text:
                        if not ttft_ms:
                            ttft_ms = int(time.time() * 1000 - start_ms)
                            first_token_ms = ttft_ms
                        raw_content_parts.append(text)
                        if broadcast_thought:
                            if not header_sent:
                                _post_in_background(http_client.broadcast_thought, agent_id, "💭 LLM Reasoning:")
                                header_sent = True
                            # Streamed model text is not broadcast: it can contain the answer and clues.
                if hasattr(chunk, "usage") and chunk.usage:
                    usage = chunk.usage
        except Exception as e:
            # Log only, before any re-raise: a stream that failed is the stall the record is for.
            will_fall_back = (
                "stream" in str(e).lower()
                or (_connection_dropped(e) and budget is not None and budget.remaining() > STREAM_DROP_RETRY_MIN_S)
            ) and not (watch_first_token and not raw_content_parts and first_token_watchdog.is_timeout(e))
            _note_streamed_call(model_name, first_token_ms, int(time.time() * 1000 - start_ms),
                                error=type(e).__name__, fallback=will_fall_back)
            streamed = False  # recorded; the non-streaming retry is not a streamed call
            if watch_first_token and not raw_content_parts and first_token_watchdog.is_timeout(e):
                raise first_token_watchdog.FirstTokenTimeout(
                    f"{model_name} sent no first token in {first_token_watchdog.first_token_s():.0f}s"
                ) from e
            from msquad import keep_streamed_answer

            if keep_streamed_answer.enabled() and keep_streamed_answer.complete(
                "".join(reply_parts), extract_answer, _is_invalid_answer_candidate
            ):
                # A/B arm (MSQUAD_KEEP_STREAMED_ANSWER): the reply already holds a complete answer; keep it.
                print("   ⚠️  Stream dropped after a complete answer; keeping it.")
            else:
                stream_enabled = False
                raw_content_parts = []
                if "stream" in str(e).lower() or "Stream" in str(e):
                    pass  # Fall through to non-streaming
                elif _connection_dropped(e) and budget is not None and budget.remaining() > STREAM_DROP_RETRY_MIN_S:
                    # The connection dropped mid-stream with time to spare: the non-streaming call
                    # below retries it once (its own timeout and the budget guard still apply).
                    print(f"   ⚠️  Stream dropped ({type(e).__name__}); retrying without streaming.")
                else:
                    raise

    watch_first_token = False  # the non-streaming and strict calls keep the normal timeout
    if not stream_enabled or not raw_content_parts:
        # Non-streaming fallback
        response = _create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
            **extra_params,
        )
        raw_content = response.choices[0].message.content or ""
        finish_reason = str(getattr(response.choices[0], "finish_reason", "") or "")
        usage = response.usage
        ttft_ms = ttft_ms or getattr(response, "ttft_ms", 0) or int((time.time() * 1000 - start_ms) * 0.1)
    else:
        reply = "".join(reply_parts)
        raw_content = reply if reply.strip() else "".join(reasoning_parts)

    total_time_ms = int(time.time() * 1000 - start_ms)
    answer_format = getattr(challenge, "answer_format", "")
    answer = answer_normalise.normalise(_normalize_answer_shape(extract_answer(raw_content), answer_format), answer_format)
    if _is_invalid_answer_candidate(answer):
        answer = ""
    # Extra model calls only while there is time to spare; past the margin the
    # best draft goes out instead of a new call.
    has_time = budget is None or budget.remaining() > budget.margin_s
    # The recovery call is bounded like every other call: no time left for a timed call means no recovery.
    if not answer and evidence_lines and has_time and (budget is None or budget.llm_timeout() > 0):
        answer = _derive_answer_from_evidence(
            llm_client=_timed_client(),
            model_name=model_name,
            challenge_description=str(ctx.description or ""),
            challenge_rules=str(ctx.rules or ""),
            evidence_lines=list(evidence_lines or []),
            max_tokens=max_tokens,
        )
        if _is_invalid_answer_candidate(answer):
            answer = ""
        # MSQUAD_KEEP_EVIDENCE_ANSWER (astra E): the final pass re-reads raw_content, so the recovered
        # answer must be in it or it is lost.
        raw_content = keep_evidence_answer.raw_for(answer, raw_content)
    # A model that ran out of tokens while thinking would only do it again;
    # the caller retries with another model instead.
    if not answer and not _is_token_limit(finish_reason) and has_time:
        strict_system_msg = (
            "Return only one line in exact format: ANSWER: <final answer>. "
            "No preamble, no tags, no explanation, no additional lines."
        )
        try:
            strict_response = _create(
                model=model_name,
                messages=[
                    {"role": "system", "content": strict_system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=min(temperature, 0.0),
                stream=False,
            )
            raw_content = strict_response.choices[0].message.content or ""
            usage = strict_response.usage
            total_time_ms = int(time.time() * 1000 - start_ms)
            answer = extract_answer(raw_content)
        except Exception:
            pass
    if _is_invalid_answer_candidate(answer):
        answer = ""

    usage_dict = {
        "finish_reason": finish_reason,
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) if usage else 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) if usage else 0,
        "total_tokens": getattr(usage, "total_tokens", 0) if usage else 0,
    }
    # Streams usually carry no usage; estimate from everything streamed,
    # reasoning included, not only the reply the answer was read from.
    streamed_text = "".join(raw_content_parts) or raw_content
    if not usage_dict["total_tokens"] and streamed_text:
        usage_dict["total_tokens"] = len(streamed_text.split()) * 2  # rough estimate
    ttft_ms = ttft_ms or int(total_time_ms * 0.1)
    if streamed:
        # a stream that finished with no text falls back to one non-streaming call
        _note_streamed_call(model_name, first_token_ms, total_time_ms, fallback=first_token_ms is None)

    return answer, raw_content, model_name, usage_dict, ttft_ms, total_time_ms


# Solve-path state kept for the last-resort submit (see submit_guard_fallback).
_GUARD: dict = {}
# Log only: one entry per streamed LLM call this run, for the run record (live TTFT per model).
_STREAMED_CALLS: list[dict] = []


def _note_streamed_call(
    model_name: str,
    first_token_ms: int | None,
    total_time_ms: int,
    *,
    error: str | None = None,
    fallback: bool = False,
) -> None:
    """Record a streamed call's measured first-token time (None when no token arrived); never raises.

    error is the exception type when the stream raised; fallback is True when a non-streaming call
    followed it.
    """
    try:
        entry: dict = {
            "model": str(model_name),
            "ttft_ms": int(first_token_ms) if first_token_ms is not None else None,
            "total_time_ms": int(total_time_ms),
            "fallback": bool(fallback),
        }
        if error:
            entry["error"] = str(error)
        _STREAMED_CALLS.append(entry)
    except Exception:
        pass

# A run with no broadcast thought loses 10%. ensure_thought sends one before a submit only when
# none was accepted yet, and waits at most this long so a slow endpoint never delays the submit.
THOUGHT_BEFORE_SUBMIT_TIMEOUT_S = 3.0


def track_thoughts(http_client) -> None:
    """Count accepted thoughts in _GUARD["thoughts_ok"] by wrapping the client's broadcast_thought."""
    send = http_client.broadcast_thought
    if getattr(send, "_msquad_tracked", False):
        return

    def tracked(agent_id: str, thought: str) -> bool:
        ok = bool(send(agent_id, thought))
        if ok:
            _GUARD["thoughts_ok"] = int(_GUARD.get("thoughts_ok", 0)) + 1
        return ok

    tracked._msquad_tracked = True
    http_client.broadcast_thought = tracked


# Coverage calls are a score bonus: the submit waits this long for them at most.
IMAGE_COVERAGE_WAIT_S = 5.0


def ensure_thought(http_client, agent_id: str, thought: str = "Submitting answer.") -> bool:
    """Broadcast one thought unless one was already accepted. Bounded and never raises."""
    if int(_GUARD.get("thoughts_ok", 0)) > 0:
        return True
    # A daemon thread, not a pool: Python joins pool workers at exit, so a hung thought endpoint
    # held the finished process open for the HTTP timeout (gym hang-thought: +29 s after submit).
    try:
        return bool(_warm_submit(http_client.broadcast_thought, agent_id, thought).result(
            timeout=THOUGHT_BEFORE_SUBMIT_TIMEOUT_S))
    except Exception as exc:  # timeout or transport error: submit anyway
        print(f"   Thought before submit not confirmed ({exc!r}); submitting anyway.")
        return False


# The MCP thought after an unconfirmed REST one waits at most this long, and never past the margin.
MCP_THOUGHT_TIMEOUT_S = 3.0


# Text arm (default off): the first thought is awaited just before the submit, not before the
# clue read. Live the REST thought takes ~0.9 s and the clue read ~0.3 s, so awaiting it first
# held ~0.6 s of the clock; awaited later it overlaps the clue read, tool calls and solve. Still
# bounded (_pre_stage) and still before the submit, so #265's guarantee holds.
LATE_THOUGHT_AWAIT_FLAG = "MSQUAD_LATE_THOUGHT_AWAIT"
# The event cannot set env vars: a winner ships by flipping this. The env var still overrides it.
LATE_THOUGHT_AWAIT_DEFAULT = False


def late_thought_await_enabled() -> bool:
    value = os.environ.get(LATE_THOUGHT_AWAIT_FLAG, "").strip().lower()
    if not value:
        return LATE_THOUGHT_AWAIT_DEFAULT
    return value in {"1", "true", "yes", "on"}


async def _image_thought_over_mcp(mcp_client, agent_id: str, budget) -> str:
    """Send the pre-submit thought over arena.image.broadcast_thought. Bounded; never raises.

    Returns "sent", "failed", "skipped" (no time) or "timeout". A timeout means the MCP
    transport is not answering: the caller then submits over REST instead of over it.

    A hung REST thought endpoint left the run with no thought, and the server takes 10% off a
    run with none (gym image-hang-thought: 89 against 99). The image channel is a second route.
    """
    timeout_s = min(MCP_THOUGHT_TIMEOUT_S, budget.remaining() - budget.margin_s)
    if timeout_s <= 0:
        return "skipped"
    call = asyncio.ensure_future(mcp_client.broadcast_image_thought("Image ready; submitting.", agent_id))
    done, _ = await asyncio.wait({call}, timeout=timeout_s)
    if not done:
        call.cancel()
        call.add_done_callback(lambda task: task.cancelled() or task.exception())
        print("   Thought over MCP timed out; treating the MCP session as dead.")
        return "timeout"
    if call.exception() is not None:
        print(f"   Thought over MCP failed ({call.exception()!r}); submitting anyway.")
        return "failed"
    _GUARD["thoughts_ok"] = int(_GUARD.get("thoughts_ok", 0)) + 1
    print("   Thought sent over MCP (REST thought not confirmed).")
    return "sent"


# The required text challenge fetch on the image path waits at most this long.
IMAGE_TEXT_FETCH_TIMEOUT_S = 8.0

# Live status and usage are telemetry: each push waits at most this long.
LIVE_STATUS_TIMEOUT_S = 2.0

# The MCP connect before registering is tried this long; then it moves after registering.
PRE_REGISTER_CONNECT_S = 3.0

# Kept back from MCP retries for what follows a give-up: the fallback answer and a REST submit.
MCP_RETRY_RESERVE_S = 10.0


def _cap_mcp_retries(mcp_client, budget) -> None:
    """Reconnects and read-only retries stop in time for the fallback submit to land."""
    cap = getattr(mcp_client, "cap_retries_until", None)
    if cap is not None:
        cap(time.monotonic() + max(0.0, budget.remaining() - budget.margin_s - MCP_RETRY_RESERVE_S))


def _submit_budget_s() -> float:
    """Retry budget for a submit: the time left to the challenge limit, so REST 5xx retries stop there."""
    budget = _GUARD.get("budget")
    if budget is None:
        return resilience.DEFAULT_BUDGET_S
    return min(resilience.DEFAULT_BUDGET_S, budget.deadline_left())


# The guard's submit budget never drops below this: at the deadline a 429/503 still gets one short Retry-After
# wait (capped at half of it) and one more attempt, because a late submit beats none (Fable A1).
GUARD_SUBMIT_FLOOR_S = 4.0


def submit_guard_fallback(exc: BaseException) -> int:
    """Last line of defence: a crash after the challenge was fetched still submits.

    Skipped once an answer is accepted (``submitted``). Image challenges submit
    an image over REST with ``challenge_type="image"``, never a text answer.
    Text uses the best answer so far, or a fallback built from the clues. Returns
    the process exit code.
    """
    print(f"   ⚠️  Solve path failed ({exc!r}).")
    if _GUARD.get("submitted"):
        print("   Answer already submitted; no fallback needed.")
        return 0
    http_client = _GUARD.get("http_client")
    challenge = _GUARD.get("challenge")
    if http_client is None or challenge is None:
        print("   No challenge was fetched, so there is nothing to submit.")
        return 1
    is_image = _GUARD.get("modality") == "image"
    if is_image:
        answer = str(_GUARD.get("answer") or "").strip() or str(
            getattr(challenge, "input_image_uri", "") or ""
        ).strip() or BLANK_PNG_DATA_URI
        submit_kwargs = {"challenge_type": "image"}
    else:
        clues = list(_GUARD.get("clues") or [])
        rules = str(getattr(challenge, "rules", "") or "")
        try:
            if str(challenge.challenge_type or "").strip().lower() == "code":
                # Code drafts are already bare; the list extractor corrupts literal syntax.
                answer = str(_GUARD.get("answer") or "")
            else:
                # The draft may still carry an "ANSWER:" label; only the bare answer is submitted.
                extracted = extract_final_answer(str(_GUARD.get("answer") or ""), rules=rules, clues=clues)
                answer = extracted.answer.strip() if extracted.valid else ""
            if not answer.strip():
                answer = _fallback_with_evidence(challenge, clues, rules, _GUARD.get("evidence"))
        except Exception as build_exc:  # a broken builder must not cost the submission
            print(f"   Fallback builder failed ({build_exc!r}); submitting the raw draft.")
            answer = str(_GUARD.get("answer") or "").strip()
        answer = answer or "N/A"
        submit_kwargs = {}
    print(f"   Submitting a {'image' if is_image else 'text'} fallback before the deadline.")
    ensure_thought(http_client, _GUARD.get("agent_id", ""))
    try:
        result = resilience.submit_resilient(
            http_client, _GUARD["agent_id"], answer=answer, budget_s=max(_submit_budget_s(), GUARD_SUBMIT_FLOOR_S),
            **submit_kwargs,
        )
    except Exception as submit_exc:
        print(f"   Fallback submit failed: {submit_exc!r}")
        return 1
    _GUARD["submitted"] = True
    print(f"   Fallback submitted: accepted={result.accepted} status={result.status}")
    return 0


async def main():
    """Main agent loop."""
    stages = StageTimer()  # log only: where the fixed live time goes
    _STREAMED_CALLS.clear()
    tool_trace.reset()
    strategy = MyStrategy()
    agent_id = (
        os.getenv("AGENT_ID")
        or str(getattr(strategy, "agent_id", "")).strip()
        or "simple-agent"
    ).strip()
    agent_name = (
        os.getenv("AGENT_NAME")
        or str(getattr(strategy, "agent_name", "")).strip()
        or "Team Nova"
    ).strip()
    os.environ["AGENT_ID"] = agent_id
    # Practice is shared: a default id lets another team's run replace yours.
    id_problem = agent_id_problem(os.environ["AGENT_ID"])
    if id_problem:
        raise SystemExit(f"❌ {id_problem}")
    os.environ["AGENT_NAME"] = agent_name
    print(f"🤖 {agent_name} starting...")
    print(f"   Agent ID: {agent_id}")

    ensure_connected()

    # Initialize clients
    api_base = get_api_base()
    mcp_url = get_mcp_url()
    llm_host = get_proxy_host()
    api_key = get_arena_api_key()
    llm_api_key = api_key

    print(f"   API: {api_base}")
    print(f"   MCP: {mcp_url}")
    print(f"   LLM: {llm_host}")
    print()

    # HTTP client for Agent Gauntlet coordination
    http_client = HttpArenaClient(api_base=api_base, api_key=api_key)
    track_thoughts(http_client)
    _GUARD.update(http_client=http_client, agent_id=agent_id)

    if not HAS_OPENAI:
        raise RuntimeError("Missing dependency: openai. Install with `pip install openai`.")
    
    # The openai import (~1 s cold) and the client build (~0.2 s) run on daemon threads while
    # register and the MCP connect wait on the network; the text path takes the built client.
    # Daemon threads need no shutdown and never hold the process open after main() returns.
    openai_class_ready = _warm_submit(_openai_class)
    llm_client_ready: concurrent.futures.Future | None = None
    llm_client_scope: str | None = None

    def _build_llm_client(scope: str | None):
        return openai_class_ready.result()(
            base_url=llm_host,
            api_key=llm_api_key,
            default_headers=build_proxy_headers(agent_id, scope),
        )

    stages.mark("startup")
    # The live speed clock starts when the register response arrives (server elapsed = solve -
    # register + ~0.1 s over 141 Practice logic runs), so everything that does not need the agent
    # session runs before registering: the MCP connect, the model list, the usage scope and the
    # warm LLM client. The early connect is bounded; if the server refuses SSE before
    # registration, the agent registers first and connects after, with the normal budget.
    deferred_mcp: contextlib.AsyncExitStack | None = None  # MSQUAD_SUBMIT_BEFORE_CLOSE (astra R)
    async with contextlib.AsyncExitStack() as mcp_stack:
        print("🔌 Connecting to MCP...")
        mcp_client = None
        try:
            mcp_client = await mcp_stack.enter_async_context(
                resilience.ResilientMcp(mcp_url, agent_id=agent_id, budget_s=PRE_REGISTER_CONNECT_S)
            )
            mcp_client.set_budget(resilience.DEFAULT_BUDGET_S)  # later calls keep the full budget
        except Exception as exc:
            print(f"   MCP connect before registering failed ({exc!r}); connecting after registering.")
        stages.mark("mcp connect")
        models_prefetch = asyncio.ensure_future(_in_daemon(fetch_available_models, llm_host, llm_api_key))
        scope_started = time.monotonic()
        usage_scope = await _pre_stage("usage scope", http_client.fetch_usage_scope, None) or resolve_usage_scope()
        # A fetch that ran out its pre-stage timeout is a hung endpoint: asking again after the
        # challenge arrives would spend another PRE_STAGE_TIMEOUT_S of the challenge clock.
        scope_refetch_ok = time.monotonic() - scope_started < PRE_STAGE_TIMEOUT_S - 0.5
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope
        # Built on the warm thread behind the import, with the scope the proxy headers need. An
        # image run never awaits it.
        llm_client_scope = usage_scope
        llm_client_ready = _warm_submit(_build_llm_client, usage_scope)
        stages.mark("usage scope + warm client")

        # Step 1: Register with Agent Gauntlet (the live clock starts when this returns)
        print("📝 Registering with Agent Gauntlet...")
        # Off the event loop: a closed lobby can hold register for minutes, and the MCP session
        # opened above is kept alive (or reopened) meanwhile.
        session, lobby_wait_s = await resilience.register_waiting(http_client, agent_id, agent_name, mcp_client)
        if lobby_wait_s > 2.0:
            print(f"   Lobby wait: {lobby_wait_s:.0f}s")
        stages.mark("register")
        print(f"   Session: {session.session_id}")
        print(f"   Status: {session.status}")
        session_monitor = monitor_session(http_client, agent_id).start()
        if mcp_client is None:
            mcp_client = await mcp_stack.enter_async_context(resilience.ResilientMcp(mcp_url, agent_id=agent_id))
        early_challenge_task = early_clues_task = None

        # Step 2: Get challenge from MCP. The tools are listed again now: the list can depend on
        # the session (modality).
        print("\n🎯 Getting challenge...")
        if modality_overlap.enabled():
            # A/B arm (MSQUAD_MODALITY_OVERLAP): the session lookup runs while the tools are re-listed;
            # same result as the serial path, and the re-list is never skipped (#330).
            async def _relist():
                return await mcp_client.refresh_tools()

            def _detect(tool_names):
                return _in_daemon(
                    modality_warm.detect_modality, http_client, tool_names, agent_id, McpArenaClient.detect_modality
                )

            tools, tool_defs, modality = await modality_overlap.relist_and_detect(
                _relist, _detect, list(getattr(mcp_client, "tools", []) or [])
            )
            stages.mark("tool relist")
            stages.mark("detect modality")
        else:
            tools, tool_defs = await mcp_client.refresh_tools()
            stages.mark("tool relist")  # log only: the "modality" stage is scored; split it (re-list / HTTP / resolve)
            modality = modality_warm.detect_modality(http_client, tools, agent_id, McpArenaClient.detect_modality)
            stages.mark("detect modality")
        clock = ClockReader(mcp_client, agent_id, tool_defs)
        modality, tools = await resilience.resolve_modality(mcp_client, modality, agent_id)
        if early_challenge.enabled() and modality == "text":
            # A/B arm (MSQUAD_EARLY_CHALLENGE): a text heat fetches the challenge next anyway, so the fetch
            # starts now and the clue reads start once it returns a text challenge; the text path awaits
            # both. Only after the modality says text, so an image heat's calls never change (Fable on #424).
            early_challenge_task, early_clues_task = early_challenge.start(
                lambda: mcp_client.get_challenge(agent_id), lambda: read_clues(mcp_client, agent_id)
            )
        stages.mark("modality")
        image_tool_proxy_args: dict[str, dict[str, str]] = {}

        live_prompt_tokens = 0
        live_completion_tokens = 0
        live_total_tokens = 0
        active_model_name = ""
        metrics_started_ms = 0.0
        reporter_stop = asyncio.Event()
        metrics_task: asyncio.Task | None = None

        def _elapsed_metrics_ms() -> int:
            if metrics_started_ms <= 0:
                return 0
            return int(max(0.0, time.time() * 1000 - metrics_started_ms))

        async def _refresh_live_usage() -> None:
            nonlocal live_prompt_tokens, live_completion_tokens, live_total_tokens
            try:
                usage = await asyncio.wait_for(
                    _in_daemon(_fetch_proxy_usage, llm_host, llm_api_key, agent_id, usage_scope),
                    timeout=LIVE_STATUS_TIMEOUT_S,
                )
            except Exception:  # a timeout too: live usage is telemetry, never worth the run
                usage = None
            if not isinstance(usage, dict):
                return
            live_prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
            live_completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
            live_total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))

        async def _push_live_status(status: str = "running") -> None:
            await _refresh_live_usage()
            try:
                # Bounded: it runs before the image call and before the submit, so a hung status
                # endpoint held the run until the deadline and nothing was submitted (hang audit).
                await asyncio.wait_for(_in_daemon(
                    http_client.update_status,
                    agent_id,
                    status,
                    _build_live_metrics(
                        active_model_name,
                        {
                            "prompt_tokens": live_prompt_tokens,
                            "completion_tokens": live_completion_tokens,
                            "total_tokens": live_total_tokens,
                        },
                        _elapsed_metrics_ms(),
                    ),
                ), timeout=LIVE_STATUS_TIMEOUT_S)
            except Exception:
                return

        async def _runtime_metrics_reporter() -> None:
            while not reporter_stop.is_set():
                await _push_live_status("running")
                try:
                    await asyncio.wait_for(reporter_stop.wait(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

        async def _start_metrics_reporter(model_name: str) -> None:
            nonlocal active_model_name, metrics_started_ms, metrics_task
            active_model_name = str(model_name or "").strip()
            metrics_started_ms = time.time() * 1000
            reporter_stop.clear()
            await _push_live_status("running")
            metrics_task = asyncio.create_task(_runtime_metrics_reporter())

        async def _stop_metrics_reporter() -> None:
            reporter_stop.set()
            if metrics_task is not None:
                try:
                    await asyncio.wait_for(metrics_task, timeout=2.0)
                except Exception:
                    if not metrics_task.done():
                        metrics_task.cancel()
            await _push_live_status("running")

        if modality == "image":
            # The model list does not depend on the challenge: fetch it (blocking HTTP) in a thread
            # while the challenge arrives, so it no longer waits in series before the image call.
            models_future = models_prefetch  # started before registering
            challenge = None
            while True:
                try:
                    challenge = await mcp_client.get_image_challenge(agent_id)
                    break
                except McpArenaError as e:
                    message = str(e).lower()
                    if "locked" in message or "waiting for organizer" in message:
                        print("   Lobby open; waiting for organizer to start battle...")
                        await asyncio.sleep(3.0)
                    else:
                        raise
            print_challenge(challenge)
            # The crash guard knows the challenge from here on: a failure before submit still submits.
            _GUARD.update(challenge=challenge, modality="image")
            # Hard guard starts at challenge receipt, as in the text path.
            image_budget = Budget(challenge.max_time_s or 120)
            _GUARD["budget"] = image_budget
            # The resize after an edit needs the input image: fetch it beside the model call.
            input_prefetch = start_input_prefetch(challenge.input_image_uri or "")
            image_budget.update_server_remaining(float(getattr(challenge, "time_remaining_s", 0) or 0))
            _cap_mcp_retries(mcp_client, image_budget)
            if not usage_scope and scope_refetch_ok:
                usage_scope = await _pre_stage("usage scope", http_client.fetch_usage_scope, None) or resolve_usage_scope()
                if usage_scope:
                    os.environ["ARENA_USAGE_SCOPE"] = usage_scope

            # Bounded like the text path: a failing /models retries for ~25 s and then returns [],
            # which left no model to pick. Fall back to the model cards instead.
            models_timeout = min(IMAGE_MODEL_LIST_TIMEOUT_S, max(0.5, image_budget.remaining() * 0.1))
            try:
                available_models = await asyncio.wait_for(asyncio.shield(models_future), timeout=models_timeout)
            except Exception as exc:
                print(f"   ⚠️  model list unavailable ({exc!r}); using the model cards.")
                available_models = []
            available_models = available_models or _fallback_models()
            image_rules = "\n".join(
                part
                for part in (challenge.prompt, challenge.reference_notes)
                if isinstance(part, str) and part.strip()
            )
            image_prompt = (challenge.prompt or challenge.description or "").strip()
            image_ctx = _build_context(
                challenge_type=challenge.challenge_type,
                description=challenge.description,
                rules=image_rules,
                max_time_s=challenge.max_time_s,
                available_models=available_models,
                image_url=challenge.input_image_uri or None,
            )
            ranked_models = strategy.rank_models(image_ctx, available_models)
            model_name = strategy.pick_model("solve", ranked_models, image_ctx)
            model_name = require_explicit_model(
                model_name,
                available_models,
                source="python_simple agent",
            )
            image_tool_proxy_args = {
                tool_name: build_image_tool_arguments(
                    tool_defs,
                    tool_name,
                    # Per-tool A/B override (MSQUAD_IMAGE_MODEL_EDIT / _GENERATE); unset keeps model_name.
                    selected_model=image_tool_model(tool_name, model_name, available_models),
                    llm_api_key=llm_api_key,
                    arena_api_key=api_key,
                )
                for tool_name in ("image_edit", "image_generate", "image_analyze")
            }
            # IM8 (log only): the model each image tool really calls; MSQUAD_IMAGE_MODEL_EDIT / _GENERATE
            # can differ from the planner, which the record and usage used to report instead.
            image_models = {
                tool_name: image_tool_model(tool_name, model_name, available_models)
                for tool_name in ("image_edit", "image_generate", "image_analyze")
            }
            primary_image_model = image_models["image_edit" if challenge.input_image_uri else "image_generate"]
            print(f"   Selected model: {model_name}")
            print(f"   Image models: {image_models}")
            # The thought is blocking HTTP: send it in a thread and settle it before the submit.
            # A daemon thread, not asyncio.to_thread: asyncio.run waits for the default executor at
            # shutdown, so a hung thought endpoint held exit for the HTTP timeout.
            planner_thought = asyncio.wrap_future(
                _warm_submit(http_client.broadcast_thought, agent_id, f"Selected planner model: {model_name}")
            )
            await _start_metrics_reporter(primary_image_model)

            start_ms = time.time() * 1000
            prompt_text = strategy.build_image_prompt(image_ctx).strip() or image_prompt
            image_tools = [
                tool_name
                for tool_name in ("image_edit", "image_generate", "image_analyze")
                if tool_name in tools
            ]
            image_tool_sequence = _plan_image_tool_sequence(
                strategy,
                image_ctx,
                image_tools,
            )
            selected_tool = image_tool_sequence[-1] if image_tool_sequence else ""
            tool_result: dict = {}
            mcp_session_dead = False

            image_calls: list[dict] = []  # IM8 (log only): every image tool call's model and exact prompt

            def _note_image_call(name: str, arguments: dict) -> None:
                if not str(name).startswith("image_"):
                    return
                try:
                    prompt = str(arguments.get("prompt") or "")
                    image_calls.append({
                        "tool": name,
                        "model": str(arguments.get("model") or image_models.get(name) or ""),
                        "prompt_len": len(prompt),
                        "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
                        "prompt": prompt[:4000],
                        "attempt": 1 + sum(1 for c in image_calls if c["tool"] == name),
                    })
                except Exception:
                    pass

            async def _call_image_tool(name: str, arguments: dict, cap_s: float | None = None) -> dict:
                nonlocal mcp_session_dead
                _note_image_call(name, arguments)
                # Every image call ends before the guard minus the submit margin: a slow tool
                # (chaos-image-slow: 200 s on a 150 s limit) must not make the run late. A timeout is
                # not a dead session, so the submit still goes over MCP with the fallback image.
                timeout_s = image_budget.remaining() - image_budget.margin_s
                if cap_s is not None:
                    timeout_s = min(timeout_s, cap_s)
                if timeout_s <= 0:
                    print(f"   Image tool {name} skipped: no time left before the submit margin")
                    return {"error": "no time left"}
                try:
                    # asyncio.wait, not wait_for: wait_for waits for the cancelled call to unwind, and
                    # a call that is slow to cancel would hold the run past the deadline anyway.
                    call = asyncio.ensure_future(mcp_client.call_tool(name, arguments))
                    done, _ = await asyncio.wait({call}, timeout=timeout_s)
                    if not done:
                        call.cancel()
                        call.add_done_callback(lambda task: task.cancelled() or task.exception())
                        print(f"   Image tool {name} timed out after {timeout_s:.0f}s; using the fallback image")
                        return {"error": "timeout"}
                    result = call.result()
                    return result if isinstance(result, dict) else {}
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    mcp_session_dead = True
                    print(f"   Image tool {name} failed ({type(exc).__name__}): {exc}")
                    return {}

            if "arena.get_challenge" in tools:
                # The image challenge does not list required tools; the server does at submit,
                # and scores a missing text challenge fetch as quality 0. Fetch it up front, never
                # in the background where the submit margin could cancel it.
                # Capped: a hung fetch used the whole image window and a blank image was submitted
                # (hang audit F-C). An image with weaker text grounding beats a blank one.
                await _call_image_tool("arena.get_challenge", {"agent_id": agent_id}, cap_s=IMAGE_TEXT_FETCH_TIMEOUT_S)

            async def _bookkeeping_calls() -> None:
                # The image path needs 3 unique tools too (scoring cap is 3): top up the cheap ones.
                used = await ensure_tool_coverage(mcp_client, agent_id, {"arena.image.get_challenge"})
                print(f"   Tool coverage (image): {len(used)} unique")

            # Coverage only has to land before the submit, so it runs beside the image call instead
            # of in front of it. A failure here cannot close the shared session under the image call
            # (ResilientMcp drops the connection only from the last call in flight).
            bookkeeping = asyncio.ensure_future(_bookkeeping_calls())
            if (
                len(image_tool_sequence) > 1
                and image_tool_sequence[0] == "image_analyze"
                and challenge.input_image_uri
            ):
                print("   Using image_analyze before output tool")
                analysis_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(analysis_result.get("text") or "").strip()
                if analysis_text:
                    _post_in_background(http_client.broadcast_thought,
                        agent_id,
                        "Image analysis done.",
                    )
                    prompt_text = (
                        f"{prompt_text}\n\n"
                        "Source-image analysis to preserve while transforming: "
                        f"{analysis_text[:1000]}"
                    )
            if (
                selected_tool == "image_edit"
                and challenge.input_image_uri
                and "image_edit" in image_tools
            ):
                print("   Using image_edit tool")
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif selected_tool == "image_generate" and "image_generate" in image_tools:
                print("   Using image_generate tool")
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )
            elif (
                selected_tool == "image_analyze"
                and challenge.input_image_uri
                and "image_analyze" in image_tools
            ):
                print("   Using image_analyze tool (no image output tool available)")
                tool_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(tool_result.get("text") or "").strip()
                if analysis_text:
                    _post_in_background(http_client.broadcast_thought,
                        agent_id,
                        "Image analysis done.",
                    )
            elif challenge.input_image_uri and "image_edit" in image_tools:
                selected_tool = "image_edit"
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif "image_generate" in image_tools:
                selected_tool = "image_generate"
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )

            if tool_result.get("error"):
                print(f"   Tool warning: {tool_result.get('error')}")

            # Required-tools gate: a required tool that is never called zeroes quality.
            # Call each missing one the server listed, then keep the chosen output.
            # The submit tool is the final call itself, so it is never a missing requirement here.
            called_image_tools = set(image_tool_sequence) | {
                selected_tool,
                "arena.image.get_challenge",
                "arena.image.submit_edit",
            }
            for missing_name in missing_required_tools(challenge.required_tools, called_image_tools):
                if missing_name not in tools:
                    print(f"   Required tool unavailable on this server: {missing_name}")
                    continue
                if missing_name == "image_generate":
                    extra_args = {"prompt": prompt_text}
                elif missing_name in {"image_edit", "image_analyze"} and challenge.input_image_uri:
                    extra_args = {"image_uri": challenge.input_image_uri, "prompt": prompt_text}
                else:
                    print(f"   Required tool not handled by the image path: {missing_name}")
                    continue
                print(f"   Required tool added: {missing_name}")
                await _call_image_tool(
                    missing_name,
                    {**extra_args, **image_tool_proxy_args.get(missing_name, {})},
                )
                called_image_tools.add(missing_name)
            output_image_uri = _usable_image_uri(tool_result)
            # Walk the roster: a blank result, or a 402/403/429 (model unavailable), moves on to the
            # next image model. Blank is submitted only once no roster model remains in time.
            if not output_image_uri and selected_tool in {"image_generate", "image_edit"}:
                # Without a model parameter the same tool gets one retry; with one, the roster is walked.
                supports_model = "model" in image_tool_proxy_args.get(selected_tool, {})
                alternates = (
                    [name for name in ranked_models if name != model_name] if supports_model else []
                ) or [model_name]
                for alternate in alternates:
                    if time.time() * 1000 - start_ms >= challenge.max_time_s * 500:
                        break
                    print(
                        f"   No usable image from {selected_tool} ({_failure_reason(tool_result)}); "
                        f"trying {alternate}"
                    )
                    retry_args = {"prompt": prompt_text, "agent_id": agent_id}
                    if selected_tool == "image_edit":
                        retry_args["image_uri"] = challenge.input_image_uri
                    retry_args.update(image_tool_proxy_args.get(selected_tool, {}))
                    if supports_model:
                        retry_args["model"] = alternate
                    tool_result = await _call_image_tool(selected_tool, retry_args)
                    output_image_uri = _usable_image_uri(tool_result)
                    if output_image_uri:
                        break
            if not output_image_uri and challenge.input_image_uri:
                output_image_uri = challenge.input_image_uri
            if not output_image_uri:
                # Never withhold the submission: a blank image can still earn tools and speed points.
                print("   No usable image after the retry; submitting the blank result")
                output_image_uri = BLANK_PNG_DATA_URI
            if (
                selected_tool == "image_generate"
                and not challenge.input_image_uri
                and "image_analyze" in image_tools
                and output_image_uri != BLANK_PNG_DATA_URI
            ):
                # Off unless MSQUAD_GENERATE_SELF_CHECK=1 (or DEFAULT_ENABLED): one analyze for legible text, one regeneration.
                async def _self_check_call(name: str, arguments: dict) -> dict:
                    # Not _call_image_tool: an optional check that fails must not mark the MCP session
                    # dead, or the real submit would fall back to REST. The helper catches and keeps image 1.
                    _note_image_call(name, arguments)
                    result = await mcp_client.call_tool(name, arguments)
                    return result if isinstance(result, dict) else {}

                output_image_uri, check_note = await recheck_for_text(
                    _self_check_call,
                    image_uri=output_image_uri,
                    prompt=prompt_text,
                    remaining_s=image_budget.remaining,
                    usable=_usable_image_uri,
                    analyze_args={"agent_id": agent_id, **image_tool_proxy_args.get("image_analyze", {})},
                    generate_args={"agent_id": agent_id, **image_tool_proxy_args.get("image_generate", {})},
                )
                if check_note != "off":
                    print(f"   Text self-check: {check_note}")
            if selected_tool == "image_edit" and challenge.input_image_uri and (
                output_image_uri != challenge.input_image_uri
            ):
                # Edits come back at the model's own size; match the input so the judge compares like with like.
                output_image_uri = await _match_input_size(
                    output_image_uri, challenge.input_image_uri, image_budget, input_prefetch,
                    str(getattr(challenge, "prompt", "") or ""),
                )
            _GUARD.update(answer=output_image_uri, challenge=challenge, modality="image")
            bookkeeping_timeout_s = max(
                0.0, min(IMAGE_COVERAGE_WAIT_S, image_budget.remaining() - image_budget.margin_s)
            )
            done, _ = await asyncio.wait({bookkeeping}, timeout=bookkeeping_timeout_s)
            if not done:
                bookkeeping.cancel()
                bookkeeping.add_done_callback(lambda task: task.cancelled() or task.exception())
                print("   Tool coverage calls still running; submitting anyway")
            elif bookkeeping.exception() is not None:
                print(f"   Tool coverage calls failed: {bookkeeping.exception()}")

            total_time_ms = int(time.time() * 1000 - start_ms)
            await _stop_metrics_reporter()
            client_metrics = {
                # The model the image tool really called (IM8): the same name the live status reports,
                # so an MSQUAD_IMAGE_MODEL_* override is not submitted as the planner (Fable on #350).
                # The tool the planner actually chose, which can be the other one (Fable nit on #356).
                "model_name": image_models.get(selected_tool, primary_image_model),
                "planner_tool": selected_tool,
                "total_tokens": str(live_total_tokens),
                "prompt_tokens": str(live_prompt_tokens),
                "completion_tokens": str(live_completion_tokens),
                "ttft_ms": 0,
                "total_time_ms": total_time_ms,
            }
            try:  # the planner thought normally finished long ago; never wait past 2 s for it
                await asyncio.wait_for(asyncio.shield(planner_thought), timeout=2.0)
            except Exception:
                pass
            if (
                not ensure_thought(http_client, agent_id, "Image ready; submitting.")
                and not mcp_session_dead
                and "arena.image.broadcast_thought" in tools
            ):
                if await _image_thought_over_mcp(mcp_client, agent_id, image_budget) == "timeout":
                    # Fable on #241: the transport did not answer in 3 s; submit_image would hang on it too.
                    mcp_session_dead = True
            if mcp_session_dead:
                await session_monitor.stop()
                print("   MCP session unavailable; submitting image over REST")
                image_submit_result = resilience.submit_resilient(
                    http_client,
                    agent_id,
                    answer=output_image_uri,
                    client_metrics=client_metrics,
                    challenge_type="image",
                    budget_s=_submit_budget_s(),
                )
            else:
                mcp_submit_s = max(
                    min(IMAGE_SUBMIT_MCP_MIN_S, IMAGE_SUBMIT_MCP_TIMEOUT_S),
                    min(
                        IMAGE_SUBMIT_MCP_TIMEOUT_S,
                        image_budget.remaining() - image_budget.margin_s - IMAGE_SUBMIT_REST_RESERVE_S,
                    ),
                )
                try:
                    # asyncio.wait, not wait_for: wait_for waits for the cancelled submit to unwind,
                    # and a transport slow to cancel would hold the REST fallback (as in #201).
                    submit_call = asyncio.ensure_future(
                        mcp_client.submit_image(
                            agent_id=agent_id,
                            image_uri=output_image_uri,
                            client_metrics=client_metrics,
                            rationale=image_rationale_for(challenge),
                        )
                    )
                    done, _ = await asyncio.wait({submit_call}, timeout=mcp_submit_s)
                    if not done:
                        submit_call.cancel()
                        submit_call.add_done_callback(lambda task: task.cancelled() or task.exception())
                        raise asyncio.TimeoutError(f"MCP submit_image did not answer in {mcp_submit_s:.1f}s")
                    image_submit_result = submit_call.result()
                except McpArenaError:
                    raise  # the server answered (a rejection): not a transport problem
                except (asyncio.TimeoutError, Exception) as exc:
                    # A hung or broken transport at submit time: the same image over REST. If the
                    # MCP submit did land, REST gets a 409 and returns the landed receipt.
                    print(f"   MCP image submit failed ({exc!r}); submitting image over REST")
                    await session_monitor.stop()
                    image_submit_result = resilience.submit_resilient(
                        http_client,
                        agent_id,
                        answer=output_image_uri,
                        client_metrics=client_metrics,
                        challenge_type="image",
                        budget_s=_submit_budget_s(),
                    )
            _GUARD["submitted"] = True
            for line in submission_summary_lines(image_submit_result):
                print(f"   {line}")
            await session_monitor.stop()
            # Last steps, after the submission is final; neither raises.
            run_tag = f"{challenge.puzzle_id}-{time.strftime('%Y%m%dT%H%M%S')}"
            print(f"   Image: {save_submitted_image(agent_id, output_image_uri, REPO_ROOT, run_tag=run_tag)}")
            if isinstance(image_submit_result, dict):
                image_result = image_submit_result
            else:  # REST fallback returns a SubmitResult
                image_result = {
                    "accepted": getattr(image_submit_result, "accepted", None),
                    "score": getattr(image_submit_result, "score", None),
                }
            score = image_result.get("score") if isinstance(image_result.get("score"), dict) else {}
            run_record = {
                "agent_id": agent_id,
                "challenge": challenge_record(challenge),
                "model": model_name,
                "image_tool_sequence": image_tool_sequence,
                "image_models": image_models,
                "image_calls": image_calls,
                "tool_calls": tool_trace.calls(),
                "submission": {
                    **image_facts(output_image_uri),
                    "prompt": bounded(prompt_text),
                    "tool": selected_tool,
                },
                "result": {
                    "accepted": image_result.get("accepted"),
                    "score": {key: value for key, value in score.items() if key != "output_image_uri"},
                    # The judge's own text, when the submit response carries one. It names the broken axis.
                    "judge_text": bounded(
                        score.get("judge_detail") or score.get("judge_reason") or judge_reason_of(score),
                        1000,
                    ),
                },
            }
            print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
            print("\n✅ Agent completed!")
            return

        # Wait for organizer to start (challenge is locked while lobby is open)
        challenge = None
        while True:
            try:
                if early_challenge_task is not None:
                    # MSQUAD_EARLY_CHALLENGE: the fetch already in flight is this call; a retry is a new one.
                    pending, early_challenge_task = early_challenge_task, None
                    challenge = await pending
                else:
                    challenge = await mcp_client.get_challenge(agent_id)
                break
            except McpArenaError as e:
                message = str(e).lower()
                if "locked" in message or "waiting for organizer" in message:
                    print("   Lobby open; waiting for organizer to start battle...")
                    await asyncio.sleep(3.0)
                else:
                    raise
        print_challenge(challenge)
        # The crash guard knows the challenge from here on: a failure before submit still submits.
        _GUARD.update(challenge=challenge, modality="text")
        evidence_window.set_question(str(challenge.description or ""))  # what an oversized result is windowed on
        stages.mark("get_challenge")
        # Hard guard starts at challenge receipt: everything after this counts, including model lookup.
        budget = Budget(challenge.max_time_s or 60)
        _GUARD["budget"] = budget
        budget.update_server_remaining(float(getattr(challenge, "time_remaining_s", 0) or 0))
        _cap_mcp_retries(mcp_client, budget)
        clock.time_limit_s = float(challenge.max_time_s or 60)
        if not usage_scope and scope_refetch_ok:
            # Fetched once after the MCP connect; ask again only if that came back empty (not hung).
            usage_scope = await _pre_stage("usage scope", http_client.fetch_usage_scope, None) or resolve_usage_scope()
            if usage_scope:
                os.environ["ARENA_USAGE_SCOPE"] = usage_scope
        llm_client = None
        if llm_client_ready is not None and llm_client_scope == usage_scope:
            try:
                llm_client = await asyncio.wrap_future(llm_client_ready)
            except Exception:
                llm_client = None  # the warm build failed: build it here, as before
        if llm_client is None:
            llm_client = _openai_class()(
                base_url=llm_host,
                api_key=llm_api_key,
                default_headers=build_proxy_headers(agent_id, usage_scope),
            )
        print("   LLM: Enabled")
        stages.mark("usage scope + llm client")
        print()

        models_timeout = min(MODEL_LIST_TIMEOUT_S, max(3.0, budget.remaining() * 0.1))
        # The model list, the first thought and the clue reads do not depend on each other:
        # run them together (live they ran one after another, about 4 s in all).
        async def _prefetched_models():
            # Started before registering; still bounded here like a fresh fetch.
            try:
                return await asyncio.wait_for(asyncio.shield(models_prefetch), timeout=models_timeout)
            except Exception as exc:
                print(f"   ⚠️  model list timed out or failed ({exc!r}); continuing.")
                return None

        models_task = asyncio.ensure_future(_prefetched_models())
        thought_task = asyncio.ensure_future(
            _pre_stage("thought", lambda: http_client.broadcast_thought(agent_id, "Reading challenge and clues..."), None)
        )
        # An empty list is retried, then clue_0.. are probed: solving without clues is a guess.
        if early_clues_task is not None:
            # MSQUAD_EARLY_CHALLENGE: the reads began when the challenge proved a text heat; read now
            # only if they did not start (a failed early fetch), so the calls match the serial path.
            async def _early_or_fresh_clues(task=early_clues_task):
                result = await task
                return result if result is not None else await read_clues(mcp_client, agent_id)

            clues_task = asyncio.ensure_future(_early_or_fresh_clues())
        else:
            clues_task = asyncio.ensure_future(read_clues(mcp_client, agent_id))
        available_models = await models_task or _fallback_text_models()
        stages.mark("model list")  # log only: split the scored "clues" stage (models / reporter / thought / reads)
        model_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            max_time_s=challenge.max_time_s,
            available_models=available_models,
        )
        ranked_models = strategy.rank_models(model_ctx, available_models)
        model_name = strategy.pick_model("solve", ranked_models, model_ctx)
        model_name = require_explicit_model(
            model_name,
            available_models,
            source="python_simple agent",
        )
        print(f"   Selected model: {model_name}")
        await _start_metrics_reporter(model_name)
        stages.mark("reporter start")
        
        
        # Get all clues
        # Hard guard starts at challenge start: clue reading and tool calls count.
        print("\n📖 Reading clues...")
        late_thought = late_thought_await_enabled()
        if not late_thought:
            await thought_task
        stages.mark("first thought")
        # Bounded: a clue read that never answers falls back to the challenge's own clues.
        clues_timeout = min(TEXT_CLUES_TIMEOUT_S, max(1.0, budget.remaining() - budget.margin_s - TEXT_SOLVE_RESERVE_S))
        clue_ids, clues = await _bounded(clues_task, clues_timeout, ([], []), "clue read")
        stages.mark("clues")
        if not clues:
            clues = [str(clue_text) for clue_text in challenge.clues]
        if layered_decode.enabled() and str(challenge.challenge_type or "").strip().lower() != "code":
            # Code clues are executable source: decoding can change identifiers and string literals.
            # encoded clues (base64 -> rot13, hex, ...) decoded in code; the model reads the plain text
            clues = layered_decode.annotate_clues(clues, str(challenge.description or ""))
        # Near-zero-cost calls: three unique tools per run (scoring cap is 3).
        tools_used = _clue_tools_used(clue_ids)
        tools_used = await _bounded(
            ensure_tool_coverage(mcp_client, agent_id, tools_used), TEXT_COVERAGE_TIMEOUT_S, tools_used, "tool coverage"
        )

        _GUARD.update(challenge=challenge, clues=clues)
        budget.update_server_remaining(await clock.remaining())
        stage_end = time.monotonic() + budget.tool_stage_s()
        tool_evidence_lines = await _enforce_required_tool_calls(
            mcp_client=mcp_client,
            agent_id=agent_id,
            challenge_type=str(challenge.challenge_type or ""),
            description=str(challenge.description or ""),
            rules=str(challenge.rules or ""),
            clues=clues,
            available_tool_names=[str(name) for name in tools],
            http_client=http_client,
            extra_context=str(getattr(challenge, "extra_text", "") or ""),
            server_required=challenge.required_tools,
            budget=budget,
            stage_end=stage_end,
            already_used=tools_used,
        )
        stages.mark("required tool calls")
        
        if str(challenge.challenge_type or "").strip().lower() == "retrieval" and _needs_second_entity(
            f"{challenge.description or ''} {challenge.rules or ''}"
        ):
            hop_lines = await _second_hop_evidence(
                mcp_client=mcp_client,
                agent_id=agent_id,
                available_tool_names=[str(name) for name in tools],
                question=f"{challenge.description or ''} {challenge.rules or ''}",
                evidence_lines=list(tool_evidence_lines),
                budget=budget,
                stage_end=stage_end,
            )
            print(f"   second hop: +{len(hop_lines)} documents", flush=True)
            tool_evidence_lines = list(tool_evidence_lines) + hop_lines
        if str(challenge.challenge_type or "").strip().lower() == "retrieval":
            feedback_lines = await _feedback_evidence(
                mcp_client=mcp_client,
                agent_id=agent_id,
                available_tool_names=[str(name) for name in tools],
                question=str(challenge.description or ""),
                answer_format=str(getattr(challenge, "answer_format", "") or ""),
                evidence_lines=list(tool_evidence_lines),
                budget=budget,
                stage_end=stage_end,
            )
            if feedback_lines:
                print(f"   feedback search: +{len(feedback_lines)} documents", flush=True)
                tool_evidence_lines = list(tool_evidence_lines) + feedback_lines
        _GUARD.update(evidence=list(tool_evidence_lines))  # the deadline guard's fallback can read it
        # Broadcast thought
        _post_in_background(http_client.broadcast_thought, agent_id, f"Analyzing {len(clues)} clues...")
        
        # Save draft (backup): a well-formed guess from the clues, not a placeholder string, in case
        # the last draft is ever what counts on a timeout. The solved answer replaces it below.
        try:
            first_draft = _fallback_with_evidence(challenge, clues, getattr(challenge, "rules", ""), tool_evidence_lines)
        except Exception:
            first_draft = ""
        _post_in_background(http_client.save_draft, agent_id, first_draft or "Working on solution...", "clue-based fallback")
        
        # Step 3: Solve
        print("\n🧠 Solving...")
        _post_in_background(http_client.broadcast_thought, agent_id, "Calling LLM...")
        answer_format = str(getattr(challenge, "answer_format", "") or "")
        solve_rules = str(challenge.rules or "")
        if answer_format_rules.enabled():
            solve_rules = answer_format_rules.solve_rules_for(solve_rules, answer_format)
        elif "json" in answer_format.lower():
            # msquad: the answer format decides the contract (JSON, not a comma list).
            solve_rules = f"{solve_rules}\nAnswer format: {answer_format}".strip()
        solve_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=solve_rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
        )
        
        ticker = ReasoningTicker(model_name)
        def _solve_on(solve_model: str):
            return solve_challenge(
                challenge,
                clues,
                llm_client,
                solve_model,
                strategy,
                solve_ctx,
                http_client=http_client,
                agent_id=agent_id,
                broadcast_thought=True,
                evidence_lines=tool_evidence_lines,
                ticker=ticker,
                budget=budget,
            )

        try:
            # A failed call (for example HTTP 400) gets one try on the next roster model.
            model_name, result = await solve_with_model_fallback(
                _solve_on,
                ranked_models,
                model_name,
                budget.remaining,
                RESOLVE_MIN_REMAINING_S,
                fastest=lambda current: strategy.fastest_model(ranked_models, str(challenge.challenge_type or ""), current),
                submit_margin_s=SUBMIT_MARGIN_S,
            )
            answer, raw_response, model_name, usage, ttft_ms, total_time_ms = result
        except Exception as exc:  # timeout or transport error: submit the fallback, never nothing
            print(f"   ⚠️  LLM call failed ({exc}); submitting fallback.")
            answer, raw_response, usage, ttft_ms, total_time_ms = "", "", {"finish_reason": "error"}, 0, 0
        # Hard-mode distractors can name people who are not in this puzzle. An answer
        # with an outsider is re-solved once with the real entity list stated.
        entities = entities_from_challenge(challenge.description)
        outsiders = outside_names(answer, entities)
        # An empty or placeholder answer ("-") is never submitted while time remains.
        if needs_resolve(getattr(strategy, "_task", ""), answer, outsiders, str(challenge.challenge_type or "")) and budget.remaining() > RESOLVE_MIN_REMAINING_S:
            print(f"   ⚠️  Answer {answer!r} is empty or names people outside the puzzle {outsiders}; re-solving once.")
            try:
                retry = await solve_challenge(
                    challenge,
                    clues,
                    llm_client.with_options(timeout=budget.llm_timeout(), max_retries=1),
                    model_name,
                    strategy,
                    solve_ctx,
                    http_client=http_client,
                    agent_id=agent_id,
                    broadcast_thought=False,
                    evidence_lines=[*tool_evidence_lines, *([entity_note(entities)] if entities else [])],
                    budget=budget,
                )
                if not is_placeholder(retry[0]) and not outside_names(retry[0], entities):
                    answer, raw_response, model_name, usage, ttft_ms, total_time_ms = retry
            except Exception as exc:  # keep the first answer if the re-solve fails
                print(f"   ⚠️  Re-solve failed ({exc}); keeping the first answer.")
        ticker.finish()
        async def _remaining_s() -> float:
            return await clock.remaining()

        def _solve_with(retry_model: str):
            nonlocal ticker
            _post_in_background(http_client.broadcast_thought, agent_id, f"Retrying with {retry_model}...")
            ticker = ReasoningTicker(retry_model)
            return solve_challenge(
                challenge,
                clues,
                llm_client,
                retry_model,
                strategy,
                solve_ctx,
                http_client=http_client,
                agent_id=agent_id,
                broadcast_thought=True,
                evidence_lines=tool_evidence_lines,
                ticker=ticker,
                budget=budget,
            )

        answer, raw_response, model_name, usage, ttft_ms, total_time_ms = await _retry_after_length_stop(
            (answer, raw_response, model_name, usage, ttft_ms, total_time_ms),
            ranked_models=ranked_models,
            remaining_s=_remaining_s,
            solve_with=_solve_with,
        )
        ticker.finish()
        for line in summary_lines(
            model=model_name,
            elapsed_s=total_time_ms / 1000,
            usage=usage,
            finish_reason=str(usage.get("finish_reason") or ""),
            answer=answer,
            ticker=ticker,
        ):
            print(line)
        
        # Deterministic normalization first; one cheap repair call only if it
        # fails validation and the clock allows it.
        finalized = strategy.finalize_answer(raw_response, solve_ctx)
        # The logic solver's answer is already validated; clue-inferred names can miss some.
        logic_solved = normalize_entity_answer(
            solve_logic_from_challenge(
                f"{challenge.description}\n{challenge.rules}\n{getattr(challenge, 'answer_format', '')}",
                clues,
            ),
            str(challenge.rules or ""),
        )
        if not finalized.valid and not logic_solved and budget.remaining() - budget.margin_s > 15:
            print(f"   ⚠️  Reply rejected ({finalized.reason}); asking for a bare answer once.")
            repair_raw = _repair_answer(
                llm_client.with_options(timeout=budget.llm_timeout(), max_retries=0),
                model_name, raw_response, solve_ctx, finalized.reason,
            )
            repaired = strategy.finalize_answer(repair_raw, solve_ctx)
            print(
                f"   first reply: {finalized.answer!r} valid={finalized.valid} ({finalized.reason or 'ok'}); "
                f"repair: {repaired.answer!r} valid={repaired.valid} ({repaired.reason or 'ok'})"
            )
            # A valid first answer is never replaced by the repair.
            finalized = choose_final_answer(finalized, repaired)
            print(f"   using: {finalized.answer!r}")
        if not finalized.valid:
            # A reply cut off mid-thought: submit an order it stated, never the reasoning.
            salvaged = salvage_final_answer(finalized, raw_response, solve_ctx)
            if salvaged.valid:
                print(f"   salvaged order from reasoning: {salvaged.answer!r}")
            finalized = salvaged
        answer = logic_solved or finalized.answer
        literal_empty_ok = accepts_literal_empty(str(challenge.challenge_type or ""), answer)
        if (not literal_empty_ok and _is_invalid_answer_candidate(answer)) or is_logic_refusal(answer, str(challenge.challenge_type or "")):
            answer = ""
        if finalized.reason == "reasoning, not a short answer" and not logic_solved:
            # Never submit a long reasoning dump; the fallback below tries the last line. A logic
            # answer that only justifies itself keeps its head ("Ava because ..." -> "Ava"):
            # a blank scores 0 for sure (Fable on #248).
            answer = logic_answer_before_reasoning(
                finalized.answer, str(challenge.challenge_type or ""), str(challenge.rules or ""),
                entities_from_challenge(challenge.description),
            )
        # msquad: reconstruct entity names without changing literal code output.
        if str(challenge.challenge_type or "").strip().lower() != "code":
            answer = collapse_single_value(answer, str(challenge.rules or ""), list(clues) + list(tool_evidence_lines))
        if not answer:
            print("   ⚠️  No valid ANSWER format found; normalizing last line as fallback.")
            answer = _last_resort_answer(raw_response, challenge, clues, solve_ctx, strategy, tool_evidence_lines)

        if is_json_answer_shape(
            str(challenge.challenge_type or ""),
            str(challenge.rules or ""),
            str(challenge.description or ""),
        ):
            # MSQUAD_ORDER_FROM_RULES (astra H): with the arm on, an order stated in the rules counts too.
            order_text = order_from_rules.question_text(
                str(challenge.description or ""), str(challenge.rules or ""), str(getattr(challenge, "answer_format", "") or "")
            )
            answer = natural_order(answer, order_text, clue_texts=clues)

        if (
            str(challenge.challenge_type or "").strip().lower() == "retrieval"
            and budget.remaining() - budget.margin_s > GROUNDING_REASK_MIN_S
        ):
            # msquad: an answer made of clue words that no fetched document contains came from a
            # distractor clue, not the documents; ask once more from the documents alone.
            documents = grounding.document_texts(list(tool_evidence_lines))
            if grounding.clue_built_ungrounded(answer, documents, list(clues)):
                print(f"   ⚠️  Answer {answer!r} is in no document (clue words); re-asking from the documents.")
                reask_raw = _single_answer_call(
                    llm_client.with_options(timeout=budget.llm_timeout(), max_retries=0),
                    model_name,
                    grounding.reask_prompt(str(challenge.description or ""), str(challenge.rules or ""), documents),
                )
                reasked = strategy.finalize_answer(reask_raw, solve_ctx)
                if reasked.valid and grounding.is_grounded(reasked.answer, documents):
                    print(f"   grounded re-ask: {reasked.answer!r}")
                    answer = reasked.answer

        _GUARD["answer"] = answer
        if str(challenge.challenge_type or "").strip().lower() == "structured":
            # msquad: check the answer against the described shape; re-ask once when time allows.
            answer, shape_note = await resolve_shape_answer(
                answer,
                answer_format=str(getattr(challenge, "answer_format", "") or ""),
                rules=str(challenge.rules or ""),
                task=str(challenge.description or ""),
                llm_client=llm_client.with_options(timeout=max(1.0, budget.remaining() - budget.margin_s), max_retries=0),
                model_name=model_name,
                remaining_s=budget.remaining(),
                margin_s=SUBMIT_MARGIN_S,
            )
            if shape_note:
                print(f"   Shape check: {shape_note}")
        answer = _cut_stream_answer(answer, raw_response, challenge)
        # Save draft with extracted answer as backup
        _post_in_background(http_client.save_draft, agent_id, answer, "LLM solution")
        # Thoughts are public: never echo the answer, the clues or the solver output here.
        _post_in_background(http_client.broadcast_thought, agent_id, "Answer ready; submitting.")
        
        # Check time remaining. Arm (MSQUAD_FINALIZE_LOCAL_CLOCK): well clear of the deadline, the
        # budget synced at the tool stage answers without the ~0.5 s live clock read.
        remaining_s = await finalize_clock.finalize_remaining(clock, budget)
        submit_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            time_remaining_s=remaining_s,
            tokens_used=usage.get("total_tokens", 0),
        )
        if not answer:
            answer = _fallback_with_evidence(challenge, clues, getattr(challenge, "rules", ""), tool_evidence_lines)
        budget.set_draft(answer)
        if strategy.should_submit_early(answer, submit_ctx):
            _post_in_background(http_client.broadcast_thought, agent_id, "⚡ Strategy submitting early.")
        revised_answer = strategy.on_time_warning(remaining_s, answer, submit_ctx)
        if isinstance(revised_answer, str) and revised_answer.strip():
            answer = revised_answer.strip()
        print(f"   Time remaining: {remaining_s:.1f}s")
        stages.mark("solve")
        if submit_before_close.enabled():
            deferred_mcp = mcp_stack.pop_all()  # closed after the POST, in this same task
    # astra R (MSQUAD_SUBMIT_BEFORE_CLOSE): with the arm on, the MCP stack was detached at the end of the
    # solve; it is closed in the finally below, in this same task, whether the POST succeeds or this
    # span raises (an SSE session left open as main() unwinds held the process open; F-B, Fable on #341).
    try:
        # Log only: the MCP stack above has just closed (bounded by CLOSE_TIMEOUT_S, 3 s). Its own stage
        # shows whether that close costs scored time before the submit POST (astra R).
        stages.mark("mcp close")

        # Optional second-model check (msquad/verify.py), flag-gated by MSQUAD_VERIFY=1.
        if verify_enabled(
            str(getattr(challenge, "difficulty", "") or ""),
            remaining_s,
            float(challenge.max_time_s or 0),
            os.getenv("MSQUAD_VERIFY", ""),
        ) and should_verify(remaining_s, usage.get("total_tokens", 0), 0):
            async def _resolve(hctx):
                return (await solve_challenge(
                    challenge, clues, llm_client, model_name, strategy, hctx,
                ))[0]

            answer = await verify_and_maybe_resolve(
                answer,
                llm_client=llm_client.with_options(timeout=max(1.0, budget.remaining() - budget.margin_s), max_retries=0),
                verifier_model=pick_verifier_model(ranked_models, model_name),
                challenge_text=str(challenge.description or ""),
                clues=[(f"c{i + 1}", text) for i, text in enumerate(clues)],
                ctx=submit_ctx,
                remaining_s=remaining_s,
                resolve=_resolve,
            )

        answer = _normalize_answer_shape(answer, getattr(challenge, "answer_format", ""))

        # Step 4: Submit the extracted answer with real metrics
        stages.mark("solve + finalize")
        print("\n📤 Submitting answer...")
        # The server clock runs until the submission arrives, so nothing slow goes before it: the
        # reporter is stopped without waiting, and no extra thought is sent (one already went out
        # while reading the clues). Live, this bookkeeping took about 3.9 s before the POST.
        reporter_stop.set()
        if metrics_task is not None and not metrics_task.done():
            metrics_task.cancel()
        if late_thought:
            await thought_task  # bounded by _pre_stage; ensure_thought below is the fallback, as before
        stages.mark("late thought")  # log only: the live "submit" stage was 2.56 s median; split it
        ensure_thought(http_client, agent_id)  # no-op when a thought was already accepted
        stages.mark("ensure thought")  # after this, "submit" is the POST alone

        result = resilience.submit_resilient(
            http_client,
            agent_id,
            answer=answer,
            budget_s=_submit_budget_s(),
            client_metrics={
                "model_name": model_name,
                "total_tokens": str(live_total_tokens),
                "prompt_tokens": str(live_prompt_tokens),
                "completion_tokens": str(live_completion_tokens),
                "ttft_ms": ttft_ms,
                "total_time_ms": total_time_ms,
            }
        )
    
        _GUARD["submitted"] = True
        stages.mark("submit")
    finally:
        if deferred_mcp is not None:
            await deferred_mcp.aclose()  # bounded: ResilientMcp's close has its own CLOSE_TIMEOUT_S
            deferred_mcp = None
            stages.mark("mcp close (after submit)")
    print(f"   Accepted: {result.accepted}")
    print(f"   Status: {result.status}")
    if result.score:
        print(f"   Score: {result.score.get('final_score', 0)}")
        print(f"   Quality: {result.score.get('quality_score', 0)}")
        print(f"   Speed: {result.score.get('speed_score', 0)}")
    if missing_tools_note(result):
        print(f"   ⚠️  {missing_tools_note(result)}")
    
    await session_monitor.stop()
    # Last step, after the submission is final; never raises.
    run_record = {
        "agent_id": agent_id,
        "challenge": challenge_record(challenge),
        "model": model_name,
        "answer": answer,
        "usage": usage,
        "total_time_ms": total_time_ms,
        "streamed_calls": list(_STREAMED_CALLS),
        "tool_calls": tool_trace.calls(),
        "stages": stages.marks,
        "result": {
            "accepted": result.accepted,
            "status": result.status,
            "score": result.score,
        },
    }
    print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
    print("\n✅ Agent completed!")


def run_agent(entry=None) -> int:
    """Run the agent and return the exit code. Once a challenge is fetched, every failure submits."""
    try:
        asyncio.run((entry or main)())
    except resilience.RegistrationTerminal as exc:
        print(f"   {exc}")
        return 1
    except asyncio.CancelledError as exc:
        # Cancelled with a challenge in hand still submits; before one, it is a clean stop.
        return submit_guard_fallback(exc) if _GUARD.get("challenge") is not None else 0
    except ModelSelectionError as exc:
        # Raised after get_challenge too (require_explicit_model), so it must submit like any crash.
        print(f"   {exc}")
        return submit_guard_fallback(exc)
    except Exception as exc:
        return submit_guard_fallback(exc)
    return 0


if __name__ == "__main__":
    raise SystemExit(run_agent())
