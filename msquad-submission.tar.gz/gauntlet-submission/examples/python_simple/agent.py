#!/usr/bin/env python3
"""Simple Agent Gauntlet competitor agent.

This is a minimal example showing how to connect to Agent Gauntlet from any Python code.
It uses:
- HTTP client for Agent Gauntlet coordination (REST API)
- MCP client for challenge tools
- OpenAI SDK for LLM calls via the proxy

Usage:
    cd examples/python_simple
    python agent.py

This example loads `.env` from the repository root automatically.
"""

import asyncio
import importlib.util
import threading
import json
import os
import re
import sys
import time
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

from dotenv import load_dotenv

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path: 
    sys.path.insert(0, str(REPO_ROOT))

load_dotenv(REPO_ROOT / ".env")

from arena_clients.config import agent_id_problem
from arena_clients import (
    build_image_tool_arguments,
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.display import (
    ReasoningTicker,
    challenge_record,
    print_challenge,
    save_run_record,
    summary_lines,
)
from arena_clients.outputs import (
    bounded,
    image_facts,
    missing_tools_note,
    save_submitted_image,
    submission_summary_lines,
)
from arena_clients.required_tools import missing_required_tools, required_tool_names
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from base_strategy import (
    ChallengeContext,
    choose_final_answer,
    salvage_final_answer,
    is_logic_refusal,
    collapse_single_value,
    ensure_tool_coverage,
    extract_final_answer,
    is_json_answer_shape,
    natural_order,
    normalize_entity_answer,
    repair_prompt,
)
from model_selector import (
    ModelSelectionError,
    fetch_available_models,
    require_explicit_model,
)
from my_strategy import MyStrategy
from msquad import resilience
from msquad.budget import SUBMIT_MARGIN_S, Budget, call_with_one_retry, fallback_answer
from msquad.clue_fetch import read_clues
from msquad.stage_timer import StageTimer
from msquad.shape_check import resolve_shape_answer
from msquad.clock import ClockReader
from msquad.big_logic import solve_big_choice
from msquad.knights_solver import solve_knights
from msquad.sequence_solver import solve_sequence
from msquad.numeric_solver import solve_numeric
from msquad.zebra_solver import solve_zebra
from msquad.logic_solver import logic_candidates, solve_logic_from_challenge
from msquad.model_fallback import solve_with_model_fallback
from msquad.code_eval import run_code_challenge
from msquad.presolve import presolve_challenge
from msquad.entities import (
    RESOLVE_MIN_REMAINING_S,
    entities_from_challenge,
    entity_note,
    is_placeholder,
    accepts_literal_empty,
    needs_resolve,
    outside_names,
)
from msquad.verify import (
    pick_verifier_model,
    should_verify,
    verify_and_maybe_resolve,
    verify_enabled,
)

# Use OpenAI SDK for LLM calls through the proxy. Imported only on the text path that
# calls the LLM: importing it costs ~0.7 s, and image and solver-answered runs never use it.
HAS_OPENAI = importlib.util.find_spec("openai") is not None


def _openai_class():
    """The OpenAI client class. A seam: tests patch this instead of the import."""
    from openai import OpenAI

    return OpenAI


BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)


MIN_IMAGE_SIDE_PX = 16


def _png_side_lengths(uri: str) -> tuple[int, int] | None:
    """(width, height) from a PNG data URI's IHDR chunk, or None when it is not a PNG."""
    import base64
    import struct

    prefix = "data:image/png;base64,"
    if not uri.startswith(prefix):
        return None
    try:
        head = base64.b64decode(uri[len(prefix):len(prefix) + 64] + "===")
    except ValueError:
        return None
    if len(head) < 24 or head[12:16] != b"IHDR":
        return None
    return struct.unpack(">II", head[16:24])


# Below this much time left, the resize is skipped: the submit must not wait on it.
RESIZE_MIN_BUDGET_S = 15.0
# Total time allowed for the input fetch (applies to connect, read and write together).
RESIZE_FETCH_TIMEOUT_S = 3.0


async def _match_input_size(output_uri: str, input_uri: str, budget) -> str:
    """Resize an edited image to the input's exact width and height, if they differ.

    Returns the output unchanged when there is less than RESIZE_MIN_BUDGET_S left, when the
    sizes already match, or when either image cannot be read (no Pillow, an unreachable input
    URL after RESIZE_FETCH_TIMEOUT_S, not an image). No crop: the aspect ratio is kept by the
    input's own size, so a mismatch is only a resampling step.
    """
    if budget is None or budget.remaining() < RESIZE_MIN_BUDGET_S:
        return output_uri
    try:
        import base64
        import io

        import httpx
        from PIL import Image
    except ImportError:
        return output_uri

    def fetch(uri: str) -> bytes:
        response = httpx.get(uri, timeout=httpx.Timeout(RESIZE_FETCH_TIMEOUT_S), follow_redirects=True)
        response.raise_for_status()
        return response.content

    async def load(uri: str) -> "Image.Image":
        if uri.startswith("data:image/"):
            raw = base64.b64decode(uri.split(",", 1)[1])
        else:
            # The fetch runs in a worker thread with its own cap, so a slow host cannot hold the submit.
            raw = await asyncio.wait_for(asyncio.to_thread(fetch, uri), timeout=RESIZE_FETCH_TIMEOUT_S)
        return Image.open(io.BytesIO(raw)).convert("RGB")

    try:
        source = await load(input_uri)
        edited = await load(output_uri)
    except Exception:
        return output_uri
    if edited.size == source.size:
        return output_uri
    buffer = io.BytesIO()
    edited.resize(source.size, Image.LANCZOS).save(buffer, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode("ascii")


def judge_reason_of(score: dict) -> str | None:
    """The judge's reason text from a score payload, if it has one."""
    judge = score.get("judge")
    return judge.get("reason") if isinstance(judge, dict) else None


def _usable_image_uri(result: dict) -> str:
    """The generated image, or "" when the result is blank, tiny or a failure."""
    uri = str(result.get("image_uri") or "").strip()
    if not uri or uri == BLANK_PNG_DATA_URI:
        return ""
    sides = _png_side_lengths(uri)
    if sides is not None and min(sides) < MIN_IMAGE_SIDE_PX:
        return ""  # a 1x1 PNG is a valid file, not a picture
    return uri


def _failure_reason(result: dict) -> str:
    """Short reason for the log: a 402/403/429 model failure, or a blank result."""
    text = str(result.get("error") or "")
    match = re.search(r"(402|403|429)", text)
    return f"HTTP {match.group(1)}" if match else "blank result"


def _plan_image_tool_sequence(
    strategy: MyStrategy,
    ctx: ChallengeContext,
    available_tools: list[str],
) -> list[str]:
    """Expand an analysis-first choice into a usable image-output plan."""
    selected_tool = strategy.plan_image_tool(ctx, available_tools)
    if not selected_tool:
        return []
    sequence = [selected_tool]
    if selected_tool != "image_analyze":
        return sequence
    if ctx.image_url and "image_edit" in available_tools:
        sequence.append("image_edit")
    elif "image_generate" in available_tools:
        sequence.append("image_generate")
    return sequence

# Pre-LLM calls (usage scope, model list, thought) run before the solve budget's
# guard. Each gets a short bound so a stalled proxy cannot eat the answer time.
PRE_STAGE_TIMEOUT_S = 5.0
MODEL_LIST_TIMEOUT_S = 15.0


def _settle(future: asyncio.Future, result, error) -> None:
    if not future.done():
        future.set_result((result, error))


async def _pre_stage(label: str, fn, default, timeout_s: float = PRE_STAGE_TIMEOUT_S):
    """Run a blocking call on a daemon thread, wait at most timeout_s, else return default.

    A daemon thread (not the default executor) so a stuck call cannot hold up exit.
    """
    loop = asyncio.get_running_loop()
    future: asyncio.Future = loop.create_future()

    def run() -> None:
        try:
            outcome = (fn(), None)
        except Exception as exc:
            outcome = (None, exc)
        loop.call_soon_threadsafe(_settle, future, *outcome)

    threading.Thread(target=run, daemon=True).start()
    try:
        result, error = await asyncio.wait_for(future, timeout=timeout_s)
    except asyncio.TimeoutError:
        print(f"   ⚠️  {label} timed out after {timeout_s:.0f}s; continuing.")
        return default
    if error is not None:
        print(f"   ⚠️  {label} failed ({error}); continuing.")
        return default
    return result


def _fallback_text_models() -> list[str]:
    """Text models from msquad/model_cards.json, used when the live list is unavailable."""
    import json

    try:
        cards = json.loads((REPO_ROOT / "msquad" / "model_cards.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return [name for name in cards.get("models", {}) if "image" not in name]


def extract_answer(raw_response: str) -> str:
    """Extract the answer line from the LLM response."""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", raw_response, flags=re.DOTALL).strip()

    # Accept either "ANSWER:" or "Final answer:" on its own line.
    for line in cleaned.splitlines():
        match = re.match(
            r"^\s*(?:answer|final answer)\s*:\s*(.+?)\s*$",
            line,
            flags=re.IGNORECASE,
        )
        if match:
            answer = match.group(1).strip().strip("`\"'")
            if answer:
                return answer

    return ""


def _challenge_text_blob(
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
) -> str:
    return " ".join(
        [challenge_type or "", description or "", rules or "", extra_context or ""]
    ).lower()


_DOC_CUE_RE = re.compile(
    r"\b(documents?|docs?|records?|corpus|archives?|memos?|rosters?|directory|catalogue?|database)\b"
)


def _required_runtime_tools(
    available_tool_names: list[str],
    *,
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
    server_required: list[str] | None = None,
) -> list[str]:
    blob = _challenge_text_blob(challenge_type, description, rules, extra_context)
    required: list[str] = []
    for tool_name in available_tool_names:
        normalized = str(tool_name or "").strip()
        if not normalized:
            continue
        if normalized.lower() in blob:
            required.append(normalized)
    if challenge_type.strip().lower() in {"web-search", "market-research"}:
        for tool_name in available_tool_names:
            normalized = str(tool_name or "").strip()
            if "search" in normalized.lower() and normalized not in required:
                required.append(normalized)
    # A question that asks about documents, records or a corpus must search them, even when
    # it never names the tool and the server did not list it as required.
    if challenge_type.strip().lower() == "retrieval" or _DOC_CUE_RE.search(blob):
        for tool_name in available_tool_names:
            normalized = str(tool_name or "").strip()
            if normalized.lower().startswith("docs.") and normalized not in required:
                required.append(normalized)
    # The server's own required_tools list is authoritative: a missed one zeroes quality.
    available = {str(name or "").strip() for name in available_tool_names}
    for tool_name in required_tool_names(server_required):
        if tool_name in available and tool_name not in required:
            required.append(tool_name)
    return required


def _best_search_query(description: str, rules: str, clues: list[str] | None) -> str:
    text = (description or "").strip()
    if text:
        return text
    if clues:
        for clue in clues:
            if isinstance(clue, str) and clue.strip():
                return clue.strip()
    return (rules or "").strip()


def _query_candidates(
    description: str,
    rules: str,
    clues: list[str] | None,
    extra_context: str = "",
) -> list[str]:
    candidates: list[str] = []
    primary = _best_search_query(description, rules, clues)
    if primary:
        candidates.append(primary)
    for clue in clues or []:
        if isinstance(clue, str) and clue.strip():
            candidates.append(clue.strip())
    if isinstance(rules, str) and rules.strip():
        split_parts = re.split(r"[.;\n]+", rules)
        for part in split_parts:
            part = part.strip()
            if 8 <= len(part) <= 220:
                candidates.append(part)
    for text in [description, rules, extra_context, *(clues or [])]:
        if not isinstance(text, str):
            continue
        for url in re.findall(r"https?://[^\s)>\"]+", text):
            cleaned = url.strip().rstrip(".,);")
            if cleaned:
                candidates.append(cleaned)
    deduped: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped[:5]


def _tool_result_text(result: object) -> str:
    if result is None:
        return ""
    if isinstance(result, str):
        return result.strip()
    if isinstance(result, (int, float, bool)):
        return str(result)
    if isinstance(result, list):
        parts = [_tool_result_text(item) for item in result]
        return "\n".join(part for part in parts if part).strip()
    if isinstance(result, dict):
        cleaned: dict[str, object] = {}
        for key, value in result.items():
            key_lower = str(key).lower()
            if "image" in key_lower and isinstance(value, str) and len(value) > 256:
                continue
            cleaned[str(key)] = value
        try:
            return json.dumps(cleaned, ensure_ascii=False)
        except Exception:
            return str(cleaned)
    return str(result)


def _is_invalid_answer_candidate(value: str) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    lowered = text.lower()
    if lowered.startswith(("<toolcall", "toolcall", "<think", "reasoning:", "analysis:", "action:")):
        return True
    # A truncated reply such as "{" or "[" has no letters or digits: never submit it.
    if not any(ch.isalnum() for ch in text):
        return True
    blocked_tokens = ("<toolcall", "</toolcall", '"tool_calls"', "function_call")
    if any(token in lowered for token in blocked_tokens):
        return True
    return False


def _derive_answer_from_evidence(
    *,
    llm_client,
    model_name: str,
    challenge_description: str,
    challenge_rules: str,
    evidence_lines: list[str],
    max_tokens: int = 8192,
) -> str:
    if not evidence_lines:
        return ""
    evidence_block = "\n".join(f"- {line}" for line in evidence_lines if line.strip())
    if not evidence_block:
        return ""
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Use the provided tool evidence to answer the challenge. "
                        "Return only one final answer line that follows the challenge rules."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Question: {challenge_description}\n"
                        f"Rules: {challenge_rules}\n\n"
                        f"Tool evidence:\n{evidence_block}\n\n"
                        "Return only the final answer line."
                    ),
                },
            ],
            max_tokens=max_tokens,
            temperature=0.0,
        )
    except Exception:
        return ""
    raw = (response.choices[0].message.content or "").strip()
    answer = extract_answer(raw)
    if answer:
        return answer
    first_line = raw.splitlines()[0].strip().strip("`\"'") if raw.strip() else ""
    return "" if _is_invalid_answer_candidate(first_line) else first_line


def _call_timeout(stage_left: float, budget: Budget | None) -> float:
    """Per-call timeout inside the tool stage; the stage cap is already in stage_left."""
    if budget is None:
        return max(0.1, min(stage_left, 6.0))
    return max(0.1, budget.tool_call_timeout(stage_left))


_PHRASE_RE = re.compile(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b")
_NUMBER_WITH_WORD_RE = re.compile(r"^(-?\d[\d,]*(?:\.\d+)?)\s+[A-Za-z][A-Za-z ]*\.?$")


def _normalize_answer_shape(answer: str, answer_format: str) -> str:
    """A bare-number format keeps only the number: "255 units" -> "255"."""
    text = str(answer or "").strip()
    if not str(answer_format or "").strip().lower().startswith(("integer", "number")):
        return text
    match = _NUMBER_WITH_WORD_RE.match(text)
    return match.group(1) if match else text


_SECOND_ENTITY_RE = re.compile(
    r"\b(person|one|team|lead|owner|author|carrier|supplier|company|project|office|member)\s+(who|that|which|whose)\b"
    r"|\bwhose\b|\bled by\b|\bowned by\b|\bwritten by\b|\b(lead|owner|author) of the\b"
    r"|\bthat (shipped|wrote|leads|led|owns|runs|delivered|maintains)\b"
    r"|\b(the|that|this)\s+\w+\s+(that|who|which|whose)\s+\w+\b",
    re.IGNORECASE,
)


def _needs_second_entity(question: str) -> bool:
    """True when the question names a person or thing through another ("the lead of", "the carrier that")."""
    return bool(_SECOND_ENTITY_RE.search(str(question or "")))


def _hop_phrases(question: str, evidence_lines: list[str], limit: int = 4) -> list[str]:
    """Two-or-more-word capitalised names from fetched documents the question did not already name, most frequent first."""
    lowered_question = str(question or "").lower()
    counts: dict[str, int] = {}
    for line in evidence_lines:
        for phrase in _PHRASE_RE.findall(str(line)):
            words = phrase.split()
            if len(words) < 2 or phrase.lower() in lowered_question or any(len(word) <= 2 for word in words):
                continue
            counts[phrase] = counts.get(phrase, 0) + 1
    return [phrase for phrase, _ in sorted(counts.items(), key=lambda pair: (-pair[1], pair[0]))][:limit]


async def _second_hop_evidence(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    available_tool_names: list[str],
    question: str,
    evidence_lines: list[str],
    budget: Budget | None,
    stage_end: float,
) -> list[str]:
    """Follow names found in the first documents with one more docs.search, then fetch what it returns."""
    search_tool = next((n for n in available_tool_names if str(n).lower() == "docs.search"), "")
    get_tool = next((n for n in available_tool_names if str(n).lower() == "docs.get"), "")
    if not (search_tool and get_tool and evidence_lines and budget is not None):
        return []
    new_ids: list[str] = []
    for phrase in _hop_phrases(question, evidence_lines):
        left = stage_end - time.monotonic()
        if left <= 0:
            break
        try:
            result = await asyncio.wait_for(
                mcp_client.call_tool(search_tool, {"agent_id": agent_id, "query": phrase}),
                timeout=budget.tool_call_timeout(left),
            )
        except Exception:
            continue
        for doc_id in re.findall(r'\\?"id\\?"\s*:\s*\\?"([^"\\]+)', _tool_result_text(result)):
            if doc_id not in new_ids:
                new_ids.append(doc_id)
    found: list[str] = []
    for doc_id in new_ids[:3]:
        left = stage_end - time.monotonic()
        if left <= 0:
            break
        try:
            result = await asyncio.wait_for(
                mcp_client.call_tool(get_tool, {"agent_id": agent_id, "doc_id": doc_id}),
                timeout=budget.tool_call_timeout(left),
            )
        except Exception:
            continue
        rendered = _tool_result_text(result)
        if rendered and not any(rendered[:120] in line for line in evidence_lines):
            found.append(f"{get_tool}: {rendered[:2000]}")
    return found


async def _enforce_required_tool_calls(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None,
    available_tool_names: list[str],
    http_client: HttpArenaClient,
    extra_context: str = "",
    server_required: list[str] | None = None,
    budget: Budget | None = None,
    stage_end: float | None = None,
) -> list[str]:
    required_runtime_tools = _required_runtime_tools(
        available_tool_names,
        challenge_type=challenge_type,
        description=description,
        rules=rules,
        extra_context=extra_context,
        server_required=server_required,
    )
    if not required_runtime_tools:
        return []

    evidence_lines: list[str] = []
    if stage_end is None:
        stage_end = time.monotonic() + (budget.tool_stage_s() if budget is not None else 30.0)

    def _stage_left() -> float:
        return max(0.0, stage_end - time.monotonic())

    queries = _query_candidates(description, rules, clues, extra_context)
    if not queries:
        queries = [""]
    # Search tools run first so the ids they return can feed fetch-by-id tools (docs.get).
    search_ids: list[str] = []
    ordered_tools = sorted(required_runtime_tools, key=lambda name: name.lower().endswith(".get"))
    for tool_name in ordered_tools:
        is_search_like = "search" in tool_name.lower()
        fetch_by_id = tool_name.lower().endswith(".get") and bool(search_ids)
        if fetch_by_id:
            target_calls = min(len(search_ids), 3)
        else:
            target_calls = min(len(queries), 3) if is_search_like else 1
        calls_made = 0
        if fetch_by_id:
            for doc_id in search_ids[:target_calls]:
                if _stage_left() <= 0:
                    break
                try:
                    result = await asyncio.wait_for(
                        mcp_client.call_tool(tool_name, {"agent_id": agent_id, "doc_id": doc_id}),
                        timeout=_call_timeout(_stage_left(), budget),
                    )
                    rendered = _tool_result_text(result)
                    if rendered:
                        evidence_lines.append(f"{tool_name}: {rendered[:2000]}")
                    calls_made += 1
                except Exception:
                    continue
        else:
            for query in queries[:target_calls]:
                payload_variants = [
                    {"agent_id": agent_id, "query": query},
                    {"query": query},
                    {"agent_id": agent_id, "search_query": query},
                    {"search_query": query},
                    {"agent_id": agent_id, "text": query},
                    {"text": query},
                    {"agent_id": agent_id, "url": query},
                    {"url": query},
                    {"agent_id": agent_id, "video_url": query},
                    {"video_url": query},
                    {"agent_id": agent_id},
                    {},
                ]
                for payload in payload_variants:
                    if _stage_left() <= 0:
                        break
                    done = False
                    for attempt in range(2 if is_search_like and challenge_type.strip().lower() == "retrieval" else 1):  # a search fault is retried once, retrieval only
                        try:
                            result = await asyncio.wait_for(
                                mcp_client.call_tool(tool_name, payload),
                                timeout=_call_timeout(_stage_left(), budget),
                            )
                            rendered = _tool_result_text(result)
                            if rendered:
                                evidence_lines.append(f"{tool_name}: {rendered[:2000]}")
                                if is_search_like:
                                    for found in re.findall(r'"id"\s*:\s*"([^"]+)"', rendered):
                                        if found not in search_ids:
                                            search_ids.append(found)
                            calls_made += 1
                            done = True
                            break
                        except Exception:
                            continue
                    if done:
                        break
        status_note = (
            f"Required tool coverage: {tool_name} ({calls_made}/{target_calls})"
            if target_calls > 1
            else f"Required tool called: {tool_name}"
            if calls_made
            else f"Could not call required tool: {tool_name}"
        )
        try:
            http_client.broadcast_thought(agent_id, status_note)
        except Exception:
            pass
    return evidence_lines


def _build_context(
    *,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None = None,
    max_time_s: int = 0,
    available_models: list[str] | None = None,
    time_remaining_s: float = 0.0,
    tokens_used: int = 0,
    image_url: str | None = None,
) -> ChallengeContext:
    return ChallengeContext(
        challenge_type=challenge_type,
        difficulty="unknown",
        challenge_text=description,
        description=description,
        rules=rules,
        clues=list(clues or []),
        time_remaining_s=time_remaining_s,
        max_time_s=max_time_s,
        available_models=list(available_models or []),
        tools_used=[],
        tokens_used=tokens_used,
        required_tools=[],
        image_url=image_url,
    )


def _coerce_nonnegative_int(value: object, default: int = 0) -> int:
    try:
        return max(0, int(value if value is not None else default))
    except (TypeError, ValueError):
        return default


def _fetch_proxy_usage(
    llm_host: str,
    api_key: str,
    agent_id: str,
    scope_id: str | None = None,
) -> dict[str, int] | None:
    """Best-effort fetch of proxy usage for one agent, scoped when possible."""
    if not llm_host or not api_key or not agent_id:
        return None
    encoded_agent_id = quote(agent_id, safe="")

    def _read_usage(url: str) -> dict[str, int] | None:
        request = Request(
            url,
            headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"},
            method="GET",
        )
        with urlopen(request, timeout=1.0) as response:
            payload = json.loads(response.read().decode("utf-8"))
        usage = payload.get("usage")
        if not isinstance(usage, dict):
            return None
        return {
            "prompt_tokens": _coerce_nonnegative_int(usage.get("prompt_tokens")),
            "completion_tokens": _coerce_nonnegative_int(usage.get("completion_tokens")),
            "total_tokens": _coerce_nonnegative_int(usage.get("total_tokens")),
        }

    if scope_id:
        encoded_scope_id = quote(scope_id, safe="")
        scoped_url = f"{llm_host.rstrip('/')}/usage/{encoded_scope_id}/{encoded_agent_id}"
        try:
            return _read_usage(scoped_url)
        except HTTPError as exc:
            if exc.code not in {400, 404}:
                raise

    aggregate_url = f"{llm_host.rstrip('/')}/usage/{encoded_agent_id}"
    return _read_usage(aggregate_url)


def _build_live_metrics(model_name: str, usage: dict[str, int] | None, elapsed_ms: int) -> dict[str, object]:
    usage = usage or {}
    prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
    completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
    total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))
    return {
        "model_name": str(model_name or "").strip(),
        "total_tokens": str(total_tokens),
        "prompt_tokens": str(prompt_tokens),
        "completion_tokens": str(completion_tokens),
        "total_time_ms": int(max(0, elapsed_ms)),
    }


# A retry with another model needs time to think and answer.
RETRY_MIN_REMAINING_S = 30.0


def _next_ranked_model(ranked_models: list[str], current: str) -> str:
    """The first ranked model after ``current``, or "" when there is none."""
    remaining = [model for model in ranked_models if model != current]
    if current in ranked_models:
        after = ranked_models[ranked_models.index(current) + 1 :]
        remaining = [model for model in after if model != current] or remaining
    return remaining[0] if remaining else ""


_TOKEN_LIMIT_REASONS = frozenset({"length", "max_tokens", "max_token", "token_limit", "token limit", "max_output_tokens"})


def _is_token_limit(reason: object) -> bool:
    """True when a model stopped because it ran out of tokens, whatever its provider calls it."""
    text = str(reason or "").strip().lower().replace("-", "_")
    return text in _TOKEN_LIMIT_REASONS or text.endswith("max_tokens")


async def _retry_after_length_stop(result, *, ranked_models, remaining_s, solve_with):
    """Retry once with the next ranked model when the first ran out of tokens.

    ``result`` is solve_challenge's tuple. A reasoning model that spends its
    whole token budget thinking returns no answer with finish_reason
    "length"; asking it again would do the same, so another model gets one
    try while enough time remains. Token usage and time add up across both.
    """
    answer, _raw, model_name, usage, _ttft, total_time_ms = result
    if _is_invalid_answer_candidate(answer):
        answer = ""
    if (answer or not _is_token_limit(usage.get("finish_reason"))):
        return result
    tokens_spent = int(usage.get("completion_tokens", 0) or 0)
    print(f"   ⚠️  {model_name} used all {tokens_spent} tokens thinking and gave no answer.")
    retry_model = _next_ranked_model(ranked_models, model_name)
    left_s = await remaining_s()
    if not retry_model or left_s < RETRY_MIN_REMAINING_S:
        print(f"   Not retrying ({left_s:.0f}s left). Tune text_max_tokens or rank_models in my_strategy.py.")
        return result
    print(f"   Retrying with {retry_model}. Tune text_max_tokens or rank_models in my_strategy.py.")
    retried = await solve_with(retry_model)
    r_answer, r_raw, r_model, r_usage, r_ttft, r_time_ms = retried
    merged_usage = dict(r_usage)
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        merged_usage[key] = int(r_usage.get(key, 0) or 0) + int(usage.get(key, 0) or 0)
    return r_answer, r_raw, r_model, merged_usage, r_ttft, total_time_ms + r_time_ms


# A dropped connection mid-stream is retried through the non-streaming call only with this much left.
STREAM_DROP_RETRY_MIN_S = 20.0


def _connection_dropped(exc: BaseException) -> bool:
    """A raw connection reset, abort or truncated response, as raised by the socket or httpx layer."""
    import httpx

    return isinstance(exc, (ConnectionResetError, ConnectionAbortedError, httpx.RemoteProtocolError))


def _retryable_llm_error(exc: Exception) -> bool:
    """Transient proxy failures: rate limit, connection, timeout, 5xx, and a dropped connection."""
    import openai

    if isinstance(exc, (openai.RateLimitError, openai.APIConnectionError, openai.APITimeoutError)):
        return True
    if _connection_dropped(exc):
        return True
    return isinstance(exc, openai.APIStatusError) and exc.status_code >= 500


def _repair_answer(llm_client, model_name: str, bad_reply: str, ctx: ChallengeContext, reason: str) -> str:
    """One short non-streaming call that restates only the bare answer."""
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": repair_prompt(bad_reply, ctx.rules, ctx.clues, reason)}],
            max_tokens=1024,
            temperature=0.0,
        )
    except Exception:
        return ""
    return (response.choices[0].message.content or "").strip()


def _evidence_prompt(evidence_lines: list[str] | None, limit: int = 4000) -> str:
    """Tool evidence for the solve prompt: the solver must answer from it, not from memory."""
    lines = [str(line).strip() for line in (evidence_lines or []) if str(line).strip()]
    if not lines:
        return ""
    body = "\n".join(f"- {line}" for line in lines)[:limit]
    return (
        "Tool evidence:\n"
        f"{body}\n"
        "Answer from the tool evidence; it overrides your own knowledge."
    )


async def solve_challenge(
    challenge,
    clues: list[str],
    llm_client,
    model_name: str,
    strategy: MyStrategy,
    ctx: ChallengeContext,
    *,
    http_client=None,
    agent_id: str = "",
    broadcast_thought: bool = True,
    evidence_lines: list[str] | None = None,
    ticker: ReasoningTicker | None = None,
    budget: Budget | None = None,
):
    """Solve the challenge using the selected LLM model.
    
    When http_client and agent_id are provided, streams reasoning to Agent Gauntlet in real time.
    
    Returns:
        tuple: (extracted_answer, raw_response, model_name, usage_dict, ttft_ms, total_time_ms)
    """
    
    print(f"   solve_challenge: type={getattr(challenge, 'challenge_type', None)!r} clues={len(clues)}", flush=True)
    # Deterministic path: skip the LLM when the logic solver finds a unique answer.
    solved = solve_knights(
        f"{getattr(challenge, 'description', '')}\n{getattr(challenge, 'rules', '')}\n"
        f"{getattr(challenge, 'answer_format', '')}",
        clues,
    ) or solve_sequence(str(getattr(challenge, "description", "") or ""), clues) or solve_numeric(str(getattr(challenge, "description", "") or ""), clues) or solve_zebra(str(getattr(challenge, "description", "") or ""), clues) or solve_big_choice(str(getattr(challenge, "description", "") or ""), clues) or solve_logic_from_challenge(
        f"{getattr(challenge, 'description', '')}\n{getattr(challenge, 'rules', '')}\n"
        f"{getattr(challenge, 'answer_format', '')}",
        clues,
    )
    solved = normalize_entity_answer(solved, str(getattr(challenge, "rules", "") or ""))
    if solved:
        # The reply must carry an ANSWER line, or the empty-reply retry calls the LLM.
        return solved, f"ANSWER: {solved}", model_name, {}, 0, 0
    # A code challenge's clue is a program; running it in the sandbox gives the answer.
    executed = run_code_challenge(getattr(challenge, "challenge_type", ""), clues)
    if executed:
        return executed, f"ANSWER: {executed}", model_name, {"finish_reason": "code_eval"}, 0, 0
    # Math rules answer only when they parse the whole question; otherwise the model answers.
    presolved = presolve_challenge(
        getattr(challenge, "challenge_type", ""),
        getattr(challenge, "description", ""),
        getattr(challenge, "rules", ""),
    )
    if presolved:
        return presolved, f"ANSWER: {presolved}", model_name, {"finish_reason": "presolve"}, 0, 0
    prompt = strategy.build_solver_prompt(ctx)
    evidence_block = _evidence_prompt(evidence_lines)
    if evidence_block:
        prompt = f"{evidence_block}\n\n{prompt}"
    # An ordering puzzle with a few valid orders: the solver lists them and the model picks one,
    # which needs far less reasoning than deriving the orders (practice logic easy took ~9 s).
    candidates = logic_candidates(
        f"{getattr(challenge, 'description', '')}\n{getattr(challenge, 'rules', '')}\n"
        f"{getattr(challenge, 'answer_format', '')}",
        clues,
    ) if "logic" in str(getattr(challenge, "challenge_type", "") or "").lower() else []
    if candidates:
        listed = "\n".join(f"- {order}" for order in candidates)
        prompt = (
            f"{prompt}\n\nA constraint check found that exactly these orders satisfy every clue:\n{listed}\n"
            "Do not re-derive them. Choose the one order the puzzle intends and answer with it."
        )
    if str(ctx.challenge_type or "").strip().lower() == "retrieval" and evidence_lines:
        prompt = (
            f"{prompt}\n\nDocuments carry dates. Use the latest revision that applies; earlier, withdrawn or "
            "superseded values do not count. If the question asks for a total, difference or count, compute it "
            "from the document values and answer the result only."
        )
    prompt = (
        f"{prompt}\n\n"
        "Output guardrails:\n"
        "- Return only your final answer line.\n"
        "- Do not output tool-call markup, XML tags, or thinking traces."
    )
    system_msg = strategy.build_system_prompt(ctx)
    llm_params = strategy.get_llm_params(ctx)
    max_tokens = int(llm_params.get("max_tokens", 8192))
    temperature = float(llm_params.get("temperature", 0.0))
    # Strategy pass-through: reasoning controls go straight to chat.completions.
    extra_params = {k: llm_params[k] for k in ("reasoning_effort", "extra_body") if k in llm_params}
    
    # Track timing
    start_ms = time.time() * 1000
    ttft_ms = 0
    raw_content_parts = []
    # Kept apart so the answer comes from the final reply, as in the
    # non-streaming path; reasoning can hold draft "ANSWER:" lines.
    reply_parts: list[str] = []
    reasoning_parts: list[str] = []
    pending_broadcast = ""
    _BROADCAST_CHUNK = 80  # chars before sending a thought

    def _flush_broadcast(force: bool = False) -> None:
        nonlocal pending_broadcast
        if not http_client or not agent_id or not broadcast_thought:
            return
        if force or len(pending_broadcast) >= _BROADCAST_CHUNK or "\n" in pending_broadcast:
            chunk = pending_broadcast.strip()
            pending_broadcast = ""
            if chunk:
                try:
                    http_client.broadcast_thought(agent_id, chunk[:300])
                except Exception:
                    pass

    def _timed_client():
        # Each attempt gets the time left now, with SDK retries off: a retry
        # reuses the old timeout, so one slow attempt could run it twice.
        if budget is None:
            return llm_client
        timeout = budget.llm_timeout()
        if timeout <= 0:
            raise RuntimeError("no time left for an LLM call")
        return llm_client.with_options(timeout=timeout, max_retries=0)

    def _create(**kwargs):
        # One explicit retry for transient proxy errors, with time to spare.
        return call_with_one_retry(
            lambda: _timed_client().chat.completions.create(**kwargs), budget, _retryable_llm_error
        )

    stream_enabled = os.getenv("LLM_STREAM", "1").lower() not in {"0", "false", "no"}
    usage = None
    finish_reason = ""
    if stream_enabled and http_client and agent_id:
        # Stream and broadcast in real time
        try:
            stream = _create(
                model=model_name,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=temperature,
                stream=True,
                **extra_params,
            )
            header_sent = False
            for chunk in stream:
                # Per-read timeouts never fire while tokens keep arriving, so
                # the deadline is checked here; the submit margin stays free.
                if budget is not None and budget.remaining() <= budget.margin_s:
                    print("   ⏱  Deadline reached mid-stream; stopping and submitting the best draft.")
                    stream.close()
                    break
                if chunk.choices and getattr(chunk.choices[0], "finish_reason", None):
                    finish_reason = str(chunk.choices[0].finish_reason)
                if chunk.choices and chunk.choices[0].delta:
                    delta = chunk.choices[0].delta
                    content = delta.content or ""
                    reasoning = getattr(delta, "reasoning_content", None) or getattr(delta, "reasoning", None) or ""
                    text = reasoning or content
                    if ticker is not None:
                        ticker.feed(reasoning=reasoning, answer=content)
                    if reasoning:
                        reasoning_parts.append(reasoning)
                    if content:
                        reply_parts.append(content)
                    if text:
                        if not ttft_ms:
                            ttft_ms = int(time.time() * 1000 - start_ms)
                        raw_content_parts.append(text)
                        if broadcast_thought:
                            if not header_sent:
                                http_client.broadcast_thought(agent_id, "💭 LLM Reasoning:")
                                header_sent = True
                            # Streamed model text is not broadcast: it can contain the answer and clues.
                            _flush_broadcast()
                if hasattr(chunk, "usage") and chunk.usage:
                    usage = chunk.usage
            _flush_broadcast(force=True)
        except Exception as e:
            stream_enabled = False
            raw_content_parts = []
            if "stream" in str(e).lower() or "Stream" in str(e):
                pass  # Fall through to non-streaming
            elif _connection_dropped(e) and budget is not None and budget.remaining() > STREAM_DROP_RETRY_MIN_S:
                # The connection dropped mid-stream with time to spare: the non-streaming call
                # below retries it once (its own timeout and the budget guard still apply).
                print(f"   ⚠️  Stream dropped ({type(e).__name__}); retrying without streaming.")
            else:
                raise

    if not stream_enabled or not raw_content_parts:
        # Non-streaming fallback
        response = _create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
            **extra_params,
        )
        raw_content = response.choices[0].message.content or ""
        finish_reason = str(getattr(response.choices[0], "finish_reason", "") or "")
        usage = response.usage
        ttft_ms = ttft_ms or getattr(response, "ttft_ms", 0) or int((time.time() * 1000 - start_ms) * 0.1)
    else:
        reply = "".join(reply_parts)
        raw_content = reply if reply.strip() else "".join(reasoning_parts)

    total_time_ms = int(time.time() * 1000 - start_ms)
    answer = _normalize_answer_shape(extract_answer(raw_content), getattr(challenge, "answer_format", ""))
    if _is_invalid_answer_candidate(answer):
        answer = ""
    # Extra model calls only while there is time to spare; past the margin the
    # best draft goes out instead of a new call.
    has_time = budget is None or budget.remaining() > budget.margin_s
    if not answer and evidence_lines and has_time:
        answer = _derive_answer_from_evidence(
            llm_client=llm_client,
            model_name=model_name,
            challenge_description=str(ctx.description or ""),
            challenge_rules=str(ctx.rules or ""),
            evidence_lines=list(evidence_lines or []),
            max_tokens=max_tokens,
        )
        if _is_invalid_answer_candidate(answer):
            answer = ""
    # A model that ran out of tokens while thinking would only do it again;
    # the caller retries with another model instead.
    if not answer and not _is_token_limit(finish_reason) and has_time:
        strict_system_msg = (
            "Return only one line in exact format: ANSWER: <final answer>. "
            "No preamble, no tags, no explanation, no additional lines."
        )
        try:
            strict_response = _create(
                model=model_name,
                messages=[
                    {"role": "system", "content": strict_system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=min(temperature, 0.0),
                stream=False,
            )
            raw_content = strict_response.choices[0].message.content or ""
            usage = strict_response.usage
            total_time_ms = int(time.time() * 1000 - start_ms)
            answer = extract_answer(raw_content)
        except Exception:
            pass
    if _is_invalid_answer_candidate(answer):
        answer = ""

    usage_dict = {
        "finish_reason": finish_reason,
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) if usage else 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) if usage else 0,
        "total_tokens": getattr(usage, "total_tokens", 0) if usage else 0,
    }
    # Streams usually carry no usage; estimate from everything streamed,
    # reasoning included, not only the reply the answer was read from.
    streamed_text = "".join(raw_content_parts) or raw_content
    if not usage_dict["total_tokens"] and streamed_text:
        usage_dict["total_tokens"] = len(streamed_text.split()) * 2  # rough estimate
    ttft_ms = ttft_ms or int(total_time_ms * 0.1)

    return answer, raw_content, model_name, usage_dict, ttft_ms, total_time_ms


# Solve-path state kept for the last-resort submit (see submit_guard_fallback).
_GUARD: dict = {}


def submit_guard_fallback(exc: BaseException) -> int:
    """Last line of defence: a crash after the challenge was fetched still submits.

    Skipped once an answer is accepted (``submitted``). Image challenges submit
    an image over REST with ``challenge_type="image"``, never a text answer.
    Text uses the best answer so far, or a fallback built from the clues. Returns
    the process exit code.
    """
    print(f"   ⚠️  Solve path failed ({exc!r}).")
    if _GUARD.get("submitted"):
        print("   Answer already submitted; no fallback needed.")
        return 0
    http_client = _GUARD.get("http_client")
    challenge = _GUARD.get("challenge")
    if http_client is None or challenge is None:
        print("   No challenge was fetched, so there is nothing to submit.")
        return 1
    is_image = _GUARD.get("modality") == "image"
    if is_image:
        answer = str(_GUARD.get("answer") or "").strip() or str(
            getattr(challenge, "input_image_uri", "") or ""
        ).strip() or BLANK_PNG_DATA_URI
        submit_kwargs = {"challenge_type": "image"}
    else:
        clues = list(_GUARD.get("clues") or [])
        rules = str(getattr(challenge, "rules", "") or "")
        # The draft may still carry an "ANSWER:" label; only the bare answer is submitted.
        extracted = extract_final_answer(str(_GUARD.get("answer") or ""), rules=rules, clues=clues)
        answer = extracted.answer.strip() if extracted.valid else ""
        if not answer:
            answer = fallback_answer(challenge.challenge_type, clues, challenge.description, getattr(challenge, "rules", ""))
        submit_kwargs = {}
    print(f"   Submitting a {'image' if is_image else 'text'} fallback before the deadline.")
    try:
        result = resilience.submit_resilient(http_client, _GUARD["agent_id"], answer=answer, **submit_kwargs)
    except Exception as submit_exc:
        print(f"   Fallback submit failed: {submit_exc!r}")
        return 1
    _GUARD["submitted"] = True
    print(f"   Fallback submitted: accepted={result.accepted} status={result.status}")
    return 0


async def main():
    """Main agent loop."""
    stages = StageTimer()  # log only: where the fixed live time goes
    strategy = MyStrategy()
    agent_id = (
        os.getenv("AGENT_ID")
        or str(getattr(strategy, "agent_id", "")).strip()
        or "simple-agent"
    ).strip()
    agent_name = (
        os.getenv("AGENT_NAME")
        or str(getattr(strategy, "agent_name", "")).strip()
        or "Team Nova"
    ).strip()
    os.environ["AGENT_ID"] = agent_id
    # Practice is shared: a default id lets another team's run replace yours.
    id_problem = agent_id_problem(os.environ["AGENT_ID"])
    if id_problem:
        raise SystemExit(f"❌ {id_problem}")
    os.environ["AGENT_NAME"] = agent_name
    print(f"🤖 {agent_name} starting...")
    print(f"   Agent ID: {agent_id}")

    ensure_connected()

    # Initialize clients
    api_base = get_api_base()
    mcp_url = get_mcp_url()
    llm_host = get_proxy_host()
    api_key = get_arena_api_key()
    llm_api_key = api_key

    print(f"   API: {api_base}")
    print(f"   MCP: {mcp_url}")
    print(f"   LLM: {llm_host}")
    print()

    # HTTP client for Agent Gauntlet coordination
    http_client = HttpArenaClient(api_base=api_base, api_key=api_key)
    _GUARD.update(http_client=http_client, agent_id=agent_id)

    if not HAS_OPENAI:
        raise RuntimeError("Missing dependency: openai. Install with `pip install openai`.")
    
    # Step 1: Register with Agent Gauntlet
    print("📝 Registering with Agent Gauntlet...")
    session = resilience.register_or_resume(http_client, agent_id, agent_name)
    stages.mark("register")
    print(f"   Session: {session.session_id}")
    print(f"   Status: {session.status}")
    session_monitor = monitor_session(http_client, agent_id).start()
    
    # Step 2: Get challenge from MCP
    print("\n🎯 Getting challenge...")
    async with resilience.ResilientMcp(mcp_url, agent_id=agent_id) as mcp_client:
        tools, tool_defs = await asyncio.gather(mcp_client.list_tools(), mcp_client.list_tool_defs())
        clock = ClockReader(mcp_client, agent_id, tool_defs)
        modality = McpArenaClient.detect_modality(tools, agent_id=agent_id)
        modality, tools = await resilience.resolve_modality(mcp_client, modality, agent_id)
        stages.mark("mcp connect + tool list")
        image_tool_proxy_args: dict[str, dict[str, str]] = {}
        usage_scope = await _pre_stage("usage scope", http_client.fetch_usage_scope, None) or resolve_usage_scope()
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope

        live_prompt_tokens = 0
        live_completion_tokens = 0
        live_total_tokens = 0
        active_model_name = ""
        metrics_started_ms = 0.0
        reporter_stop = asyncio.Event()
        metrics_task: asyncio.Task | None = None

        def _elapsed_metrics_ms() -> int:
            if metrics_started_ms <= 0:
                return 0
            return int(max(0.0, time.time() * 1000 - metrics_started_ms))

        async def _refresh_live_usage() -> None:
            nonlocal live_prompt_tokens, live_completion_tokens, live_total_tokens
            try:
                usage = await asyncio.to_thread(
                    _fetch_proxy_usage,
                    llm_host,
                    llm_api_key,
                    agent_id,
                    usage_scope,
                )
            except Exception:
                usage = None
            if not isinstance(usage, dict):
                return
            live_prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
            live_completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
            live_total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))

        async def _push_live_status(status: str = "running") -> None:
            await _refresh_live_usage()
            try:
                await asyncio.to_thread(
                    http_client.update_status,
                    agent_id,
                    status,
                    _build_live_metrics(
                        active_model_name,
                        {
                            "prompt_tokens": live_prompt_tokens,
                            "completion_tokens": live_completion_tokens,
                            "total_tokens": live_total_tokens,
                        },
                        _elapsed_metrics_ms(),
                    ),
                )
            except Exception:
                return

        async def _runtime_metrics_reporter() -> None:
            while not reporter_stop.is_set():
                await _push_live_status("running")
                try:
                    await asyncio.wait_for(reporter_stop.wait(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

        async def _start_metrics_reporter(model_name: str) -> None:
            nonlocal active_model_name, metrics_started_ms, metrics_task
            active_model_name = str(model_name or "").strip()
            metrics_started_ms = time.time() * 1000
            reporter_stop.clear()
            await _push_live_status("running")
            metrics_task = asyncio.create_task(_runtime_metrics_reporter())

        async def _stop_metrics_reporter() -> None:
            reporter_stop.set()
            if metrics_task is not None:
                try:
                    await asyncio.wait_for(metrics_task, timeout=2.0)
                except Exception:
                    if not metrics_task.done():
                        metrics_task.cancel()
            await _push_live_status("running")

        if modality == "image":
            challenge = None
            while True:
                try:
                    challenge = await mcp_client.get_image_challenge(agent_id)
                    break
                except McpArenaError as e:
                    message = str(e).lower()
                    if "locked" in message or "waiting for organizer" in message:
                        print("   Lobby open; waiting for organizer to start battle...")
                        await asyncio.sleep(3.0)
                    else:
                        raise
            print_challenge(challenge)
            # Hard guard starts at challenge receipt, as in the text path.
            image_budget = Budget(challenge.max_time_s or 120)
            image_budget.update_server_remaining(float(getattr(challenge, "time_remaining_s", 0) or 0))
            usage_scope = await _pre_stage("usage scope", http_client.fetch_usage_scope, None) or resolve_usage_scope()
            if usage_scope:
                os.environ["ARENA_USAGE_SCOPE"] = usage_scope

            available_models = fetch_available_models(llm_host, llm_api_key)
            image_rules = "\n".join(
                part
                for part in (challenge.prompt, challenge.reference_notes)
                if isinstance(part, str) and part.strip()
            )
            image_prompt = (challenge.prompt or challenge.description or "").strip()
            image_ctx = _build_context(
                challenge_type=challenge.challenge_type,
                description=challenge.description,
                rules=image_rules,
                max_time_s=challenge.max_time_s,
                available_models=available_models,
                image_url=challenge.input_image_uri or None,
            )
            ranked_models = strategy.rank_models(image_ctx, available_models)
            model_name = strategy.pick_model("solve", ranked_models, image_ctx)
            model_name = require_explicit_model(
                model_name,
                available_models,
                source="python_simple agent",
            )
            image_tool_proxy_args = {
                tool_name: build_image_tool_arguments(
                    tool_defs,
                    tool_name,
                    selected_model=model_name,
                    llm_api_key=llm_api_key,
                    arena_api_key=api_key,
                )
                for tool_name in ("image_edit", "image_generate", "image_analyze")
            }
            print(f"   Selected model: {model_name}")
            http_client.broadcast_thought(agent_id, f"Selected planner model: {model_name}")
            await _start_metrics_reporter(model_name)

            start_ms = time.time() * 1000
            prompt_text = strategy.build_image_prompt(image_ctx).strip() or image_prompt
            image_tools = [
                tool_name
                for tool_name in ("image_edit", "image_generate", "image_analyze")
                if tool_name in tools
            ]
            # The image path needs 3 unique tools too (scoring cap is 3): top up the cheap ones.
            image_tools_used = await ensure_tool_coverage(mcp_client, agent_id, {"arena.image.get_challenge"})
            print(f"   Tool coverage (image): {len(image_tools_used)} unique")
            image_tool_sequence = _plan_image_tool_sequence(
                strategy,
                image_ctx,
                image_tools,
            )
            selected_tool = image_tool_sequence[-1] if image_tool_sequence else ""
            tool_result: dict = {}
            mcp_session_dead = False

            async def _call_image_tool(name: str, arguments: dict) -> dict:
                nonlocal mcp_session_dead
                try:
                    result = await mcp_client.call_tool(name, arguments)
                    return result if isinstance(result, dict) else {}
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    mcp_session_dead = True
                    print(f"   Image tool {name} failed ({type(exc).__name__}): {exc}")
                    return {}

            if "arena.get_challenge" in tools:
                # The image challenge does not list required tools; the server does at submit,
                # and scores a missing text challenge fetch as quality 0. Fetch it up front.
                await _call_image_tool("arena.get_challenge", {"agent_id": agent_id})
            if (
                len(image_tool_sequence) > 1
                and image_tool_sequence[0] == "image_analyze"
                and challenge.input_image_uri
            ):
                print("   Using image_analyze before output tool")
                analysis_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(analysis_result.get("text") or "").strip()
                if analysis_text:
                    http_client.broadcast_thought(
                        agent_id,
                        "Image analysis done.",
                    )
                    prompt_text = (
                        f"{prompt_text}\n\n"
                        "Source-image analysis to preserve while transforming: "
                        f"{analysis_text[:1000]}"
                    )
            if (
                selected_tool == "image_edit"
                and challenge.input_image_uri
                and "image_edit" in image_tools
            ):
                print("   Using image_edit tool")
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif selected_tool == "image_generate" and "image_generate" in image_tools:
                print("   Using image_generate tool")
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )
            elif (
                selected_tool == "image_analyze"
                and challenge.input_image_uri
                and "image_analyze" in image_tools
            ):
                print("   Using image_analyze tool (no image output tool available)")
                tool_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(tool_result.get("text") or "").strip()
                if analysis_text:
                    http_client.broadcast_thought(
                        agent_id,
                        "Image analysis done.",
                    )
            elif challenge.input_image_uri and "image_edit" in image_tools:
                selected_tool = "image_edit"
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif "image_generate" in image_tools:
                selected_tool = "image_generate"
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )

            if tool_result.get("error"):
                print(f"   Tool warning: {tool_result.get('error')}")

            # Required-tools gate: a required tool that is never called zeroes quality.
            # Call each missing one the server listed, then keep the chosen output.
            # The submit tool is the final call itself, so it is never a missing requirement here.
            called_image_tools = set(image_tool_sequence) | {
                selected_tool,
                "arena.image.get_challenge",
                "arena.image.submit_edit",
            }
            for missing_name in missing_required_tools(challenge.required_tools, called_image_tools):
                if missing_name not in tools:
                    print(f"   Required tool unavailable on this server: {missing_name}")
                    continue
                if missing_name == "image_generate":
                    extra_args = {"prompt": prompt_text}
                elif missing_name in {"image_edit", "image_analyze"} and challenge.input_image_uri:
                    extra_args = {"image_uri": challenge.input_image_uri, "prompt": prompt_text}
                else:
                    print(f"   Required tool not handled by the image path: {missing_name}")
                    continue
                print(f"   Required tool added: {missing_name}")
                await _call_image_tool(
                    missing_name,
                    {**extra_args, **image_tool_proxy_args.get(missing_name, {})},
                )
                called_image_tools.add(missing_name)
            output_image_uri = _usable_image_uri(tool_result)
            # Walk the roster: a blank result, or a 402/403/429 (model unavailable), moves on to the
            # next image model. Blank is submitted only once no roster model remains in time.
            if not output_image_uri and selected_tool in {"image_generate", "image_edit"}:
                # Without a model parameter the same tool gets one retry; with one, the roster is walked.
                supports_model = "model" in image_tool_proxy_args.get(selected_tool, {})
                alternates = (
                    [name for name in ranked_models if name != model_name] if supports_model else []
                ) or [model_name]
                for alternate in alternates:
                    if time.time() * 1000 - start_ms >= challenge.max_time_s * 500:
                        break
                    print(
                        f"   No usable image from {selected_tool} ({_failure_reason(tool_result)}); "
                        f"trying {alternate}"
                    )
                    retry_args = {"prompt": prompt_text, "agent_id": agent_id}
                    if selected_tool == "image_edit":
                        retry_args["image_uri"] = challenge.input_image_uri
                    retry_args.update(image_tool_proxy_args.get(selected_tool, {}))
                    if supports_model:
                        retry_args["model"] = alternate
                    tool_result = await _call_image_tool(selected_tool, retry_args)
                    output_image_uri = _usable_image_uri(tool_result)
                    if output_image_uri:
                        break
            if not output_image_uri and challenge.input_image_uri:
                output_image_uri = challenge.input_image_uri
            if not output_image_uri:
                # Never withhold the submission: a blank image can still earn tools and speed points.
                print("   No usable image after the retry; submitting the blank result")
                output_image_uri = BLANK_PNG_DATA_URI
            if selected_tool == "image_edit" and challenge.input_image_uri and (
                output_image_uri != challenge.input_image_uri
            ):
                # Edits come back at the model's own size; match the input so the judge compares like with like.
                output_image_uri = await _match_input_size(
                    output_image_uri, challenge.input_image_uri, image_budget
                )
            _GUARD.update(answer=output_image_uri, challenge=challenge, modality="image")

            total_time_ms = int(time.time() * 1000 - start_ms)
            await _stop_metrics_reporter()
            client_metrics = {
                "model_name": model_name,
                "planner_tool": selected_tool,
                "total_tokens": str(live_total_tokens),
                "prompt_tokens": str(live_prompt_tokens),
                "completion_tokens": str(live_completion_tokens),
                "ttft_ms": 0,
                "total_time_ms": total_time_ms,
            }
            if mcp_session_dead:
                await session_monitor.stop()
                print("   MCP session unavailable; submitting image over REST")
                image_submit_result = resilience.submit_resilient(
                    http_client,
                    agent_id,
                    answer=output_image_uri,
                    client_metrics=client_metrics,
                    challenge_type="image",
                )
            else:
                image_submit_result = await mcp_client.submit_image(
                    agent_id=agent_id,
                    image_uri=output_image_uri,
                    client_metrics=client_metrics,
                    rationale="simple_agent dynamic image flow",
                )
            _GUARD["submitted"] = True
            for line in submission_summary_lines(image_submit_result):
                print(f"   {line}")
            await session_monitor.stop()
            # Last steps, after the submission is final; neither raises.
            run_tag = f"{challenge.puzzle_id}-{time.strftime('%Y%m%dT%H%M%S')}"
            print(f"   Image: {save_submitted_image(agent_id, output_image_uri, REPO_ROOT, run_tag=run_tag)}")
            if isinstance(image_submit_result, dict):
                image_result = image_submit_result
            else:  # REST fallback returns a SubmitResult
                image_result = {
                    "accepted": getattr(image_submit_result, "accepted", None),
                    "score": getattr(image_submit_result, "score", None),
                }
            score = image_result.get("score") if isinstance(image_result.get("score"), dict) else {}
            run_record = {
                "agent_id": agent_id,
                "challenge": challenge_record(challenge),
                "model": model_name,
                "image_tool_sequence": image_tool_sequence,
                "submission": {
                    **image_facts(output_image_uri),
                    "prompt": bounded(prompt_text),
                    "tool": selected_tool,
                },
                "result": {
                    "accepted": image_result.get("accepted"),
                    "score": {key: value for key, value in score.items() if key != "output_image_uri"},
                    # The judge's own text, when the submit response carries one. It names the broken axis.
                    "judge_text": bounded(
                        score.get("judge_detail") or score.get("judge_reason") or judge_reason_of(score),
                        1000,
                    ),
                },
            }
            print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
            print("\n✅ Agent completed!")
            return

        # Wait for organizer to start (challenge is locked while lobby is open)
        challenge = None
        while True:
            try:
                challenge = await mcp_client.get_challenge(agent_id)
                break
            except McpArenaError as e:
                message = str(e).lower()
                if "locked" in message or "waiting for organizer" in message:
                    print("   Lobby open; waiting for organizer to start battle...")
                    await asyncio.sleep(3.0)
                else:
                    raise
        print_challenge(challenge)
        stages.mark("get_challenge")
        # Hard guard starts at challenge receipt: everything after this counts, including model lookup.
        budget = Budget(challenge.max_time_s or 60)
        budget.update_server_remaining(float(getattr(challenge, "time_remaining_s", 0) or 0))
        clock.time_limit_s = float(challenge.max_time_s or 60)
        usage_scope = await _pre_stage("usage scope", http_client.fetch_usage_scope, None) or resolve_usage_scope()
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope
        llm_client = _openai_class()(  # deferred import: only the text path calls the LLM
            base_url=llm_host,
            api_key=llm_api_key,
            default_headers=build_proxy_headers(agent_id, usage_scope),
        )
        print("   LLM: Enabled")
        stages.mark("usage scope + llm client")
        print()

        models_timeout = min(MODEL_LIST_TIMEOUT_S, max(3.0, budget.remaining() * 0.1))
        available_models = await _pre_stage(
            "model list", lambda: fetch_available_models(llm_host, llm_api_key), None, models_timeout
        ) or _fallback_text_models()
        model_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            max_time_s=challenge.max_time_s,
            available_models=available_models,
        )
        ranked_models = strategy.rank_models(model_ctx, available_models)
        model_name = strategy.pick_model("solve", ranked_models, model_ctx)
        model_name = require_explicit_model(
            model_name,
            available_models,
            source="python_simple agent",
        )
        print(f"   Selected model: {model_name}")
        await _start_metrics_reporter(model_name)
        
        # Broadcast thought
        await _pre_stage("thought", lambda: http_client.broadcast_thought(agent_id, "Reading challenge and clues..."), None)
        
        # Get all clues
        # Hard guard starts at challenge start: clue reading and tool calls count.
        print("\n📖 Reading clues...")
        # An empty list is retried, then clue_0.. are probed: solving without clues is a guess.
        clue_ids, clues = await read_clues(mcp_client, agent_id)
        stages.mark("clues")
        if not clues:
            clues = [str(clue_text) for clue_text in challenge.clues]
        # Near-zero-cost calls: three unique tools per run (scoring cap is 3).
        tools_used = {"arena.get_challenge"}
        if clues:
            tools_used |= {"arena.clues.list", "arena.clues.get"}
        tools_used = await ensure_tool_coverage(mcp_client, agent_id, tools_used)

        _GUARD.update(challenge=challenge, clues=clues)
        budget.update_server_remaining(await clock.remaining())
        stage_end = time.monotonic() + budget.tool_stage_s()
        tool_evidence_lines = await _enforce_required_tool_calls(
            mcp_client=mcp_client,
            agent_id=agent_id,
            challenge_type=str(challenge.challenge_type or ""),
            description=str(challenge.description or ""),
            rules=str(challenge.rules or ""),
            clues=clues,
            available_tool_names=[str(name) for name in tools],
            http_client=http_client,
            extra_context=str(getattr(challenge, "extra_text", "") or ""),
            server_required=challenge.required_tools,
            budget=budget,
            stage_end=stage_end,
        )
        stages.mark("required tool calls")
        
        if str(challenge.challenge_type or "").strip().lower() == "retrieval" and _needs_second_entity(
            f"{challenge.description or ''} {challenge.rules or ''}"
        ):
            hop_lines = await _second_hop_evidence(
                mcp_client=mcp_client,
                agent_id=agent_id,
                available_tool_names=[str(name) for name in tools],
                question=f"{challenge.description or ''} {challenge.rules or ''}",
                evidence_lines=list(tool_evidence_lines),
                budget=budget,
                stage_end=stage_end,
            )
            print(f"   second hop: +{len(hop_lines)} documents", flush=True)
            tool_evidence_lines = list(tool_evidence_lines) + hop_lines
        # Broadcast thought
        http_client.broadcast_thought(agent_id, f"Analyzing {len(clues)} clues...")
        
        # Save draft (backup)
        http_client.save_draft(agent_id, "Working on solution...")
        
        # Step 3: Solve
        print("\n🧠 Solving...")
        http_client.broadcast_thought(agent_id, "Calling LLM...")
        answer_format = str(getattr(challenge, "answer_format", "") or "")
        solve_rules = str(challenge.rules or "")
        if "json" in answer_format.lower():
            # msquad: the answer format decides the contract (JSON, not a comma list).
            solve_rules = f"{solve_rules}\nAnswer format: {answer_format}".strip()
        solve_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=solve_rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
        )
        
        ticker = ReasoningTicker(model_name)
        def _solve_on(solve_model: str):
            return solve_challenge(
                challenge,
                clues,
                llm_client,
                solve_model,
                strategy,
                solve_ctx,
                http_client=http_client,
                agent_id=agent_id,
                broadcast_thought=True,
                evidence_lines=tool_evidence_lines,
                ticker=ticker,
                budget=budget,
            )

        try:
            # A failed call (for example HTTP 400) gets one try on the next roster model.
            model_name, result = await solve_with_model_fallback(
                _solve_on,
                ranked_models,
                model_name,
                budget.remaining,
                RESOLVE_MIN_REMAINING_S,
                fastest=lambda current: strategy.fastest_model(ranked_models, str(challenge.challenge_type or ""), current),
                submit_margin_s=SUBMIT_MARGIN_S,
            )
            answer, raw_response, model_name, usage, ttft_ms, total_time_ms = result
        except Exception as exc:  # timeout or transport error: submit the fallback, never nothing
            print(f"   ⚠️  LLM call failed ({exc}); submitting fallback.")
            answer, raw_response, usage, ttft_ms, total_time_ms = "", "", {"finish_reason": "error"}, 0, 0
        # Hard-mode distractors can name people who are not in this puzzle. An answer
        # with an outsider is re-solved once with the real entity list stated.
        entities = entities_from_challenge(challenge.description)
        outsiders = outside_names(answer, entities)
        # An empty or placeholder answer ("-") is never submitted while time remains.
        if needs_resolve(getattr(strategy, "_task", ""), answer, outsiders, str(challenge.challenge_type or "")) and budget.remaining() > RESOLVE_MIN_REMAINING_S:
            print(f"   ⚠️  Answer {answer!r} is empty or names people outside the puzzle {outsiders}; re-solving once.")
            try:
                retry = await solve_challenge(
                    challenge,
                    clues,
                    llm_client.with_options(timeout=budget.llm_timeout(), max_retries=1),
                    model_name,
                    strategy,
                    solve_ctx,
                    http_client=http_client,
                    agent_id=agent_id,
                    broadcast_thought=False,
                    evidence_lines=[*tool_evidence_lines, *([entity_note(entities)] if entities else [])],
                    budget=budget,
                )
                if not is_placeholder(retry[0]) and not outside_names(retry[0], entities):
                    answer, raw_response, model_name, usage, ttft_ms, total_time_ms = retry
            except Exception as exc:  # keep the first answer if the re-solve fails
                print(f"   ⚠️  Re-solve failed ({exc}); keeping the first answer.")
        ticker.finish()
        async def _remaining_s() -> float:
            return await clock.remaining()

        def _solve_with(retry_model: str):
            nonlocal ticker
            http_client.broadcast_thought(agent_id, f"Retrying with {retry_model}...")
            ticker = ReasoningTicker(retry_model)
            return solve_challenge(
                challenge,
                clues,
                llm_client,
                retry_model,
                strategy,
                solve_ctx,
                http_client=http_client,
                agent_id=agent_id,
                broadcast_thought=True,
                evidence_lines=tool_evidence_lines,
                ticker=ticker,
                budget=budget,
            )

        answer, raw_response, model_name, usage, ttft_ms, total_time_ms = await _retry_after_length_stop(
            (answer, raw_response, model_name, usage, ttft_ms, total_time_ms),
            ranked_models=ranked_models,
            remaining_s=_remaining_s,
            solve_with=_solve_with,
        )
        ticker.finish()
        for line in summary_lines(
            model=model_name,
            elapsed_s=total_time_ms / 1000,
            usage=usage,
            finish_reason=str(usage.get("finish_reason") or ""),
            answer=answer,
            ticker=ticker,
        ):
            print(line)
        
        # Deterministic normalization first; one cheap repair call only if it
        # fails validation and the clock allows it.
        finalized = strategy.finalize_answer(raw_response, solve_ctx)
        # The logic solver's answer is already validated; clue-inferred names can miss some.
        logic_solved = normalize_entity_answer(
            solve_logic_from_challenge(
                f"{challenge.description}\n{challenge.rules}\n{getattr(challenge, 'answer_format', '')}",
                clues,
            ),
            str(challenge.rules or ""),
        )
        if not finalized.valid and not logic_solved and budget.remaining() - budget.margin_s > 15:
            print(f"   ⚠️  Reply rejected ({finalized.reason}); asking for a bare answer once.")
            repair_raw = _repair_answer(
                llm_client.with_options(timeout=budget.llm_timeout(), max_retries=0),
                model_name, raw_response, solve_ctx, finalized.reason,
            )
            repaired = strategy.finalize_answer(repair_raw, solve_ctx)
            print(
                f"   first reply: {finalized.answer!r} valid={finalized.valid} ({finalized.reason or 'ok'}); "
                f"repair: {repaired.answer!r} valid={repaired.valid} ({repaired.reason or 'ok'})"
            )
            # A valid first answer is never replaced by the repair.
            finalized = choose_final_answer(finalized, repaired)
            print(f"   using: {finalized.answer!r}")
        if not finalized.valid:
            # A reply cut off mid-thought: submit an order it stated, never the reasoning.
            salvaged = salvage_final_answer(finalized, raw_response, solve_ctx)
            if salvaged.valid:
                print(f"   salvaged order from reasoning: {salvaged.answer!r}")
            finalized = salvaged
        answer = logic_solved or finalized.answer
        literal_empty_ok = accepts_literal_empty(str(challenge.challenge_type or ""), answer)
        if (not literal_empty_ok and _is_invalid_answer_candidate(answer)) or is_logic_refusal(answer, str(challenge.challenge_type or "")):
            answer = ""
        # msquad: a single-entity answer is never a comma-joined pair.
        answer = collapse_single_value(answer, str(challenge.rules or ""), list(clues) + list(tool_evidence_lines))
        if not answer:
            print("   ⚠️  No valid ANSWER format found; normalizing last line as fallback.")
            lines = raw_response.strip().splitlines()
            last_line = lines[-1].strip().strip("`\"'") if lines else ""
            if is_logic_refusal(last_line, str(challenge.challenge_type or "")):
                last_line = ""
            # Same normalizer as the main path, so spaces and prose never reach submit.
            fallback = strategy.finalize_answer(last_line, solve_ctx)
            answer = (
                fallback.answer
                if fallback.answer and not _is_invalid_answer_candidate(fallback.answer)
                else fallback_answer(challenge.challenge_type, clues, challenge.description, getattr(challenge, "rules", ""))
            )

        if is_json_answer_shape(
            str(challenge.challenge_type or ""),
            str(challenge.rules or ""),
            str(challenge.description or ""),
        ):
            answer = natural_order(answer, str(challenge.description or ""), clue_texts=clues)

        _GUARD["answer"] = answer
        if str(challenge.challenge_type or "").strip().lower() == "structured":
            # msquad: check the answer against the described shape; re-ask once when time allows.
            answer, shape_note = await resolve_shape_answer(
                answer,
                answer_format=str(getattr(challenge, "answer_format", "") or ""),
                rules=str(challenge.rules or ""),
                task=str(challenge.description or ""),
                llm_client=llm_client,
                model_name=model_name,
                remaining_s=budget.remaining(),
                margin_s=SUBMIT_MARGIN_S,
            )
            if shape_note:
                print(f"   Shape check: {shape_note}")
        # Save draft with extracted answer as backup
        http_client.save_draft(agent_id, answer, "LLM solution")
        # Thoughts are public: never echo the answer, the clues or the solver output here.
        http_client.broadcast_thought(agent_id, "Answer ready; submitting.")
        
        # Check time remaining
        remaining_s = await clock.remaining()
        submit_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            time_remaining_s=remaining_s,
            tokens_used=usage.get("total_tokens", 0),
        )
        if not answer:
            answer = fallback_answer(challenge.challenge_type, clues, challenge.description, getattr(challenge, "rules", ""))
        budget.set_draft(answer)
        if strategy.should_submit_early(answer, submit_ctx):
            http_client.broadcast_thought(agent_id, "⚡ Strategy submitting early.")
        revised_answer = strategy.on_time_warning(remaining_s, answer, submit_ctx)
        if isinstance(revised_answer, str) and revised_answer.strip():
            answer = revised_answer.strip()
        print(f"   Time remaining: {remaining_s:.1f}s")
    
    # Optional second-model check (msquad/verify.py), flag-gated by MSQUAD_VERIFY=1.
    if verify_enabled(
        str(getattr(challenge, "difficulty", "") or ""),
        remaining_s,
        float(challenge.max_time_s or 0),
        os.getenv("MSQUAD_VERIFY", ""),
    ) and should_verify(remaining_s, usage.get("total_tokens", 0), 0):
        async def _resolve(hctx):
            return (await solve_challenge(
                challenge, clues, llm_client, model_name, strategy, hctx,
            ))[0]

        answer = await verify_and_maybe_resolve(
            answer,
            llm_client=llm_client,
            verifier_model=pick_verifier_model(ranked_models, model_name),
            challenge_text=str(challenge.description or ""),
            clues=[(f"c{i + 1}", text) for i, text in enumerate(clues)],
            ctx=submit_ctx,
            remaining_s=remaining_s,
            resolve=_resolve,
        )

    # Step 4: Submit the extracted answer with real metrics
    stages.mark("solve + finalize")
    print("\n📤 Submitting answer...")
    http_client.broadcast_thought(agent_id, "Submitting final answer!")
    await _stop_metrics_reporter()
    
    result = resilience.submit_resilient(
        http_client,
        agent_id,
        answer=answer,
        client_metrics={
            "model_name": model_name,
            "total_tokens": str(live_total_tokens),
            "prompt_tokens": str(live_prompt_tokens),
            "completion_tokens": str(live_completion_tokens),
            "ttft_ms": ttft_ms,
            "total_time_ms": total_time_ms,
        }
    )
    
    _GUARD["submitted"] = True
    stages.mark("submit")
    print(f"   Accepted: {result.accepted}")
    print(f"   Status: {result.status}")
    if result.score:
        print(f"   Score: {result.score.get('final_score', 0)}")
        print(f"   Quality: {result.score.get('quality_score', 0)}")
        print(f"   Speed: {result.score.get('speed_score', 0)}")
    if missing_tools_note(result):
        print(f"   ⚠️  {missing_tools_note(result)}")
    
    await session_monitor.stop()
    # Last step, after the submission is final; never raises.
    run_record = {
        "agent_id": agent_id,
        "challenge": challenge_record(challenge),
        "model": model_name,
        "answer": answer,
        "usage": usage,
        "total_time_ms": total_time_ms,
        "stages": stages.marks,
        "result": {
            "accepted": result.accepted,
            "status": result.status,
            "score": result.score,
        },
    }
    print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
    print("\n✅ Agent completed!")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except resilience.RegistrationTerminal as exc:
        print(f"   {exc}")
        raise SystemExit(1)
    except asyncio.CancelledError:
        raise SystemExit(0)
    except ModelSelectionError as exc:
        print(f"   {exc}")
        raise SystemExit(1)
    except Exception as exc:
        raise SystemExit(submit_guard_fallback(exc))
