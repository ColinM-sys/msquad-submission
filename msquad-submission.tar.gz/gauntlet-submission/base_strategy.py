"""Programmable strategy hooks for Agent Gauntlet Starter Kit agents.

`BaseStrategy` is framework-agnostic and exposes the same hook surface to
Python, LangGraph, and CrewAI examples.
"""

from __future__ import annotations

import difflib
import json
import re
from dataclasses import dataclass, field
from typing import Any

from model_selector import prefer_image_models as filter_image_models


_IMAGE_SIZE_HINT = (
    "Keep the output compact for transport: standard resolution only "
    "(about 1024 pixels on the longest side, or the source size if smaller). "
    "Do not request HD, 4K, ultra-high-resolution, or upscaled output."
)


# --- Output contract and answer extraction ---------------------------------
_THINK_RE = re.compile(r"<think>.*?(?:</think>|$)", re.DOTALL | re.IGNORECASE)
_FENCE_LINE_RE = re.compile(r"^\s*```[a-zA-Z0-9_-]*\s*$", re.MULTILINE)
_ARROW_RE = re.compile(r"\s*(?:-->|->|=>|→|⇒|»)\s*")
_LABEL_RE = re.compile(
    r"^[\s*_`#>\-]*"
    r"(?:the\s+)?(?:final\s+)?(?:answer|solution|result|ordering|order)"
    r"[\s*_`]*(?:is)?[\s*_`]*:?[\s*_`]*",
    re.IGNORECASE,
)
_QUOTE_CHARS = "\"'`“”‘’*_"
_NUMBERING_RE = re.compile(r"^\s*(?:\d+[.)]|[-*•])\s+")
_CAPITALIZED_RE = re.compile(r"\b[A-Z][a-zA-Z]+\b")
_NAME_SHAPE_RE = re.compile(r"[A-Z][A-Za-z'-]*(?: [A-Z][A-Za-z'-]*){0,2}$")
_TWO_WORD_RE = re.compile(r"\b([A-Z][a-zA-Z]+)\s+[A-Z][a-zA-Z]+\b")
_NON_ENTITY_WORDS = frozenset(
    {
        "A", "An", "The", "If", "Then", "Else", "And", "Or", "Not", "No", "Yes",
        "Since", "While", "After", "Before", "Once", "Because", "Although", "Unless",
        "However", "Therefore", "Thus", "Hence", "Now", "Here", "There", "Also", "Assume",
        "Suppose", "Given", "Only", "Exactly", "Both", "Neither", "Either", "Next", "Last",
        "Who", "What", "Which", "Where", "When", "Why", "How", "Each", "Every",
        "Clue", "Clues", "Rules", "Rule", "Answer", "Final", "ANSWER", "Output",
        "Unknown", "None", "Only", "Exactly", "Format", "Note", "Given", "Also",
        "Both", "Either", "Neither", "Someone", "Nobody", "Everyone", "First",
        "Last", "Second", "Third", "Before", "After", "Between", "Next", "Since",
        "Because", "Therefore", "Thus", "Hence", "So", "It", "This", "That",
        "There", "They", "He", "She", "Its", "Their", "His", "Her",
    }
)


def infer_entities(clues: list[str] | None) -> list[str]:
    """Return candidate entity names found in the clues, keeping multi-word names.

    A capitalized word that often comes before another capitalized word ("Team"
    in "Team Alpha") is a generic prefix, not a name. A name written with its
    prefix in the clues is kept whole ("Team Alpha"), so answers in either form
    map to one canonical spelling. Only clue text counts, never the rules.
    """
    texts = [str(clue or "") for clue in clues or []]
    heads: dict[str, int] = {}
    for text in texts:
        for match in _TWO_WORD_RE.finditer(text):
            heads[match.group(1)] = heads.get(match.group(1), 0) + 1
    prefixes = {
        word for word, count in heads.items() if count >= 2 and word not in _NON_ENTITY_WORDS
    }
    seen: list[str] = []
    for text in texts:
        for match in _CAPITALIZED_RE.finditer(text):
            word = match.group(0)
            if word in _NON_ENTITY_WORDS or word in prefixes:
                continue
            before = text[: match.start()].split()
            name = f"{before[-1]} {word}" if before and before[-1] in prefixes else word
            if name not in seen:
                seen.append(name)
    return seen


_ENTITY_LIST_RE = re.compile(
    r"\b(names?|order|ordering|sequence|people|persons?|teams?|players?|suspects?|"
    r"candidates?|items?\s+in\s+order)\b",
    re.IGNORECASE,
)
_NON_ENTITY_ANSWER_RE = re.compile(
    r"\b(numbers?|numeric|digits?|ids?|identifiers?|codes?|counts?|how\s+many|"
    r"integers?|years?|dates?|amounts?|prices?)\b",
    re.IGNORECASE,
)


def is_entity_list_answer(rules: str) -> bool:
    """True only when the challenge asks for a list of named entities.

    Numeric, ID, code and free-text answers return False, so their tokens are
    never checked against clue names.
    """
    text = str(rules or "")
    if _NON_ENTITY_ANSWER_RE.search(text):
        return False
    return bool(_ENTITY_LIST_RE.search(text))


def separator_from_rules(rules: str) -> str:
    """Pick the join separator the challenge asks for (default: comma, no spaces)."""
    lowered = str(rules or "").lower()
    if "newline" in lowered or "one per line" in lowered:
        return "\n"
    if "space-separated" in lowered or "space separated" in lowered:
        return " "
    return ","


def expected_count_from_rules(rules: str) -> int | None:
    """Return N when the rules say e.g. "list all 5 names", else None."""
    match = re.search(
        r"\b(\d+)\s+(?:names|items|entities|people|persons|steps|words|letters|cities|colors|colours)\b",
        str(rules or ""),
        flags=re.IGNORECASE,
    )
    return int(match.group(1)) if match else None


def wants_json(rules: str) -> bool:
    """True when the challenge's answer format asks for JSON (the list contract does not apply)."""
    return "json" in str(rules or "").lower()


def output_contract(rules: str, clues: list[str] | None = None) -> str:
    """Build the strict output contract shown to the model.

    The contract quotes the challenge's own answer rules, so the format comes
    from the challenge text rather than a hardcoded template.
    """
    rules_text = str(rules or "").strip() or "Follow the challenge format exactly."
    if wants_json(rules):
        return "\n".join(
            [
                "OUTPUT CONTRACT (mandatory):",
                "- Final line: ANSWER: <one JSON object on one line>.",
                "- Use exactly the keys and types in the rules (Required JSON shape).",
                "- No prose, no code fences.",
                "- The top-level JSON type is exactly the Required JSON shape: 'array of ...' means a bare JSON array, not an object.",
                "- Ignore clues that do not describe the entities the question asks about; use names exactly as written.",
                "- If the challenge states an order (e.g. 'in sensor order', 'sorted by', 'chronological'), order array items exactly that way; otherwise keep the order the facts appear in the clues.",
                f"- Challenge answer rules: {rules_text}",
            ]
        )
    count = expected_count_from_rules(rules)
    if not is_entity_list_answer(rules):
        single = [
            "OUTPUT CONTRACT (mandatory):",
            "- Your final line must be exactly: ANSWER: <bare answer>",
            "- The bare answer is the single value exactly as written in the evidence or clues, spaces and capitalisation kept.",
            "- No prose, no quotes, no code fences.",
            f"- Challenge answer rules: {rules_text}",
        ]
        if count:
            single.append(f"- Include exactly {count} items.")
        return "\n".join(single)
    separator = separator_from_rules(rules)
    sep_label = {",": "comma-separated, no spaces", " ": "space-separated", "\n": "one per line"}[separator]
    entities = infer_entities(clues)
    lines = [
        "OUTPUT CONTRACT (mandatory):",
        "- Your final line must be exactly: ANSWER: <bare answer>",
        f"- The bare answer is {sep_label}. No prose, no arrows, no quotes, no code fences, no explanation inside it.",
        f"- Challenge answer rules: {rules_text}",
    ]
    if entities:
        lines.append(f"- Use only these names exactly as spelled: {', '.join(entities)}")
    if count:
        lines.append(f"- Include exactly {count} items.")
    return "\n".join(lines)


_LEADING_ARTICLE_RE = re.compile(r"^(?:the|a|an)\s+(.+)$")  # lower-case article only


# Place-label words a JSON key can name ("room" for "Room 3"). Only these prefixes are restored.
_PLACE_LABEL_WORDS = frozenset(
    {
        "room", "gate", "pier", "bay", "desk", "platform", "hall", "building", "floor", "suite",
        "track", "terminal", "lane", "booth", "stand", "dock",
    }
)


def _restore_clue_token(text: str, clues: list[str], key: str | None) -> str:
    """Restore a bare number to the longer clue token it was cut from ("3" -> "Room 3").

    Only for digits, only under a JSON key that names the prefix ("room" for "Room 3"), and
    only when every occurrence of it in the clues is
    preceded by one capitalised word, and those words agree on a single token. A value
    that also appears standalone in the clues (a real number, "3 people") is left alone.
    """
    # Digits only: a bare id like "INV-2291" is already the full value, not a cut-down one.
    if not clues or not text or not text.isdigit():
        return text
    joined = " ".join(clues)
    occurrences = list(re.finditer(r"(?<![\w-])" + re.escape(text) + r"(?![\w-])", joined))
    if not occurrences:
        return text
    candidates: set[str] = set()
    for match in occurrences:
        before = re.search(r"([A-Z][A-Za-z'-]*)\s+$", joined[: match.start()])
        word = before.group(1).casefold() if before else ""
        if word not in _PLACE_LABEL_WORDS or not key or word != key.casefold():
            return text
        candidates.add(f"{before.group(1)} {text}")
    return candidates.pop() if len(candidates) == 1 else text


def _drop_article_absent_from_clues(value, clues: list[str], key: str | None = None):
    """Adjust JSON strings to the clues: restore a cut-down token, and drop a lower-case article.

    A "label" copied from "the lab at +44..." should be "lab". Capitalised names ("The Hague",
    "A Tale of Two Cities") keep their article. A bare value such as "3" becomes "Room 3" only
    when the clues never use it on its own (see _restore_clue_token).
    """
    if not clues:
        return value
    clue_text = " ".join(clues).casefold()

    if isinstance(value, dict):
        return {
            item_key: _drop_article_absent_from_clues(item, clues, item_key)
            for item_key, item in value.items()
        }
    if isinstance(value, list):
        return [_drop_article_absent_from_clues(item, clues, key) for item in value]
    if not isinstance(value, str):
        return value
    text = _restore_clue_token(value, clues, key)
    if key == "label":
        match = _LEADING_ARTICLE_RE.match(text)
        if match and match.group(1).casefold() in clue_text:
            text = match.group(1)
    return text


def _json_reply(text: str, rules: str, clues: list[str] | None = None) -> str | None:
    """Return the compact JSON for the first balanced object (or array, if the rules ask for JSON).

    A JSON object is never a list of names, so it must not go through the
    comma/entity normalizer, which rejects every object. Prose around the
    JSON is ignored.
    """
    stripped = re.sub(r"^\s*ANSWER:\s*", "", str(text or "").strip(), flags=re.IGNORECASE)
    decoder = json.JSONDecoder()
    wants_json = "json" in str(rules or "").lower()
    for index, char in enumerate(stripped):
        if char not in "{[":
            continue
        if char == "[" and not wants_json:
            continue
        try:
            value, _ = decoder.raw_decode(stripped[index:])
        except ValueError:
            continue
        if isinstance(value, dict) and _TOP_LEVEL_ARRAY_RE.search(str(rules or "")) and len(value) == 1:
            only = next(iter(value.values()))
            if isinstance(only, list):
                value = only
        if isinstance(value, dict) or (isinstance(value, list) and wants_json):
            value = _drop_article_absent_from_clues(value, clues or [])
            return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return None



@dataclass
class ExtractedAnswer:
    """Result of ``extract_final_answer``."""

    answer: str
    valid: bool
    reason: str = ""
    tokens: list[str] = field(default_factory=list)


def _clean_token(token: str) -> str:
    cleaned = _NUMBERING_RE.sub("", token).strip()
    cleaned = cleaned.strip(_QUOTE_CHARS + " \t()[]{}")
    cleaned = cleaned.rstrip(".;:!?")
    return cleaned.strip(_QUOTE_CHARS + " \t")


def _pick_candidate_line(text: str) -> str:
    """Return the text holding the final answer: the last label, else the last list."""
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return ""
    labeled = [index for index, line in enumerate(lines) if _LABEL_RE.match(line)]
    if labeled:
        index = labeled[-1]
        remainder = _LABEL_RE.sub("", lines[index], count=1).strip()
        if remainder:
            return remainder
        # "ANSWER:" on its own line: the answer is the lines that follow it.
        return "\n".join(lines[index + 1 :])
    # No label: a trailing bullet or numbered list is the answer.
    start = len(lines) - 1
    if _NUMBERING_RE.match(lines[start]):
        while start > 0 and _NUMBERING_RE.match(lines[start - 1]):
            start -= 1
    return "\n".join(lines[start:])


def _split_tokens(candidate: str, entities: list[str]) -> list[str]:
    text = _ARROW_RE.sub(",", candidate)
    text = text.replace("\n", ",")
    parts = re.split(r"[,;|]+", text)
    tokens: list[str] = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        # Whitespace-only lists are accepted only when every word is a known entity.
        part = re.sub(r"(?<!\S)\d+[.)](?!\S)", " ", part)
        words = [_clean_token(word) for word in part.split()]
        if (
            entities
            and len(words) > 1
            and all(word.lower() in {e.lower() for e in entities} for word in words if word)
        ):
            tokens.extend(word for word in words if word)
            continue
        tokens.append(_clean_token(part))
    return [token for token in tokens if token]


def _canonical(token: str, entities: list[str]) -> str | None:
    """Map a reply token to a known entity without ever lengthening it.

    Exact matches win. Otherwise a known name inside a longer reply item shrinks
    to that name ("Since Alice" -> "Alice"), and a close spelling maps to its
    entity. A bare name is never extended to a prefixed entity ("Alpha" stays
    "Alpha" even when the clues say "Team Alpha").
    """
    lookup = {entity.lower(): entity for entity in entities}
    key = token.lower()
    if key in lookup:
        return lookup[key]
    words = token.split()
    for size in range(len(words) - 1, 0, -1):
        for start in range(len(words) - size + 1):
            phrase = " ".join(words[start : start + size]).lower()
            if phrase in lookup:
                return lookup[phrase]
    close = difflib.get_close_matches(key, list(lookup), n=1, cutoff=0.85)
    return lookup[close[0]] if close else None


ANSWER_SHAPES = ("entity_list", "pairs", "json", "number", "date", "id_code", "short_text", "image")


_SCHEMA_DROP_TOKENS = frozenset({"number", "no", "num", "id", "code"})
_SCHEMA_SYNONYMS = {"vendor": "supplier", "company": "supplier"}


def _key_tokens(key: str) -> tuple[str, ...]:
    """Words of a key, lowercased; camelCase splits; number/id suffixes dropped."""
    spaced = re.sub(r"([a-z])([A-Z])", r"\1 \2", str(key))
    words = [word for word in re.split(r"[^A-Za-z]+", spaced.lower()) if word]
    return tuple(word for word in words if word not in _SCHEMA_DROP_TOKENS)


def _match_schema_key(key: str, properties: dict) -> str | None:
    """The schema property a reply key means, by synonym or by words; None if none.

    A key with no words left after dropping suffixes ('id', 'code') never matches.
    """
    synonym = _SCHEMA_SYNONYMS.get(key.lower())
    if synonym in properties:
        return synonym
    tokens = _key_tokens(key)
    if not tokens:
        return None
    for prop in properties:
        if _key_tokens(prop) == tokens:
            return prop
    return None


def _name_part_key(value: dict, properties: dict, words: tuple[str, ...]) -> str | None:
    """A reply key made of the given words that the schema does not already name exactly."""
    return next(
        (key for key in value if key not in properties and _key_tokens(key) == words),
        None,
    )


def coerce_to_schema(value: object, schema: object) -> object:
    """Shape a JSON value to a schema: map renamed keys, drop extras, keep nesting.

    Exact key matches win first, and each schema property is claimed once. Extra
    keys are dropped only when the schema says additionalProperties is false.
    Never invents a value: a required key with no counterpart stays missing.
    """
    if not isinstance(schema, dict):
        return value
    enum = schema.get("enum")
    if isinstance(enum, list) and isinstance(value, str) and value not in enum:
        # A value that matches exactly one enum member ignoring case becomes that member.
        matches = [member for member in enum if isinstance(member, str) and member.lower() == value.lower()]
        if len(matches) == 1:
            return matches[0]
        return value
    if schema.get("type") == "array" and isinstance(value, list):
        return [coerce_to_schema(item, schema.get("items", {})) for item in value]
    if schema.get("type") != "object" or not isinstance(value, dict):
        return value
    properties = schema.get("properties", {})
    drop_extras = schema.get("additionalProperties") is False
    out: dict = {}
    # Pass 1: exact key matches.
    for key, item in value.items():
        if key in properties:
            out[key] = coerce_to_schema(item, properties[key])
    # Pass 2: first/last name joined into a single 'name', only when the schema
    # asks for 'name' and does not name the parts itself.
    first = _name_part_key(value, properties, ("first", "name"))
    last = _name_part_key(value, properties, ("last", "name"))
    joined = "name" in properties and "name" not in out and first is not None and last is not None
    if joined:
        out["name"] = f"{value[first]} {value[last]}"
    # Pass 3: remaining keys map to at most one unclaimed property each. The name
    # parts are consumed only when the join used them; otherwise they are mapped
    # or kept like any other key.
    for key, item in value.items():
        if key in properties or (joined and key in (first, last)):
            continue
        target = _match_schema_key(key, properties)
        if target is None:
            if not drop_extras:
                out[key] = item
            continue
        if target in out:
            # Already claimed by another reply key: kept verbatim unless extras are banned.
            if not drop_extras:
                out[key] = item
            continue
        out[target] = coerce_to_schema(item, properties[target])
    return out


def _split_top_level(body: str) -> list[str]:
    """Split on commas that sit outside any {}, [] or () group."""
    parts: list[str] = []
    depth = 0
    current = ""
    for char in body:
        if char in "{[(":
            depth += 1
        elif char in "}])":
            depth -= 1
        if char == "," and depth == 0:
            parts.append(current.strip())
            current = ""
        else:
            current += char
    if current.strip():
        parts.append(current.strip())
    return parts


def _parse_shape(text: str) -> dict | None:
    """Parse the plain-text shape the gym prints, e.g. 'object {id: integer, n (optional): string}'."""
    text = text.strip()
    if text.startswith("object {") and text.endswith("}"):
        properties: dict = {}
        required: list[str] = []
        for field in _split_top_level(text[len("object {") : -1]):
            key_part, separator, sub = field.partition(":")
            if not separator:
                return None
            key = key_part.replace("(optional)", "").strip()
            sub_schema = _parse_shape(sub)
            if not key or sub_schema is None:
                return None
            properties[key] = sub_schema
            if "(optional)" not in key_part:
                required.append(key)
        schema: dict = {"type": "object", "properties": properties}
        if required:
            schema["required"] = required
        return schema
    if text.startswith("array of "):
        items = _parse_shape(text[len("array of ") :])
        return None if items is None else {"type": "array", "items": items}
    match = re.fullmatch(r"(string|integer|number|boolean|null)(?: matching (.+))?", text)
    if match:
        schema = {"type": match.group(1)}
        if match.group(2):
            schema["pattern"] = match.group(2).strip()
        return schema
    return None


def _schema_from_text(text: str) -> dict | None:
    """The schema in the challenge text: a JSON schema, or the gym's 'Required JSON shape' line."""
    source = str(text or "")
    decoder = json.JSONDecoder()
    for index, char in enumerate(source):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(source[index:])
        except ValueError:
            continue
        if isinstance(value, dict) and ("properties" in value or value.get("type") == "array"):
            return value
    marker = "Required JSON shape:"
    if marker in source:
        line = source.split(marker, 1)[1].splitlines()[0]
        return _parse_shape(line)
    return None


def is_json_answer_shape(challenge_type: str, rules: str, description: str = "") -> bool:
    """True when the challenge asks for a JSON answer, whatever its type is named.

    The type 'structured' counts, and so does a JSON answer format or a
    description that mentions JSON, so a renamed JSON task still gets its
    array ordered.
    """
    if classify_answer_shape(rules, challenge_type=challenge_type) == "json":
        return True
    return "json" in f"{rules} {description}".lower()


def classify_answer_shape(answer_format: str, *, challenge_type: str = "") -> str:
    """Classify the answer shape from the challenge's answer text and type (rules only).

    Order matters: image and structured types first, then explicit pairs, then
    entity lists, then the scalar shapes. Anything unmatched is short_text, which
    gets no normalizing.
    """
    fmt = str(answer_format or "").lower()
    ctype = str(challenge_type or "").lower()
    if ctype.startswith("image"):
        return "image"
    if fmt.startswith("json") or ctype == "structured":
        return "json"
    if "pairs" in fmt:
        return "pairs"
    if "names" in fmt and "comma" in fmt:
        return "entity_list"
    if "yyyy-mm-dd" in fmt or "date" in fmt:
        return "date"
    if "code" in fmt:
        return "id_code"
    if any(word in fmt for word in ("integer", "decimal", "number", "year")):
        return "number"
    return "short_text"


# Longest short-text answer in the gym bank is 67 characters / 16 words; a reply far past
# this is the model's reasoning, not an answer (retrieval_hard_01 submitted ~14k characters).
PROSE_DUMP_MAX_CHARS = 400
PROSE_DUMP_MAX_WORDS = 60


# A sentence end: ., ! or ? (optionally closing a quote or bracket), whitespace, then a capital.
_SENTENCE_END_RE = re.compile(r"[.!?][\"')\]]?\s+[A-Z]")


def compact_json_answer(answer: str, rules: str) -> str:
    """A JSON array/object answer in compact form when the rules ask for JSON.

    "Answer with a JSON array of strings" is classed short_text (only formats that start
    with "json" take the json path), so a spaced reply like ["Alpha", "Delta"] was submitted
    as is and failed an exact judge keyed ["Alpha","Delta"] (fmt_json_18, quality 0).
    """
    if not re.search(r"\bjson\b", str(rules or ""), re.IGNORECASE):
        return answer
    try:
        value = json.loads(answer)
    except (TypeError, ValueError):
        return answer
    if not isinstance(value, (list, dict)):
        return answer
    # Lossless: drop only whitespace outside strings. Re-dumping would rewrite numbers
    # (1.50 -> 1.5, 1e3 -> 1000.0) and break an exact key that spells them as given.
    out: list[str] = []
    in_string = escaped = False
    for char in answer.strip():
        if in_string:
            out.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
        elif char == '"':
            in_string = True
            out.append(char)
        elif not char.isspace():
            out.append(char)
    return "".join(out)


_PAIR_ITEM_RE = re.compile(r"^(\s*)[_*`]*\s*([^:,]*?)\s*[_*`]*\s*:(.*)$", re.DOTALL)


def canonical_pair_names(answer: str, names: list[str]) -> str:
    """Name:value pairs with each name spelled as the puzzle spells it.

    Markdown or stray marks around a name are dropped and its case is matched to the roster
    ("_echo:teal" -> "Echo:teal"); a name the puzzle never mentions is only stripped. Values,
    separators and order are left exactly as given.
    """
    canon = {name.casefold(): name for name in names}
    pieces = re.split(r"(,\s*)", str(answer or ""))
    out = []
    for piece in pieces:
        match = _PAIR_ITEM_RE.match(piece) if piece and not piece.startswith(",") else None
        if match is None:
            out.append(piece)
            continue
        lead, name, rest = match.groups()
        out.append(f"{lead}{canon.get(name.casefold(), name)}:{rest}")
    return "".join(out)


def is_prose_dump(answer: str, challenge_type: str = "", rules: str = "") -> bool:
    """True when a short-text answer is really a block of reasoning.

    Long alone is not enough: a code answer can be a long one-line literal (a 70-item list,
    a 400-character string). Prose is long AND written in sentences, and code answers are
    never judged as prose.
    """
    if str(challenge_type or "").strip().lower() == "code":
        return False
    text = str(answer or "").strip()
    if _is_logic_reasoning(text, challenge_type, rules):
        return True
    if len(text) <= PROSE_DUMP_MAX_CHARS and len(text.split()) <= PROSE_DUMP_MAX_WORDS:
        return False
    return len(_SENTENCE_END_RE.findall(text)) >= 2


# A logic answer is names, values or a letter; every gym logic answer is one token. A reply cut
# off mid-thought ("Let me think ... so after weighing everything I am fairly sure") is short of
# the general limits above, has one sentence end or none, and was submitted as the answer.
# Reasoning is recognised by its markers, not by common words: a long name list ("Catherine of
# Aragon, ..., Anne of Denmark") or a sentence the rules ask for must stay valid (Fable on #248).
LOGIC_PROSE_MIN_WORDS = 15
_REASONING_MARKER_RE = re.compile(
    r"\b(?:let me|let's|let us|step by step|therefore|thus|hence|because|since|which means|"
    r"so (?:the|that|after|we|i|it)|first(?:ly)?(?=,)|i think|i am|i'm|we know|we can|"
    r"wait|hmm|double[- ]check|clue \d)\b",
    re.IGNORECASE,
)
_SENTENCE_RULE_RE = re.compile(r"\b(?:sentence|describe|description|explain|explanation|in words)\b", re.IGNORECASE)
_SHORT_LIST_ITEM_WORDS = 4


def _is_short_item_list(text: str) -> bool:
    """A comma list whose items are all a few words long: names, places, values."""
    items = [item.strip() for item in text.split(",")]
    return len(items) >= 3 and all(0 < len(item.split()) <= _SHORT_LIST_ITEM_WORDS for item in items)


def _is_logic_reasoning(text: str, challenge_type: str, rules: str = "") -> bool:
    """True when a logic answer is a run of reasoning rather than names, values or a requested sentence."""
    if "logic" not in str(challenge_type or "").strip().lower():
        return False
    if len(text.split()) <= LOGIC_PROSE_MIN_WORDS or _SENTENCE_RULE_RE.search(rules or ""):
        return False
    if _is_short_item_list(text):
        return False
    return bool(_REASONING_MARKER_RE.search(text))


def logic_answer_before_reasoning(
    text: str, challenge_type: str, rules: str = "", entities: list[str] | None = None
) -> str:
    """What to submit when a logic answer and its repair are both reasoning, or "".

    A blank scores 0 for sure, while "Ava because she arrived first" may still score (Fable on
    #248), so the text before the first reasoning marker is kept. "" (blank, then the last-line
    fallback) when the marker opens the reply, when the head is a comma list shorter than the
    puzzle's entity list ("Ava, Ben because ..." of three), or when the answer is not logic
    reasoning at all.
    """
    text = str(text or "").strip()
    if not _is_logic_reasoning(text, challenge_type, rules):
        return ""
    match = _REASONING_MARKER_RE.search(text)
    head = text[: match.start()].strip().rstrip(",;:-").strip() if match else ""
    if "," in head and entities and len([i for i in head.split(",") if i.strip()]) < len(entities):
        return ""
    return head


def format_answer(answer: str, rules: str) -> str:
    """Apply the layout the answer rules name: one per line, Name: value pairs, comma spacing.

    Only a rule that names the layout changes the answer; anything else is returned as is.
    """
    lowered = str(rules or "").lower()
    per_line = "per line" in lowered
    pairs = "name: value" in lowered
    comma = "comma-separated" in lowered or "comma separated" in lowered
    if not (per_line or pairs or comma):
        return answer
    items = [part.strip() for part in re.split(r"[,\n;]+", answer) if part.strip()]
    if not items:
        return answer
    if pairs and all(":" in item for item in items):
        items = [f"{key.strip()}: {value.strip()}" for key, value in (item.split(":", 1) for item in items)]
    if per_line:
        return "\n".join(items)
    if pairs or "space after each comma" in lowered or "one space after" in lowered:
        return ", ".join(items)
    if comma and "no spaces" in lowered:
        return ",".join(items)
    return answer


# An inline label: case-sensitive "ANSWER:" at the start or after a sentence end ("42. ANSWER: 42").
_INLINE_LABEL_RE = re.compile(r"(?:^|(?<=[.!?;:])\s+)ANSWER:")
_OPENERS = {"(": ")", "[": "]", "{": "}"}


def _inline_label_answer(text: str) -> str:
    """The text after the last inline "ANSWER:" that is outside quotes and brackets, else ""."""
    best = ""
    for match in _INLINE_LABEL_RE.finditer(text):
        before = text[: match.start()]
        depth = sum(before.count(o) - before.count(c) for o, c in _OPENERS.items())
        quoted = before.count('"') % 2 == 1 or before.count("“") > before.count("”")
        after = text[match.end():].strip()
        if depth == 0 and not quoted and after:
            best = after
    return best


def extract_bare_answer(raw: str, rules: str = "", challenge_type: str = "") -> ExtractedAnswer:
    """Bare extraction for non-list shapes: strip think blocks, fences and labels only.

    No comma splitting, arrow handling, name mapping or duplicate checks, so a JSON
    object, number or text value comes back exactly as the model wrote it. When the
    rules ask for one item per line, every line after the answer label is kept.
    """
    text = _THINK_RE.sub("", str(raw or ""))
    text = _FENCE_LINE_RE.sub("", text).replace("```", "")
    if any(_LABEL_RE.match(line.strip()) for line in text.splitlines() if line.strip()):
        if "per line" in str(rules or "").lower():
            lines = text.splitlines()
            labelled = [i for i, line in enumerate(lines) if _LABEL_RE.match(line.strip())]
            candidate = "\n".join(line for line in lines[labelled[-1]:] if line.strip())
            candidate = _LABEL_RE.sub("", candidate, count=1)
        else:
            candidate = _pick_candidate_line(text)
    else:
        candidate = text.strip()
        # "So the total is 42. ANSWER: 42" on one line: the answer follows the last real label.
        # Never for code, whose answer may itself contain the text "ANSWER:".
        if "code" not in str(challenge_type or "").lower():
            candidate = _inline_label_answer(candidate) or candidate
    # A code answer can be a string repr ('abc'): its quotes are part of the answer.
    wrappers = "`" if "code" in str(challenge_type or "").lower() else "`\"'“”‘’"
    candidate = candidate.strip().strip(wrappers).strip()
    if not candidate:
        return ExtractedAnswer("", False, "empty reply")
    candidate = format_answer(candidate, rules)
    return ExtractedAnswer(candidate, True, "")


_LOGIC_REFUSAL_RE = re.compile(
    r"^\s*I (?:cannot|can't)\b"
    r"|\bSince no\b[^.]*\bclues were provided\b"
    r"|\bthere (?:are|is) no\b[^.]*\bclues\b",
    re.IGNORECASE | re.MULTILINE,
)


def is_logic_refusal(text: str, challenge_type: str) -> bool:
    """True when a logic reply is a refusal or explanation rather than an answer.

    Scoped to logic tasks, and anchored to refusal shapes ('I cannot...',
    'Since no ... clues were provided', 'there are no ... clues'), so ordinary
    answers such as 'Guests cannot provide their own food' are not affected.
    """
    if "logic" not in str(challenge_type or "").lower():
        return False
    return bool(_LOGIC_REFUSAL_RE.search(str(text or "")))


def choose_final_answer(first: "ExtractedAnswer", repaired: "ExtractedAnswer") -> "ExtractedAnswer":
    """Pick between the first reply and the repair reply.

    A repair replaces the first answer only when the first is invalid and the
    repair is valid. A valid first answer is never replaced.
    """
    if first.valid:
        return first
    if repaired.valid:
        return repaired
    return first



def salvage_entity_order(text: str, entities: list[str], clues: list[str] | None = None) -> str:
    """Return the one order in ``text`` that names every entity once and fits every clue, or "".

    Reasoning also writes orders it then rejects ("check Ava,Leo,Ben,Maya... no"), so a
    stated order is used only when the clues confirm it: every clue must parse, the
    order must satisfy all of them, and exactly one distinct stated order may pass.
    Anything less returns "", because a wrong answer is worse than no salvage.
    """
    from msquad.logic_solver import order_satisfies

    names = [name for name in entities if name]
    if len(names) < 2 or not clues:
        return ""
    alternation = "|".join(re.escape(name) for name in sorted(names, key=len, reverse=True))
    name_re = rf"(?<![A-Za-z])(?:{alternation})(?![A-Za-z])"
    run_re = re.compile(rf"{name_re}(?:\s*,\s*{name_re})+")
    passing: set[str] = set()
    for match in run_re.finditer(str(text or "")):
        tokens = [token.strip() for token in match.group(0).split(",")]
        if len(tokens) == len(names) and sorted(tokens) == sorted(names) and order_satisfies(names, list(clues), tokens):
            passing.add(",".join(tokens))
    return passing.pop() if len(passing) == 1 else ""


def salvage_final_answer(first: "ExtractedAnswer", raw: str, ctx: "ChallengeContext") -> "ExtractedAnswer":
    """Recover an entity order from reasoning when no valid answer was extracted.

    A reply cut off mid-thought can still state the full order ("the intended
    answer is Ava,Ben,Maya,Leo"); submitting the prose instead scores zero
    quality. A valid answer, or any non entity-list shape, is returned unchanged.
    """
    if first.valid:
        return first
    if classify_answer_shape(ctx.rules, challenge_type=ctx.challenge_type) != "entity_list":
        return first
    entities = infer_entities(ctx.clues)
    order = salvage_entity_order(raw, entities, ctx.clues) or salvage_entity_order(first.answer, entities, ctx.clues)
    if not order:
        order = _dedupe_full_order(first, entities)
    if not order:
        return first
    return ExtractedAnswer(order, True, "", order.split(","))


def _dedupe_full_order(first: "ExtractedAnswer", entities: list[str]) -> str:
    """The closing full order of a list rejected only for repeated names, or "".

    The name normalizer collects every name a cut-off reply mentions ("Ava before Ben ... so
    Ava,Ben,Cal") into "Ava,Ben,Ava,Ben,Cal", which is invalid and was still submitted (quality
    0). Reasoning states its conclusion last, so the last len(entities) names are used, and only
    when they name every entity exactly once; anything else stays invalid.
    """
    if first.reason != "duplicate items" or len(entities) < 2:
        return ""
    tokens = [token.strip() for token in (first.answer or "").split(",") if token.strip()]
    tail = tokens[-len(entities):]
    return ",".join(tail) if sorted(tail) == sorted(entities) else ""

_GENERIC_LEADING_WORDS = frozenset(
    {"team", "squad", "player", "person", "agent", "group", "member"}
)  # group words only: personal titles (Dr, Mr, Ms, Mrs) are part of a name and stay


def _strip_shared_generic_prefix(tokens: list[str]) -> list[str]:
    """Drop a leading word that every item shares, when it is a generic label.

    "Team Alpha,Team Bravo" becomes "Alpha,Bravo". Items whose first words differ
    ("Ana Lopes,Ben Ruiz") are left alone, and so is a single item.
    """
    parts = [token.split() for token in tokens]
    if len(parts) < 2 or any(len(words) < 2 for words in parts):
        return tokens
    leading = {words[0].lower() for words in parts}
    if len(leading) != 1 or leading.pop() not in _GENERIC_LEADING_WORDS:
        return tokens
    return [" ".join(words[1:]) for words in parts]


def extract_final_answer(
    raw: str,
    *,
    rules: str = "",
    clues: list[str] | None = None,
    entities: list[str] | None = None,
) -> ExtractedAnswer:
    """Turn a raw model reply into the bare, normalized final answer.

    Handles: ``<think>`` blocks, code fences, ``ANSWER:``/``Final answer:``
    labels (also bolded), arrows (``A -> B``), quoted or numbered items, trailing
    punctuation, and comma/space/newline lists. When entities are known, each
    token is mapped to its canonical spelling, duplicates and unknown names
    make the answer invalid.
    """
    if entities is None:
        entities = infer_entities(clues) if is_entity_list_answer(rules) else []
    separator = separator_from_rules(rules)
    text = _THINK_RE.sub("", str(raw or ""))
    text = _FENCE_LINE_RE.sub("", text).replace("```", "")
    json_answer = _json_reply(text, rules, clues)
    if json_answer is not None:
        return ExtractedAnswer(json_answer, True, "", [])
    if wants_json(rules):
        # A JSON challenge never goes through the list normalizer; the caller repairs it.
        return ExtractedAnswer("", False, "no JSON object in reply", [])
    candidate = _pick_candidate_line(text)
    if not candidate:
        return ExtractedAnswer("", False, "empty reply")

    raw_tokens = _strip_shared_generic_prefix(_split_tokens(candidate, entities))
    if not raw_tokens:
        return ExtractedAnswer("", False, "no tokens")

    tokens: list[str] = []
    for token in raw_tokens:
        # "Name:colour" items are checked on the name side; the part after the colon is kept.
        name_part, colon, rest = token.partition(":")
        canonical = _canonical(name_part, entities) if entities else None
        if canonical is None and entities and not _NAME_SHAPE_RE.match(name_part):
            return ExtractedAnswer(
                separator.join(raw_tokens), False, f"not a name: {token}", raw_tokens
            )
        # The clue-derived list can miss real names, so an unmatched name is kept as
        # written. Only a name that is not name-shaped makes the answer invalid.
        tokens.append(f"{canonical or name_part}{colon}{rest}")

    answer = separator.join(tokens)
    if len(tokens) != len(set(tokens)):
        return ExtractedAnswer(answer, False, "duplicate items", tokens)
    count = expected_count_from_rules(rules)
    if count and len(tokens) != count:
        return ExtractedAnswer(answer, False, f"expected {count} items, got {len(tokens)}", tokens)
    if len(answer) > 300 or any(len(token.split()) > 6 for token in tokens):
        return ExtractedAnswer(answer, False, "looks like prose", tokens)
    if answer.lower() in {"unknown", "none", "n/a", "na"}:
        return ExtractedAnswer(answer, False, "placeholder answer", tokens)
    return ExtractedAnswer(answer, True, "", tokens)


def normalize_entity_answer(answer: str, rules: str) -> str:
    """Apply the shared-prefix strip to a deterministic solver's entity-list answer.

    Solver answers skip finalize_answer, so "Team Alpha,Team Bravo" would reach submit
    unstripped. Only the prefix strip runs here: each comma item is kept whole, so
    multi-word names ("Ana Lopes") are never split. Non-list answers pass through unchanged.
    """
    if not answer or "," not in answer or not is_entity_list_answer(rules):
        return answer
    tokens = [token.strip() for token in answer.split(",")]
    return ",".join(_strip_shared_generic_prefix(tokens))


def collapse_single_value(answer: str, rules: str, sources: list[str]) -> str:
    """For a single-entity question, never return a comma-joined pair.

    A name split into parts ("Mara,Lindqvist") becomes "Mara Lindqvist" only when
    that spelling appears verbatim in the sources. Anything else, including a real
    list, is returned unchanged.
    """
    if not answer or "," not in answer or is_entity_list_answer(rules):
        return answer
    source_text = " ".join(str(item) for item in sources if item)
    lowered = source_text.lower()
    parts = [part.strip() for part in answer.split(",") if part.strip()]
    if not parts:
        return answer
    joined = " ".join(parts)
    if joined.lower() in lowered:
        start = lowered.index(joined.lower())
        return source_text[start : start + len(joined)]
    return answer


# Units a question can name ("in Celsius") and how an answer may write them ("25 C").
_UNIT_SPELLINGS: dict[str, tuple[str, ...]] = {
    "celsius": ("c", "°c", "ºc", "celsius", "degrees c", "degrees celsius", "deg c"),
    "fahrenheit": ("f", "°f", "ºf", "fahrenheit", "degrees f", "degrees fahrenheit", "deg f"),
    "kelvin": ("k", "kelvin"),
    "percent": ("%", "percent", "per cent"),
    "minutes": ("min", "mins", "minute", "minutes"),
    "seconds": ("s", "sec", "secs", "second", "seconds"),
    "hours": ("h", "hr", "hrs", "hour", "hours"),
    "days": ("day", "days"),
    "kilometres": ("km", "kilometre", "kilometres", "kilometer", "kilometers"),
    "kilometers": ("km", "kilometre", "kilometres", "kilometer", "kilometers"),
    "metres": ("m", "metre", "metres", "meter", "meters"),
    "meters": ("m", "metre", "metres", "meter", "meters"),
    "kilograms": ("kg", "kilogram", "kilograms"),
    "dollars": ("$", "usd", "dollar", "dollars"),
    "centimetres": ("cm", "centimetre", "centimetres", "centimeter", "centimeters"),
    "millimetres": ("mm", "millimetre", "millimetres", "millimeter", "millimeters"),
    "litres": ("l", "litre", "litres", "liter", "liters"),
    "liters": ("l", "litre", "litres", "liter", "liters"),
    "millilitres": ("ml", "millilitre", "millilitres", "milliliter", "milliliters"),
    "euros": ("eur", "€", "euro", "euros"),
    "months": ("month", "months"),
    "years": ("year", "years", "yr", "yrs"),
}
# Abbreviations a question may use for the unit ("in kg", "in °C", "in %").
_UNIT_ABBREVIATIONS: dict[str, str] = {
    "kg": "kilograms", "km": "kilometres", "m": "metres", "cm": "centimetres", "mm": "millimetres",
    "min": "minutes", "s": "seconds", "h": "hours", "%": "percent", "°c": "celsius", "ºc": "celsius",
    "°f": "fahrenheit", "ºf": "fahrenheit", "k": "kelvin", "$": "dollars", "usd": "dollars",
    "ml": "millilitres", "l": "litres", "eur": "euros", "€": "euros",
}
_UNIT_NAMES = sorted(list(_UNIT_SPELLINGS) + list(_UNIT_ABBREVIATIONS), key=len, reverse=True)
# "in <unit>" as a whole token, not followed by a number: "in kg for the drone?" names the
# answer's unit; "in days 3 to 5" (a range) and "in museum" (a word) do not.
_ASKED_UNIT_RE = re.compile(
    r"\bin\s+(" + "|".join(re.escape(u) for u in _UNIT_NAMES) + r")(?![\w°º%$])(?!\s*\d)"
)
_NUMBER = r"-?\d+(?:\.\d+)?"
# Formats whose answer is the bare value: a short phrase, or a number ("integer litres",
# "Answer with the value only", "a single integer"). web_search_04 asked "integer litres" and
# "5600 litres" was submitted.
_UNIT_STRIP_FORMAT_RE = re.compile(r"short phrase|^\s*integer\b|value only|\bsingle integer\b|^\s*number\b", re.I)


def strip_named_unit(answer: str, question: str, answer_format: str, challenge_type: str) -> str:
    """A short-phrase retrieval answer that repeats the unit or label the question names becomes the number.

    "in Celsius" + "25 C" -> "25"; "route number" + "route 22" -> "22". Only those exact
    shapes change: a question that asks for the unit, any other wording, and free text
    are returned unchanged.
    """
    text = str(answer or "").strip()
    q = str(question or "").lower()
    if "retrieval" not in str(challenge_type or "").lower() or not _UNIT_STRIP_FORMAT_RE.search(str(answer_format or "")):
        return answer
    if re.search(r"\b(?:with|including|and)\s+(?:the\s+)?units?\b", q):
        return answer
    unit = _ASKED_UNIT_RE.search(q)
    if unit:
        # A unit must end the clause or lead into "for/of/per/at/on <lowercase word>": "in K-12
        # schools" and "in M district" are names, and "active in years past" is not asking for
        # the answer in years, so the band "10 Years" must stay (Fable on #267).
        after = str(question or "")[unit.end():]
        # Single letters double as names, so only a lowercase word may follow them.
        follower = "[a-z]" if len(unit.group(1)) == 1 and unit.group(1).isalpha() else "[A-Za-z]"
        if not re.match(r"\s*(?:[?.,;:!]|$)|\s+(?:for|of|per|at|on)\s+" + follower, after):
            unit = None
    if unit:
        name = _UNIT_ABBREVIATIONS.get(unit.group(1), unit.group(1))
        spellings = "|".join(re.escape(s) for s in sorted(_UNIT_SPELLINGS[name], key=len, reverse=True))
        found = re.fullmatch(rf"({_NUMBER})\s*(?:{spellings})\.?", text, flags=re.IGNORECASE)
        if found:
            return found.group(1)
    # Only labels a transit answer drops ("route 22" -> 22); a room, gate, platform or flight
    # key may keep its label, so those are left alone.
    label = re.search(r"\b(route|bus|line) number\b", q)
    if label:
        found = re.fullmatch(rf"{re.escape(label.group(1))}\s*(?:no\.?\s*|#\s*)?(\d+)", text, flags=re.IGNORECASE)
        if found:
            return found.group(1)
    return answer


def repair_prompt(bad_reply: str, rules: str, clues: list[str] | None, reason: str) -> str:
    """Short follow-up message asking the model to restate only the answer."""
    contract = output_contract(rules, clues)
    return (
        f"Your previous reply was rejected ({reason}).\n"
        f"Previous reply:\n{bad_reply.strip()[:1000]}\n\n"
        f"{contract}\n"
        "Reply with the single ANSWER line only."
    )


_TOP_LEVEL_ARRAY_RE = re.compile(r"required json shape:\s*array\s+of", re.IGNORECASE)
_ORDER_WORDS_RE = re.compile(r"\b(in (?:the )?(?:\w+ )?order|order given|sorted|sort|chronolog\w*|ascending|descending|first|last|before|after)\b", re.IGNORECASE)
_TIME_KEY_RE = re.compile(r"(date|time|_at$|^at$)", re.IGNORECASE)
_ORDER_KEY_RE = re.compile(r"\b(?:in|sorted by|ordered by|by)\s+([a-z_]+)\s+order\b", re.IGNORECASE)


def _sort_value(value: object) -> tuple[int, float | str]:
    """Numbers sort by value ('9' before '10'); everything else sorts as text after them."""
    if isinstance(value, bool):
        return (1, str(value))
    if isinstance(value, (int, float)):
        return (0, float(value))
    if isinstance(value, str):
        try:
            return (0, float(value))
        except ValueError:
            return (1, value)
    return (1, str(value))


def natural_order(answer: str, question_text: str, clue_texts: list[str] | None = None) -> str:
    """Order a JSON array when the question states no order.

    Sort by an ISO date/time field if the items have one, else by the first
    place each item's first value is mentioned in the question. Stated orders
    and non-array answers are returned unchanged.
    """
    try:
        value = json.loads(answer)
    except ValueError:
        return answer
    if isinstance(value, dict):
        # An object such as {"shifts": [...]}: order each list it holds.
        changed = {
            key: json.loads(natural_order(json.dumps(item, ensure_ascii=False), question_text, clue_texts))
            if isinstance(item, list)
            else item
            for key, item in value.items()
        }
        return json.dumps(changed, ensure_ascii=False, separators=(",", ":"))
    if not isinstance(value, list) or len(value) < 2:
        return answer
    # "in <key> order" / "sorted by <key>" names the key: sort by it, numbers by value.
    stated = _ORDER_KEY_RE.search(question_text or "")
    if stated:
        key = stated.group(1).lower()
        if all(isinstance(item, dict) and key in item for item in value):
            ordered = sorted(value, key=lambda item: _sort_value(item[key]))
            return json.dumps(ordered, ensure_ascii=False, separators=(",", ":"))
        return answer
    if _ORDER_WORDS_RE.search(question_text or ""):
        return answer
    if all(isinstance(item, dict) for item in value):
        time_keys = [
            key
            for key in value[0]
            if _TIME_KEY_RE.search(key) and all(isinstance(item.get(key), str) for item in value)
        ]
        if time_keys:
            ordered = sorted(value, key=lambda item: item[time_keys[0]])
            return json.dumps(ordered, ensure_ascii=False, separators=(",", ":"))
    question = (question_text or "").lower()

    def mention(item) -> int:
        first = next((str(v) for v in item.values() if isinstance(v, str) and v.strip()), "") if isinstance(item, dict) else str(item)
        position = question.find(first.lower()) if first else -1
        return position if position >= 0 else len(question)

    def first_text(item) -> str:
        if isinstance(item, dict):
            return next((str(v) for v in item.values() if isinstance(v, str) and v.strip()), "").lower()
        return str(item).lower()

    def clue_position(item) -> int:
        clues_text = " ".join(clue_texts or []).lower()
        text = first_text(item)
        position = clues_text.find(text) if text else -1
        return position if position >= 0 else len(clues_text)

    positions = [mention(item) for item in value]
    if len(set(positions)) == 1:
        # The question orders none of the items. The clues' order is used when a clue
        # names the items; otherwise the items are sorted alphabetically by text value.
        clues_text = " ".join(clue_texts or []).lower()
        if clues_text and any(first_text(item) and first_text(item) in clues_text for item in value):
            ordered = sorted(value, key=clue_position)
        else:
            ordered = sorted(value, key=first_text)
    else:
        ordered = sorted(value, key=mention)
    return json.dumps(ordered, ensure_ascii=False, separators=(",", ":"))


# --- Tool coverage ---------------------------------------------------------
# Read-only MCP tools that cost almost nothing. Order is the call order.
COVERAGE_TOOLS = ("arena.tools.list", "arena.time_remaining")
MIN_UNIQUE_TOOLS = 3


async def ensure_tool_coverage(
    mcp_client: Any,
    agent_id: str,
    already_used: set[str],
    *,
    min_unique: int = MIN_UNIQUE_TOOLS,
) -> set[str]:
    """Call cheap tools until ``already_used`` holds ``min_unique`` names.

    Returns the updated set of tool names used. Failures are swallowed: coverage
    is a score bonus and must never block the answer.
    """
    used = set(already_used)
    for tool_name in COVERAGE_TOOLS:
        if len(used) >= min_unique:
            break
        if tool_name in used:
            continue
        try:
            await mcp_client.call_tool(tool_name, {"agent_id": agent_id})
            used.add(tool_name)
        except Exception:
            continue
    return used


@dataclass
class ChallengeContext:
    """Runtime challenge context passed into strategy hooks."""

    challenge_type: str
    difficulty: str = "unknown"
    challenge_text: str = ""
    description: str = ""
    rules: str = ""
    clues: list[str] = field(default_factory=list)
    time_remaining_s: float = 0.0
    max_time_s: int = 0
    available_models: list[str] = field(default_factory=list)
    tools_used: list[str] = field(default_factory=list)
    tokens_used: int = 0
    required_tools: list[str] = field(default_factory=list)
    image_url: str | None = None


class BaseStrategy:
    """Default strategy behavior used by all starter-kit agents."""

    agent_id = "my-agent"
    agent_name = "My Team"

    text_system_prompt = (
        "You are a text challenge solver. "
        "Your first line must always be: ANSWER: <final answer>. "
        "Follow challenge rules exactly, including strict output formats. "
        "Do not output <think> tags. "
        "If you add reasoning, keep it to at most 2 short lines after the ANSWER line. "
        "Never output 'unknown'. "
        "Before submitting, broadcast at least one progress thought via broadcast_thought "
        "(POST /api/thought) so spectators can follow your progress."
    )
    text_strategy_notes = "Keep reasoning concise and always include an ANSWER line."
    text_temperature = 0.0
    # Reasoning models spend most of this budget thinking before they answer;
    # 1024 cut the roster's default model off before it wrote an answer.
    text_max_tokens = 8192
    image_strategy_notes = (
        "Prefer image_edit when an input image is available. Keep rationale concise. "
        "Request standard-resolution output only and avoid HD or 4K images."
    )

    @staticmethod
    def is_image_challenge(ctx: ChallengeContext) -> bool:
        """True when the running heat is an image challenge."""
        return "image" in ctx.challenge_type.strip().lower() or bool(ctx.image_url)

    @staticmethod
    def prefer_image_models(
        available_models: list[str],
        *,
        model_rows: list[dict[str, Any]] | None = None,
    ) -> list[str]:
        """Filter to image-capable aliases, preserving relative order.

        Uses ``capabilities: ["image"]`` from the last ``/models`` fetch when
        present. Falls back to the ``*-image`` suffix when the flag is absent
        (practice LiteLLM does not carry it).
        """
        return filter_image_models(available_models, model_rows=model_rows)

    def rank_models(
        self,
        ctx: ChallengeContext,
        available_models: list[str],
    ) -> list[str]:
        """Return the ranked model list for the current challenge.

        Text challenges keep proxy roster order. Image challenges prefer
        image-capable aliases via ``prefer_image_models``. Override this
        (or `pick_model`) to implement a real model-selection strategy.
        """
        if self.is_image_challenge(ctx):
            preferred = self.prefer_image_models(available_models)
            if preferred:
                return preferred
        return list(available_models)

    def pick_model(
        self,
        stage: str,
        ranked_models: list[str],
        ctx: ChallengeContext,
    ) -> str:
        """Choose the model to run for a stage (`solve`, `verify`, etc)."""
        _ = stage
        _ = ctx
        if not ranked_models:
            return ""
        return ranked_models[0]

    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        """Build the system prompt for text solving."""
        base = str(self.text_system_prompt).strip()
        return f"{base}\n\n{output_contract(ctx.rules, ctx.clues)}"

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        """Build the user prompt for text solving."""
        lines = "\n".join(f"- {clue}" for clue in ctx.clues if clue.strip())
        if not lines:
            lines = "- (No clues provided.)"

        challenge_type = ctx.challenge_type.strip() or "text"
        challenge_description = ctx.description.strip() or "No description provided."
        challenge_rules = ctx.rules.strip() or "No additional rules provided."

        return (
            "Solve the text challenge below.\n\n"
            f"Challenge Type: {challenge_type}\n"
            f"Description: {challenge_description}\n"
            f"Rules: {challenge_rules}\n\n"
            f"Clues:\n{lines}\n\n"
            f"{output_contract(ctx.rules, ctx.clues)}\n"
            "- Optional: up to 2 brief reasoning lines before the ANSWER line."
        )

    def finalize_answer(self, raw_reply: str, ctx: ChallengeContext) -> ExtractedAnswer:
        """Turn the raw model reply into the bare answer submitted to the arena.

        Dispatch by answer shape: only an entity list goes through the name
        normalizer. Other shapes (json, number, date, id, text, pairs, image) get
        the bare extraction with no comma, arrow or name processing.
        """
        shape = classify_answer_shape(ctx.rules, challenge_type=ctx.challenge_type)
        if shape == "json":
            compact = _json_reply(raw_reply, "json", ctx.clues)
            if compact is not None:
                # Ordering is applied once, at submit, by natural_order.
                schema = _schema_from_text(f"{ctx.rules}\n{ctx.description}")
                if schema is not None:
                    value = coerce_to_schema(json.loads(compact), schema)
                    compact = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
                return ExtractedAnswer(compact, True, "")
            return extract_bare_answer(raw_reply, ctx.rules, ctx.challenge_type)
        if shape == "pairs":
            extracted = extract_bare_answer(raw_reply, ctx.rules, ctx.challenge_type)
            if extracted.valid:
                names = infer_entities([*ctx.clues, ctx.description])
                extracted = ExtractedAnswer(canonical_pair_names(extracted.answer, names), True, "")
            return extracted
        if shape == "short_text":
            extracted = extract_bare_answer(raw_reply, ctx.rules, ctx.challenge_type)
            if extracted.valid and is_prose_dump(extracted.answer, ctx.challenge_type, ctx.rules):
                # Invalid, so the agent's one bare-answer repair runs instead of submitting prose.
                return ExtractedAnswer(extracted.answer, False, "reasoning, not a short answer")
            if extracted.valid:
                extracted = ExtractedAnswer(compact_json_answer(extracted.answer, ctx.rules), True, "")
            return extracted
        if shape != "entity_list":
            return extract_bare_answer(raw_reply, ctx.rules, ctx.challenge_type)
        return extract_final_answer(raw_reply, rules=ctx.rules, clues=ctx.clues)

    def get_llm_params(self, ctx: ChallengeContext) -> dict[str, Any]:
        """Return model parameters for the current text solve."""
        _ = ctx
        return {
            "temperature": float(self.text_temperature),
            "max_tokens": int(self.text_max_tokens),
        }

    def fastest_model(self, models: list[str], challenge_type: str, exclude: str) -> str:
        """Fastest roster model for this task; "" when unknown. Strategies with latency data override."""
        _ = (models, challenge_type, exclude)
        return ""

    def plan_tools(
        self,
        ctx: ChallengeContext,
        available_tools: list[str],
    ) -> list[str]:
        """Return a preferred tool order."""
        _ = ctx
        return list(available_tools)

    def on_tool_result(
        self,
        tool_name: str,
        result: dict[str, Any] | Any,
        ctx: ChallengeContext,
    ) -> str | None:
        """Optional callback after tool execution."""
        _ = tool_name
        _ = result
        _ = ctx
        return None

    def should_submit_early(self, answer: str, ctx: ChallengeContext) -> bool:
        """Return True to submit before the standard end-of-loop."""
        _ = answer
        _ = ctx
        return False

    def on_time_warning(
        self,
        remaining_s: float,
        current_answer: str,
        ctx: ChallengeContext,
    ) -> str | None:
        """Opportunity to override the final answer near timeout."""
        _ = remaining_s
        _ = ctx
        return current_answer or None

    def plan_image_tool(
        self,
        ctx: ChallengeContext,
        available_tools: list[str],
    ) -> str:
        """Choose `image_edit`, `image_generate`, or `image_analyze`."""
        if ctx.image_url and "image_edit" in available_tools:
            return "image_edit"
        if "image_generate" in available_tools:
            return "image_generate"
        if ctx.image_url and "image_analyze" in available_tools:
            return "image_analyze"
        return available_tools[0] if available_tools else ""

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        """Build a prompt for image tool calls.

        The bundled examples put the challenge's own image instruction (its
        ``prompt`` / ``edit_prompt``) and reference notes in ``ctx.rules``;
        ``ctx.challenge_text`` is often only the generic description. Lead with
        the instruction so the image model draws what was asked.
        """
        headline = ctx.challenge_text.strip() or ctx.description.strip()
        details = ctx.rules.strip()
        if details and headline and headline not in details:
            base_prompt = f"{details}\n\nContext: {headline}"
        else:
            base_prompt = details or headline or "Generate a clear image response for the task."
        return f"{base_prompt}\n\nOutput constraints: {_IMAGE_SIZE_HINT}"
