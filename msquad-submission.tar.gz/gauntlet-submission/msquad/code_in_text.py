"""Code arm: run a program quoted in the question text through the existing code sandbox.

A logic or math question can quote a Python program in its text ("What does this Python 3 program print?").
run_code_challenge only sees `code` challenges with the program in the clues, so such a question went to the
model, which guessed. This arm takes the quoted program and runs it through msquad.code_eval.run_program: the
same three layers, no new execution surface. A rejection, timeout, error or empty output returns None and the
model answers as before.

Fires only when the question asks what a Python program prints, and the text after that sentence (or a fenced
block) parses and contains a print call. An image challenge never fires. Off unless MSQUAD_CODE_IN_TEXT=1 or
DEFAULT_ENABLED is True, so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import ast
import os
import re

from msquad import code_eval

ENV_FLAG = "MSQUAD_CODE_IN_TEXT"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

# The tight trigger: the question asks what a Python program prints. Literal tokens only, so it is linear-time.
_ASK_RE = re.compile(r"what does this python(?: 3)? (?:program|code|snippet) (?:print|output)\b[?.:]?", re.IGNORECASE)
_FENCE_RE = re.compile(r"```(?:python|py)?\s*\n(.*?)```", re.DOTALL)
# The answer-only tail is an instruction, not code; it may sit between the question and the program.
_TAIL_RE = re.compile(r"^[ \t]*answer with the printed output only\.?[ \t]*$", re.IGNORECASE | re.MULTILINE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def program_for(text: str) -> str | None:
    """The quoted program after a 'what does this python program print' question, or None when it does not apply."""
    text = str(text or "")
    match = _ASK_RE.search(text)
    if not match:
        return None
    rest = text[match.end():]
    fence = _FENCE_RE.search(rest)
    source = fence.group(1) if fence else rest
    source = _TAIL_RE.sub("", source).strip("\n")
    if not source.strip():
        return None
    try:
        tree = ast.parse(source, mode="exec")
    except (SyntaxError, ValueError):
        return None
    prints = any(
        isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "print"
        for node in ast.walk(tree)
    )
    return source if prints else None


def run(challenge_type: str, text: str) -> str | None:
    """What the quoted program prints, or None: not applicable, rejected, failed, timed out or silent."""
    if (challenge_type or "").strip().lower() == "image":
        return None
    source = program_for(text)
    if source is None:
        return None
    output = code_eval.run_program(source)
    if not output or not output.strip():
        return None
    return output


def run_any(challenge_type: str, texts) -> str | None:
    """The first text, in order, whose quoted program runs; then all the texts joined, so an ask in one text
    and the program in another still reads as one question."""
    for text in texts:
        output = run(challenge_type, text)
        if output:
            return output
    return run(challenge_type, "\n\n".join(text for text in texts if text))
