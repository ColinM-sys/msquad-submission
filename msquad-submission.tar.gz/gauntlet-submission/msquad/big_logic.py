"""BIG-bench logical_deduction (multiple choice): solve the clue set and pick the option that holds.

The paragraph lists N objects ("there are three books: a black book, an orange book, and a blue book")
and gives clues about their order: positions ("to the left of", "the leftmost", "second from the right"),
comparisons ("older than", "more expensive than") and ranks ("the second-cheapest", "finished above").
Each clue is rewritten into the solver grammar, the order is brute-forced, and the one option that holds
in the unique order is the answer.

Never-wrong: any clue or option we cannot read, a clue set without exactly one order, or no single holding
option returns None so the model answers.
"""

from __future__ import annotations

import re
import time

from msquad.logic_solver import SEARCH_BUDGET_S, _solutions, parse_named

_INTRO = re.compile(r"\b(three|five|seven)\s+[a-z]+\s*:\s*([^.]+)\.", re.IGNORECASE)
_COUNT = {"three": 3, "five": 5, "seven": 7}
_ORDINAL_WORDS = {"first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5, "sixth": 6, "seventh": 7}
_OPTION = re.compile(r"^([A-G])\. (.+)$", re.MULTILINE)

# Direction of each dimension, fixed by checking against the gold answers (see the test suite).
# +1: the older (or more expensive) object sits further left; -1: further right.
DIR_AGE = 1
DIR_PRICE = 1


def _names_from_list(raw: str) -> list[str]:
    parts = re.split(r",\s*(?:and\s+)?|\s+and\s+", raw.strip())
    names = []
    for part in parts:
        part = re.sub(r"^(?:a|an|the)\s+", "", part.strip(), flags=re.IGNORECASE).strip().lower()
        if part:
            names.append(part)
    return names


def _to_last(word: str, n: int) -> str:
    """'second-to-last' is slot n-1, 'third-to-last' is slot n-2, and so on. Unknown words are left alone."""
    k = _ORDINAL_WORDS.get(word.lower())
    if k is None:
        return f"finished {word}-to-last"
    return f"is in slot {n + 1 - k}"


def _convert(sentence: str, names: list[str], n: int) -> str:
    """Rewrite BIG-bench phrasing into the solver grammar. Unknown phrasing is left for the grammar to reject."""
    alt = "|".join(re.escape(w) for w in sorted(names, key=len, reverse=True))
    text = re.sub(r"\b(?:the|a|an)\s+(?=(?:" + alt + r")\b)", "", sentence, flags=re.IGNORECASE)
    text = re.sub(r"\b(" + alt + r") are\b", r"\1 is", text, flags=re.IGNORECASE)
    text = re.sub(r"\bfinished above\b", "is somewhere ahead of", text, flags=re.IGNORECASE)
    text = re.sub(r"\bfinished below\b", "is somewhere behind", text, flags=re.IGNORECASE)
    text = re.sub(r"\bfinished (\w+)-to-last\b", lambda m: _to_last(m.group(1), n), text, flags=re.IGNORECASE)
    text = re.sub(r"\bfinished (first|second|third|fourth|fifth|sixth|seventh|last)\b", r"is \1", text,
                  flags=re.IGNORECASE)
    text = re.sub(r"\bis the leftmost\b", "is first", text, flags=re.IGNORECASE)
    text = re.sub(r"\bis the rightmost\b", "is last", text, flags=re.IGNORECASE)

    def from_left(m):
        k = _ORDINAL_WORDS.get(m.group(1).lower())
        return f"is {m.group(1).lower()}" if k else m.group(0)

    def from_right(m):
        k = _ORDINAL_WORDS.get(m.group(1).lower())
        return f"is in slot {n + 1 - k}" if k else m.group(0)

    text = re.sub(r"\bis the (\w+) from the left\b", from_left, text, flags=re.IGNORECASE)
    text = re.sub(r"\bis the (\w+) from the right\b", from_right, text, flags=re.IGNORECASE)

    def relation(m):
        x, adj, y = m.group(1), m.group(2).lower(), m.group(3)
        if adj in ("older", "newer"):
            d = DIR_AGE if adj == "older" else -DIR_AGE
        else:
            d = DIR_PRICE if adj == "more expensive" else -DIR_PRICE
        return f"{x} is somewhere ahead of {y}" if d == 1 else f"{x} is somewhere behind {y}"

    text = re.sub(r"\b(" + alt + r") is (older|newer|more expensive|less expensive|cheaper) than (" + alt + r")\b",
                  relation, text, flags=re.IGNORECASE)

    def superlative(m):
        x, ordw, what = m.group(1), m.group(2), m.group(3).lower()
        k = _ORDINAL_WORDS.get(ordw.lower(), 1) if ordw else 1
        if what == "oldest":
            pos = k if DIR_AGE == 1 else n + 1 - k
        elif what == "newest":
            pos = n + 1 - k if DIR_AGE == 1 else k
        elif what == "most expensive":
            pos = k if DIR_PRICE == 1 else n + 1 - k
        else:
            pos = n + 1 - k if DIR_PRICE == 1 else k
        return f"{x} is in slot {pos}"

    text = re.sub(r"\b(" + alt + r") is the (?:(second|third|fourth|fifth|sixth|seventh)-)?"
                  r"(oldest|newest|cheapest|most expensive|least expensive)\b", superlative, text,
                  flags=re.IGNORECASE)
    return text.strip().rstrip(".").strip()


def solve_big_choice(challenge_text: str, clues: list[str]) -> str | None:
    """Return the letter of the single option that holds in the unique order, else None."""
    deadline = time.perf_counter() + SEARCH_BUDGET_S
    paragraph = " ".join(clues)
    intro = _INTRO.search(paragraph)
    if not intro:
        return None
    n = _COUNT[intro.group(1).lower()]
    names = _names_from_list(intro.group(2))
    if len(names) != n or len(set(names)) != n:
        return None
    rest = paragraph[intro.end():]
    sentences = [s.strip() for s in re.split(r"(?<=\.)\s+", rest) if s.strip()]
    options = _OPTION.findall(challenge_text)
    if len(options) < 2:
        return None
    converted = [_convert(s, names, n) for s in sentences]
    parsed = parse_named(names, None, converted)
    if parsed is None:
        return None
    solutions = _solutions(parsed, deadline)
    if solutions is None or len(solutions) != 1:
        return None
    solution = solutions[0]
    holding = []
    for letter, statement in options:
        opt = parse_named(names, None, [_convert(statement, names, n)])
        if opt is None or not opt.constraints:
            return None
        if all(k.test(solution) for k in opt.constraints):
            holding.append(letter)
    return holding[0] if len(holding) == 1 else None
