"""Arm: a tool the challenge prohibits is not selected just because its name appears in the text.

"do not use docs.mirror" names docs.mirror, and the required-tool match took any mention, so the prohibited
tool was called. With this arm on, a name counts only when some mention is not governed by a prohibition verb
in its sentence: "do not", "don't", "never", "avoid" or "must not", then an optional use/call/invoke/run/open/
fetch/query, then the name or a list of names ("X or Y"). A bare "not" or "without" does not count, so
"if the answer is not in the clues, use docs.search" still selects docs.search. Off by default. Off unless
MSQUAD_SKIP_PROHIBITED_TOOLS=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import bisect
import os
import re

ENV_FLAG = "MSQUAD_SKIP_PROHIBITED_TOOLS"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

# A prohibition verb directly governing the name, as in "never call docs.mirror or docs.archive".
_PROHIBITION_RE = re.compile(
    r"(?:\bdo\s+not|\bdon'?t|\bnever|\bavoid|\bmust\s+not|\bmustn'?t)\s+"
    r"(?:(?:use|call|invoke|run|open|fetch|query)\s+)?(?:the\s+)?"
    r"(?:[\w.\-]+\s*(?:,|\bor\b|\band\b)\s*)*$",
    re.IGNORECASE,
)
# A sentence ends at . ; ! or ? followed by whitespace or the end, so "docs.mirror" does not split.
_SENTENCE_END = re.compile(r"[.;!?](?=\s|$)")
_SENTENCE_MARKS = ".;!?"
# The longest clause looked at before a mention: a prohibition is a verb and a short list of names.
_CLAUSE_CAP = 240


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def positively_mentioned(name: str, blob: str) -> bool:
    """True when some occurrence of ``name`` in ``blob`` is not governed by a prohibition in its sentence."""
    text = blob.lower()
    needle = name.lower()
    # Sentence starts are found once for the whole blob, not re-scanned from the top for every mention:
    # a 100 KB blob with many mentions took 1.8 s this way (quadratic; 0.1 s at 25 KB, 0.46 s at 50 KB).
    breaks = [m.end() for m in _SENTENCE_END.finditer(text)]
    start = text.find(needle)
    while start != -1:
        index = bisect.bisect_right(breaks, start)
        sentence_start = breaks[index - 1] if index else 0
        if start and text[start - 1] in _SENTENCE_MARKS:
            sentence_start = start
        clause = text[max(sentence_start, start - _CLAUSE_CAP):start]
        if not _PROHIBITION_RE.search(clause):
            return True
        start = text.find(needle, start + len(needle))
    return False


def prohibited(name: str, blob: str) -> bool:
    """True when ``name`` is named in ``blob`` but only inside prohibitions (never as something to use)."""
    return name.lower() in blob.lower() and not positively_mentioned(name, blob)
