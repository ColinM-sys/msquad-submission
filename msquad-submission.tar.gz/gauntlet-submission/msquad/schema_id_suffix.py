"""Arm: a reply key with an id suffix maps to the schema property that keeps it (astra ST1).

base_strategy._match_schema_key compares keys by their words with the id/number/code suffix dropped, so
with a schema {invoice, invoice_id} the reply key "invoiceId" matched "invoice" (the first property with
the same stripped words) and the id landed in the wrong field. With this arm on, a reply key whose words
end in such a suffix first looks for a property with exactly the same words, suffix included; only if
there is none does the usual suffix-blind match run ("order_id" still fills "order_number").
Off unless MSQUAD_SCHEMA_ID_SUFFIX=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_SCHEMA_ID_SUFFIX"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

SUFFIXES = frozenset({"id", "number", "num", "no", "code"})


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _words(key: str) -> tuple[str, ...]:
    spaced = re.sub(r"([a-z])([A-Z])", r"\1 \2", str(key))
    return tuple(word for word in re.split(r"[^A-Za-z]+", spaced.lower()) if word)


def exact_suffix_match(key: str, properties) -> str | None:
    """The property whose words equal the key's, suffix included, when the key ends in an id suffix."""
    words = _words(key)
    if len(words) < 2 or words[-1] not in SUFFIXES:
        return None
    return next((prop for prop in properties if _words(prop) == words), None)
