"""Arm: a singular name format gets the single-value output contract, not the list contract.

Rules such as "name" or "full name" count as an entity list (the word "name" matches), so the solve
prompt said "The bare answer is comma-separated, no spaces." The model applied that inside one name
("Rafael Duarte" -> "RafaelDuarte") and was nudged toward listing several people. With this arm on, a
format that asks for one name and has no list cue gets the single-value contract ("the single value
exactly as written ..., spaces and capitalisation kept"). Every list format and every non-name format
gets exactly today's contract. Off unless MSQUAD_SINGLE_NAME_PROMPT=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_SINGLE_NAME_PROMPT"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

_SINGULAR_NAME_RE = re.compile(r"\bname\b(?!s)", re.IGNORECASE)
# Any cue that the answer is several things, an order, or a separated layout keeps the list contract.
_LIST_CUE_RE = re.compile(
    r"\b(?:names|list|lists|order|ordering|ordered|sequence|people|persons|teams|players|suspects|candidates|"
    r"items|all|both|each|every|separated|comma|commas|per line|one per|slot|slots|\d+)\b|[,;]",
    re.IGNORECASE,
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def is_singular_name(rules: str) -> bool:
    """True for "name", "full name", "the person's name": one name and no list cue."""
    text = str(rules or "")
    return bool(_SINGULAR_NAME_RE.search(text)) and not _LIST_CUE_RE.search(text)
