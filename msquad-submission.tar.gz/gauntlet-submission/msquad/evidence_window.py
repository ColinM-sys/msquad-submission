"""Arm: an oversized tool result keeps the sentences that answer the question, not only its head.

Every tool result was cut to its head (2000 chars per evidence line, 1500 for an unknown key, a 4000-char
evidence block), so a long document or a late hop with the answer in its second half lost the answer
(haiku-pr-check's context probe: a 200 KB document, a 30-hop chain). With this arm on, a result over its
budget keeps a head plus the sentences that share the most key terms with the question (its names,
numbers and content words), in document order, within the SAME budget. A result that fits, or whose best
sentences already sit inside the plain head cut, is returned exactly as before (text[:budget]).
Linear: one pass over the sentences, set lookups, no backtracking patterns.
Off unless MSQUAD_EVIDENCE_WINDOW=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os
import re

from msquad import evidence_stem

ENV_FLAG = "MSQUAD_EVIDENCE_WINDOW"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

SEPARATOR = " … "
# Larger results keep the plain head cut: a 2 MB padding field (gym huge-fields) is never scanned.
MAX_SCAN_CHARS = 250_000
# An unpunctuated run longer than this is scored in chunks of about CHUNK_CHARS.
MAX_SPAN_CHARS = 400
CHUNK_CHARS = 300
_SENTENCE_RE = re.compile(r"[^.!?\n]+[.!?\n]*")  # possessive-free, but each char is consumed once: linear
_WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9'-]*")
_STOP = frozenset({
    "what", "which", "who", "whom", "whose", "when", "where", "why", "how", "many", "much", "does", "did",
    "the", "and", "for", "with", "from", "that", "this", "these", "those", "into", "onto", "about", "answer",
    "give", "name", "number", "value", "only", "exact", "exactly", "integer", "short", "phrase", "according",
    "document", "documents", "record", "records", "text", "following", "there", "their", "they", "them",
})
_state: dict[str, frozenset] = {"terms": frozenset(), "stems": frozenset()}


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def key_terms(question: str) -> frozenset:
    """Lowercased names, numbers and content words of the question."""
    terms = set()
    for word in _WORD_RE.findall(str(question or "")):
        low = word.lower()
        if word[:1].isdigit() or word[:1].isupper() and len(word) > 1 or len(low) >= 4:
            if low not in _STOP:
                terms.add(low)
    return frozenset(terms)


def set_question(question: str) -> None:
    """The run's question; clip() windows on its key terms."""
    _state["terms"] = key_terms(question)
    _state["stems"] = evidence_stem.stem_terms(question, _STOP)


def _spans(text: str):
    """Sentence spans; a span longer than MAX_SPAN_CHARS (unpunctuated text: logs, tables, scraped pages)
    is cut into word-bounded chunks, so the answer is not buried in one huge 'sentence'. Linear."""
    for match in _SENTENCE_RE.finditer(text):
        start, end = match.start(), match.end()
        while end - start > MAX_SPAN_CHARS:
            cut = text.rfind(" ", start + CHUNK_CHARS // 2, start + CHUNK_CHARS)
            cut = cut + 1 if cut > start else start + CHUNK_CHARS
            yield start, cut
            start = cut
        yield start, end


def _new_keys_past(spans, keys_by_span: dict, budget: int) -> bool:
    """MSQUAD_EVIDENCE_STEM: a sentence past the head cut matches a question word (or stem) no head sentence does.

    A titled document's first span can outscore the answer by repeating the title's words; the head cut would then
    hide a later sentence that is the only one carrying the question's other words. Always False with the arm off.
    """
    if not keys_by_span:
        return False
    head = frozenset().union(*(keys_by_span.get(s, frozenset()) for _, s, e in spans if e <= budget))
    return any(keys_by_span.get(s, frozenset()) - head for _, s, e in spans if e > budget)


def clip(text: str, budget: int, terms: frozenset | None = None) -> str:
    """text[:budget], or, with the arm on and the best-matching sentences past the head cut, a head plus them."""
    text = str(text)
    if len(text) <= budget or not enabled():
        return text[:budget]
    stems = _state["stems"] if terms is None and evidence_stem.enabled() else frozenset()
    terms = _state["terms"] if terms is None else terms
    if not terms or budget < 200 or len(text) > MAX_SCAN_CHARS:
        return text[:budget]
    spans = []
    keys_by_span: dict[int, frozenset] = {}
    for start, end in _spans(text):
        words = {w.lower() for w in _WORD_RE.findall(text, start, end)}
        exact = words & terms
        score = len(exact)
        if stems:
            # MSQUAD_EVIDENCE_STEM: exact words score 2, a question stem met only through an inflection scores 1
            hit = {evidence_stem.stem(w) for w in words} & stems
            score = 2 * score + len(hit - {evidence_stem.stem(w) for w in exact})
            keys_by_span[start] = frozenset(exact) | hit
        if score:
            spans.append((score, start, end))
    if not spans:
        return text[:budget]
    best = max(score for score, _, _ in spans)
    top = sorted((s for s in spans if s[0] == best), key=lambda s: s[1])
    if all(end <= budget for _, _, end in top) and not _new_keys_past(spans, keys_by_span, budget):
        return text[:budget]  # the answer-bearing sentences already fit in the plain head cut
    head_len = budget // 4
    room = budget - head_len
    chosen: list[tuple[int, int]] = []
    for _, start, end in sorted(spans, key=lambda s: (-s[0], s[1])):
        if end <= head_len:
            continue
        start = max(start, head_len)
        cost = (end - start) + len(SEPARATOR)
        if cost > room:
            if not chosen and room > len(SEPARATOR) + 20:
                chosen.append((start, start + room - len(SEPARATOR)))  # one long sentence: keep its start
            continue
        chosen.append((start, end))
        room -= cost
    if not chosen:
        return text[:budget]
    chosen.sort()
    if room > 0:
        # Spend what is left around each kept sentence: the text right after it (the next hop, the unit,
        # the row), then the text right before it (the earlier hop, the heading), so an answer at the very
        # end of a document still gets its context (Fable on #432).
        share = room // len(chosen)
        widened = []
        floor = head_len
        for i, (s, e) in enumerate(chosen):
            limit = chosen[i + 1][0] if i + 1 < len(chosen) else len(text)
            stop = min(limit, e + share // 2)
            cut = max(text.rfind(".", e, stop), text.rfind("\n", e, stop))
            new_e = cut + 1 if cut >= e else e
            back = share - (new_e - e)
            begin = max(floor, s - back)
            if begin < s:
                # start just after a sentence end (or at least a word break) inside [begin, s)
                mark = max(text.find(". ", begin, s), text.find("\n", begin, s))
                if mark >= 0:
                    begin = mark + 1
                else:
                    space = text.find(" ", begin, s)
                    begin = space + 1 if space >= 0 else s
            widened.append((begin, new_e))
            floor = new_e
        chosen = widened
    out = text[:head_len] + "".join(SEPARATOR + text[s:e].strip() for s, e in chosen)
    return out[:budget]
