"""Edit arm: an item added to a person must not cover or reshape them.

Live edit loses most on the preservation axis (mean 78.1 over 75 flash-lite runs, range 50-94).
The saved outputs at the bottom add the item oversized and pulled over the face (a cap down over
the eyes and brow, which reshapes them); the top outputs add the same item small and on top,
with the face untouched. This says how big and where, for any add-an-item-to-a-person edit.

Fires when the instruction adds an item (add, give, put, place, wear, ...) and names a person
or "the subject". Off unless MSQUAD_EDIT_NO_OCCLUDE=1 or DEFAULT_ENABLED is True, so it can be
A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_EDIT_NO_OCCLUDE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

RULE = (
    "Placement: size the added item in proportion to the subject and place it so it does not "
    "cover, reshape or move the eyes, brows, ears, mouth or face outline; it should hide as "
    "little of the original subject as possible."
)

_ADD_RE = re.compile(r"\b(?:add|adds|adding|give|gives|put|place|wear|wearing|dress)\b", re.IGNORECASE)
_PERSON_RE = re.compile(
    r"\b(?:subject|person|people|man|men|woman|women|boy|girl|child|children|kid|baby|couple|"
    r"model|portrait|face|head|he|she|him|her|his|hers|they|them|their)\b",
    re.IGNORECASE,
)
# Items that are worn over the eyes, nose or mouth: the placement rule would contradict the edit.
_FACE_ITEM_RE = re.compile(
    r"\b(?:\w*glasses|goggles|spectacles|monocle|eye\s*patch|\w*mask|veil|balaclava|respirator|"
    r"mou?stache|beard|goatee|lipstick|make-?up|face\s*paint|nose\s*ring|eyeliner|mascara)\b",
    re.IGNORECASE,
)
_NOT_ADD_RE =re.compile(r"\b(?:remove|erase|delete|replace|swap|change|recolou?r|convert|turn)\b", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def applies(instruction: str) -> bool:
    """True for an edit that adds an item to a person (and is not a remove/replace/recolour)."""
    text = " ".join(str(instruction or "").split())
    if _FACE_ITEM_RE.search(text):
        return False  # glasses, a mask or make-up belong on the eyes or mouth the rule protects
    return bool(_ADD_RE.search(text) and _PERSON_RE.search(text) and not _NOT_ADD_RE.search(text))


def rule_for(instruction: str) -> str:
    """The placement rule for ``instruction``, or "" when it does not add an item to a person."""
    return RULE if applies(instruction) else ""
