"""Fetch a challenge's clue texts concurrently, keeping the server's clue order.

Each get_clue is a read-only round trip. Run one at a time, an 8-clue challenge pays
eight network round trips before the solver starts; run together, it pays about one.
"""

from __future__ import annotations

import asyncio
from typing import Any


async def fetch_clue_texts(mcp: Any, clue_ids: list[str], agent_id: str) -> list[str]:
    """Return the text of each clue in ``clue_ids`` order."""
    infos = await asyncio.gather(*(mcp.get_clue(clue_id, agent_id) for clue_id in clue_ids))
    return [info.text for info in infos]
