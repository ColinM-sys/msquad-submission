"""Fetch a challenge's clue texts concurrently, keeping the server's clue order.

Each get_clue is a read-only round trip. Run one at a time, an 8-clue challenge pays
eight network round trips before the solver starts; run together, it pays about one.
"""

from __future__ import annotations

import asyncio
from typing import Any


async def _settle(mcp: Any, clue_id: str, agent_id: str) -> tuple[Any, BaseException | None]:
    """``(info, None)`` on success, ``(None, error)`` on a failed read. Cancellation still propagates."""
    try:
        return await mcp.get_clue(clue_id, agent_id), None
    except Exception as exc:
        return None, exc


async def fetch_clues(mcp: Any, clue_ids: list[str], agent_id: str) -> tuple[list[str], list[str]]:
    """Return ``(ids, texts)`` for the clues that could be read, in ``clue_ids`` order.

    A failed read is retried once. A clue that still fails is dropped, so one bad read no longer
    throws away the clues that came back. If every read fails, the first error is raised.
    """
    settled = await asyncio.gather(*(_settle(mcp, clue_id, agent_id) for clue_id in clue_ids))
    failed = [clue_id for clue_id, (_, error) in zip(clue_ids, settled) if error is not None]
    if failed:
        retried = await asyncio.gather(*(_settle(mcp, clue_id, agent_id) for clue_id in failed))
        retry_by_id = dict(zip(failed, retried))
        settled = [retry_by_id.get(clue_id, outcome) for clue_id, outcome in zip(clue_ids, settled)]
    ids: list[str] = []
    texts: list[str] = []
    errors: list[BaseException] = []
    for clue_id, (info, error) in zip(clue_ids, settled):
        if error is not None:
            errors.append(error)
            continue
        ids.append(clue_id)
        texts.append(info.text)
    if clue_ids and not ids:
        raise errors[0]
    return ids, texts


async def fetch_clue_texts(mcp: Any, clue_ids: list[str], agent_id: str) -> list[str]:
    """Return the text of each readable clue in ``clue_ids`` order."""
    _, texts = await fetch_clues(mcp, clue_ids, agent_id)
    return texts


# Clue ids the arena has always used ("clue_0", "clue_1", ...); probed only when the list is empty.
_PROBE_LIMIT = 12


async def read_clues(mcp: Any, agent_id: str) -> tuple[list[str], list[str]]:
    """Return ``(clue_ids, texts)``, recovering when ``arena.clues.list`` comes back empty.

    An empty list is retried once. If it is still empty, ``clue_0``, ``clue_1``, ... are
    read in order until the first miss: the clues exist even when the list hides them,
    and solving without them means guessing.
    """
    clue_ids = list(await mcp.list_clues(agent_id))
    if not clue_ids:
        clue_ids = list(await mcp.list_clues(agent_id))
    if clue_ids:
        return await fetch_clues(mcp, clue_ids, agent_id)
    found_ids: list[str] = []
    texts: list[str] = []
    for index in range(_PROBE_LIMIT):
        clue_id = f"clue_{index}"
        try:
            info = await mcp.get_clue(clue_id, agent_id)
        except Exception:
            break
        text = str(getattr(info, "text", "") or "")
        if not text:
            break
        found_ids.append(clue_id)
        texts.append(text)
    return found_ids, texts
