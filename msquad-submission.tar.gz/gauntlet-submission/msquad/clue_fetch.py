"""Fetch a challenge's clue texts concurrently, keeping the server's clue order.

Each get_clue is a read-only round trip. Run one at a time, an 8-clue challenge pays
eight network round trips before the solver starts; run together, it pays about one.
"""

from __future__ import annotations

import asyncio
from typing import Any


async def fetch_clue_texts(mcp: Any, clue_ids: list[str], agent_id: str) -> list[str]:
    """Return the text of each clue in ``clue_ids`` order."""
    infos = await asyncio.gather(*(mcp.get_clue(clue_id, agent_id) for clue_id in clue_ids))
    return [info.text for info in infos]


# Clue ids the arena has always used ("clue_0", "clue_1", ...); probed only when the list is empty.
_PROBE_LIMIT = 12


async def read_clues(mcp: Any, agent_id: str) -> tuple[list[str], list[str]]:
    """Return ``(clue_ids, texts)``, recovering when ``arena.clues.list`` comes back empty.

    An empty list is retried once. If it is still empty, ``clue_0``, ``clue_1``, ... are
    read in order until the first miss: the clues exist even when the list hides them,
    and solving without them means guessing.
    """
    clue_ids = list(await mcp.list_clues(agent_id))
    if not clue_ids:
        clue_ids = list(await mcp.list_clues(agent_id))
    if clue_ids:
        return clue_ids, await fetch_clue_texts(mcp, clue_ids, agent_id)
    found_ids: list[str] = []
    texts: list[str] = []
    for index in range(_PROBE_LIMIT):
        clue_id = f"clue_{index}"
        try:
            info = await mcp.get_clue(clue_id, agent_id)
        except Exception:
            break
        text = str(getattr(info, "text", "") or "")
        if not text:
            break
        found_ids.append(clue_id)
        texts.append(text)
    return found_ids, texts
