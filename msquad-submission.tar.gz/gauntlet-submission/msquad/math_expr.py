"""Evaluate the arithmetic expression a model writes for a math challenge.

The solver is asked to end with ``EXPR: <expression>`` instead of working the
number out itself. The expression is evaluated locally with the whitelisted
evaluator, so the submitted value is exact. A reply with no usable expression,
or one that is not a whole number, returns None and the caller keeps the
model's own answer.
"""

from __future__ import annotations

import re
from fractions import Fraction

from msquad.safe_eval import ToolError, evaluate_expr

_EXPR_RE = re.compile(r"^\s*EXPR:\s*(.+?)\s*$", re.IGNORECASE | re.MULTILINE)


def evaluate_reply(raw_reply: str) -> str | None:
    """The integer the reply's last ``EXPR:`` line evaluates to, else None."""
    matches = _EXPR_RE.findall(raw_reply or "")
    if not matches:
        return None
    expr = matches[-1].strip("`")
    # "EXPR: (32 - 4) = 28" is the model writing its result after the expression: evaluate the left side.
    if "=" in expr:
        left, _, right = expr.rpartition("=")
        if not re.fullmatch(r"\s*-?\d+(\.\d+)?\s*", right):
            return None
        expr = left
    try:
        value = evaluate_expr(expr)
    except ToolError:
        return None
    if isinstance(value, Fraction) and value.denominator != 1:
        return None
    return str(int(value))
