"""Evaluate the arithmetic expression a model writes for a math challenge.

The solver is asked to end with ``EXPR: <expression>`` instead of working the
number out itself. The expression is evaluated locally with the whitelisted
evaluator, so the submitted value is exact. A reply with no usable expression,
or one that is not a whole number, returns None and the caller keeps the
model's own answer.
"""

from __future__ import annotations

import re
from fractions import Fraction

from msquad.safe_eval import ToolError, evaluate_expr

def _line_start_in(text: str, lo: int, hi: int) -> bool:
    """True when some index p in [lo, hi] starts a line (p == 0, or text[p - 1] is a newline)."""
    if lo == 0 or text[lo - 1] == "\n":
        return True
    return "\n" in text[lo:hi]


def _labelled_occurrences(text: str, label: str, ignore_case: bool = True):
    """(a, b) for each "LABEL:": a is where it starts, b where the spaces before it begin."""
    flags = re.IGNORECASE if ignore_case else 0
    for match in re.finditer(re.escape(label) + ":", text, flags):
        a = match.start()
        b = a
        while b and text[b - 1].isspace():
            b -= 1
        yield a, b


def has_labelled_line(text: str, label: str, *, ignore_case: bool = True) -> bool:
    """True when ``re.search(rf"^\\s*{label}:", text, re.M)`` matches (with re.I when ``ignore_case``).

    Walks back over the spaces before each label instead of trying every line start, which is quadratic
    on a long run of newlines.
    """
    return any(_line_start_in(text, b, a) for a, b in _labelled_occurrences(text, label, ignore_case))


def labelled_groups(text: str, label: str, *, nonspace_start: bool) -> list[str]:
    """The groups of ``re.findall(rf"^\\s*{label}:\\s*(...)\\s*$", text, re.I | re.M)``, in linear time.

    With ``nonspace_start`` the group is ``\\S.*?`` (the ANSWER pattern); otherwise ``.+?`` (the EXPR pattern),
    which may be a single space when the rest of the text is only whitespace. Each match ends where the
    greedy ``\\s*$`` stops: at the last newline of the blank run after the group, or at the end of the text.
    """
    n = len(text)
    groups: list[str] = []
    pos = 0
    for a, b in _labelled_occurrences(text, label):
        if a < pos or not _line_start_in(text, max(b, pos), a):
            continue
        s = a + len(label) + 1
        while s < n and text[s].isspace():
            s += 1
        if s == n:
            if nonspace_start:
                continue
            g = n - 1
            while g >= a + len(label) + 1 and text[g] == "\n":
                g -= 1
            if g < a + len(label) + 1:
                continue
            groups.append(text[g])
            pos = n
            continue
        nl = text.find("\n", s)
        nl = n if nl == -1 else nl
        last = nl - 1
        while text[last].isspace():
            last -= 1
        groups.append(text[s:last + 1])
        r = last + 1
        while r < n and text[r].isspace():
            r += 1
        pos = n if r == n else text.rfind("\n", last + 1, r)
    return groups


def evaluate_reply(raw_reply: str) -> str | None:
    """The integer the reply's last ``EXPR:`` line evaluates to, else None."""
    matches = labelled_groups(raw_reply or "", "EXPR", nonspace_start=False)
    if not matches:
        return None
    expr = matches[-1].strip("`")
    # "EXPR: (32 - 4) = 28" is the model writing its result after the expression: evaluate the left side.
    if "=" in expr:
        left, _, right = expr.rpartition("=")
        if not re.fullmatch(r"-?\d+(\.\d+)?", right.strip()):
            return None
        expr = left
    try:
        value = evaluate_expr(expr)
    except ToolError:
        return None
    if isinstance(value, Fraction) and value.denominator != 1:
        return None
    return str(int(value))
