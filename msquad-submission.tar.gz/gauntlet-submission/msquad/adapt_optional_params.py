"""Arm: match tool arity using required parameters when the schema lists them (spec V).

Off unless MSQUAD_ADAPT_OPTIONAL_PARAMS=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_ADAPT_OPTIONAL_PARAMS"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}
