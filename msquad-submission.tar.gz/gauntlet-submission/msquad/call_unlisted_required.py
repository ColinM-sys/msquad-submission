"""Arm: call the tools the server marks required even when tools/list leaves them out.

A required tool missing from tools/list was dropped from enforcement, so a missed required call zeroed
quality. With this arm on the required names are kept; the existing per-call timeout bounds the cost of a
call the server does not list. Off by default. Off unless MSQUAD_CALL_UNLISTED_REQUIRED=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_CALL_UNLISTED_REQUIRED"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}
