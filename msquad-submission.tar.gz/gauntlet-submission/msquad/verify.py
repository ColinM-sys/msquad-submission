"""Cheap second-model verification of a candidate answer before submit.

A different model from the solver checks each clue against the candidate
answer and replies strictly ``OK`` or ``FAIL: <clue id>``. On FAIL, with time
left, the caller may re-solve once with the failing clue highlighted.
"""

from __future__ import annotations

import re
import asyncio
import time
from dataclasses import dataclass, replace
from typing import Awaitable, Callable

# Skip verification below these floors; the answer is submitted as is.
MIN_REMAINING_S = 20.0
MIN_TOKENS_LEFT = 2000
RESOLVE_MIN_REMAINING_S = 40.0
VERIFY_TIMEOUT_S = 8.0
DEADLINE_RESERVE_S = 10.0

_FAST_HINTS = ("flash", "mini", "haiku", "lite", "fast")


@dataclass
class Verdict:
    status: str  # "OK", "FAIL", or "INVALID"
    clue_id: str = ""
    raw: str = ""


def pick_verifier_model(available_models: list[str], solver_model: str) -> str:
    """Pick a fast model from the roster that is not the solver's model."""
    others = [m for m in available_models if m and m != solver_model]
    if not others:
        return ""
    for hint in _FAST_HINTS:
        for model in others:
            if hint in model.lower():
                return model
    return others[0]


def parse_verdict(text: str) -> Verdict:
    """Parse a reply that must be exactly ``OK`` or ``FAIL: <clue id>``."""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", text or "", flags=re.DOTALL).strip()
    line = cleaned.splitlines()[0].strip().strip("`\"'") if cleaned else ""
    if line.upper() == "OK":
        return Verdict("OK", raw=cleaned)
    match = re.match(r"^FAIL\s*:\s*(\S+)\s*$", line, flags=re.IGNORECASE)
    if match:
        return Verdict("FAIL", clue_id=match.group(1), raw=cleaned)
    return Verdict("INVALID", raw=cleaned)


VERIFY_DIFFICULTIES = ("hard", "brutal")
VERIFY_MIN_TIME_FRACTION = 0.4


def verify_enabled(
    difficulty: str,
    remaining_s: float,
    max_time_s: float,
    env_value: str,
) -> bool:
    """Policy gate: opt-in via MSQUAD_VERIFY=1, then only on hard/brutal
    challenges while more than 40% of the time limit remains."""
    if env_value.strip() != "1":
        return False
    if (difficulty or "").strip().lower() not in VERIFY_DIFFICULTIES:
        return False
    return max_time_s > 0 and remaining_s > VERIFY_MIN_TIME_FRACTION * max_time_s


def should_verify(
    remaining_s: float,
    tokens_used: int,
    token_budget: int,
    *,
    deterministic: bool = False,
) -> bool:
    """Run verification only with enough time and token budget left."""
    if deterministic:
        return False
    if remaining_s < MIN_REMAINING_S:
        return False
    if token_budget and token_budget - tokens_used < MIN_TOKENS_LEFT:
        return False
    return True


def build_verify_prompt(challenge_text: str, clues: list[tuple[str, str]], answer: str) -> str:
    clue_lines = "\n".join(f"- [{cid}] {text}" for cid, text in clues) or "- (no clues)"
    return (
        "You are checking a candidate answer to a puzzle. Check each clue against "
        "the candidate answer.\n\n"
        f"Challenge:\n{challenge_text}\n\n"
        f"Clues:\n{clue_lines}\n\n"
        f"Candidate answer: {answer}\n\n"
        "Reply with exactly one line: OK if every clue holds, otherwise "
        "FAIL: <clue id> naming the first clue the answer violates. No other text."
    )


def verify_answer(
    llm_client,
    verifier_model: str,
    challenge_text: str,
    clues: list[tuple[str, str]],
    answer: str,
) -> Verdict:
    """Ask the verifier model to check the candidate answer."""
    response = llm_client.chat.completions.create(
        model=verifier_model,
        messages=[
            {"role": "system", "content": "Reply only with OK or FAIL: <clue id>."},
            {"role": "user", "content": build_verify_prompt(challenge_text, clues, answer)},
        ],
        max_tokens=256,
        temperature=0.0,
    )
    return parse_verdict(response.choices[0].message.content or "")


def highlight_clue(ctx, clue_id: str, clue_text: str):
    """Return a copy of the solver context with the failing clue called out."""
    note = (
        f"\nA checker found that the previous answer breaks clue [{clue_id}]: "
        f"{clue_text}. Re-solve and make sure this clue holds."
    )
    return replace(ctx, rules=f"{ctx.rules or ''}{note}")


async def verify_and_maybe_resolve(
    answer: str,
    *,
    llm_client,
    verifier_model: str,
    challenge_text: str,
    clues: list[tuple[str, str]],
    ctx,
    remaining_s: float,
    resolve: Callable[[object], Awaitable[str]],
) -> str:
    """Return the answer to submit: the original, or one re-solve after FAIL.

    Every step is bounded by the time left: the verifier call gets at most
    ``VERIFY_TIMEOUT_S`` (and never more than the time left minus a reserve),
    and the re-solve gets whatever is left after the verdict. Any error or
    timeout keeps the original answer, so verification can only ever cost
    the seconds it is allowed.
    """
    if not answer or not verifier_model:
        return answer
    started = time.monotonic()
    verify_budget = min(VERIFY_TIMEOUT_S, remaining_s - DEADLINE_RESERVE_S)
    if verify_budget <= 0:
        print("   [verify] skipped: not enough time left to verify safely")
        return answer
    try:
        verdict = await asyncio.wait_for(
            asyncio.to_thread(
                verify_answer, llm_client, verifier_model, challenge_text, clues, answer,
            ),
            timeout=verify_budget,
        )
    except asyncio.TimeoutError:
        print(f"   [verify] timed out after {verify_budget:.1f}s; submitting original")
        return answer
    except Exception as exc:
        print(f"   [verify] error ({type(exc).__name__}); submitting original")
        return answer
    elapsed = time.monotonic() - started
    print(f"   [verify] {verifier_model}: {verdict.status} {verdict.clue_id} in {elapsed:.1f}s")
    left = remaining_s - elapsed
    if verdict.status != "FAIL":
        return answer
    if left < RESOLVE_MIN_REMAINING_S:
        print(f"   [verify] FAIL on {verdict.clue_id} but only {left:.1f}s left; no re-solve")
        return answer
    failing = next((text for cid, text in clues if cid == verdict.clue_id), "")
    try:
        revised = await asyncio.wait_for(
            resolve(highlight_clue(ctx, verdict.clue_id, failing)),
            timeout=left - DEADLINE_RESERVE_S,
        )
    except (asyncio.TimeoutError, Exception) as exc:
        print(f"   [verify] re-solve failed ({type(exc).__name__}); submitting original")
        return answer
    print(f"   [verify] re-solved after FAIL on {verdict.clue_id}")
    return revised.strip() if revised and revised.strip() else answer
