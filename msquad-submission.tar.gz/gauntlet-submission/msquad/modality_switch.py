"""Arm: an image fetch answered not_image_challenge switches the run to the text path instead of failing.

The kit's guidance (AGENTS.md, troubleshooting): not_image_challenge from arena.image.get_challenge means
the running heat is text, so stop using the image tool, rediscover the tools and use arena.get_challenge.
Main raised there, and the round was lost: the deadline guard has no challenge to answer. That happens
whenever the run guessed "image" for a text heat, e.g. when resolve_modality's probe ran during the lobby
(it answers "locked", so "image" stays) and the heat turned out text at GO.

With the switch in place a wrong "image" guess corrects itself, so the modality lookup's failure path may
guess "image" when the image fetch is listed (modality_cap.fallback_modality): main guessed "text" there,
and an image heat then failed its text fetch with no way back (a stalled session API lost image heats).
On by default; MSQUAD_MODALITY_SWITCH=0 restores both old behaviours.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_MODALITY_SWITCH"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def is_text_heat(exc: BaseException) -> bool:
    """The image fetch's answer for a text heat: code not_image_challenge (the image client keeps the code)."""
    return str(getattr(exc, "code", "") or "") == "not_image_challenge"
