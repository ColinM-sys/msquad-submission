"""Arm: adapt undeclared canonical-tool arguments to a single free required property.

Token-like properties are never fallback targets. Off unless MSQUAD_ADAPT_CANONICAL_ARGS=1
or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_ADAPT_CANONICAL_ARGS"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}
