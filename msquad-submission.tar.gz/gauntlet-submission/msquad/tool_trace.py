"""Log only: every wire-level MCP tool call's name and argument KEYS for the run record.

Live no-op checks (an arm on vs off on a standard server) could compare tool names but not the
arguments sent. The trace records top-level argument keys only, never values or nested keys, so secrets and answers stay out of
the record. It wraps the raw ClientSession below tool_adapt, so it shows what actually went over the
wire. Not an arm: it changes no call and never raises into one.
"""

from __future__ import annotations

import time
from typing import Any

MAX_CALLS = 200
MAX_KEYS = 20
MAX_KEY_CHARS = 40

_CALLS: list[dict] = []
_DROPPED = [0]


def reset() -> None:
    _CALLS.clear()
    _DROPPED[0] = 0


def calls() -> list[dict]:
    return list(_CALLS)


def dropped() -> int:
    return _DROPPED[0]


def key_paths(arguments: Any) -> list[str]:
    """Sorted TOP-LEVEL argument keys, capped in count and length; values are never read.

    Nested keys are not recorded: a dict's keys can themselves be data (answers={"HARBOR-7": ...},
    Fable on #309), and the top-level keys are the ones the tool's schema declares.
    """
    if not isinstance(arguments, dict):
        return []
    keys = sorted(str(key)[:MAX_KEY_CHARS] for key in arguments)
    return keys[:MAX_KEYS]


def _note(name: Any, arguments: Any, started: float, *, ok: bool, error: str | None = None) -> None:
    try:
        if len(_CALLS) >= MAX_CALLS:
            _DROPPED[0] += 1
            return
        entry: dict = {
            "tool": str(name),
            "arg_keys": key_paths(arguments),
            "ok": ok,
            "ms": int((time.monotonic() - started) * 1000),
        }
        if error:
            entry["error"] = error
        _CALLS.append(entry)
    except Exception:
        pass


class TracingSession:
    """Wraps an MCP ClientSession; records each call_tool, every other attribute passes through."""

    def __init__(self, session: Any) -> None:
        self._inner = session

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None, *args: Any, **kwargs: Any) -> Any:
        started = time.monotonic()
        try:
            result = await self._inner.call_tool(name, arguments, *args, **kwargs)
        except BaseException as exc:
            _note(name, arguments, started, ok=False, error=type(exc).__name__)
            raise
        _note(name, arguments, started, ok=not getattr(result, "isError", False))
        return result
