"""Arm: a multi-line answer (code, program output, verse) keeps every line, with its indentation.

The prompt asks for "ANSWER: <answer>" on one line, so a model writes "ANSWER: 1" and puts "2" and
"3" on the lines after it. The bare extraction kept only the label line ("1"), stripped every line's
indentation (broken Python) and kept a lead-in ("The output is:") when there was no label.
With this arm on, for a code challenge or rules that ask for several lines:
- a ``` fence in the answer area wins: its content verbatim, indentation and blank lines included;
- otherwise the label line's remainder plus the lines after it, up to an explanation marker or prose,
  or a blank line (code goes past a blank line when the next line still looks like code).
Anything else returns None and the old extraction runs unchanged ("ANSWER: 42\\nBecause ..." stays "42").
Off unless MSQUAD_CODE_MULTILINE=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os
import re

from msquad.clause_negation import strip_negated

ENV_FLAG = "MSQUAD_CODE_MULTILINE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

_THINK_RE = re.compile(r"<think>.*?(?:</think>|$)", re.DOTALL | re.IGNORECASE)
_LABEL_RE = re.compile(r"^[ \t*_`#>]*(?:final )?answer[ \t*_`]*:", re.IGNORECASE)
_FENCE_RE = re.compile(r"^[ \t]*```[\w+-]*[ \t]*$")
# Non-code challenges qualify only on an explicit several-lines cue; "code", "output" or "function" alone
# also name single values ("three-letter airport code", "output as an integer") (Fable on #412).
_MULTILINE_RULES_RE = re.compile(
    r"\b(?:lines|every line|each line|multiple lines|several lines|poem|haiku|verse|stanza|address block)\b",
    re.IGNORECASE,
)
_SINGLE_LINE_RE = re.compile(r"\b(?:one|single|a) line\b|\bper line\b", re.IGNORECASE)
_MULTI_BANNED_RE = re.compile(r"\b(?:multiple|several)\s+lines?\s+(?:are|is)\s+not\s+(?:allowed|wanted|permitted)\b", re.IGNORECASE)
_EXPLANATION_RE = re.compile(
    r"^\s*(?:because|explanation|note|this (?:is|code|function|prints|works|returns)|here(?:'s| is)|"
    r"therefore|so the|the (?:output|answer|code|function|result) (?:is|was|prints|returns))\b",
    re.IGNORECASE,
)
_CODE_LINE_RE = re.compile(r"^(?:[ \t]+\S|\s*(?:def|class|return|import|from|if|elif|else|for|while|try|except|"
                           r"finally|with|public|private|static|function|const|let|var|#include)\b|\s*[}\])])"
                           r"|[;{:]\s*$")


# A sentence (capitalised, four or more words, ending . ! ?) after the first line is prose, not output.
# Prose: a capitalised word then three lowercase words ("The code implements a ..."), whatever it ends with.
_PROSE_RE = re.compile(r"^[A-Z][a-z]+(?:[ \t]+[a-z][\w'-]*){3,}")
# Lowercase prose: a connective then two or more plain words, no code punctuation ("which is the sum and
# count") (Fable on #412).
_LOWER_PROSE_RE = re.compile(
    r"^(?:which|and|so|that|this|it|where|because|since|meaning|giving|thus|hence|the)\b(?:[ \t]+[a-z][a-z'-]*){2,}[.!?]?$"
)
_SENTENCE_RE = re.compile(r"^[A-Z]\S*(?:[ \t]+\S+){3,}[.!?]$")


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def wants_multiline(challenge_type: str, rules: str) -> bool:
    """A code challenge, or rules that ask for several lines (and not for one line or one per line)."""
    if "code" in str(challenge_type or "").lower():
        return True
    text = str(rules or "")
    # "Multiple lines are not allowed" and "no multiple lines" name the thing banned, not a request for it.
    asked = strip_negated(_MULTI_BANNED_RE.sub(" ", text), r"(?:multiple|several)\s+lines?")
    return bool(_MULTILINE_RULES_RE.search(asked)) and not _SINGLE_LINE_RE.search(text)


def _looks_like_code(line: str) -> bool:
    return bool(_CODE_LINE_RE.search(line))


def _fenced(lines: list[str]) -> str | None:
    """The content of the first complete ``` block in ``lines``, verbatim; None without one."""
    opens = [i for i, line in enumerate(lines) if _FENCE_RE.match(line)]
    if len(opens) < 2:
        return None
    start, end = opens[0], opens[1]
    body = lines[start + 1:end]
    while body and not body[0].strip():
        body = body[1:]
    while body and not body[-1].strip():
        body = body[:-1]
    return "\n".join(line.rstrip() for line in body) if body else None


def extract(raw: str, challenge_type: str = "") -> str | None:
    """The whole multi-line answer in ``raw``, or None when the old extraction should decide."""
    text = _THINK_RE.sub("", str(raw or "")).replace("\r\n", "\n")
    lines = text.split("\n")
    labels = [i for i, line in enumerate(lines) if _LABEL_RE.match(line)]
    area = lines[labels[-1]:] if labels else lines
    if labels:
        first = _LABEL_RE.sub("", area[0], count=1)
        area = ([first] if first.strip() else []) + area[1:]
    fenced = _fenced(area)
    if fenced is not None:
        return fenced
    if not labels:
        return None
    code = "code" in str(challenge_type or "").lower()
    kept: list[str] = []
    for index, line in enumerate(area):
        if not line.strip():
            if not kept:
                continue
            following = next((later for later in area[index + 1:] if later.strip()), "")
            if (code and following and _looks_like_code(following) and not _EXPLANATION_RE.match(following)
                    and not _PROSE_RE.match(following.strip())):
                kept.append("")
                continue
            break
        prose = code and (_SENTENCE_RE.match(line.strip()) or _PROSE_RE.match(line.strip())
                          or (not line[:1].isspace() and _LOWER_PROSE_RE.match(line.strip())))
        if kept and (_EXPLANATION_RE.match(line) or prose):
            break
        kept.append(line.rstrip() if kept else line.strip())
    while kept and not kept[-1].strip():
        kept.pop()
    return "\n".join(kept) if len(kept) > 1 else None
