"""Per-tool image model override, for A/B tests of the roster's image models.

Every live image run so far used gemini-3.1-flash-lite-image only because it is first in
roster order. MSQUAD_IMAGE_MODEL_EDIT / MSQUAD_IMAGE_MODEL_GENERATE pick another roster
model for image_edit / image_generate. Unset (the default), nothing changes.
"""

from __future__ import annotations

import os
from typing import Mapping

# The event cannot set env vars: once an A/B wins, name the model here (one line), e.g.
# {"image_edit": "gemini-3-pro-image"}. An env var still overrides it; empty keeps roster order.
DEFAULT_BY_TOOL: dict[str, str] = {}

ENV_BY_TOOL = {
    "image_edit": "MSQUAD_IMAGE_MODEL_EDIT",
    "image_generate": "MSQUAD_IMAGE_MODEL_GENERATE",
}


def image_tool_model(
    tool_name: str,
    default: str,
    available_models: list[str],
    env: Mapping[str, str] | None = None,
) -> str:
    """The model to send with ``tool_name``: the override when set and in the roster, else ``default``."""
    env = os.environ if env is None else env
    variable = ENV_BY_TOOL.get(tool_name)
    wanted = str((env.get(variable, "") if variable else "") or DEFAULT_BY_TOOL.get(tool_name, "")).strip()
    if not wanted:
        return default
    if wanted not in available_models:
        print(f"   ⚠️  image model {wanted!r} for {tool_name} is not in the roster; using {default!r}", flush=True)
        return default
    return wanted
