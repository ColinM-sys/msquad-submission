"""Generate arm: when the request forbids text, say how to draw light sources without glyphs.

Live generate loses most on the constraints axis (mean 74.5 over 80 flash-lite runs, range
38-94). The saved outputs at the bottom are full of legible signage: lit shop signs carry kanji
and Latin letters even though the request says "no text" and the generate guard already forbids
signage words. The top outputs have the same lighting with every sign reduced to glow. The
guard says what not to draw; this says what to draw instead, for any scene.

Fires whenever the request forbids text (no/without/avoid ... text, letters, words, writing,
captions, logos, watermarks, signs) within one clause: "no people, a wooden sign" does not fire. Off unless MSQUAD_GENERATE_NO_SIGNAGE=1 or DEFAULT_ENABLED
is True, so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_GENERATE_NO_SIGNAGE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

RULE = (
    "Text-free rendering: draw every sign, screen, label, poster, display and lit shape as pure "
    "colour, glow and simple geometry with no letters, characters, digits or logos; any surface "
    "that would carry writing stays blank, patterned or out of focus."
)

_FORBIDS_TEXT_RE = re.compile(
    r"\b(?:no|without|avoid|free of|never)\b[^.,;:!?]{0,60}?"
    r"\b(?:text|lettering|letters|words|writing|captions?|logos?|watermarks?|signs?|signage|typography)\b",
    re.IGNORECASE,
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def applies(request: str) -> bool:
    """True when ``request`` forbids text in the image."""
    return bool(_FORBIDS_TEXT_RE.search(" ".join(str(request or "").split())))


def rule_for(request: str) -> str:
    """The rendering rule for ``request``, or "" when it does not forbid text."""
    return RULE if applies(request) else ""
