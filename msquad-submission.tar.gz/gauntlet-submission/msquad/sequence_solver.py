"""Sequence puzzles: "What is the next number in the sequence: 2, 6, 12, 20, ?"

Each visible term sequence is tested against four rule families:
  arithmetic     a[i+1] - a[i] is constant
  geometric      a[i+1] / a[i] is a constant ratio (nonzero terms, ratio not 1)
  second-diff    the differences grow by a constant, and the second difference is not zero
  fibonacci      a[i] = a[i-1] + a[i-2]
The answer is the next term under a family only when exactly one family fits every visible term and that
family yields one next term. Single-letter sequences ("A, C, E, G, ?") use their alphabet positions.
Anything else declines to the model.
"""

from __future__ import annotations

import re

_SEQ = re.compile(r"sequence:?\s*([^?]*),\s*\?", re.IGNORECASE)
_INT = re.compile(r"^-?\d+$")
_LETTER = re.compile(r"^[A-Z]$")


def _terms(text: str) -> list[str] | None:
    m = _SEQ.search(text)
    if not m:
        return None
    parts = [p.strip() for p in m.group(1).split(",") if p.strip()]
    return parts if len(parts) >= 3 else None


def _families(a: list[int]) -> list[int]:
    """Return the next term predicted by each family that fits every visible term."""
    nxt = []
    d = [a[i + 1] - a[i] for i in range(len(a) - 1)]
    if len(set(d)) == 1:
        nxt.append(a[-1] + d[0])
    if all(x != 0 for x in a) and len(a) >= 2:
        ratios = [a[i + 1] * 1.0 / a[i] for i in range(len(a) - 1)]
        if all(abs(r - ratios[0]) < 1e-9 for r in ratios) and abs(ratios[0] - 1) > 1e-9 and ratios[0] == int(ratios[0]):
            nxt.append(int(a[-1] * ratios[0]))
    if len(d) >= 2:
        dd = [d[i + 1] - d[i] for i in range(len(d) - 1)]
        if len(set(dd)) == 1 and dd[0] != 0:
            nxt.append(a[-1] + d[-1] + dd[0])
    if len(a) >= 3 and all(a[i] == a[i - 1] + a[i - 2] for i in range(2, len(a))):
        nxt.append(a[-1] + a[-2])
    return nxt


def solve_sequence(challenge_text: str, clues: list[str] | None = None) -> str | None:
    terms = _terms(challenge_text)
    if terms is None:
        return None
    if all(_INT.match(t) for t in terms):
        values = [int(t) for t in terms]
        fits = _families(values)
        if len(fits) != 1:
            return None
        return str(fits[0])
    if all(_LETTER.match(t) for t in terms):
        positions = [ord(t) - ord("A") + 1 for t in terms]
        fits = _families(positions)
        if len(fits) != 1:
            return None
        nxt = fits[0]
        if not (1 <= nxt <= 26):
            return None
        return chr(ord("A") + nxt - 1)
    return None
