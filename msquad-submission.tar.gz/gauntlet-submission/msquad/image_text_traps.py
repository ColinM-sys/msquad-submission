"""Generate arm: name the trap surfaces when a text-banned request names a lettering-prone object.

The shipped no-text guard bans lettering in general. A banned request that names a poster, vehicle,
packaging or similar object still gets lettering on the object's obvious surfaces (headlines, plates,
badges, numerals). This arm adds one sentence naming those surfaces, drawn from a closed lexicon.

Fires only when the request (or notes) bans text, lettering, logos or watermarks AND names an object from
the closed lexicon. It stays silent when the request asks for specific words (the same exceptions IM2 uses)
and on every edit. Off unless MSQUAD_GENERATE_TEXT_TRAPS=1 or DEFAULT_ENABLED is True, so it can be A/B
tested. Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

from msquad import image_positive_render

ENV_FLAG = "MSQUAD_GENERATE_TEXT_TRAPS"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

# A text ban: the phrases the shipped no-text guard answers to, plus "avoid ... text/logo/watermark".
_BAN_RE = re.compile(
    r"\b(no text|without text|without any text|no lettering|no words|text-free|no visible text|no writing"
    r"|no logos?|no watermarks?|avoid\b[^.;\n]{0,40}\b(?:text|logos?|watermarks?))\b",
    re.IGNORECASE,
)
# The closed lexicon of lettering-prone objects; each maps to its trap clause.
_TRAPS = (
    (r"poster|billboard|banner|cover", "no headline, title band or tagline"),
    (r"sign|storefront|label|packaging|menu", "the sign, label or packaging carries no lettering, numerals or logos"),
    (r"vehicle|car|motorcycle|bike|truck|bus|plane", "the vehicle carries no badge, plate or numerals"),
    (r"jersey", "the jersey carries no number, name or crest"),
    (r"screen", "the screen shows abstract shapes, not text"),
)
_NEON_CLAUSE = "neon is abstract tubes, not letters"
_NOTES_LINE = "Single coherent scene. Keep composition clean."


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def sentence_for(request: str, notes: str = "", *, positive_render: bool = False) -> str | None:
    """One sentence naming the trap surfaces, or None when the arm does not apply to this generate request.

    ``positive_render`` is True when IM2 is on: its light sentence already covers neon, so the neon clause is skipped.
    """
    text = " ".join(str(request or "").split())
    if not _BAN_RE.search(text):
        return None
    rest = _BAN_RE.sub(" ", text)
    if image_positive_render._QUOTED_RE.search(rest) or image_positive_render._ASKS_WORDS_RE.search(rest):
        return None
    clauses = [clause for pattern, clause in _TRAPS if re.search(rf"\b(?:{pattern})s?\b", text, re.IGNORECASE)]
    if not clauses:
        return None
    if re.search(r"\bneon\b", text, re.IGNORECASE) and not positive_render:
        clauses.append(_NEON_CLAUSE)
    sentence = "; ".join(clauses)
    sentence = sentence[0].upper() + sentence[1:] + "."
    if "Single coherent scene. Keep composition clean" in str(notes or ""):
        sentence = f"{sentence} {_NOTES_LINE}"
    return sentence
