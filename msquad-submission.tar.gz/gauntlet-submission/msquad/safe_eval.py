"""Exact arithmetic over a whitelisted AST: numbers, + - * / // % **, parentheses.

No names, calls, attributes or eval/exec. Model text is only ever parsed, so a
hostile expression fails with ToolError instead of running code.
"""

from __future__ import annotations

import ast
import operator
from fractions import Fraction
from typing import Any, Callable

MAX_EXPR_CHARS = 400
MAX_EXPR_DEPTH = 40
MAX_POW_EXPONENT = 1000
MAX_RESULT_BITS = 6000

_BIN_OPS: dict[type, Callable[[Any, Any], Any]] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY_OPS: dict[type, Callable[[Any], Any]] = {ast.UAdd: operator.pos, ast.USub: operator.neg}


class ToolError(ValueError):
    """Input that is not a safe arithmetic expression."""


def _number(value: Any) -> Any:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ToolError("only numeric literals are allowed")
    # Fraction(str(...)) keeps the decimal the model wrote: 0.4 is 2/5, not the binary approximation.
    return Fraction(str(value)) if isinstance(value, float) else value


def _check_size(value: Any) -> Any:
    if isinstance(value, int) and value.bit_length() > MAX_RESULT_BITS:
        raise ToolError("result too large")
    return value


def _eval(node: ast.AST, depth: int) -> Any:
    if depth > MAX_EXPR_DEPTH:
        raise ToolError("expression too deeply nested")
    if isinstance(node, ast.Constant):
        return _number(node.value)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPS:
        return _UNARY_OPS[type(node.op)](_eval(node.operand, depth + 1))
    if isinstance(node, ast.BinOp) and type(node.op) in _BIN_OPS:
        left = _eval(node.left, depth + 1)
        right = _eval(node.right, depth + 1)
        op = type(node.op)
        if op is ast.Pow:
            if isinstance(right, Fraction) and right.denominator != 1:
                raise ToolError("fractional exponents are not supported")
            exponent = int(right)
            if abs(exponent) > MAX_POW_EXPONENT:
                raise ToolError("exponent too large")
            if isinstance(left, int) and abs(exponent) > 1 and abs(left) > 1:
                _check_size(left ** abs(exponent))
            return _check_size(Fraction(left) ** exponent if isinstance(left, Fraction) else left ** exponent)
        if op in (ast.Div, ast.FloorDiv, ast.Mod) and right == 0:
            raise ToolError("division by zero")
        if op is ast.Div:
            return Fraction(left) / Fraction(right)
        if op is ast.FloorDiv:
            return Fraction(left) // Fraction(right)
        if op is ast.Mod:
            return Fraction(left) % Fraction(right)
        return _check_size(_BIN_OPS[op](left, right))
    raise ToolError(f"{type(node).__name__} is not allowed")


def evaluate_expr(expr: str) -> Any:
    """Exact value (int or Fraction) of an arithmetic expression. Raises ToolError otherwise."""
    if not isinstance(expr, str):
        raise ToolError("expr must be a string")
    text = expr.strip()
    if not text:
        raise ToolError("empty expression")
    if len(text) > MAX_EXPR_CHARS:
        raise ToolError("expression too long")
    try:
        tree = ast.parse(text, mode="eval")
    except SyntaxError as exc:
        raise ToolError(f"syntax error: {exc.msg}") from None
    return _eval(tree.body, 0)
