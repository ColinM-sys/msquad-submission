"""Arm: natural_order sees the rules and answer format too, not only the description (astra H).

natural_order leaves an answer alone when the question states an order, and otherwise re-sorts a JSON
array (by date, or by first mention). The agent passed it only the description, so an order stated in
the rules ("sorted by date descending") was invisible and a correct descending array was re-sorted.
With this arm on it gets the description, the rules and the answer format together.
Off unless MSQUAD_ORDER_FROM_RULES=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_ORDER_FROM_RULES"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def question_text(description: str, rules: str, answer_format: str) -> str:
    """What natural_order reads for a stated order: with the arm on, all three texts."""
    if not enabled():
        return str(description or "")
    return "\n".join(part for part in (str(description or ""), str(rules or ""), str(answer_format or "")) if part)
