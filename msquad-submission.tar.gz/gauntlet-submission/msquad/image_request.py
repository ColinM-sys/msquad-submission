"""What an image request asks for, so the shipped guards never contradict it.

The generate guard said "Compose the scene without signs, billboards, labels, captions, screens or
writing; if one is essential, leave it blank." and "no logos, no numbers" to every request, so a logo
with the word "ACME", a labelled diagram, a price tag, a street sign that reads "MAPLE AVE" or a poster
headline were all told to stay blank. The edit guard kept "subject, ... colors and lighting" unchanged
for every edit, against "turn it black and white", "make it a sunset" or "remove the person".
These cues decide which guard clauses apply. A negated mention ("no text", "avoid logo/watermark
text", "remove any text", "avoid heavy style transfer") is not a request, so the live practice prompts
are unchanged.
"""

from __future__ import annotations

import re

# A double-quoted word or phrase the image must show: "ACME", “SUMMER JAZZ”. Never single quotes: an
# apostrophe ("a child's bedroom ... the cat's bed", "it's snowing") is not a quotation (Fable on #426).
_QUOTED_RE = re.compile(r"[\"“”]([A-Za-z0-9$][^\"“”\n]{0,60})[\"“”]")
_TEXT_CUE_RE = re.compile(
    r"\b(?:text|lettering|label(?:s|led|ed)?|logo(?:type)?|wordmark|headline|caption|titled|the title|price(?: tag)?|"
    r"banner with|the words?|spell(?:ed|s)?|sign (?:that )?(?:reads|says)|"
    # Unquoted written content (fresh-request audit): "the number 30 written in icing", "a name engraved on the
    # backrest", "a motto printed on the side", "the number 7 on the back". A written-content noun must come
    # first: "a dragon embroidered on the back", "a mural painted on the wall" are pictures (Fable on #458).
    r"(?:names?|words?|motto|slogan|initials|date|letters|text|message|monogram|quote|number[ \t]+\d+)"
    r"(?:[ \t]+[A-Za-z]+){0,2}?[ \t]+(?:written|engraved|printed|embroidered|inscribed|painted|stencill?ed|stitched)|"
    r"the number[ \t]+\d+|spelled out)\b"
    r"|\breading(?=\s+(?-i:[\"“'$A-Z0-9]))",  # "a price tag reading $79.99", not "a reading nook"
    re.IGNORECASE,
)
# Edits that change the whole picture's colours or lighting. A one-object recolour is local: "everything
# else" already excludes the object being changed.
# Season, time-of-day and style words count only as a transformation of the picture ("make it winter",
# "into a watercolour painting", "a snowy winter scene"), never as a thing in it ("a winter hat", "the
# painting on the wall", "a spring flower") (Fable on #426).
_SCENE = r"(?:winter|summer|autumn|spring|snowy|night(?:time)?|sunset|sunrise|dusk|dawn)"
_GLOBAL_EDIT_RE = re.compile(
    r"\b(?:black and white|black-and-white|gr[ae]yscale|monochrome|sepia|re-?light(?:ing)?|golden hour|"
    r"day[- ]to[- ]night|colou?r grade|change the season|the season|in the style of|"
    rf"(?:to|into|make (?:it|the (?:scene|photo|image|picture))(?: an?)?|turn (?:it|the \w+) into an?|look like an?) {_SCENE}\b|"
    rf"{_SCENE}(?: \w+)? (?:scene|setting|landscape|day|evening|light(?:ing)?|version|atmosphere)|"
    r"(?:into|as|like) an? (?:\w+ )?(?:painting|watercolou?r|oil painting|sketch|cartoon|anime|pencil drawing))\b",
    re.IGNORECASE,
)
_REMOVE_RE = re.compile(r"\b(?:remove|erase|delete|take out|get rid of|replace)\b", re.IGNORECASE)
# The person must be what is removed: "remove the man", "erase the tall woman" (one optional word between),
# not "remove the handbag the woman is holding".
_REMOVED_PERSON_RE = re.compile(
    r"[ \t]{1,3}(?:(?:the|a|an|any|all|both|every|that|this|these|those)[ \t]{1,3})?(?:[a-z-]{1,30}[ \t]{1,3})?"
    r"(?:(?:everyone|everybody|(?:person|people|man|woman|men|women|child|children|kid|boy|girl|subject|figure|"
    r"pedestrian|passer-?by|crowd|rider|driver)s?)\b(?![’']s)|(?:him|them)\b|her\b(?!['’]s)(?![ \t]+(?!(?:from|out|entirely|completely)\b)[a-z]))",
    re.IGNORECASE,
)  # a possessive is not the person: "the man's glasses", "her earrings" (Fable on #426)
# A cue right after one of these words (within the same short phrase) is a ban, not a request.
_NEGATION_RE = re.compile(
    r"\b(?:no|not|never|without|avoid|avoiding|free of|nothing|exclude|excluding)\b[^.;:\n]{0,30}$",
    re.IGNORECASE,
)
# For text cues only: "remove any text" asks for no text. A removal must not cancel a global-edit cue later
# in the same request ("remove the man and make it a winter scene").
_TEXT_NEGATION_RE = re.compile(r"\b(?:remove|erase|delete)\b[^.;:\n]{0,30}$", re.IGNORECASE)


def _requested(match: re.Match, text: str, text_cue: bool = False) -> bool:
    """True unless the cue is negated ("no text", "avoid logo/watermark text") or a "-free" compound."""
    before = text[max(0, match.start() - 40):match.start()]
    after = text[match.end():match.end() + 6]
    if text_cue and _TEXT_NEGATION_RE.search(before):
        return False
    return not _NEGATION_RE.search(before) and not after.lower().startswith("-free")


def asks_for_text(request: str) -> bool:
    """The request wants readable text in the image: a quoted phrase or a non-negated text cue."""
    text = str(request or "")
    if any(_requested(m, text, text_cue=True) for m in _QUOTED_RE.finditer(text)):
        return True
    return any(_requested(m, text, text_cue=True) for m in _TEXT_CUE_RE.finditer(text))


def global_edit(request: str) -> bool:
    """The edit changes the whole picture's colours or lighting (B&W, sunset, season, a painting style)."""
    text = str(request or "")
    return any(_requested(m, text) for m in _GLOBAL_EDIT_RE.finditer(text))


# Everyone goes: "remove all the people", "remove everyone", "erase every person".
_REMOVE_ALL_RE = re.compile(
    r"\b(?:remove|erase|delete|take out|get rid of)[ \t]+(?:everyone|everybody|all[ \t]+(?:of[ \t]+)?(?:the[ \t]+)?"
    r"(?:people|persons|men|women|children|kids|pedestrians|figures)|every[ \t]+(?:person|pedestrian|figure|one))\b",
    re.IGNORECASE,
)


# A removal limited to part of the picture or with an exception leaves people: "except the bride", "in the
# background", "on the left" (Fable on #458).
_REMOVE_SCOPE_RE = re.compile(
    r"\b(?:except|but|other than|apart from|besides|save for)\b"
    r"|\b(?:in|on|at|to|from)[ \t]+the[ \t]+(?:background|foreground|left|right|back|front|edge|edges|corner|side|sides|"
    r"distance|middle|centre|center)\b|\bbehind\b|\bnext to\b|\bnear\b",
    re.IGNORECASE,
)


def removes_everyone(request: str) -> bool:
    """The edit removes every person, so no person is kept ("remove all the people from the beach")."""
    text = str(request or "")
    for m in _REMOVE_ALL_RE.finditer(text):
        clause = re.split(r"[.;:\n]", text[m.end():], maxsplit=1)[0]
        if _requested(m, text) and not _REMOVE_SCOPE_RE.search(clause):
            return True
    return False


def removes_subject(request: str) -> bool:
    """The edit removes or replaces a person: the subject must not be kept as it is."""
    text = str(request or "")
    for m in _REMOVE_RE.finditer(text):
        if _requested(m, text) and _REMOVED_PERSON_RE.match(text[m.end():]):
            return True
    return False
