"""Arm: a JSON answer is read from after the reply's last ANSWER: label, not the first object (astra F).

finalize_answer's json branch takes the first balanced object in the reply. A model that shows an example
or thinks aloud first ("Example: {"x":0}\nANSWER: {"x":1}", or a <think> block with JSON in it) had the
example submitted. With this arm on, <think>...</think> is dropped and, when the reply has an ANSWER:
label, the JSON is looked for after the last one first; the old whole-reply search is the fallback.
Off unless MSQUAD_JSON_AFTER_LABEL=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_JSON_AFTER_LABEL"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

_THINK_RE = re.compile(r"<think>.*?</think>", re.IGNORECASE | re.DOTALL)
_LABEL_RE = re.compile(r"ANSWER:", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def strip_think(reply: str) -> str:
    """The reply without <think>...</think> blocks. Not part of the arm: a draft there is never the answer."""
    return _THINK_RE.sub(" ", str(reply or ""))


def focus(reply: str) -> str:
    """The reply without <think> blocks, from its last ANSWER: label on (the whole reply when there is none)."""
    text = strip_think(reply)
    labels = list(_LABEL_RE.finditer(text))
    return text[labels[-1].end():] if labels else text
