"""Arm: spread the fetch-by-id slots across the search queries, instead of the first query's ids.

The first search's ids filled all three docs.get slots, so a later query's ids were never fetched. With this
arm on the ids are taken round-robin: the first id of each query, then the second id of each, and so on, with
duplicates dropped. Off by default. Off unless MSQUAD_FETCH_ROUND_ROBIN=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_FETCH_ROUND_ROBIN"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def round_robin(buckets: list[list[str]]) -> list[str]:
    """The ids of each bucket in turn, first ids first, duplicates dropped."""
    order: list[str] = []
    depth = max((len(bucket) for bucket in buckets), default=0)
    for index in range(depth):
        for bucket in buckets:
            if index < len(bucket) and bucket[index] not in order:
                order.append(bucket[index])
    return order
