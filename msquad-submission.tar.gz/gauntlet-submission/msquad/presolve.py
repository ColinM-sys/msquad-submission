"""Deterministic answers for math challenges, tried before the LLM.

Each rule answers only when its pattern parses the whole question. No match
returns None and the caller falls through to the model. Stdlib only.
"""

from __future__ import annotations

import re
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from msquad.safe_eval import ToolError, evaluate_expr

_ISO_DATE = r"(\d{4}-\d{2}-\d{2})"
_DAY_FORWARD_RE = re.compile(
    rf"start on {_ISO_DATE}.*?count forward (\d+) calendar days", re.IGNORECASE | re.DOTALL
)
_WEEKDAY_RE = re.compile(
    r"what day of the week is (\d{1,2} [A-Za-z]+ \d{4}|\d{4}-\d{2}-\d{2})\?", re.IGNORECASE
)
_COMPOUND_RE = re.compile(
    r"([\d,]+(?:\.\d+)?)\s+(?:is\s+)?invested at ([\d.]+)%.*?compounded annually for (\d+)",
    re.IGNORECASE | re.DOTALL,
)
_COMPUTE_RE = re.compile(
    r"(?:compute|calculate|evaluate|what is)\s+(.+?)[.?]\s+answer", re.IGNORECASE | re.DOTALL
)


def _parse_date(text: str) -> date | None:
    for fmt in ("%Y-%m-%d", "%d %B %Y"):
        try:
            return datetime.strptime(text.strip(), fmt).date()
        except ValueError:
            continue
    return None


def _days_forward(text: str) -> tuple[str, re.Match[str]] | None:
    match = _DAY_FORWARD_RE.search(text)
    if not match:
        return None
    start = _parse_date(match.group(1))
    if start is None:
        return None
    return (start + timedelta(days=int(match.group(2)))).isoformat(), match


def _weekday(text: str) -> tuple[str, re.Match[str]] | None:
    match = _WEEKDAY_RE.search(text)
    if not match:
        return None
    day = _parse_date(match.group(1))
    return (day.strftime("%A"), match) if day else None


def _compound(text: str) -> tuple[str, re.Match[str]] | None:
    match = _COMPOUND_RE.search(text)
    if not match:
        return None
    try:
        principal = Decimal(match.group(1).replace(",", ""))
        rate = Decimal(match.group(2)) / Decimal(100)
    except InvalidOperation:
        return None
    years = int(match.group(3))
    if years > 100:
        return None
    balance = principal * (Decimal(1) + rate) ** years
    return str(balance.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)), match


def _arithmetic(text: str) -> tuple[str, re.Match[str]] | None:
    match = _COMPUTE_RE.search(text)
    if not match:
        return None
    expr = re.sub(r"(?<=[\w)])\s*[x×]\s*(?=[\w(])", " * ", match.group(1))
    try:
        value = evaluate_expr(expr)
    except ToolError:
        return None
    if getattr(value, "denominator", 1) != 1:
        return None
    return str(int(value)), match


_PRINT_RE = re.compile(
    r"^\s*what does this print\?\s*((?:[A-Za-z_]\w*\s*=\s*-?\d+\s*;\s*)+)print\((.+)\)",
    re.IGNORECASE | re.DOTALL,
)
_ASSIGN_RE = re.compile(r"([A-Za-z_]\w*)\s*=\s*(-?\d+)")


def _print_expr(text: str) -> tuple[str, re.Match[str]] | None:
    """`What does this print? a = 12; b = 5; print(...)`: substitute the integer names, then evaluate."""
    match = _PRINT_RE.search(text)
    if not match:
        return None
    values = {name: value for name, value in _ASSIGN_RE.findall(match.group(1))}
    expr = re.sub(r"[A-Za-z_]\w*", lambda m: f"({values[m.group(0)]})" if m.group(0) in values else m.group(0), match.group(2))
    try:
        value = evaluate_expr(expr)
    except ToolError:
        return None
    if getattr(value, "denominator", 1) != 1:
        return None
    return str(int(value)), match


_RULES = (_days_forward, _weekday, _compound, _arithmetic, _print_expr)

# Wording a complete question may carry after the matched part. Anything else left
# over (a withdrawal, a go-back step, a second number) means the rule did not parse
# the whole question, so the model answers it instead.
_ALLOWED_TAILS = (
    r"answer in yyyy-mm-dd",
    r"answer with the english weekday name only",
    r"answer with the integer result only",
    r"answer with the integer only",
    r"answer with two decimal places, no currency symbol",
    r"rounded to the nearest penny",
    r"with no withdrawals",
    r"what is the resulting date\?",
    r"what day of the week is",
    r"what is the balance in gbp",
)
_TAIL_RE = re.compile("|".join(_ALLOWED_TAILS), re.IGNORECASE)
_LEFTOVER_RE = re.compile(
    r"\d|\b(then|after|minus|plus|withdraw\w*|deposit\w*|add|subtract|back|before|each|monthly|quarterly|per month)\b",
    re.IGNORECASE,
)


def _leftover_is_harmless(text: str, span: tuple[int, int]) -> bool:
    rest = text[: span[0]] + " " + text[span[1]:]
    rest = _TAIL_RE.sub(" ", rest)
    return _LEFTOVER_RE.search(rest) is None


def presolve_math(description: str, rules: str = "") -> str | None:
    """The bare answer if one rule parses the whole question, else None."""
    text = f"{description} {rules}".strip()
    if not text:
        return None
    for rule in _RULES:
        found = rule(text)
        if found is None:
            continue
        answer, match = found
        if not _leftover_is_harmless(text, match.span()):
            return None
        return answer
    return None


def presolve_challenge(challenge_type: str, description: str, rules: str = "") -> str | None:
    """presolve_math for challenges whose type is math; every other type goes to the model."""
    if "math" not in str(challenge_type or "").casefold():
        return None
    return presolve_math(description or "", rules or "")
