"""Arm: a JSON answer cut off by the deadline before any answer token never submits the model's reasoning.

deadline-squeeze structured_medium_03 (RC3, gym 52d7e0b): the stream hit the deadline after ~455 reasoning tokens and no
answer tokens; every fallback kept the reasoning, and the run submitted 1.8 KB of prose ("Okay, let's tackle this
problem...") that the judge rejected as not JSON. RC2 finished 0.5 s sooner on the same model and passed: the path is
the same in both builds, so the leak is shared. With this arm on, and only when the stream was cut with an empty
answer, a JSON-shaped answer becomes (a) the last complete JSON value in the reasoning that parses and passes the
described shape, else (b) an empty value of the described shape ([] or {}), never the prose. Every other run is
untouched.
Off unless MSQUAD_CUT_STREAM_SALVAGE=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import json
import os

from msquad.shape_check import check_shape, parse_shape

ENV_FLAG = "MSQUAD_CUT_STREAM_SALVAGE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

# Only the tail of a long reasoning is scanned, and only so many candidate starts: linear and bounded.
_SCAN_CHARS = 20_000
_MAX_STARTS = 400
_state: dict[str, object] = {"cut": False, "reply": ""}


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def note_cut(reply_so_far: str) -> None:
    """The stream was stopped at the deadline; reply_so_far is the answer text (not reasoning) received by then."""
    _state["cut"], _state["reply"] = True, str(reply_so_far or "")


def consume() -> bool:
    """True once when the arm is on and the last stream was cut with no answer text; clears the record."""
    hit = bool(_state["cut"]) and not str(_state["reply"]).strip() and enabled()
    _state["cut"], _state["reply"] = False, ""
    return hit


def last_json_value(text: str, shape: dict | None) -> str:
    """The latest-ending complete JSON object or array in text that passes the shape (any object/array when no shape
    is described), compact; "" when none."""
    tail = str(text or "")[-_SCAN_CHARS:]
    decoder = json.JSONDecoder()
    starts = [i for i, ch in enumerate(tail) if ch in "[{"][-_MAX_STARTS:]
    best: tuple[int, int, str] | None = None
    for start in starts:
        try:
            value, end = decoder.raw_decode(tail, start)
        except (ValueError, RecursionError):
            continue
        if not isinstance(value, (list, dict)) or (isinstance(value, list) and not value):
            continue
        compact = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        if shape is not None and check_shape(compact, shape):
            continue
        # latest end wins; for the same end the outermost (earliest start) value
        if best is None or end > best[0] or (end == best[0] and start < best[1]):
            best = (end, start, compact)
    return best[2] if best else ""


def is_valid_json(answer: str, shape_text: str) -> bool:
    """The answer already parses as JSON and passes the described shape (when one is described)."""
    try:
        json.loads(str(answer or ""))
    except (ValueError, RecursionError):
        return False
    return not check_shape(str(answer), parse_shape(shape_text))


def salvage(reasoning: str, shape_text: str) -> str:
    """(a) the last valid JSON value in the reasoning, else (b) an empty value of the described shape."""
    shape = parse_shape(shape_text)
    found = last_json_value(reasoning, shape)
    if found:
        return found
    return "[]" if shape is not None and shape["array"] else "{}"
