"""Image arm: a compact, task-first prompt in place of the generic Context paragraph and shipped guard.

The shipped image prompt leads with a guard, repeats the request as "Context: <description>" and ends with a
constraints block, so the request reads as one line among boilerplate. With this arm on the prompt is:
the request verbatim (all lines, the reference notes included), the task-specific rules of the enabled arms
once each, and one output line. Nothing is truncated.

Off unless MSQUAD_IMAGE_COMPACT=1 or DEFAULT_ENABLED is True, so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_IMAGE_COMPACT"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

OUTPUT_LINE = "Output: one image, about 1024 px on the longest side."


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}
