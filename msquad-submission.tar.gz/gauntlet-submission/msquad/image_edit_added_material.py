"""Edit arm: an object added to the subject in a named colour is its own real object, not part of the subject.

Live edit preservation was lowest (58, tester-live 2026-10-27 21:03) when the requested blue cap came out in
the figure's own glazed-ceramic texture and a muddy grey-blue, moulded into the head; the 95 run had a saturated
fabric cap sitting on top (side notes image-live-loss-axes.md). This names the added object, its colour and its
own material.

Fires only when the instruction adds a named object with a colour ("give the subject a blue baseball cap",
"add a red wool scarf"): an add verb, then the colour, then the object, in one clause. A removal, a global edit
or a recolour ("change the car's colour to black", "make the sky orange") gets no rule.
Off unless MSQUAD_EDIT_ADDED_MATERIAL=1 or DEFAULT_ENABLED is True, so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_EDIT_ADDED_MATERIAL"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

_COLOURS = (
    r"red|blue|green|yellow|orange|purple|violet|pink|black|white|grey|gray|brown|beige|cream|gold|golden|silver|"
    r"navy|teal|turquoise|maroon|crimson|scarlet|lime|olive|magenta|cyan|lavender|tan|ivory|bronze|copper"
)
# add verb ... [a|an|the] [one shade word] COLOUR OBJECT(1-2 words), all inside one clause
_ADDED_RE = re.compile(
    r"\b(?:add|adds|adding|give|gives|put|puts|place|places|pin|pins|attach|attaches|hang|hangs|dress \w+ in)\b"
    r"[^.;:\n]{0,40}?\b(?:a|an|the)?\s*(?:(?:light|dark|bright|pale|deep|matte|glossy)\s+)?"
    rf"(?P<colour>{_COLOURS})\s+(?P<obj>[a-z]+(?:\s+(?!(?:on|onto|to|around|behind|in|into|at|over|under|while|"
    r"with|and|for|from|near|next|beside|across|above|below)\b)[a-z]+)?)\b",
    re.IGNORECASE,
)
_NOT_ADD_RE = re.compile(r"\b(?:remove|erase|delete|take off|get rid of)\b", re.IGNORECASE)
# Words that are a light, colour treatment, surface, setting or body mark, not an added object: "a golden glow",
# "a pink hue", "a white background", "a black eye", "a silver finish", "black and white" (Fable on #459).
_NOT_OBJECT = frozenset({
    "and", "or", "glow", "hue", "tint", "tone", "tones", "cast", "light", "lighting", "sunlight", "shade", "shadow",
    "shadows", "filter", "finish", "coat", "paint", "colour", "color", "background", "backdrop", "sky", "forest",
    "field", "sea", "water", "wall", "walls", "floor", "scene", "setting", "atmosphere", "mood", "haze", "fog",
    "eye", "eyes", "skin", "tan", "border", "frame", "gradient", "overlay", "effect", "sheen", "texture",
})


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def rule_for(instruction: str) -> str:
    """The material sentence for an added coloured object, or "" when the edit adds none."""
    text = str(instruction or "")
    for match in _ADDED_RE.finditer(text):
        if _NOT_ADD_RE.search(text[: match.start()] + match.group(0)):
            return ""
        obj = match.group("obj").lower()
        if not set(obj.split()) & _NOT_OBJECT:
            break
    else:
        return ""
    colour = match.group("colour").lower()
    return (
        f"Render the added {obj} as a separate real {obj} in its own natural material, in a clear, saturated "
        f"{colour}; it does not take on the subject's surface, glaze or texture."
    )
