"""Arm: tool_adapt tells a same-schema decoy from the real tool by its description, not list order.

gym black-box-v2 lists "arena.clues.read" first, with exactly the schema of the real clue tool
"arena.clues.fetch" and the description "Deprecated mirror of the clue store. Serves cached clues
from an earlier round". Both names match arena.clues.get equally (read ~ get, fetch ~ get), so the
first listed won and every clue read returned a stale clue from another puzzle (main + #300's arms
on: 1/10 accepted).

With this arm on, a candidate whose description says deprecated, stale, cached, mirror, legacy,
archived or from an earlier/other round is never chosen, and among the rest a description that says
live or current breaks a tie. Off unless MSQUAD_DECOY_DESCRIPTION=1 or DEFAULT_ENABLED. On a
standard server every canonical tool is listed under its own name, so nothing is resolved at all.
"""

from __future__ import annotations

import os
import re
from typing import Any

ENV_FLAG = "MSQUAD_DECOY_DESCRIPTION"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

_DECOY_RE = re.compile(
    r"\b(deprecated|stale|cached|mirror|legacy|obsolete|archived|do not use|don't use|"
    r"(?:an? )?(?:earlier|previous|past|other) (?:round|puzzle|challenge)s?|test only)\b",
    re.IGNORECASE,
)
_LIVE_RE = re.compile(r"\b(live|current|this) (?:challenge|puzzle|round)\b", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def description_of(tool_def: Any) -> str:
    return str(getattr(tool_def, "description", "") or "")


def is_decoy(tool_def: Any) -> bool:
    return bool(_DECOY_RE.search(description_of(tool_def)))


def live_bonus(tool_def: Any) -> float:
    """A small score bonus that breaks a name tie in favour of the tool described as live/current."""
    return 0.25 if _LIVE_RE.search(description_of(tool_def)) else 0.0
