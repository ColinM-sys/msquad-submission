"""Deterministic solver for ordering and assignment logic puzzles.

The clues are parsed into constraints over slots (1 = front) and, when the
puzzle has a "(one of: ...)" attribute list, over one attribute value per
person. solve_logic_puzzle() returns an answer string only when every clue
parsed and exactly one assignment satisfies all of them. Anything else returns
None, and the LLM path runs.

Supported clue shapes (names and values are matched case-insensitively):
  X is in slot k / X is not in slot k / X finished <ordinal> / X finished either first or last
  X is somewhere ahead of Y / X is somewhere behind Y / X is somewhere between Y and Z
  X is immediately ahead of Y / X is immediately behind Y / X is neither first nor last
  X is directly beside Y / X is not beside Y / X and Y are (not) beside each other
  X finished exactly <n> place(s) ahead of|behind Y
  X has a <value> badge / X has a <value> / X does not have a <value> (badge)
  X did not finish last
Attribute groups come from every "(one of: ...)" list (two-attribute grids
included). A person has one value per group. The answer uses Name:v1:v2 only
when the answer format shows that many colon-separated parts; otherwise None.
"""

from __future__ import annotations

import itertools
import re
import time
from dataclasses import dataclass
from typing import Callable

SEARCH_BUDGET_S = 1.5

_ORDINALS = {
    "first": 1,
    "second": 2,
    "third": 3,
    "fourth": 4,
    "fifth": 5,
    "sixth": 6,
    "seventh": 7,
    "eighth": 8,
    "ninth": 9,
    "tenth": 10,
}
_NUMBER_WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9}

_PAREN_RE = re.compile(r"\(([^()]*)\)")
_COUNT_WORDS = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
_COUNT_WORD_RE = re.compile(r"\b(" + "|".join(_COUNT_WORDS) + r")\b", re.IGNORECASE)
_ONE_OF_RE = re.compile(r"\(\s*one of:\s*([^()]*)\)", re.IGNORECASE)
_CONSTRAINT_WORD_RE = re.compile(r"\d|\b(is|has|does|did|finished|slot)\b", re.IGNORECASE)
_BACK_SLOT_RE = re.compile(r"slot\s+(\d+)\s+is the back", re.IGNORECASE)


@dataclass(frozen=True)
class Constraint:
    """A test over the people it mentions. assign maps name -> (slot, value)."""

    people: tuple[str, ...]
    test: Callable[[dict[str, tuple[int, str | None]]], bool]


@dataclass(frozen=True)
class ParsedPuzzle:
    names: tuple[str, ...]
    groups: tuple[tuple[str, ...], ...]
    constraints: tuple[Constraint, ...]


class _Timeout(Exception):
    pass


def _alt(words: tuple[str, ...]) -> str:
    return "(" + "|".join(re.escape(w) for w in sorted(words, key=len, reverse=True)) + ")"


def _split_list(raw: str) -> list[str]:
    """Split "A, B, C" and "A, B, C and D" (with or without a comma before "and")."""
    return [item.strip() for item in re.split(r",|\s+and\s+", raw) if item.strip()]


def _entities(challenge_text: str) -> tuple[list[str], list[list[str]]] | None:
    """Return (names, attribute groups). Groups is empty when there is no attribute list."""
    groups = [[v.lower() for v in _split_list(m.group(1))] for m in _ONE_OF_RE.finditer(challenge_text)]
    names: list[str] | None = None
    for match in _PAREN_RE.finditer(challenge_text):
        if _ONE_OF_RE.match(match.group(0)):
            continue
        names = _split_list(match.group(1))
        break
    if not names or len(set(names)) != len(names) or len(names) < 2:
        return None
    if any(" " in name for name in names):
        # A roster entry with a space is a mis-split list; never guess the names.
        return None
    count_word = _COUNT_WORD_RE.search(challenge_text.split("(", 1)[0])
    if count_word and _COUNT_WORDS[count_word.group(1).lower()] != len(names):
        # "Three people (Ana, Ben, Cy, Dan)": the roster disagrees with the count word.
        return None
    for group in groups:
        if len(set(group)) != len(group) or len(group) != len(names):
            return None
    flat = [v for group in groups for v in group]
    if len(set(flat)) != len(flat):
        return None  # a value in two groups would make "has a X" ambiguous
    return names, groups


def parse_puzzle(challenge_text: str, clues: list[str]) -> ParsedPuzzle | None:
    """Parse the puzzle. Returns None if any clue or the layout is not understood."""
    found = _entities(challenge_text)
    if found is None:
        return None
    names, groups = found
    back = _BACK_SLOT_RE.search(challenge_text)
    if back and int(back.group(1)) != len(names):
        return None
    if _outsider_named_in_roster(challenge_text, names, clues):
        return None
    return parse_named(names, groups, clues, skip_noise=True)


def _outsider_named_in_roster(challenge_text: str, names: list[str], clues: list[str]) -> bool:
    """True when a clue names someone who is not in the parsed roster but does appear in the roster text.

    That means the roster was misparsed, so the name is not really an outsider and the clue must not be skipped.
    """
    roster = next((m.group(1) for m in _PAREN_RE.finditer(challenge_text) if not _ONE_OF_RE.match(m.group(0))), "")
    roster_words = set(re.findall(r"[A-Za-z]+", roster))
    known = {n.lower() for n in names}
    for clue in clues:
        for word in _CAP_WORD_RE.findall(clue):
            if word.lower() not in known and word in roster_words:
                return True
    return False


_CAP_WORD_RE = re.compile(r"\b[A-Z][A-Za-z0-9]*\b")
_NON_NAME_WORDS = {
    "The", "A", "An", "It", "Each", "Slot", "Team", "No", "One", "Two", "Three", "Four", "Five", "Six",
    "Seven", "Eight", "Nine", "Ten", "First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh",
    "Eighth", "Ninth", "Tenth", "Last", "Neither", "Nor", "Either", "Immediately", "Somewhere", "Directly",
}


def _names_outsider(text: str, canon: dict[str, str]) -> bool:
    """True when the clue capitalises a word that is not a roster name (ignoring ordinary words)."""
    return any(w.lower() not in canon and w not in _NON_NAME_WORDS for w in _CAP_WORD_RE.findall(text))


def _normalise(clue: str) -> str:
    """Map live-puzzle phrasings onto the grammar: "next to" is beside; presents/comes/stands/finishes act like "is"."""
    text = re.sub(r"\s+", " ", clue).strip().rstrip(".")
    text = re.sub(r"\bnext to\b", "beside", text, flags=re.IGNORECASE)
    text = re.sub(r"\badjacent to\b", "beside", text, flags=re.IGNORECASE)
    text = re.sub(r"(?<!the )\b(left|right) of\b", r"to the \1 of", text, flags=re.IGNORECASE)
    return re.sub(r"\b(presents|comes|stands|finishes|happened|occurred|was)\b", "is", text, flags=re.IGNORECASE)


def parse_named(
    names: list[str], groups: list[list[str]] | None, clues: list[str], *, skip_noise: bool = False
) -> ParsedPuzzle | None:
    """Parse clues against known names and optional attribute groups (one value per group)."""
    if len(set(names)) != len(names) or len(names) < 2:
        return None
    groups = [list(g) for g in (groups or [])]
    for group in groups:
        if len(set(group)) != len(group) or len(group) != len(names):
            return None
    flat = [v for group in groups for v in group]
    if len(set(flat)) != len(flat):
        return None
    n = len(names)
    group_of = {v.lower(): gi for gi, group in enumerate(groups) for v in group}
    values = flat if groups else None
    canon = {name.lower(): name for name in names}
    ent = _alt(tuple(names))
    ords = "(" + "|".join(list(_ORDINALS) + ["last"]) + ")"
    nums = "(" + "|".join(_NUMBER_WORDS) + ")"

    def c(word: str) -> str:
        return canon[word.lower()]

    def ordinal(word: str) -> int:
        return n if word.lower() == "last" else _ORDINALS[word.lower()]

    rules: list[tuple[str, Callable[..., Callable[[dict], bool]]]] = [
        (rf"^{ent} (?:is|finished) in slot (\d+)$",
         lambda p, k: lambda a: a[c(p)][0] == int(k)),
        (rf"^{ent} is not {ords}$",
         lambda p, o: lambda a: a[c(p)][0] != ordinal(o)),
        (rf"^{ent} is not in slot (\d+)$",
         lambda p, k: lambda a: a[c(p)][0] != int(k)),
        (rf"^{ent} (?:is|finished) {ords}$",
         lambda p, o: lambda a: a[c(p)][0] == ordinal(o)),
        (rf"^{ent} (?:is|finished) either first or last$",
         lambda p: lambda a: a[c(p)][0] in (1, n)),
        (rf"^{ent} (?:does not present|did not present|is not) (?:either )?first or last$",
         lambda p: lambda a: a[c(p)][0] not in (1, n)),
        (rf"^{ent} is not (?:the )?{ords} or {ords}(?: \w+)?$",
         lambda p, o1, o2: lambda a: a[c(p)][0] not in (ordinal(o1), ordinal(o2))),
        (rf"^{ent} is the (?:first|initial) \w+$",
         lambda p: lambda a: a[c(p)][0] == 1),
        (rf"^{ent} is the (?:final|last) \w+$",
         lambda p: lambda a: a[c(p)][0] == n),
        (rf"^{ent} (?:did not finish|is not|does not finish) last$",
         lambda p: lambda a: a[c(p)][0] != n),
        (rf"^{ent} (?:is somewhere ahead of|is somewhere before|is ahead of|is before|finished ahead of) {ent}$",
         lambda p, q: lambda a: a[c(p)][0] < a[c(q)][0]),
        (rf"^{ent} is (?:somewhere )?between {ent} and {ent}$",
         lambda p, q, r: lambda a: min(a[c(q)][0], a[c(r)][0]) < a[c(p)][0] < max(a[c(q)][0], a[c(r)][0])),
        (rf"^{ent} is immediately to the left of {ent}$",
         lambda p, q: lambda a: a[c(p)][0] == a[c(q)][0] - 1),
        (rf"^{ent} is immediately to the right of {ent}$",
         lambda p, q: lambda a: a[c(p)][0] == a[c(q)][0] + 1),
        (rf"^{ent} is (?:somewhere )?to the left of {ent}$",
         lambda p, q: lambda a: a[c(p)][0] < a[c(q)][0]),
        (rf"^{ent} is (?:somewhere )?to the right of {ent}$",
         lambda p, q: lambda a: a[c(p)][0] > a[c(q)][0]),
        (rf"^{ent} is immediately (?:ahead of|before) {ent}$",
         lambda p, q: lambda a: a[c(p)][0] == a[c(q)][0] - 1),
        (rf"^{ent} is immediately (?:behind|after) {ent}$",
         lambda p, q: lambda a: a[c(p)][0] == a[c(q)][0] + 1),
        (rf"^{ent} is (?:somewhere )?(?:behind|after) {ent}$",
         lambda p, q: lambda a: a[c(p)][0] > a[c(q)][0]),
        (rf"^{ent} is neither {ords} nor {ords}$",
         lambda p, o1, o2: lambda a: a[c(p)][0] not in (ordinal(o1), ordinal(o2))),
        (rf"^{ent} is neither first nor last$",
         lambda p: lambda a: a[c(p)][0] not in (1, n)),
        (rf"^{ent} is (?:directly )?beside {ent}$",
         lambda p, q: lambda a: abs(a[c(p)][0] - a[c(q)][0]) == 1),
        (rf"^{ent} is not beside {ent}$",
         lambda p, q: lambda a: abs(a[c(p)][0] - a[c(q)][0]) != 1),
        (rf"^{ent} and {ent} are not beside each other$",
         lambda p, q: lambda a: abs(a[c(p)][0] - a[c(q)][0]) != 1),
        (rf"^{ent} and {ent} are beside each other$",
         lambda p, q: lambda a: abs(a[c(p)][0] - a[c(q)][0]) == 1),
        (rf"^{ent} (?:is|finished) exactly {nums} places? (ahead of|behind) {ent}$",
         lambda p, k, way, q: _place_gap(c(p), _NUMBER_WORDS[k.lower()], way, c(q))),
    ]
    if values is not None:
        val = _alt(tuple(values))
        rules += [
            (rf"^{ent} has an? {val}(?: badge)?$",
             lambda p, v: lambda a: a[c(p)][1][group_of[v.lower()]] == v.lower()),
            (rf"^{ent} does not have an? {val}(?: badge)?$",
             lambda p, v: lambda a: a[c(p)][1][group_of[v.lower()]] != v.lower()),
        ]

    constraints: list[Constraint] = []
    word = "|".join(re.escape(w) for w in list(canon) + list(values or []))
    mentions = re.compile(r"\b(" + word + r")\b", re.IGNORECASE)
    for clue in clues:
        text = _normalise(clue)
        if skip_noise and not mentions.search(text) and not _CONSTRAINT_WORD_RE.search(text):
            # A clue naming no person or value cannot constrain the answer (gym distractors).
            continue
        if skip_noise and _names_outsider(text, canon):
            # A clue about someone outside this roster (unseen mode draws distractors from other puzzles).
            continue
        built = _match_clue(text, rules, canon, c)
        if built is None:
            return None
        constraints.append(built)
    return ParsedPuzzle(tuple(names), tuple(tuple(g) for g in groups), tuple(constraints))


def _place_gap(p: str, k: int, way: str, q: str) -> Callable[[dict], bool]:
    # "X finished exactly k places behind Y" means slot(X) = slot(Y) + k.
    sign = 1 if way.lower() == "behind" else -1
    return lambda a: a[p][0] == a[q][0] + sign * k


def _match_clue(text: str, rules, canon: dict[str, str], c) -> Constraint | None:
    for pattern, build in rules:
        match = re.match(pattern, text, flags=re.IGNORECASE)
        if not match:
            continue
        groups = match.groups()
        test = build(*groups)
        people = tuple(dict.fromkeys(c(g) for g in groups if g and g.lower() in canon))
        return Constraint(people, test)
    return None


def _solutions(parsed: ParsedPuzzle, deadline: float) -> list[dict] | None:
    """Up to two solutions (enough to tell unique from ambiguous). None on timeout."""
    names = parsed.names
    n = len(names)
    choices = list(itertools.product(*parsed.groups)) if parsed.groups else [()]

    domains: dict[str, list[tuple[int, tuple[str, ...]]]] = {}
    for p in names:
        unary = [k.test for k in parsed.constraints if k.people == (p,)]
        domains[p] = [
            (pos, vals)
            for pos in range(1, n + 1)
            for vals in choices
            if all(t({p: (pos, vals)}) for t in unary)
        ]

    order = sorted(names, key=lambda p: len(domains[p]))
    index = {p: i for i, p in enumerate(order)}
    checks: list[list[Constraint]] = [[] for _ in order]
    for k in parsed.constraints:
        if len(k.people) > 1:
            checks[max(index[p] for p in k.people)].append(k)

    solutions: list[dict] = []
    assign: dict[str, tuple[int, tuple[str, ...]]] = {}
    used_pos: set[int] = set()
    used_vals: list[set[str]] = [set() for _ in parsed.groups]

    def walk(i: int) -> bool:
        if time.perf_counter() > deadline:
            raise _Timeout
        if i == len(order):
            solutions.append(dict(assign))
            return len(solutions) >= 2
        p = order[i]
        for pos, vals in domains[p]:
            if pos in used_pos or any(v in used_vals[g] for g, v in enumerate(vals)):
                continue
            assign[p] = (pos, vals)
            used_pos.add(pos)
            for g, v in enumerate(vals):
                used_vals[g].add(v)
            if all(k.test(assign) for k in checks[i]) and walk(i + 1):
                return True
            del assign[p]
            used_pos.discard(pos)
            for g, v in enumerate(vals):
                used_vals[g].discard(v)
        return False

    try:
        walk(0)
    except _Timeout:
        return None
    return solutions


def _drop_one_bad_clue(parsed: ParsedPuzzle, clues: list[str], deadline: float) -> dict | None:
    """Zero solutions: find the single clue that the unique solution of the other clues violates.

    Unseen mode adds a distractor drawn from another puzzle, which can contradict
    the answer. If every genuine clue holds for the answer, dropping the one false
    clue leaves the answer as the unique solution, and that clue is the one it
    violates. Two or more candidates means we cannot tell which clue is false.
    """
    names = list(parsed.names)
    groups = [list(g) for g in parsed.groups]
    found: list[dict] = []
    for i, clue in enumerate(clues):
        rest = clues[:i] + clues[i + 1:]
        without = parse_named(names, groups, rest, skip_noise=True)
        if without is None:
            continue
        sols = _solutions(without, deadline)
        if sols is None:
            return None
        if len(sols) != 1:
            continue
        alone = parse_named(names, groups, [clue], skip_noise=True)
        if alone is None or not alone.constraints:
            continue
        if all(k.test(sols[0]) for k in alone.constraints):
            continue
        found.append(sols[0])
        if len(found) > 1:
            return None
    return found[0] if len(found) == 1 else None


def solve_logic_puzzle(challenge_text: str, clues: list[str]) -> str | None:
    """Return the answer string, or None when the LLM should answer."""
    deadline = time.perf_counter() + SEARCH_BUDGET_S
    parsed = parse_puzzle(challenge_text, clues)
    if parsed is None:
        return None
    groups = len(parsed.groups)
    if groups:
        # Name:v1[:v2] only when the answer format shows that many parts; otherwise let the LLM answer.
        if not re.search(r"name:\w+" + r"(?::\w+)" * (groups - 1), challenge_text, re.IGNORECASE):
            return None
    elif "comma-separated" not in challenge_text.lower():
        return None
    solutions = _solutions(parsed, deadline)
    if solutions is None or len(solutions) > 1:
        return None
    solution = solutions[0] if solutions else _drop_one_bad_clue(parsed, clues, deadline)
    if solution is None:
        return None
    ordered = sorted(parsed.names, key=lambda p: solution[p][0])
    if not groups:
        return ",".join(ordered)
    return ",".join(f"{p}:" + ":".join(solution[p][1]) for p in ordered)


def solve_named(names: list[str], clues: list[str]) -> str | None:
    """Solve an ordering puzzle whose names are already known (no attributes).

    Used by the translate-then-solve path, where the names and clue constraints
    come from a model. Returns comma-joined names in slot order, or None.
    """
    deadline = time.perf_counter() + SEARCH_BUDGET_S
    parsed = parse_named(list(names), None, clues)
    if parsed is None:
        return None
    solutions = _solutions(parsed, deadline)
    if solutions is None or len(solutions) != 1:
        return None
    solution = solutions[0]
    return ",".join(sorted(parsed.names, key=lambda p: solution[p][0]))


_COUNT_WORDS = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
_COUNT_RE = re.compile(r"\b(" + "|".join(_COUNT_WORDS) + r")\s+[a-z]+", re.IGNORECASE)
_NAME_RE = re.compile(r"\b[A-Z][a-z]+(?: [A-Z][a-z]+| [A-Z]\d+)?\b|\b[A-Z]\d+\b")
_NAME_STOP = {"The", "A", "An", "It", "This", "Return", "Each", "No", "Only"}


def _names_from_clues(clues: list[str]) -> list[str]:
    """Entity names as they first appear in the clues, e.g. "Team Alpha" or "E3"."""
    found: list[str] = []
    for clue in clues:
        for match in _NAME_RE.finditer(clue):
            name = match.group(0)
            if name.split()[0] in _NAME_STOP or name in found:
                continue
            found.append(name)
    return found


def solve_logic_from_challenge(challenge_text: str, clues: list[str]) -> str | None:
    """Solve a logic challenge, deriving the names from the clues when the text lists none.

    The names are taken from the clues only when the count word in the challenge text
    ("Six events") equals how many names the clues mention, and the answer is comma-separated.
    Otherwise, or when the solve is not unique, returns None and the model answers.
    """
    solved = solve_logic_puzzle(challenge_text, clues)
    if solved is not None or _entities(challenge_text) is not None:
        return solved
    if "comma-separated" not in challenge_text.lower():
        return None
    count = _COUNT_RE.search(challenge_text)
    if count is None:
        return None
    names = _names_from_clues(clues)
    if len(names) != _COUNT_WORDS[count.group(1).lower()]:
        return None
    groups = [[v.strip().lower() for v in m.group(1).split(",") if v.strip()] for m in _ONE_OF_RE.finditer(challenge_text)]
    if not groups:
        return solve_named(names, clues)
    return _solve_grouped(names, groups, clues, challenge_text)


def _solve_grouped(names: list[str], groups: list[list[str]], clues: list[str], challenge_text: str) -> str | None:
    """Names taken from the clues plus attribute groups: unique solution in Name:v1[:v2] form, else None."""
    if any(len(group) != len(names) or len(set(group)) != len(group) for group in groups):
        return None
    if not re.search(r"name:\w+" + r"(?::\w+)" * (len(groups) - 1), challenge_text, re.IGNORECASE):
        return None
    parsed = parse_named(names, groups, clues)
    if parsed is None:
        return None
    solutions = _solutions(parsed, time.perf_counter() + SEARCH_BUDGET_S)
    if solutions is None or len(solutions) != 1:
        return None
    solution = solutions[0]
    order = sorted(names, key=lambda p: solution[p][0])
    return ",".join(f"{p}:" + ":".join(solution[p][1]) for p in order)
