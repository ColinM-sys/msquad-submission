"""Arm: decode layered clue encodings (base64 -> rot13 and similar) in code, not in the model's head.

In gym black-box-live, with MSQUAD_TOOL_ADAPT on, the nested challenge delivered its clue
("R3VyIHBicXJqYmVxIHZmIFVORU9CRS03", base64 then rot13) and the model answered COEDWORD instead
of HARBOR-7: it cannot run base64 in its head. This arm decodes each clue before the solver
sees it and appends the plain text, so the model reads "The codeword is HARBOR-7".

The layer order comes from the challenge text when it names the encodings in order ("base64
first, then rot13"). Otherwise each sequence of up to MAX_LAYERS layers is tried, and the
decode is kept only when it reads as English clearly better than the raw clue. A clue that is
already plain text is never touched. Off unless MSQUAD_LAYERED_DECODE=1 or DEFAULT_ENABLED.
"""

from __future__ import annotations

import base64
import binascii
import codecs
import itertools
import os
import re

from msquad import unlabelled_decode

ENV_FLAG = "MSQUAD_LAYERED_DECODE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

MAX_LAYERS = 3
# A decode must read as English (MIN_ENGLISH) and clearly more so than the raw clue (MIN_GAIN):
# "Mia owns no cat" reversed is "tac on snwo aiM", English-ish only because "no" reversed is "on".
MIN_ENGLISH = 0.4
MIN_GAIN = 0.25
_REVERSAL_RE = re.compile(r"\b(revers\w*|backwards?|mirrored)\b", re.IGNORECASE)
_REAL_DECODES = ("base64", "base32", "hex")  # these fail on plain text; rot13 and reverse never do
_LAYER_RE = re.compile(r"\b(base64|base32|rot[- ]?13|hex(?:adecimal)?|revers(?:e|ed))\b", re.IGNORECASE)
_COMMON = {
    "the", "is", "a", "an", "of", "and", "to", "in", "it", "for", "on", "at", "by", "with", "from", "as",
    "be", "was", "are", "this", "that", "code", "codeword", "word", "key", "answer", "password", "secret",
    "clue", "value", "number", "name", "first", "last", "left", "right", "not", "who", "what", "where",
}


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _canonical(layer: str) -> str:
    layer = layer.lower().replace(" ", "").replace("-", "")
    if layer.startswith("hex"):
        return "hex"
    if layer.startswith("revers"):
        return "reverse"
    return layer


def stated_layers(description: str) -> list[str]:
    """The encodings the challenge names, in the order it names them."""
    return [_canonical(m.group(1)) for m in _LAYER_RE.finditer(description or "")]


def _decode_one(text: str, layer: str) -> str | None:
    stripped = text.strip()
    try:
        if layer == "base64":
            if not re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", stripped) or len(stripped) % 4:
                return None
            out = base64.b64decode(stripped, validate=True).decode("utf-8")
        elif layer == "base32":
            if not re.fullmatch(r"[A-Z2-7]+=*", stripped) or len(stripped) % 8:
                return None
            out = base64.b32decode(stripped).decode("utf-8")
        elif layer == "hex":
            if not re.fullmatch(r"(?:[0-9a-fA-F]{2})+", stripped):
                return None
            out = bytes.fromhex(stripped).decode("utf-8")
        elif layer == "rot13":
            out = codecs.decode(stripped, "rot_13")
        elif layer == "reverse":
            out = stripped[::-1]
        else:
            return None
    except (ValueError, binascii.Error, UnicodeDecodeError):
        return None
    return out if out.isprintable() else None


def _decode(text: str, layers: list[str]) -> str | None:
    for layer in layers:
        decoded = _decode_one(text, layer)
        if decoded is None:
            return None
        text = decoded
    return text


def english_score(text: str) -> float:
    """Fraction of words that are common English words (0 for no words)."""
    words = re.findall(r"[a-z]+", text.lower())
    return sum(1 for w in words if w in _COMMON) / len(words) if words else 0.0


def _clearly_better(decoded: str, raw_score: float) -> bool:
    score = english_score(decoded)
    return score >= MIN_ENGLISH and score >= raw_score + MIN_GAIN


def decode_clue(clue: str, description: str = "") -> tuple[str, list[str]] | None:
    """(plain text, layers) when the clue is an encoding of English text, else None.

    "reverse" is tried as the outer layer only when the challenge mentions reversal; otherwise
    only under another decode (base64 of a reversed string), never on the raw clue.
    """
    raw_score = english_score(clue)
    if raw_score >= 0.25:
        return None  # already readable
    stated = stated_layers(description)
    if stated:
        decoded = _decode(clue, stated)
        if decoded is not None and _clearly_better(decoded, raw_score):
            return decoded, stated
    reversal_named = bool(_REVERSAL_RE.search(description or ""))
    relaxed = unlabelled_decode.enabled()  # unlabelled encodings: strict-alphabet decodes and rot13 (arm)
    best: tuple[float, str, list[str]] | None = None
    names = ("base64", "base32", "hex", "rot13", "reverse")
    for depth in range(1, MAX_LAYERS + 1):
        for layers in itertools.product(names, repeat=depth):
            if any(a == b and a in ("rot13", "reverse") for a, b in zip(layers, layers[1:])):
                continue  # rot13 twice or reverse twice is the identity
            if "reverse" in layers and not reversal_named and not any(
                    layer in _REAL_DECODES for layer in layers[:layers.index("reverse")]):
                continue  # reversing plain text turns "no" into "on": only under a real decode, or when named
            decoded = _decode(clue, list(layers))
            if decoded is None:
                continue
            score = english_score(decoded)
            ok = _clearly_better(decoded, raw_score) or (
                relaxed and unlabelled_decode.accept(decoded, list(layers), score, raw_score, MIN_GAIN))
            if ok and (best is None or score > best[0]):
                best = (score, decoded, list(layers))
    return (best[1], best[2]) if best else None


def annotate_clues(clues: list[str], description: str = "") -> list[str]:
    """Each encoded clue with its decoded text appended; plain clues are returned unchanged."""
    out = []
    for clue in clues:
        found = decode_clue(str(clue), description)
        if found is None:
            out.append(clue)
        else:
            text, layers = found
            if unlabelled_decode.enabled():
                out.append(text)  # the raw clue would be read as names by the solvers (arm)
            else:
                out.append(f"{clue}\n[decoded {' -> '.join(layers)}]: {text}")
    return out
