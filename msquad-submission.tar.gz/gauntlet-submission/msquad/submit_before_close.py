"""Arm: post the text answer before the MCP session closes, then close it (astra R).

The text path submits after leaving the MCP AsyncExitStack, and leaving it awaits ResilientMcp's
close (bounded at CLOSE_TIMEOUT_S, 3 s). The server's clock runs until the answer arrives (its
elapsed_ms matches register -> POST arrival in 285 live runs), so that close is scored time: about
0.4-0.5 s live inside "solve + finalize". With this arm on, the agent detaches the stack at the end
of the solve (AsyncExitStack.pop_all), posts the answer, and then closes the detached stack in the
same task that opened it (the SSE client's cancel scope must exit there). Off unless
MSQUAD_SUBMIT_BEFORE_CLOSE=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_SUBMIT_BEFORE_CLOSE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}
