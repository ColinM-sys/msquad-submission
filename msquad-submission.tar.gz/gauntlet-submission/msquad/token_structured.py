"""Arm: token_retry also recognises structured token refusals (astra W).

token_retry.refused_for_token only read a top-level string "error", and tool_adapt._error_text only the
first text block of an isError result. A server that refuses with {"error": {"code": "UNAUTHORIZED",
"message": "missing session token"}}, or that puts the refusal only in an isError result's
structuredContent (both allowed by the MCP contract), was not seen as a token refusal, so the retry with a
session token never ran. With this arm on, a structured error's code and message are joined and checked
with the same pattern, and an isError result's structuredContent is read when it has no text.
Off unless MSQUAD_TOKEN_STRUCTURED=1 or DEFAULT_ENABLED is True. Built from the MCP contract only.
"""

from __future__ import annotations

import os
from typing import Any

ENV_FLAG = "MSQUAD_TOKEN_STRUCTURED"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def error_text(error: Any) -> str:
    """A structured error ({"code", "message"}) as one string; "" for anything else."""
    if isinstance(error, dict):
        return " ".join(str(error.get(key) or "") for key in ("code", "message", "detail")).strip()
    return ""


def structured_error(result: Any) -> dict[str, Any]:
    """An isError result's structuredContent, as {"error": ...}, when its text gave nothing."""
    structured = getattr(result, "structuredContent", None)
    if isinstance(structured, dict) and structured.get("error"):
        return {"error": structured["error"]}
    return {}
