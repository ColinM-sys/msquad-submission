"""Generate arm: restate the request's hard constraints as an explicit checklist.

The generate judge's constraints axis is where generate loses most (live mean ~87 on
flash-lite, ~62 on flash). The gym image bench prompts carry three kinds of hard
constraint: negatives ("no people, no buildings, no text"), exact counts ("exactly three
books", "a single white sneaker") and colour limits ("using only navy blue and orange").
In prose they are easy for an image model to drop; as a short checklist they are not.

Off unless MSQUAD_GENERATE_CHECKLIST=1 or DEFAULT_ENABLED is True, so it can be A/B tested.
Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_GENERATE_CHECKLIST"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

_NUMBERS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
}
_COUNT_RE = re.compile(
    r"\b(?:exactly\s+(?P<n>\d+|" + "|".join(_NUMBERS) + r")|(?P<single>a single|only one|just one))\s+"
    r"(?P<noun>[a-z]+(?:\s+(?!(?:on|in|at|with|of|for|and|or|above|below|under|by|to|from|near|over|floating)\b)[a-z]+)?)",
    re.IGNORECASE,
)
# "no people", "without buildings", "with no readable signs or text anywhere": the prefix of a negative.
# The phrase after it is found by negative_whats(), which is linear; the one-pattern form
# (\b(?:no|without)\s+(?P<what>[a-z][a-z \-]*?)(?=\s*(?:[,.;:!]|$|\banywhere\b))) is quadratic on "no " * n.
_NEGATIVE_PREFIX_RE = re.compile(r"\b(?:no|without)\s+(?=[a-z])", re.IGNORECASE)
_PHRASE_CHARS = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ -")
_WORD_CHARS = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")


def _ends_phrase(text: str, f: int) -> bool:
    """True when the lookahead holds at f, the first non-space index after the candidate end.

    ``\\s*(?:[,.;:!]|$|\\banywhere\\b)`` at e holds iff the first non-space char at or after e is one of
    ,.;:! or the text ends there, or ``anywhere`` starts there on a word boundary.
    """
    n = len(text)
    if f == n:
        return True
    if text[f] in ",.;:!":
        return True
    if text[f:f + 8].lower() == "anywhere" and (f == 0 or text[f - 1] not in _WORD_CHARS) \
            and (f + 8 == n or text[f + 8] not in _WORD_CHARS):
        return True
    return False


def negative_whats(text: str) -> list[str]:
    """The ``what`` group of each negative, as the lazy one-pattern form finds them, in linear time.

    A start that fails also fails for every later start inside the same run of letters, spaces and
    hyphens (they share the candidate ends), so the run is skipped once.
    """
    whats: list[str] = []
    pos = 0
    dead_until = -1
    n = len(text)
    for prefix in _NEGATIVE_PREFIX_RE.finditer(text):
        s = prefix.end()
        if prefix.start() < pos or s < dead_until:
            continue
        run_end = s
        while run_end < n and text[run_end] in _PHRASE_CHARS:
            run_end += 1
        # next_nonspace[e - s] for e in [s, run_end]: the first non-space index at or after e
        after = run_end
        while after < n and text[after].isspace():
            after += 1
        chosen = None
        f = after
        for e in range(run_end, s, -1):
            if e < run_end:
                f = e if not text[e].isspace() else f
            if _ends_phrase(text, f):
                chosen = e
        if chosen is None:
            dead_until = run_end
            continue
        whats.append(text[s:chosen])
        pos = chosen
    return whats
_COLOUR_WORDS = (
    "red|orange|yellow|green|blue|navy|teal|cyan|purple|violet|pink|magenta|brown|black|white|"
    "grey|gray|gold|silver|beige|cream|turquoise|maroon|olive|lime|indigo"
)
_ONLY_COLOURS_RE = re.compile(
    r"\b(?:using|in|with)\s+only\s+(?P<colours>(?:(?:light|dark|deep|pale|bright|navy)\s+)?(?:"
    + _COLOUR_WORDS
    + r")(?:\s+(?:blue|green|red))?(?:\s*(?:,|and|&)\s*(?:(?:light|dark|deep|pale|bright|navy)\s+)?(?:"
    + _COLOUR_WORDS
    + r")(?:\s+(?:blue|green|red))?)+)",
    re.IGNORECASE,
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


_ADJECTIVES = _COLOUR_WORDS + "|small|large|big|tiny|tall|short|wooden|glass|ripe|fresh|old|new|young"
# A count stated without "exactly", in lowercase prose ("two croissants, one cup of coffee", "and
# one green pear"): the number word, then one noun, or an adjective and a noun. Case-sensitive, so a
# capitalised name ("One Direction") is not a count; "one of", "one black and" are not either.
# Words after a number that are not objects to count (Fable on #290): function words, fractions
# ("two thirds of", "three quarters"), units of extent ("3 storey") and idioms ("one corner of",
# "one point", "one end", "number one fan" via the lookbehind below).
_NOT_COUNTED = (
    r"of|another|more|or|and|by|side|sides|day|days|time|times|way|ways|"
    r"half|halves|thirds?|quarters?|fifths?|sixths?|tenths?|percent|storey|storeys|story|stories|"
    r"corner|point|end|hand|moment|piece|part|bit|level|step|floor"
)
_BARE_COUNT_RE = re.compile(
    r"(?<![\w-])(?<!number )(?P<n>" + "|".join(_NUMBERS) + r")\s+"
    r"(?P<noun>(?:(?:" + _ADJECTIVES + r")\s+)?(?!(?:" + _NOT_COUNTED + r"|" + _COLOUR_WORDS + r")\b)[a-z]{3,})\b"
)


def _counts(text: str) -> list[str]:
    items = []
    exact_spans = []
    for match in _COUNT_RE.finditer(text):
        exact_spans.append(match.span())
        n = 1 if match.group("single") else match.group("n").lower()
        n = _NUMBERS.get(n, n) if isinstance(n, str) else n
        item = f"Exactly {n} {match.group('noun').lower()}"
        if item not in items:  # the builder passes challenge_text and description, often the same text
            items.append(item)
    for match in _BARE_COUNT_RE.finditer(text):
        if any(start <= match.start() < end for start, end in exact_spans):
            continue  # the "exactly" count already covers it
        if text[max(0, match.start() - 8):match.start()].lower().endswith("exactly "):
            continue
        item = f"Exactly {_NUMBERS[match.group('n')]} {match.group('noun').lower()}"
        if item not in items:
            items.append(item)
    return items


def _negatives(text: str) -> list[str]:
    found: list[str] = []
    for what in negative_whats(text):
        for part in re.split(r"(?<!\s)\s+(?:or|and)\s+", what.strip().lower()):
            part = part.strip()
            if part and part not in found:
                found.append(part)
    return found


def _colours(text: str) -> list[str]:
    match = _ONLY_COLOURS_RE.search(text)
    if not match:
        return []
    return [c.strip().lower() for c in re.split(r",|\band\b|&", match.group("colours")) if c.strip()]


def checklist(request: str) -> str:
    """The checklist for ``request``, or "" when it states no count, colour limit or negative."""
    text = " ".join(str(request or "").split())
    lines = [f"- {item}" for item in _counts(text)]
    colours = _colours(text)
    if colours:
        lines.append(f"- Use only these colours: {', '.join(colours)}")
    negatives = _negatives(text)
    if negatives:
        lines.append(f"- Must not appear anywhere: {', '.join(negatives)}")
    if not lines:
        return ""
    return "Checklist (every item must hold in the final image):\n" + "\n".join(lines)
