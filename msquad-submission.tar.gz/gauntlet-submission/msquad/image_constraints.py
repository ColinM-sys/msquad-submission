"""Generate arm: restate the request's hard constraints as an explicit checklist.

The generate judge's constraints axis is where generate loses most (live mean ~87 on
flash-lite, ~62 on flash). The gym image bench prompts carry three kinds of hard
constraint: negatives ("no people, no buildings, no text"), exact counts ("exactly three
books", "a single white sneaker") and colour limits ("using only navy blue and orange").
In prose they are easy for an image model to drop; as a short checklist they are not.

Off unless MSQUAD_GENERATE_CHECKLIST=1 or DEFAULT_ENABLED is True, so it can be A/B tested.
Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_GENERATE_CHECKLIST"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

_NUMBERS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
}
_COUNT_RE = re.compile(
    r"\b(?:exactly\s+(?P<n>\d+|" + "|".join(_NUMBERS) + r")|(?P<single>a single|only one|just one))\s+"
    r"(?P<noun>[a-z]+(?:\s+(?!(?:on|in|at|with|of|for|and|or|above|below|under|by|to|from|near|over|floating)\b)[a-z]+)?)",
    re.IGNORECASE,
)
# "no people", "without buildings", "with no readable signs or text anywhere"
_NEGATIVE_RE = re.compile(r"\b(?:no|without)\s+(?P<what>[a-z][a-z \-]*?)(?=\s*(?:[,.;:!]|$|\banywhere\b))", re.IGNORECASE)
_COLOUR_WORDS = (
    "red|orange|yellow|green|blue|navy|teal|cyan|purple|violet|pink|magenta|brown|black|white|"
    "grey|gray|gold|silver|beige|cream|turquoise|maroon|olive|lime|indigo"
)
_ONLY_COLOURS_RE = re.compile(
    r"\b(?:using|in|with)\s+only\s+(?P<colours>(?:(?:light|dark|deep|pale|bright|navy)\s+)?(?:"
    + _COLOUR_WORDS
    + r")(?:\s+(?:blue|green|red))?(?:\s*(?:,|and|&)\s*(?:(?:light|dark|deep|pale|bright|navy)\s+)?(?:"
    + _COLOUR_WORDS
    + r")(?:\s+(?:blue|green|red))?)+)",
    re.IGNORECASE,
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _counts(text: str) -> list[str]:
    items = []
    for match in _COUNT_RE.finditer(text):
        n = 1 if match.group("single") else match.group("n").lower()
        n = _NUMBERS.get(n, n) if isinstance(n, str) else n
        items.append(f"Exactly {n} {match.group('noun').lower()}")
    return items


def _negatives(text: str) -> list[str]:
    found: list[str] = []
    for match in _NEGATIVE_RE.finditer(text):
        for part in re.split(r"\s+or\s+|\s+and\s+", match.group("what").strip().lower()):
            part = part.strip()
            if part and part not in found:
                found.append(part)
    return found


def _colours(text: str) -> list[str]:
    match = _ONLY_COLOURS_RE.search(text)
    if not match:
        return []
    return [c.strip().lower() for c in re.split(r"\s*(?:,|\band\b|&)\s*", match.group("colours")) if c.strip()]


def checklist(request: str) -> str:
    """The checklist for ``request``, or "" when it states no count, colour limit or negative."""
    text = " ".join(str(request or "").split())
    lines = [f"- {item}" for item in _counts(text)]
    colours = _colours(text)
    if colours:
        lines.append(f"- Use only these colours: {', '.join(colours)}")
    negatives = _negatives(text)
    if negatives:
        lines.append(f"- Must not appear anywhere: {', '.join(negatives)}")
    if not lines:
        return ""
    return "Checklist (every item must hold in the final image):\n" + "\n".join(lines)
