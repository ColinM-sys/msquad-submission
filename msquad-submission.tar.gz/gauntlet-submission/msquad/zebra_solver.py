"""Zebra-style puzzles: N people in N houses, each person has one value per attribute group.

Clues refer to people either by name ("Alice lives in house 2") or by an attribute value
("the person who owns the cat lives next to the person who drinks tea"). The solver parses every clue,
enumerates every house and attribute permutation, and answers the question only when exactly one
assignment satisfies all clues and the question has a single owner. Anything else returns None.
"""

from __future__ import annotations

import itertools
import re
import time

from msquad.logic_solver import SEARCH_BUDGET_S, _entities

_VERBS = "owns|drinks|likes|has|keeps|plays|eats|reads"
_PERSON = r"the person who (?:" + _VERBS + r") the (\w+)"
_QUESTION = re.compile(r"Who (?:" + _VERBS + r") the (\w+)\?", re.IGNORECASE)


def _clue_predicates(text: str, names: list[str], values: set[str]):
    """Return a predicate over an assignment {name: (house, {attr: value})}, or None when unparsed."""
    canon = {n.lower(): n for n in names}
    name_re = "(" + "|".join(re.escape(n) for n in sorted(names, key=len, reverse=True)) + ")"
    t = re.sub(r"\s+", " ", text).strip().rstrip(".")

    def owner(a, value):
        found = [p for p in a if value in a[p][1].values()]
        return found[0] if len(found) == 1 else None

    def value_ok(v):
        return v.lower() in values

    m = re.fullmatch(_PERSON + r" (?:lives|is) in house (\d)", t, re.IGNORECASE)
    if m and value_ok(m.group(1)):
        v, k = m.group(1).lower(), int(m.group(2))
        return lambda a: owner(a, v) is not None and a[owner(a, v)][0] == k
    m = re.fullmatch(_PERSON + r" (?:lives|is) to the (left|right) of " + _PERSON, t, re.IGNORECASE)
    if m and value_ok(m.group(1)) and value_ok(m.group(3)):
        v, side, w = m.group(1).lower(), m.group(2).lower(), m.group(3).lower()

        def left_of(a):
            p, q = owner(a, v), owner(a, w)
            if p is None or q is None:
                return False
            return a[p][0] < a[q][0] if side == "left" else a[p][0] > a[q][0]

        return left_of
    m = re.fullmatch(_PERSON + r" (does not live|lives) next to " + _PERSON, t, re.IGNORECASE)
    if m and value_ok(m.group(1)) and value_ok(m.group(3)):
        v, w, negate = m.group(1).lower(), m.group(3).lower(), m.group(2).lower().startswith("does")

        def next_to(a):
            p, q = owner(a, v), owner(a, w)
            if p is None or q is None:
                return False
            near = abs(a[p][0] - a[q][0]) == 1
            return (not near) if negate else near

        return next_to
    m = re.fullmatch(name_re + r" lives in house (\d)", t, re.IGNORECASE)
    if m:
        p, k = canon[m.group(1).lower()], int(m.group(2))
        return lambda a: a[p][0] == k
    m = re.fullmatch(name_re + r" (?:has|owns|drinks|likes|keeps|plays|eats|reads) the (\w+)", t, re.IGNORECASE)
    if m and value_ok(m.group(2)):
        p, v = canon[m.group(1).lower()], m.group(2).lower()
        return lambda a: v in a[p][1].values()
    m = re.fullmatch(name_re + r" does not (?:have|own|drink|like|keep|play|eat|read) the (\w+)", t, re.IGNORECASE)
    if m and value_ok(m.group(2)):
        p, v = canon[m.group(1).lower()], m.group(2).lower()
        return lambda a: v not in a[p][1].values()
    return None


def solve_zebra(challenge_text: str, clues: list[str]) -> str | None:
    """Return the name that owns the question's value, or None when the solver should not answer."""
    deadline = time.perf_counter() + SEARCH_BUDGET_S
    found = _entities(challenge_text)
    if found is None:
        return None
    names, groups = found
    if not groups:
        return None
    n = len(names)
    if any(len(group) != n for group in groups):
        return None
    if "name only" not in challenge_text.lower():
        return None
    question = _QUESTION.search(challenge_text)
    if question is None:
        return None
    qvalue = question.group(1).lower()
    values = {v for group in groups for v in group}
    if qvalue not in values:
        return None
    preds = []
    for clue in clues:
        pred = _clue_predicates(clue, names, values)
        if pred is None:
            return None
        preds.append(pred)
    attrs = list(range(len(groups)))
    group_perms = [list(itertools.permutations(group)) for group in groups]
    solutions: list[str] = []
    for houses in itertools.permutations(range(1, n + 1)):
        for combo in itertools.product(*group_perms):
            if time.perf_counter() > deadline:
                return None
            assign = {}
            for i, p in enumerate(names):
                assign[p] = (houses[i], {a: combo[a][i] for a in attrs})
            if all(pred(assign) for pred in preds):
                owners = [p for p in names if qvalue in assign[p][1].values()]
                solutions.append(owners[0] if len(owners) == 1 else "?")
                if len(solutions) > 1:
                    return None
    if len(solutions) != 1 or solutions[0] == "?":
        return None
    return solutions[0]
