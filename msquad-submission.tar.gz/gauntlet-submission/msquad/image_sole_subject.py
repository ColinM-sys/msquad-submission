"""Generate arm: a vehicle the request names as its subject is drawn unoccupied, with no rider.

Live image-generate, daily-300..365 (16 runs of "a futuristic electric motorcycle on a rainy neon
street ... no text"): every run judged constraints <= 70 except one (341, Latin shop text) had a
helmeted rider on the motorcycle (311: 54, 353: 57, 321: 68, 357: 70). The rider-free outputs
viewed scored 84-94, legible signage or not. The request names a vehicle and no person, so the rider
reads as an unrequested subject. This says to draw the vehicle alone.

Fires when the request names a vehicle and no person (rider, driver, pilot, person, people, man,
woman, figure, crowd, ...). Off unless MSQUAD_GENERATE_SOLE_SUBJECT=1 or DEFAULT_ENABLED is True,
so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_GENERATE_SOLE_SUBJECT"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

_VEHICLE_RE = re.compile(
    r"\b(motorcycles?|motorbikes?|bikes?|bicycles?|scooters?|cars?|trucks?|vans?|buses|bus|boats?|yachts?"
    r"|ships?|trains?|trams?|aircraft|airplanes?|planes?|jets?|helicopters?|drones?|tractors?|vehicles?)\b",
    re.IGNORECASE,
)
_PERSON_RE = re.compile(
    r"\b(riders?|riding|ridden|drivers?|driving|pilots?|passengers?|persons?|people|man|men|woman|women"
    r"|boy|girl|child|children|kids?|figures?|crowds?|someone|character|portrait|couple|family|astronaut"
    r"|\w*cyclists?|bikers?|racers?|sailors?|rowers?|captains?|crew|conductors?|tourists?|travell?ers?"
    r"|couriers?|officers?|police|commuters?|firefighters?|fighters?|workers?|mechanics?|soldiers?"
    r"|guards?|chauffeurs?|cabbies|cabby|truckers?|skippers?|deckhands?|fishers?|hikers?|joggers?"
    r"|shoppers?|pedestrians?|vendors?|owners?|students?|nurses?|doctors?|chefs?|players?|users?"
    r"|athletes?|he|she|his|her|they|their|\w+(?:man|men|woman|women|person|people))\b",
    re.IGNORECASE,
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


_VEHICLE_WORDS = _VEHICLE_RE.pattern[3:-3]  # the alternation inside \b(...)\b
# Fable on #284: the vehicle must open the request, as its subject: "Create a vintage red car ...",
# or the subject of a poster/photo/render "of a futuristic electric motorcycle". Up to four
# modifier words, never a function word (so "a courier on a scooter" does not reach "scooter").
_FUNCTION = r"(?:on|in|at|by|with|beside|near|of|from|to|into|onto|and|or|a|an|the|their|his|her)"
_MODIFIER = rf"(?:(?!{_FUNCTION}\b)[a-z][\w'-]*,?\s+){{0,4}}"
_OPENING_RE = re.compile(
    r"^\s*(?:(?:please\s+)?(?:create|generate|draw|make|render|design|paint|produce|show|illustrate)\s+)?"
    rf"(?:(?:a|an|the)\s+{_MODIFIER}(?:poster|photo(?:graph)?|image|picture|shot|render(?:ing)?|"
    rf"illustration|scene|view|close-?up|ad(?:vert)?)\s+of\s+)?"
    rf"(?:a|an|the|one)\s+{_MODIFIER}(?P<vehicle>{_VEHICLE_WORDS})\b",
    re.IGNORECASE,
)


def vehicle(request: str) -> str:
    """The vehicle ``request`` opens with as its subject, when it names no person; else ""."""
    text = " ".join(str(request or "").split())
    if _PERSON_RE.search(text):
        return ""
    match = _OPENING_RE.search(text)
    return match.group("vehicle").lower() if match else ""


def rule_for(request: str) -> str:
    """The sole-subject rule for ``request``, or "" when it does not apply."""
    name = vehicle(request)
    if not name:
        return ""
    return (
        f"Sole subject: show the {name} on its own and unoccupied, the clear hero of the frame. No rider, "
        f"driver, pilot or person on, in or beside it; any passers-by stay small, distant and out of "
        f"focus in the background."
    )
