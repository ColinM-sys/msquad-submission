"""Arm: a challenge fetch that fails for any reason other than the lobby is retried, then still submits.

The public RC4 lost the round on three fetch failures (payload fuzz, 2026-10-30):
- an error reply worded as anything but "locked" ("challenge expired");
- a body that is not a JSON object (``[]`` or ``"text"``), which raises AttributeError in the client.
Both exited 1 with no submit: the guard knew no challenge.

With this arm on:
1. The lobby wait is unchanged: "locked" / "waiting for organizer" sleeps 3 s and asks again, without limit, and
   never uses a retry.
2. Any other McpArenaError, and a body the client cannot read, is retried after 0.5, 1, 2 and 4 s (7.5 s in all).
   Not retried: a transient tool error (ResilientMcp already retried it for its budget) and a wrong-modality
   answer (not_text_challenge / not_image_challenge: the same tool cannot help, and gets no placeholder).
   A fetch attempt that does not answer in ATTEMPT_TIMEOUT_S (a server that accepts and never replies hung RC4
   for good) is dropped with its connection and retried the same way. Each lobby reply resets the count.
3. When the last retry fails, the caller marks the fetch as given up, and the deadline guard submits once: "N/A" for
   text, a blank PNG for image. A registered session with any submit scores tools and speed; none scores nothing.
Off with MSQUAD_FETCH_RESCUE=0 (the old behaviour: the first such failure is re-raised). On by default.
"""

from __future__ import annotations

import asyncio
import os
import re
import threading
from collections.abc import Awaitable, Callable
from typing import Any

ENV_FLAG = "MSQUAD_FETCH_RESCUE"
# Code default when the env var is unset.
DEFAULT_ENABLED = True

LOBBY_WAIT_S = 3.0
# Waits before each retry of a failed fetch; their sum bounds the time the rescue can spend.
RETRY_DELAYS_S = (0.5, 1.0, 2.0, 4.0)
# One fetch attempt that has not answered by then is a hung call (accepted, never answered): it is dropped,
# the connection with it, and retried like a failure. Live: 491 text fetches, p99 234 ms, max 516 ms.
ATTEMPT_TIMEOUT_S = 20.0

# Closes the MCP session so the next attempt reconnects (a half-open stream would hang again). Set once at
# setup by the agent (ResilientMcp.drop); None leaves the connection alone.
_reconnect: Callable[[], Awaitable[Any]] | None = None


def set_reconnect(reconnect: Callable[[], Awaitable[Any]] | None) -> None:
    global _reconnect
    _reconnect = reconnect


# A timed-out fetch counts toward the retries only while the round is running: a lobby that long-polls
# get_challenge (holds it until GO) would otherwise use up the retries and submit the placeholder before GO.
# Read only on the timeout path, never on the normal one. Set once at setup (phase_reader_for); None counts.
PHASE_READ_TIMEOUT_S = 3.0
RUNNING_PHASE = "running"
_phase_reader: Callable[[], Awaitable[str]] | None = None


def set_phase_reader(reader: Callable[[], Awaitable[str]] | None) -> None:
    global _phase_reader
    _phase_reader = reader


def _phase_of(payload: Any) -> str:
    return str(payload.get("phase") or "").strip().lower() if isinstance(payload, dict) else ""


def phase_reader_for(http_client: Any) -> Callable[[], Awaitable[str]]:
    """The round phase from /api/competition, else /api/health (as the kit's doctor reads it), on a daemon thread
    awaited for at most PHASE_READ_TIMEOUT_S. "" when both fail or the read does not answer in time."""

    def read() -> str:
        for name in ("get_competition", "health"):
            try:
                phase = _phase_of(getattr(http_client, name)())
            except Exception:
                continue
            if phase:
                return phase
        return ""

    async def reader() -> str:
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()

        def work() -> None:
            try:
                result = read()
            except BaseException:  # read() catches; a daemon thread must never raise into nothing
                result = ""
            try:
                loop.call_soon_threadsafe(lambda: future.done() or future.set_result(result))
            except RuntimeError:  # the loop already closed: nobody is waiting
                pass

        threading.Thread(target=work, daemon=True).start()
        done, _ = await asyncio.wait({future}, timeout=PHASE_READ_TIMEOUT_S)
        return future.result() if future in done else ""

    return reader


async def _round_running() -> bool:
    if _phase_reader is None:
        return True
    try:
        return (await _phase_reader()) == RUNNING_PHASE
    except Exception:
        return False


class FetchTimeout(TimeoutError):
    """A fetch attempt that did not answer within ATTEMPT_TIMEOUT_S."""


async def _attempt(call: Callable[[], Awaitable[Any]], timeout_s: float) -> Any:
    """``await call()`` for at most ``timeout_s``, in the caller's task: the SSE client's anyio cancel scope must be
    entered and exited in one task, so the reconnect after a timeout happens here too (as ResilientMcp._close)."""
    try:
        async with asyncio.timeout(timeout_s):
            return await call()
    except TimeoutError as exc:
        raise FetchTimeout(f"challenge fetch did not answer in {timeout_s:.0f}s") from exc
# What the client raises on a body that is not a JSON object ([] or "text"): data.get(...) on a list or str.
BAD_BODY_ERRORS = (AttributeError, TypeError, ValueError)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


WRONG_MODALITY_CODES = frozenset({"not_text_challenge", "not_image_challenge"})
# The text client raises its error without the code (mcp_client.get_challenge), so the wording is matched too.
_WRONG_MODALITY_TEXT = re.compile(r"not_(?:text|image)_challenge|(?:has|assigned) an? (?:image|text) challenge", re.IGNORECASE)


def is_wrong_modality(exc: BaseException) -> bool:
    """The server says this heat is the other modality: retrying the same tool cannot help, and a placeholder of
    the wrong kind must not be submitted for it."""
    return str(getattr(exc, "code", "") or "") in WRONG_MODALITY_CODES or bool(_WRONG_MODALITY_TEXT.search(str(exc)))


def already_retried(exc: BaseException) -> bool:
    """A transient tool error (upstream 5xx, "please retry"): ResilientMcp has already retried this read-only call
    for its whole budget, so another round here would multiply that budget, not add a few seconds."""
    from msquad import resilience  # here, not at import: resilience imports the MCP client stack

    return resilience.is_transient_tool_error(exc)


def is_lobby(exc: BaseException) -> bool:
    message = str(exc).lower()
    return "locked" in message or "waiting for organizer" in message


async def fetch(
    call: Callable[[], Awaitable[Any]],
    arena_error: type[BaseException],
    *,
    environ: dict | None = None,
    sleep: Callable[[float], Awaitable[Any]] | None = None,
) -> Any:
    """``await call()`` until it returns a challenge. The lobby waits as before; other failures retry, then raise."""
    sleep = sleep or asyncio.sleep  # looked up per call, as the inline loop's asyncio.sleep was
    retries = 0
    rescue = enabled(environ)
    while True:
        try:
            return await (_attempt(call, ATTEMPT_TIMEOUT_S) if rescue else call())
        except FetchTimeout as exc:
            counted = await _round_running()
            if counted and retries >= len(RETRY_DELAYS_S):
                raise
            if _reconnect is not None:
                try:
                    await _reconnect()
                except Exception as drop_exc:  # a failed close must not cost the retry
                    print(f"   ⚠️  Reconnect after a hung fetch failed ({drop_exc!r})")
            if not counted:
                # Lobby, or the phase is unknown: wait as RC4 did (plus a fresh connection), without using a retry.
                print("   Challenge fetch did not answer and the round is not known to be running; waiting.")
                await sleep(LOBBY_WAIT_S)
                continue
            error: BaseException = exc
        except arena_error as exc:
            if is_lobby(exc):
                # The server answered: hangs scattered through a long lobby never add up to the retry limit.
                retries = 0
                print("   Lobby open; waiting for organizer to start battle...")
                await sleep(LOBBY_WAIT_S)
                continue
            if not rescue or retries >= len(RETRY_DELAYS_S) or is_wrong_modality(exc) or already_retried(exc):
                raise
            error = exc
        except BAD_BODY_ERRORS as exc:
            if not rescue or retries >= len(RETRY_DELAYS_S):
                raise
            error = exc
        delay = RETRY_DELAYS_S[retries]
        retries += 1
        print(f"   ⚠️  Challenge fetch failed ({error!r}); retry {retries}/{len(RETRY_DELAYS_S)} in {delay:.1f}s")
        await sleep(delay)
