"""Deadline budget for one challenge run.

Tracks time left from the challenge limit (or the server's
``arena.time_remaining``), gives each LLM call a timeout that leaves a margin
for the submit round trip, and keeps the best draft so a late or empty model
result still submits a valid-format answer.
"""

from __future__ import annotations

import json
import random
import re
import time
from dataclasses import dataclass, field

# Seconds reserved for the submit round trip and bookkeeping.
SUBMIT_MARGIN_S = 8.0
# Smallest LLM timeout worth starting; below this we fall back instead.
MIN_LLM_TIMEOUT_S = 3.0
# Retry with another model only if this much is left after the first attempt.
RETRY_MIN_REMAINING_S = 30.0
# Pre-LLM tool calls (search, fetch) may use at most this share of the time left...
TOOL_TIME_SHARE = 0.35
# ...and always leave this much for one LLM answer.
LLM_ANSWER_RESERVE_S = 10.0
# One pre-LLM tool call never waits longer than this.
TOOL_CALL_CAP_S = 6.0
# Hard guard: nothing starts after this share of the challenge limit, so the
# best answer so far is submitted with room to spare.
GUARD_FRACTION = 0.85

def call_with_one_retry(make_call, budget, should_retry, *, sleep=time.sleep, jitter=random.uniform):
    """Run ``make_call``; on a retryable error, retry once after a short jitter.

    Only when ``should_retry(exc)`` holds and more than the submit margin plus
    5 s is left. Otherwise the error propagates and the caller falls back.
    """
    try:
        return make_call()
    except Exception as exc:
        if not should_retry(exc) or budget is None or budget.remaining() <= budget.margin_s + 5:
            raise
        sleep(jitter(0.5, 1.5))
        return make_call()


_COUNT_WORDS = frozenset({"One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                       "Eleven", "Twelve", "Twenty", "Hundred", "Thousand"})
_NAME_RE = re.compile(r"\b[A-Z][a-zA-Z'\-]+(?:\s+[A-Z][a-zA-Z'\-]+)*\b")


@dataclass
class Budget:
    """Time budget for one challenge. ``time_limit_s`` is the challenge limit."""

    time_limit_s: float
    margin_s: float = SUBMIT_MARGIN_S
    started_at: float = field(default_factory=time.monotonic)
    server_remaining_s: float | None = None
    server_seen_at: float = 0.0
    best_draft: str = ""

    def update_server_remaining(self, remaining_s: float) -> None:
        """Record ``arena.time_remaining`` so local clock drift does not matter.

        A missing or zero reading is not a real zero: it would make every call
        time out at once. Keep the challenge-limit clock instead.
        """
        if remaining_s is None or float(remaining_s) <= 0:
            return
        self.server_remaining_s = float(remaining_s)
        self.server_seen_at = time.monotonic()

    def remaining(self) -> float:
        """Seconds left before the hard guard: the earlier of the limit and GUARD_FRACTION of it.

        Uses the server reading when we have one, else the local clock. The guard
        applies either way, so the last LLM call and the submit both finish inside
        the guard.
        """
        elapsed = time.monotonic() - self.started_at
        guard_left = self.time_limit_s * GUARD_FRACTION - elapsed
        if self.server_remaining_s is not None:
            elapsed_since_read = time.monotonic() - self.server_seen_at
            left = self.server_remaining_s - elapsed_since_read
        else:
            left = self.time_limit_s - elapsed
        return max(0.0, min(left, guard_left))

    def deadline_left(self) -> float:
        """Seconds left to the challenge limit itself (no guard): the bound for submit retries."""
        if self.server_remaining_s is not None:
            left = self.server_remaining_s - (time.monotonic() - self.server_seen_at)
        else:
            left = self.time_limit_s - (time.monotonic() - self.started_at)
        return max(0.0, left)

    def llm_timeout(self, cap_s: float | None = None) -> float:
        """Timeout for one LLM call: remaining time minus the submit margin."""
        budget = self.remaining() - self.margin_s
        if cap_s is not None:
            budget = min(budget, cap_s)
        return max(MIN_LLM_TIMEOUT_S, budget) if budget >= MIN_LLM_TIMEOUT_S else 0.0

    def tool_stage_s(self) -> float:
        """Seconds the pre-LLM tool stage may use: a share of what is left, never into the LLM reserve."""
        remaining = self.remaining()
        reserve = LLM_ANSWER_RESERVE_S + self.margin_s
        share = TOOL_TIME_SHARE * remaining
        return max(0.0, min(share, remaining - reserve))

    def tool_call_timeout(self, stage_left_s: float) -> float:
        """Timeout for one tool call: the stage time left, capped per call."""
        return max(0.0, min(TOOL_CALL_CAP_S, stage_left_s))

    def can_retry(self) -> bool:
        """True when another model attempt still has time to answer and submit."""
        return self.remaining() - self.margin_s >= RETRY_MIN_REMAINING_S

    def set_draft(self, answer: str) -> None:
        """Keep the best valid answer seen so far."""
        if answer and answer.strip():
            self.best_draft = answer.strip()

    def should_submit_early(self, answer: str, ctx=None) -> bool:
        """True once the submit margin is reached: send the best answer now."""
        _ = answer, ctx
        return self.remaining() <= self.margin_s

    def on_time_warning(self, remaining_s: float, current_answer: str, ctx=None) -> str | None:
        """Final answer near the deadline: prefer a real answer, then the draft, then a fallback."""
        _ = remaining_s, ctx
        if current_answer and current_answer.strip():
            return current_answer.strip()
        return self.best_draft or None


_MONTHS = {
    name: index
    for index, name in enumerate(
        ["January", "February", "March", "April", "May", "June", "July", "August",
         "September", "October", "November", "December"], start=1)
}
_MONTH_WORDS = frozenset(_MONTHS) | frozenset(
    {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"})
_ISO_DATE_RE = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")
_DAY_MONTH_YEAR_RE = re.compile(
    r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?(" + "|".join(_MONTHS) + r"),?\s+(\d{4})\b")
_MONTH_DAY_YEAR_RE = re.compile(
    r"\b(" + "|".join(_MONTHS) + r")\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b")


def _first_iso_date(sources: list[str]) -> str:
    """The first date the clues state, as YYYY-MM-DD; '' when none is stated."""
    for text in sources:
        iso = _ISO_DATE_RE.search(text or "")
        if iso:
            return iso.group(0)
        dmy = _DAY_MONTH_YEAR_RE.search(text or "")
        if dmy:
            return f"{dmy.group(3)}-{_MONTHS[dmy.group(2)]:02d}-{int(dmy.group(1)):02d}"
        mdy = _MONTH_DAY_YEAR_RE.search(text or "")
        if mdy:
            return f"{mdy.group(3)}-{_MONTHS[mdy.group(1)]:02d}-{int(mdy.group(2)):02d}"
    return ""


_NON_NAME_OPENERS = frozenset({
    "The", "A", "An", "In", "On", "At", "By", "For", "From", "If", "When", "While", "Each", "Every",
    "This", "That", "These", "Those", "It", "There", "Here", "Then", "So", "But", "And", "Or", "Not",
    "No", "Yes", "Both", "Either", "Neither", "Since", "After", "Before", "Once", "Also", "Only",
    "Exactly", "Next", "Last", "First", "Finalists", "Winners", "Members", "Players", "Teams",
    "Candidates", "Participants", "Names", "Answer", "Order", "Result", "Note",
})


_LABEL_WORD_RE = re.compile(r"\b[A-Z][a-zA-Z'\-]+(?=\s*:)")


def _roster(description: str) -> list[str]:
    """The names the challenge text lists ("6 people (Alpha, Foxtrot, ...)"), or [] when it lists none."""
    from msquad.logic_solver import _entities

    found = _entities(description or "")
    return list(found[0]) if found else []


def _list_names(sources: list[str]) -> list[str]:
    """Capitalised names from the clues, skipping each sentence's first word and month/count words."""
    names: list[str] = []
    for text in sources:
        for sentence in re.split(r"[.!?]+", text or ""):
            # A capitalised word followed by a colon is a label ("Finalists: Chloe, ..."), not a name.
            sentence = _LABEL_WORD_RE.sub(" ", sentence)
            matches = _NAME_RE.findall(sentence)
            words = sentence.strip().split()
            if words and matches and matches[0].split()[0] == words[0] and words[0] in _NON_NAME_OPENERS:
                # The sentence opener is not a name: drop it, keeping any name after it.
                rest = matches[0][len(words[0]):].strip()
                matches = ([rest] if rest else []) + matches[1:]
            for match in matches:
                if match in _COUNT_WORDS or match in _MONTH_WORDS or match in names:
                    continue
                names.append(match)
    return names


def _placeholder_for(schema: dict):
    """A minimal value of the schema's shape: [] for arrays, required keys only for objects."""
    kind = schema.get("type")
    if kind == "array":
        return []
    if kind == "object":
        properties = schema.get("properties", {})
        return {key: _placeholder_for(properties.get(key, {})) for key in schema.get("required", [])}
    return {"integer": 0, "number": 0, "boolean": False, "null": None}.get(kind, "")


_NUMBER_RE = re.compile(r"-?\d+(?:\.\d+)?")
_NUMERIC_RULE_RE = re.compile(r"\b(?:number|numeric|integer|whole number|digits?)\b")


def _wants_number(challenge_type: str, lowered_rules: str) -> bool:
    """True for a math challenge, or rules that ask for a number."""
    if "math" in (challenge_type or "").lower():
        return True
    # Rules that ask for names or dates keep their own fallback even if they mention a number.
    if "name" in lowered_rules or "date" in lowered_rules:
        return False
    return bool(_NUMERIC_RULE_RE.search(lowered_rules))


def fallback_answer(challenge_type: str, clues: list[str], description: str = "", rules: str = "") -> str:
    """A well-formed answer with no model call, built from the clues or else the challenge text.

    Text: the capitalised names from the clues (or, with no clues, from the
    challenge text), in order. Structured (JSON) rules get an empty JSON object
    so the answer at least parses. Image: a plain prompt (the caller submits it).
    """
    if "image" in (challenge_type or "").lower():
        return (description or "A simple clean illustration").strip()[:300]
    if "json" in (rules or "").lower():
        # Schema-shaped and valid when the challenge states its shape: [] for an array,
        # or an object holding only the required keys. Otherwise an empty object.
        from base_strategy import _schema_from_text

        schema = _schema_from_text(rules or "")
        if schema:
            return json.dumps(_placeholder_for(schema), ensure_ascii=False, separators=(",", ":"))
        return "{}"
    sources = clues if any((c or "").strip() for c in clues) else [description or ""]
    lowered = (rules or "").lower()
    if _wants_number(challenge_type, lowered):
        # A numeric question never gets a list of clue words ("Ava, Each" was submitted for a
        # math puzzle): the last number the challenge states, else 0.
        numbers = _NUMBER_RE.findall(" ".join([description or "", *[c or "" for c in clues]]))
        return numbers[-1] if numbers else "0"
    if "date" in lowered or "yyyy-mm-dd" in lowered:
        # A date format gets a date the clues state, never a list of words.
        return _first_iso_date(sources) or "N/A"
    if "name" in lowered or "comma" in lowered:
        # A list of names: capitalised names only, not sentence openers or month words.
        listed = _list_names(sources)
        roster = _roster(description)
        if roster:
            # The challenge lists its people: a distractor's outsider ("Delta") never enters the
            # guess, and every roster name appears once, in clue order and then roster order.
            listed = [name for name in listed if name in roster]
            listed += [name for name in roster if name not in listed]
        if listed:
            return ", ".join(listed)
    names: list[str] = []
    for clue in sources:
        for match in _NAME_RE.findall(clue or ""):
            if match in _COUNT_WORDS:
                continue
            if match not in names:
                names.append(match)
    # Bare answer only: the submit path must never send a label such as "ANSWER:".
    if names:
        return ", ".join(names)
    first = next((c.strip() for c in sources if (c or "").strip()), "")
    return first[:200] if first else "N/A"
