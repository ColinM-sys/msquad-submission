"""Text arm: keep the output contract only in the user prompt to save tokens.

Off by default so removing the duplicate system-level instruction can be A/B tested.
The user prompt retains the full contract, including for the strict retry.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_OUTPUT_CONTRACT_DEDUP"
DEFAULT_ENABLED = True


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}
