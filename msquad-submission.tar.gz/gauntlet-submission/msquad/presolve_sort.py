"""Sort arm: a deterministic answer for "order these records by key(s)" questions.

The records come from the question or its clues and documents: a JSON array of objects, a pipe table or a CSV
block with a header row. The instruction names one or more sort keys, each a column of the records, each with an
explicit direction ("descending", "lowest first", "A to Z", "newest first"); a later key ("then by", "ties
broken by") orders ties. The answer format must say what to return: a JSON array of the label column or of objects
with named fields, a comma-separated list, or one per line.

Precision first: the arm declines (None, so the model answers) when anything is unread or ambiguous. That is a
key without a direction, a direction word that does not fit the key's type ("oldest" on a number), a key column
that is neither all numbers, all ISO dates nor all text without digits, records that still tie after every key,
more than one record set, or a digit or a record value left in the instruction (a filter it does not understand).
Ordering-from-clues logic puzzles state no record set, so they never fire.
Off unless MSQUAD_PRESOLVE_SORT=1 or DEFAULT_ENABLED is True, so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import json
import os
import re
from datetime import date

ENV_FLAG = "MSQUAD_PRESOLVE_SORT"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

MAX_RECORDS = 500
_WORD_NUMBERS = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}

_NUMBER_RE = re.compile(r"[-+]?[$€£]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?%?")
_DATE_RE = re.compile(r"(\d{4})-(\d{2})-(\d{2})")
_SORT_VERB_RE = re.compile(r"\b(?:sort|sorted|sorting|order|ordered|ordering|rank|ranked|ranking|arrange|arranged)\b",
                           re.IGNORECASE)
_TIE_RE = re.compile(r"\bties?\b", re.IGNORECASE)
_TOP_RE = re.compile(r"\b(?:top|first)\s+(\d{1,3}|" + "|".join(_WORD_NUMBERS) + r")\b", re.IGNORECASE)
# Words that narrow or reshape the record set: the arm does not read filters, so it declines.
_FILTER_RE = re.compile(
    r"\b(?:only|except|excluding|exclude|without|where|whose|unless|above|below|over|under|more than|less than|"
    r"at least|at most|between|bottom|last|second|third|sum|total|average|count|how many|which one)\b",
    re.IGNORECASE,
)
# (pattern, direction, the key types it fits). "Oldest first" on an age column would be descending, so the
# date words only apply to dates.
_DIRECTIONS = (
    (r"\b(?:desc|descending|decreasing)\b", "desc", {"number", "date", "text"}),
    (r"\b(?:asc|ascending|increasing)\b", "asc", {"number", "date", "text"}),
    (r"\b(?:highest|largest|biggest|greatest|most)\s+(?:first|to\s+(?:the\s+)?(?:lowest|smallest|least))\b",
     "desc", {"number"}),
    (r"\b(?:lowest|smallest|least|fewest)\s+(?:first|to\s+(?:the\s+)?(?:highest|largest|greatest|most))\b",
     "asc", {"number"}),
    (r"\b(?:high|large|big)\s+to\s+(?:low|small)\b", "desc", {"number"}),
    (r"\b(?:low|small)\s+to\s+(?:high|large|big)\b", "asc", {"number"}),
    (r"\b(?:newest|latest|most\s+recent)\s+(?:first|to\s+(?:the\s+)?(?:oldest|earliest))\b", "desc", {"date"}),
    (r"\b(?:oldest|earliest)\s+(?:first|to\s+(?:the\s+)?(?:newest|latest|most\s+recent))\b", "asc", {"date"}),
    (r"\breverse\s+(?:alphabetical|alphabetically)\b|\bz\s*(?:to|-)\s*a\b", "desc", {"text"}),
    (r"(?<!reverse )\b(?:alphabetical|alphabetically)\b|\ba\s*(?:to|-)\s*z\b", "asc", {"text"}),
)
_DIRECTION_RES = tuple((re.compile(p, re.IGNORECASE), d, types) for p, d, types in _DIRECTIONS)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _norm(name: str) -> str:
    return " ".join(re.sub(r"[_\-]+", " ", str(name)).lower().split())


# ---- records ---------------------------------------------------------------------------------------------------

def _json_arrays(text: str) -> list[tuple[int, int, list[dict]]]:
    """Every top-level JSON array of uniform objects in ``text``, as (start, end, records)."""
    found, i = [], 0
    while True:
        start = text.find("[", i)
        if start < 0:
            return found
        try:
            value, end = json.JSONDecoder().raw_decode(text, start)
        except ValueError:
            i = start + 1
            continue
        if (isinstance(value, list) and len(value) >= 2 and all(isinstance(v, dict) and v for v in value)
                and all(set(v) == set(value[0]) for v in value)
                and all(not isinstance(x, (dict, list)) for v in value for x in v.values())):
            found.append((start, end, [{str(k): v for k, v in r.items()} for r in value]))
        i = end


def _cells(line: str) -> list[str]:
    return [c.strip() for c in line.strip().strip("|").split("|")]


def _pipe_tables(text: str) -> list[tuple[int, int, list[dict]]]:
    found = []
    lines = text.splitlines(keepends=True)
    pos, offsets = 0, []
    for line in lines:
        offsets.append(pos)
        pos += len(line)
    i = 0
    while i < len(lines):
        if lines[i].count("|") < 2:
            i += 1
            continue
        j = i
        while j < len(lines) and lines[j].count("|") >= 2:
            j += 1
        block = [ln for ln in lines[i:j] if not re.fullmatch(r"\s*\|?[\s:\-|]+\|?\s*", ln)]
        header = _cells(block[0])
        rows = [_cells(ln) for ln in block[1:]]
        if (len(rows) >= 2 and len(set(map(_norm, header))) == len(header) and all(header)
                and all(len(r) == len(header) for r in rows)):
            found.append((offsets[i], offsets[j - 1] + len(lines[j - 1]), [dict(zip(header, r)) for r in rows]))
        i = j
    return found


def _csv_blocks(text: str) -> list[tuple[int, int, list[dict]]]:
    """A header line of identifier words and at least two rows with the same comma count."""
    found = []
    lines = text.splitlines(keepends=True)
    pos, offsets = 0, []
    for line in lines:
        offsets.append(pos)
        pos += len(line)
    i = 0
    while i < len(lines):
        header = [c.strip() for c in lines[i].split(",")]
        if len(header) < 2 or not all(re.fullmatch(r"[A-Za-z][A-Za-z_ ]{0,30}", c) for c in header):
            i += 1
            continue
        j = i + 1
        while j < len(lines) and lines[j].strip() and len(lines[j].split(",")) == len(header):
            j += 1
        rows = [[c.strip() for c in ln.split(",")] for ln in lines[i + 1:j]]
        ends_clean = j == len(lines) or not lines[j].strip()  # a malformed row voids the block, never truncates it
        if ends_clean and len(rows) >= 2 and all(all(c and len(c) <= 60 for c in r) for r in rows):
            found.append((offsets[i], offsets[j - 1] + len(lines[j - 1]), [dict(zip(header, r)) for r in rows]))
            i = j
        else:
            i += 1
    return found


def _record_sets(text: str) -> list[tuple[int, int, list[dict]]]:
    sets = _json_arrays(text)
    for extra in (_pipe_tables(text), _csv_blocks(text)):
        sets += [s for s in extra if not any(s[0] < e and b < s[1] for b, e, _ in sets)]
    return sets


# ---- keys ------------------------------------------------------------------------------------------------------

def _number(value) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not _NUMBER_RE.fullmatch(text):
        return None
    return float(re.sub(r"[$€£,%+]", "", text))


def _date(value) -> date | None:
    match = _DATE_RE.fullmatch(str(value).strip())
    if not match:
        return None
    try:
        return date(*map(int, match.groups()))
    except ValueError:
        return None


def _column_type(values: list) -> str | None:
    if all(_number(v) is not None for v in values):
        return "number"
    if all(_date(v) is not None for v in values):
        return "date"
    if all(isinstance(v, str) and v.strip() and not re.search(r"\d", v) for v in values):
        return "text"
    return None


def _sort_value(value, kind: str):
    if kind == "number":
        return _number(value)
    if kind == "date":
        return _date(value)
    return str(value).strip().casefold()


def _mentions(text: str, column: str) -> list[re.Match]:
    words = _norm(column).split()
    if not words:
        return []
    pattern = r"\b" + r"[\s_\-]+".join(map(re.escape, words[:-1] + [words[-1]])) + r"(?:s|es)?\b"
    return list(re.finditer(pattern, text, re.IGNORECASE))


def _keys(instruction: str, columns: list[str], kinds: dict[str, str | None]) -> list[tuple[str, str]] | None:
    """[(column, direction)] in priority order, or None when a key or its direction is not explicit."""
    def hits_in(clause: str) -> list[tuple[str, re.Match]]:
        return [(col, m) for col in columns for m in _mentions(clause, col)
                if re.search(r"\b(?:by|of|on)\s+(?:the\s+|their\s+|its\s+)?$", clause[:m.start()], re.IGNORECASE)]

    # "by score, highest first, then by name A to Z": a fragment that names no key ("highest first") belongs to
    # the key clause before it.
    clauses: list[str] = []
    for piece in re.split(r"[;.,]|(?=\bthen\b)|(?=\bties?\b)", instruction):
        if hits_in(piece) or not clauses:
            clauses.append(piece)
        else:
            clauses[-1] += " " + piece
    primary, ties = [], []
    for clause in clauses:
        hits = hits_in(clause)
        if not hits or not (_SORT_VERB_RE.search(clause) or _TIE_RE.search(clause)
                            or re.search(r"\bthen\b", clause, re.IGNORECASE)):
            continue  # "a list of names" names a column but sorts nothing
        if len({col for col, _ in hits}) != 1:
            return None
        column = hits[0][0]
        kind = kinds.get(column)
        directions = {d for rx, d, types in _DIRECTION_RES if rx.search(clause) and kind in types}
        wrong_type = any(rx.search(clause) and kind not in types for rx, _, types in _DIRECTION_RES)
        if kind is None or len(directions) != 1 or wrong_type:
            return None
        (ties if _TIE_RE.search(clause) else primary).append((column, directions.pop()))
    keys = primary + ties
    if not keys or len({c for c, _ in keys}) != len(keys):
        return None
    return keys


# ---- output ----------------------------------------------------------------------------------------------------

def _schema_fields(text: str) -> list[tuple[str, str]] | None:
    """(field, type) of an array-of-objects schema written in the answer format or rules."""
    for start in [m.start() for m in re.finditer(r"\{", text)]:
        try:
            value, _ = json.JSONDecoder().raw_decode(text, start)
        except ValueError:
            continue
        if isinstance(value, dict) and value.get("type") == "array" and isinstance(value.get("items"), dict):
            props = value["items"].get("properties")
            if isinstance(props, dict) and props:
                return [(k, str((v or {}).get("type", "string"))) for k, v in props.items()]
    return None


def _field_value(record: dict, column: str, kind: str | None):
    value = record[column]
    if not isinstance(value, str):
        return value
    if kind in ("integer", "number"):
        number = _number(value)
        if number is None:
            raise ValueError(value)
        return int(number) if kind == "integer" or number.is_integer() else number
    return value


def _format_fields(fmt: str, columns: list[str], kinds: dict[str, str | None]) -> list[tuple[str, str, str | None]]:
    """(column, key as the format spells it, JSON type) for "objects with keys name and age", or [] when the
    format lists no keys or a key that is not a column."""
    listed = re.search(r"\b(?:with|having|containing)\s+(?:the\s+)?(?:keys?|fields?|properties)?\s*:?\s*(.+)$", fmt,
                       re.IGNORECASE | re.DOTALL)
    if not listed:
        return []
    names = [n.strip(" .`'\"") for n in re.split(r",|\band\b", re.split(r"[;(]|\bsorted\b|\bordered\b", listed.group(1))[0])]
    names = [n for n in names if n]
    by_norm = {_norm(c): c for c in columns}
    if not names or any(_norm(n) not in by_norm for n in names):
        return []
    as_json = {"number": "number", "date": None, "text": None}
    return [(by_norm[_norm(n)], n, as_json.get(kinds.get(by_norm[_norm(n)]) or "")) for n in names]


def _render(ordered: list[dict], columns: list[str], keys: list[tuple[str, str]], fmt: str, instruction: str,
            schema: list[tuple[str, str]] | None, kinds: dict[str, str | None]) -> str | None:
    lowered = fmt.lower()
    key_cols = {c for c, _ in keys}
    by_norm = {_norm(c): c for c in columns}
    if "json" in lowered and "object" in lowered or schema:
        if schema:
            if any(_norm(f) not in by_norm for f, _ in schema):
                return None
            fields = [(by_norm[_norm(f)], f, t) for f, t in schema]
        else:
            fields = _format_fields(fmt, columns, kinds)
            if not fields:
                return None
        try:
            out = [{name: _field_value(r, col, kind) for col, name, kind in fields} for r in ordered]
        except ValueError:
            return None
        return json.dumps(out, ensure_ascii=False, separators=(",", ":"))
    # The column the answer format names; else the one non-key column the instruction names.
    labels = {c for c in columns if _mentions(fmt, c)}
    if not labels:
        labels = {c for c in columns if c not in key_cols and _mentions(instruction, c)}
    if len(labels) != 1:
        return None
    label = labels.pop()
    values = [str(r[label]).strip() for r in ordered]
    if "json" in lowered and ("array" in lowered or "list" in lowered):
        return json.dumps(values, ensure_ascii=False, separators=(",", ":"))
    if re.search(r"\bcomma[\s-]*separated\b|\bcomma\b", lowered):
        return ", ".join(values)
    if re.search(r"\bone per line\b|\bnewline|\beach on its own line\b|\bone (?:\w+ )?per line\b", lowered):
        return "\n".join(values)
    return None


# ---- solve -----------------------------------------------------------------------------------------------------

def _strings(value) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        return [s for v in value.values() for s in _strings(v)]
    if isinstance(value, list):
        return [s for v in value for s in _strings(v)]
    return []


def _source_texts(source: str) -> list[str]:
    """A clue as it is, or a rendered tool result ("docs.get: {...}"): the JSON's own string fields, where a
    document's table sits with its newlines escaped."""
    text = str(source or "")
    tool = re.match(r"[a-z_]+\.[\w.]+:\s*", text)  # "docs.search: ", "arena.get_challenge: "
    if not tool:
        return [text]
    body = text[tool.end():]
    try:
        value = json.loads(body)
    except ValueError:
        return [body]
    # The result's own JSON (a hit list, ids, scores) is never a record set: only the strings inside it are.
    # Every string, prose included: a one-line correction in a document is read by _revised_elsewhere.
    return [s for s in _strings(value) if s.strip()]


_REVISION_RE = re.compile(
    r"\b(?:revised|revise|revises|revision|corrected|correction|corrects|updated|update|updates|replaces|replaced|"
    r"replacing|supersedes|superseded|amended|amends|amendment|changed\s+to|now|instead\s+of)\b",
    re.IGNORECASE,
)


def _revised_elsewhere(sources: list[str], records: list[dict], key_columns: list[str]) -> bool:
    """A clue or document sentence outside the record set that names a record together with a revision word ("the
    Dalby bid was revised to 4500"): the table's own figure may be stale, so the model reads the correction. A bare
    mention, or a revision word in a sentence that names no record ("figures are updated weekly"), does not count.
    A revision word beside a sort key's own field ("all bids above were later revised", "scores were corrected")
    counts too: every value of that key may be stale. The question text is not a source here."""
    key = json.dumps(records, sort_keys=True, default=str)
    names = {str(v).strip().casefold() for r in records for v in r.values()
             if isinstance(v, str) and len(v.strip()) > 2 and _number(v) is None and _date(v) is None}
    fields = [c for c in key_columns if _norm(c)]
    if not names and not fields:
        return False
    for text in sources:
        # the record set itself, wherever it repeats (a docs.get after a docs.search hit), is not a correction
        for start, end, recs in sorted(_record_sets(text), key=lambda s: -s[0]):
            if json.dumps(recs, sort_keys=True, default=str) == key:
                text = text[:start] + "\n" + text[end:]
        for sentence in re.split(r"(?<=[.;!?])\s+|\n+", text):
            if _REVISION_RE.search(sentence) and (
                    any(re.search(r"(?<!\w)" + re.escape(n) + r"(?!\w)", sentence, re.IGNORECASE) for n in names)
                    or any(_mentions(sentence, c) for c in fields)):
                return True
    return False


def presolve_sort(description: str, rules: str = "", answer_format: str = "", sources: list[str] | None = None
                  ) -> str | None:
    """The sorted answer when the question is a fully explicit sort of one record set, else None."""
    question = f"{description or ''}\n{rules or ''}"
    texts = [question] + [t for s in (sources or []) for t in _source_texts(s)]
    found, seen = [], set()
    for t in texts:
        for s in _record_sets(t):
            key = json.dumps(s[2], sort_keys=True, default=str)
            if key not in seen:  # the same document from a search hit and a get is one record set
                seen.add(key)
                found.append((t, s))
    if len(found) != 1:
        return None
    text, (start, end, records) = found[0]
    if len(records) > MAX_RECORDS:
        return None
    instruction = question.replace(text[start:end], " ") if text is question else question
    instruction = f"{instruction}\n{answer_format or ''}"
    if not _SORT_VERB_RE.search(instruction) or _FILTER_RE.search(instruction):
        return None
    limit = None
    top = _TOP_RE.search(instruction)
    if top:
        word = top.group(1).lower()
        limit = int(word) if word.isdigit() else _WORD_NUMBERS[word]
        instruction_digits = instruction[:top.start()] + instruction[top.end():]
    else:
        instruction_digits = instruction
    schema = _schema_fields(f"{answer_format or ''}\n{rules or ''}")
    if schema is not None:
        instruction_digits = re.sub(r"\{.*\}", " ", instruction_digits, flags=re.DOTALL)
    if re.search(r"\d", instruction_digits):
        return None
    columns = list(records[0])
    cells = {str(v).strip().casefold() for r in records for v in r.values() if isinstance(v, str) and len(v) > 2}
    words = re.findall(r"[^\W\d_][\w'\-]*", instruction_digits.casefold())
    phrase = " ".join(words)
    if any(c in cells or (" " in c and c in phrase) for c in set(words)) or any(
            " " in c and re.search(r"\b" + re.escape(c) + r"\b", phrase) for c in cells):
        return None
    kinds = {c: _column_type([r[c] for r in records]) for c in columns}
    keys = _keys(instruction, columns, kinds)
    if not keys or _revised_elsewhere(texts[1:], records, [c for c, _ in keys]):
        return None
    tuples = [tuple(_sort_value(r[c], kinds[c]) for c, _ in keys) for r in records]
    order = list(range(len(records)))
    for index in range(len(keys) - 1, -1, -1):  # stable sort, last key first
        order.sort(key=lambda i: tuples[i][index], reverse=keys[index][1] == "desc")
    if limit is not None and not 1 <= limit <= len(order):
        return None
    shown = len(order) if limit is None else limit
    # Still tied after every key, inside the answer or across a top-N cut: the order would be a guess.
    if any(tuples[order[i]] == tuples[order[i + 1]] for i in range(min(shown, len(order) - 1))):
        return None
    ordered = [records[i] for i in order[:shown]]
    return _render(ordered, columns, keys, answer_format or "", instruction, schema, kinds)


def presolve_sort_challenge(challenge_type: str, description: str, rules: str = "", answer_format: str = "",
                            sources: list[str] | None = None) -> str | None:
    """presolve_sort for text challenges; image challenges go to the image path."""
    if "image" in str(challenge_type or "").casefold():
        return None
    try:
        return presolve_sort(description or "", rules or "", answer_format or "", sources)
    except Exception:
        return None
