"""Msquad helpers: logic-puzzle solver and translate path, plus live-event resilience hooks."""
