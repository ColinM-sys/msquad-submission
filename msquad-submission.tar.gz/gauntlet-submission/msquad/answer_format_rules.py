"""Arm: include any non-empty answer format in the solver rules (spec G)."""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_ANSWER_FORMAT_RULES"
DEFAULT_ENABLED = True


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def solve_rules_for(rules: str, answer_format: str) -> str:
    """Append the answer format only when it is non-empty and absent from the rules."""
    if answer_format and answer_format not in rules:
        return f"{rules}\nAnswer format: {answer_format}".strip()
    return rules
