"""Retrieval answers must come from the fetched documents, not from unrelated clues.

Hard-mode retrieval puzzles carry distractor clues from other puzzle types ("Hotel is somewhere
ahead of Alpha", "The race was held on a Saturday morning in June"). The model sometimes answered
from them ("Hotel,Alpha,Saturday,June") although the documents plainly held the answer
("88-17: supplier Orenco Metals"). An answer whose every item is a clue word and none of which
appears in any document is re-asked once from the documents alone; the re-ask is used only when
its answer does appear in a document, so a computed answer (24 + 12 = 36) is never touched.
"""

from __future__ import annotations

import json
import re
import unicodedata
from typing import Any

_DOC_TOOL_RE = re.compile(r"^\s*(?:docs\.\w+|search\.\w+|web\.\w+|web_search|retrieval\.\w+)\s*:\s*(\{.*)$", re.S)


def document_texts(evidence_lines: list[str]) -> list[str]:
    """The document texts in tool evidence lines ("docs.search: {...}", "docs.get: {...}")."""
    texts: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            text = value.get("text")
            if isinstance(text, str) and text.strip():
                texts.append(text)
            for item in value.values():
                if isinstance(item, (dict, list)):
                    walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)

    for line in evidence_lines or []:
        match = _DOC_TOOL_RE.match(str(line or ""))
        if not match:
            continue
        try:
            walk(json.loads(match.group(1)))
        except ValueError:
            continue
    return texts


def _items(answer: str) -> list[str]:
    return [item.strip() for item in str(answer or "").split(",") if item.strip()]


def _norm(text: str) -> str:
    """Casefolded, accents stripped (NFKD), with . , - removed and spaces collapsed.

    "Dr. Okafor" and "Dr Okafor", "José" and "Jose" must match (Fable on #270): a missed match
    on a correct answer would re-ask and could swap it for a different document entity.
    """
    decomposed = unicodedata.normalize("NFKD", str(text or ""))
    plain = "".join(ch for ch in decomposed if not unicodedata.combining(ch)).casefold()
    plain = re.sub(r"[.,\-]", " ", plain)
    return " ".join(plain.split())


def _found(item: str, texts: list[str]) -> bool:
    needle = _norm(item)
    return bool(needle) and any(needle in _norm(text) for text in texts)


def is_grounded(answer: str, documents: list[str]) -> bool:
    """True when the answer (or one of its comma items) appears in a document text."""
    return any(_found(item, documents) for item in _items(answer))


def clue_built_ungrounded(answer: str, documents: list[str], clues: list[str]) -> bool:
    """True for an answer made only of clue words that appears in no document."""
    items = _items(answer)
    if not items or not documents or is_grounded(answer, documents):
        return False
    return all(_found(item, list(clues or [])) for item in items)


def reask_prompt(question: str, rules: str, documents: list[str]) -> str:
    docs = "\n".join(f"- {text}" for text in documents)[:6000]
    return (
        f"Question: {question}\n"
        f"Answer format: {rules or 'the bare answer'}\n"
        f"Documents:\n{docs}\n"
        "Answer only from these documents. Any other clues you saw may be unrelated to this "
        "question; ignore them. Reply with one line: ANSWER: <answer>"
    )
