"""Arm: on a text heat, fetch the challenge as soon as the modality says text and read the clues early.

The scored window runs from register return to the submit (live audit: elapsed_ms = submit start -
register return + ~110 ms). A text heat then fetched the challenge (~0.1 s) and only afterwards, past the
model list and the reporter start, began the clue reads (~0.5 s). With this arm on, once the modality
resolves to text the fetch starts at once, and the clue reads start the moment it returns a text
challenge; the text path awaits both, so the calls are exactly the serial ones, only earlier. Nothing
starts before the modality is known, so an image heat's calls never change: the image path fetches with
one raw call and the text path with retries, and an early fetch could not match both on failure (Fable on
#424). Off unless MSQUAD_EARLY_CHALLENGE=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import asyncio
import os
from typing import Any, Awaitable, Callable

ENV_FLAG = "MSQUAD_EARLY_CHALLENGE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def is_text_challenge(challenge: Any) -> bool:
    """True when a fetched challenge is a text heat (its type names no image task)."""
    kind = str(getattr(challenge, "challenge_type", "") or "").strip().lower()
    return bool(kind) and "image" not in kind


def start(get_challenge: Callable[[], Awaitable[Any]], read_clues: Callable[[], Awaitable[Any]]):
    """(challenge future, clues future). The clues future yields None, without calling, unless the
    challenge proves a text heat; a failed fetch also yields None (the serial path then decides)."""
    challenge_task = asyncio.ensure_future(get_challenge())

    async def _clues_if_text():
        try:
            challenge = await asyncio.shield(challenge_task)
        except Exception:
            return None
        if not is_text_challenge(challenge):
            return None
        return await read_clues()

    return challenge_task, asyncio.ensure_future(_clues_if_text())
