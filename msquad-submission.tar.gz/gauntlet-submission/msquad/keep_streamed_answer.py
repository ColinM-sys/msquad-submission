"""Arm: a stream that drops after a complete "ANSWER: x" keeps that answer instead of retrying.

A dropped connection used to reset the streamed reply and make a second call, or raise, even when the reply
already held a finished answer. With this arm on, a reply is kept only when its answer line is terminated
by a newline and the answer is valid (JSON answers must parse). An unterminated or truncated answer is retried
as on main. Off by default. Off unless MSQUAD_KEEP_STREAMED_ANSWER=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Callable

ENV_FLAG = "MSQUAD_KEEP_STREAMED_ANSWER"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

# An answer line only counts once it ends with a newline: a cut-off "ANSWER: 4" may be "ANSWER: 42".
_TERMINATED_ANSWER_RE = re.compile(r"ANSWER:[ \t]*[^\n]*\n", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def complete(reply: str, extract: Callable[[str], Any], is_invalid: Callable[[Any], bool]) -> bool:
    """True when the reply has a terminated answer line, the extractor finds a valid answer, and JSON parses."""
    if not _TERMINATED_ANSWER_RE.search(reply or ""):
        return False
    answer = extract(reply)
    if not (answer and str(answer).strip()) or is_invalid(answer):
        return False
    text = str(answer).strip()
    if text.startswith(("{", "[")):
        try:
            json.loads(text)
        except (ValueError, RecursionError):
            return False
    return True
