"""Run a code-trace challenge's Python program in an isolated child process.

For a `code` challenge the clue holds a short program and the answer is what it
prints. Running it gives that answer without a model call. Stdlib only.

Three layers, all required. A rejection at any layer returns None, and the
caller falls through to the model.

1. AST allow-list (this process). Only literals, names, arithmetic, comparisons,
   if/for/while, def/return, comprehensions, subscripts and calls to a fixed set
   of safe builtins or whitelisted str/list/dict/set methods. Any name or
   attribute starting with "_" is rejected, and so is any attribute not in the
   method whitelist, plus import, lambda, class, try, with and eval-like names.
2. Child process (`python -I -S`): empty environment, temp working directory,
   CPU-time and memory limits (Job Object on Windows, rlimit on POSIX) and a hard
   kill on timeout. The child's namespace holds only the safe builtins, with no
   Python functions of ours in it, so `print` is the real builtin writing to the
   child's stdout pipe.
3. Output cap: anything larger than MAX_OUTPUT_CHARS is discarded.

The AST check is the primary filter. The process limits are the backstop for
anything the filter lets through, such as a huge allocation or a long loop.
"""

from __future__ import annotations

import ast
import os
import subprocess
import sys
import tempfile

TIMEOUT_S = 2.0
CPU_S = 2
MEMORY_BYTES = 256 * 1024 * 1024
MAX_SOURCE_CHARS = 4000
MAX_OUTPUT_CHARS = 2000

SAFE_CALLABLES = frozenset({
    "abs", "all", "any", "bool", "chr", "dict", "divmod", "enumerate", "filter", "float",
    "int", "len", "list", "map", "max", "min", "ord", "pow", "print", "range", "repr",
    "reversed", "round", "set", "sorted", "str", "sum", "tuple", "zip",
})

# Methods on str, list, dict and set only. `format`/`format_map` are excluded:
# they can reach attributes through "{0.__class__}" style fields.
SAFE_METHODS = frozenset({
    # str
    "upper", "lower", "strip", "lstrip", "rstrip", "split", "rsplit", "join", "replace",
    "startswith", "endswith", "count", "index", "find", "title", "capitalize", "isdigit",
    "isalpha", "isalnum", "isspace", "isupper", "islower", "zfill", "center", "ljust",
    "rjust", "splitlines", "swapcase",
    # list
    "append", "extend", "insert", "pop", "remove", "reverse", "sort", "copy", "clear",
    # dict
    "get", "keys", "values", "items", "setdefault", "update",
    # set
    "add", "discard", "union", "intersection", "difference", "issubset", "issuperset",
})

_ALLOWED_NODES = (
    ast.Module, ast.Expr, ast.Assign, ast.AugAssign, ast.Name, ast.Constant,
    ast.BinOp, ast.UnaryOp, ast.BoolOp, ast.Compare, ast.IfExp, ast.If, ast.For,
    ast.While, ast.FunctionDef, ast.arguments, ast.arg, ast.Return, ast.Pass,
    ast.Break, ast.Continue, ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp,
    ast.comprehension, ast.Subscript, ast.Slice, ast.Call, ast.keyword, ast.Attribute,
    ast.Tuple, ast.List, ast.Dict, ast.Set, ast.JoinedStr, ast.FormattedValue, ast.Starred,
    ast.expr_context, ast.operator, ast.unaryop, ast.boolop, ast.cmpop,
)


def _safe_program(source: str) -> bool:
    """True only when every node is on the allow-list and every name/attr is safe."""
    try:
        tree = ast.parse(source, mode="exec")
    except (SyntaxError, ValueError):
        return False
    user_functions = {node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            return False
        if isinstance(node, ast.Name) and node.id.startswith("_"):
            return False
        if isinstance(node, ast.FunctionDef) and node.name.startswith("_"):
            return False
        if isinstance(node, ast.Attribute) and (node.attr.startswith("_") or node.attr not in SAFE_METHODS):
            return False
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name):
                if func.id not in SAFE_CALLABLES and func.id not in user_functions:
                    return False
            elif not isinstance(func, ast.Attribute):
                return False
    return True


_CHILD = r'''
import builtins, sys
names = sys.argv[1:]
ns = {"__builtins__": {name: getattr(builtins, name) for name in names}}
src = sys.stdin.read()
exec(compile(src, "<challenge>", "exec"), ns)
'''


def _posix_limits() -> None:  # runs in the child before exec
    import resource
    resource.setrlimit(resource.RLIMIT_CPU, (CPU_S, CPU_S))
    resource.setrlimit(resource.RLIMIT_AS, (MEMORY_BYTES, MEMORY_BYTES))


class _WindowsJob:
    """A Job Object with CPU and memory limits; closing it kills the child."""

    def __init__(self, pid_handle: int):
        import ctypes
        from ctypes import wintypes

        class _BasicLimit(ctypes.Structure):
            _fields_ = [
                ("PerProcessUserTimeLimit", ctypes.c_int64),
                ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", wintypes.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", wintypes.DWORD),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", wintypes.DWORD),
                ("SchedulingClass", wintypes.DWORD),
            ]

        class _IoCounters(ctypes.Structure):
            _fields_ = [(name, ctypes.c_uint64) for name in (
                "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]

        class _ExtLimit(ctypes.Structure):
            _fields_ = [
                ("BasicLimitInformation", _BasicLimit),
                ("IoInfo", _IoCounters),
                ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t),
            ]

        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateJobObjectW.restype = wintypes.HANDLE
        self._kernel = kernel
        self._job = kernel.CreateJobObjectW(None, None)
        if not self._job:
            raise OSError("CreateJobObjectW failed")
        info = _ExtLimit()
        info.BasicLimitInformation.PerProcessUserTimeLimit = CPU_S * 10_000_000  # 100 ns units
        info.BasicLimitInformation.LimitFlags = 0x2 | 0x100 | 0x2000  # CPU, memory, kill on close
        info.ProcessMemoryLimit = MEMORY_BYTES
        if not kernel.SetInformationJobObject(self._job, 9, ctypes.byref(info), ctypes.sizeof(info)):
            raise OSError("SetInformationJobObject failed")
        if not kernel.AssignProcessToJobObject(self._job, wintypes.HANDLE(pid_handle)):
            raise OSError("AssignProcessToJobObject failed")

    def close(self) -> None:
        self._kernel.CloseHandle(self._job)


def _run(source: str, timeout_s: float) -> str | None:
    if not source.strip() or len(source) > MAX_SOURCE_CHARS or not _safe_program(source):
        return None
    names = sorted(SAFE_CALLABLES)
    env: dict[str, str] = {}
    kwargs = {}
    if os.name == "posix":
        kwargs["preexec_fn"] = _posix_limits
    with tempfile.TemporaryDirectory(prefix="code-eval-") as workdir:
        try:
            proc = subprocess.Popen(
                [sys.executable, "-I", "-S", "-c", _CHILD, *names],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                cwd=workdir,
                env=env,
                text=True,
                encoding="utf-8",
                **kwargs,
            )
        except OSError:
            return None
        job = None
        if os.name == "nt":
            try:
                job = _WindowsJob(int(proc._handle))
            except OSError:
                proc.kill()
                proc.wait()
                return None
        try:
            out, _ = proc.communicate(source, timeout=timeout_s)
            code = proc.returncode
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
            return None
        finally:
            if job is not None:
                job.close()
    if code != 0 or len(out) > MAX_OUTPUT_CHARS or not out.strip():
        return None
    # Each print() adds one newline; the answer is the printed lines joined by "\n".
    return out[:-1] if out.endswith("\n") else out


def run_program(source: str, timeout_s: float = TIMEOUT_S) -> str | None:
    """Return what `source` prints, or None if it is rejected, fails or times out."""
    return _run(source, timeout_s)


def run_code_challenge(challenge_type: str, clues: list[str]) -> str | None:
    """Answer a `code` challenge from its clue programs; None for every other type."""
    if (challenge_type or "").strip().lower() != "code":
        return None
    source = "\n".join(clue for clue in clues if isinstance(clue, str))
    return run_program(source)


__all__ = ["run_program", "run_code_challenge", "SAFE_CALLABLES", "SAFE_METHODS"]
