"""Clause-scoped negation for rule helpers: a negator that governs a term in the same clause.

Used by the helpers that read format words from the challenge rules (JSON, comma separators), so a negated
mention is never read as the positive form. A negator must sit directly before the term, optionally with one of
the given verbs between them. Only spaces may come between them, so a full stop, semicolon or newline ends the
negation and a detail about the term ("avoid trailing commas", "no spaces after the commas") does not govern it.
"""

from __future__ import annotations

import re

NEGATOR = r"(?:no|not|without|never|avoid|don't|do\s+not|nor)"


def _pattern(term: str, verbs: tuple[str, ...]) -> re.Pattern:
    verb = rf"(?:(?:{'|'.join(verbs)})\s+)?" if verbs else ""
    return re.compile(rf"\b{NEGATOR}\s+{verb}{term}\b", re.IGNORECASE)


def negates(text: str, term: str, verbs: tuple[str, ...] = ()) -> bool:
    """True when a negator governs ``term`` in ``text``, e.g. "do not use commas" for term ``commas?``."""
    return _pattern(term, verbs).search(str(text or "")) is not None


def strip_negated(text: str, term: str, verbs: tuple[str, ...] = ()) -> str:
    """``text`` with each negated ``term`` removed, so what is left can be read as the positive form."""
    return _pattern(term, verbs).sub(" ", str(text or ""))


def negates_in_clause(text: str, term: str) -> bool:
    """True when a negator sits earlier in the same clause as ``term``, with any words between them.

    For a cue whose negated form is a clause, e.g. "do not put them on separate lines". A full stop, semicolon,
    colon or newline ends the clause, so a negator in an earlier sentence does not count.
    """
    return re.search(rf"\b{NEGATOR}\b[^.;:\n]{{0,40}}?\b{term}\b", str(text or ""), re.IGNORECASE) is not None
