"""Arm: adapt to a black-box MCP server that renames tools and arguments, encodes clues, hides a tool.

The event promises a "Black Box" MCP server with hidden tools and encoded data. The kit calls
fixed names (arena.clues.get with clue_id, docs.search with query, ...), so in the gym's
black-box-live mode it read no clue at all: 1/10 accepted. With this arm the MCP session is
wrapped so that:

- a canonical tool the server does not list resolves to the listed tool that matches it best by
  name (with synonyms: get~fetch/open/read/lookup, search~query/find, docs~kb/doc) and by schema
  (the same number of non-agent_id arguments, so a bulk decoy with none is never picked);
- an argument the tool's schema does not declare is renamed to the declared one that fits;
- a reply carrying {"payload", "encoding": base64|rot13|hex} gains the decoded "text";
- a note naming an unlisted tool as name(arg='ref') is remembered, and an empty/archived clue
  with that ref is fetched from that tool.

The canonical names are added to the tool list as aliases, so name checks in the agent see them.
Off unless MSQUAD_TOOL_ADAPT=1 or DEFAULT_ENABLED is True. On a standard server every canonical
tool is listed with its canonical arguments, so nothing is remapped.
"""

from __future__ import annotations

import base64
import binascii
import codecs
import json
import os
import re
from types import SimpleNamespace
from typing import Any

from msquad import decoy_description, prose_hint, token_retry

ENV_FLAG = "MSQUAD_TOOL_ADAPT"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

# The tools the agent calls by name, with their non-agent_id arguments.
CANONICAL: dict[str, tuple[str, ...]] = {
    "arena.get_challenge": (),
    "arena.clues.list": (),
    "arena.clues.get": ("clue_id",),
    "arena.time_remaining": (),
    "docs.search": ("query",),
    "docs.get": ("doc_id",),
    "web_search": ("query",),
}
_SYNONYMS = {
    "get": {"fetch", "open", "read", "lookup", "retrieve", "load"},
    "search": {"query", "find", "lookup", "seek"},
    "docs": {"doc", "kb", "knowledge", "documents", "library"},
    "clues": {"clue", "hints", "hint"},
    "list": {"index", "ids", "enumerate"},
    "time": {"clock", "timer"},
    "remaining": {"left", "now"},
}
_GENERIC = {"arena", "api", "v1", "v2", "tool", "tools"}
_HINT_RE = re.compile(r"([A-Za-z_][\w.]*)\(\s*(\w+)\s*=\s*['\"]([^'\"]+)['\"]\s*\)")
_ENCODINGS = {"base64", "rot13", "hex"}


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _tokens(name: str) -> set[str]:
    return {t for t in re.split(r"[^a-z0-9]+", name.lower()) if t and t not in _GENERIC}


def _token_match(a: str, b: str) -> bool:
    if a == b:
        return True
    return b in _SYNONYMS.get(a, set()) or a in _SYNONYMS.get(b, set())


def _props(tool_def: Any) -> list[str]:
    schema = getattr(tool_def, "inputSchema", None) or {}
    return [p for p in (schema.get("properties") or {}) if p != "agent_id"]


def _arg_fit(canonical_arg: str, served_arg: str) -> bool:
    a, b = canonical_arg.lower(), served_arg.lower()
    return a in b or b in a or bool(set(a.split("_")) & set(b.split("_")))


def resolve_tools(tool_defs: list[Any], *, skip_decoys: bool = False, ignore_tokens: bool = False) -> dict[str, str]:
    """{canonical name: served name} for each canonical tool the server does not list.

    skip_decoys (MSQUAD_DECOY_DESCRIPTION): a tool described as deprecated/stale/cached is never a
    candidate, and "live/current challenge" breaks a tie. ignore_tokens (MSQUAD_TOKEN_RETRY):
    token-like arguments do not count when matching the schema.
    """
    listed = {getattr(d, "name", ""): d for d in tool_defs}
    mapping: dict[str, str] = {}
    taken = set(listed) & set(CANONICAL)
    for canonical, args in CANONICAL.items():
        if canonical in listed:
            continue
        best, best_score, best_bonus = "", 0.0, 0.0
        for name, tool_def in listed.items():
            if name in taken or name in CANONICAL:
                continue
            if skip_decoys and decoy_description.is_decoy(tool_def):
                continue
            props = _props(tool_def)
            if ignore_tokens:
                props = [p for p in props if not token_retry.is_token_arg(p)]
            if len(props) != len(args):
                continue
            overlap = sum(1 for a in _tokens(canonical) if any(_token_match(a, b) for b in _tokens(name)))
            if not overlap:
                continue
            score = overlap + 0.5 * sum(1 for a in args if any(_arg_fit(a, p) for p in props))
            bonus = decoy_description.live_bonus(tool_def) if skip_decoys else 0.0
            if score + bonus > best_score + (best_bonus if best else 0.0):
                best, best_score, best_bonus = name, score, bonus
        # every name token must find a counterpart, so "time_remaining" never maps onto a stray "time"
        if best and best_score >= len(_tokens(canonical)):
            mapping[canonical] = best
            taken.add(best)
    return mapping


def _norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", name.lower())


def map_arguments(arguments: dict[str, Any], tool_def: Any, *, renamed: bool) -> dict[str, Any]:
    """Rename each argument the schema does not declare to the declared one that fits it.

    On a tool the server serves under its canonical name (renamed=False) only a normalised
    spelling is mapped (clueId -> clue_id): any other undeclared argument is sent as is, exactly
    as with the arm off. Name-fit and the single-free-slot fallback apply to renamed tools only.
    """
    props = _props(tool_def)
    if not props:
        return dict(arguments)
    out: dict[str, Any] = {}
    free = [p for p in props if p not in arguments]
    for key, value in arguments.items():
        if key == "agent_id" or key in props or not free:
            out[key] = value
            continue
        target = next((p for p in free if _norm(key) == _norm(p)), "")
        if not target and renamed:
            target = next((p for p in free if _arg_fit(key, p)), free[0] if len(free) == 1 else "")
        if target:
            out[target] = value
            free.remove(target)
        else:
            out[key] = value
    return out


def decode_payload(data: dict[str, Any]) -> dict[str, Any]:
    """Add "text" decoded from {"payload"/"data", "encoding"} when the reply has no text of its own."""
    encoding = str(data.get("encoding", "")).lower()
    raw = data.get("payload", data.get("data"))
    if encoding not in _ENCODINGS or not isinstance(raw, str) or str(data.get("text") or "").strip():
        return data
    try:
        if encoding == "base64":
            text = base64.b64decode(raw, validate=True).decode("utf-8")
        elif encoding == "hex":
            text = bytes.fromhex(raw).decode("utf-8")
        else:
            text = codecs.decode(raw, "rot_13")
    except (ValueError, binascii.Error, UnicodeDecodeError):
        return data
    return {**data, "text": text}


def _reply(data: dict[str, Any]) -> Any:
    return SimpleNamespace(isError=False, structuredContent=None,
                           content=[SimpleNamespace(type="text", text=json.dumps(data))])


def _error_text(result: Any) -> dict[str, Any]:
    """An MCP error result (e.g. the server's input validation) as {"error": text}, else {}."""
    if not getattr(result, "isError", False):
        return {}
    content = getattr(result, "content", None) or []
    return {"error": str(getattr(content[0], "text", "") if content else "")}


def _data(result: Any) -> dict[str, Any] | None:
    if getattr(result, "isError", False):
        return None
    structured = getattr(result, "structuredContent", None)
    if isinstance(structured, dict):
        return dict(structured)
    content = getattr(result, "content", None) or []
    try:
        data = json.loads(content[0].text)
    except (IndexError, AttributeError, TypeError, ValueError):
        return None
    return data if isinstance(data, dict) else None


class AdaptiveSession:
    """Wraps an MCP ClientSession; every other attribute passes through."""

    def __init__(self, session: Any, tool_defs: list[Any], hints: dict[str, tuple[str, str]] | None = None) -> None:
        self._inner = session
        self._defs = {getattr(d, "name", ""): d for d in tool_defs}
        self.token_retry = token_retry.enabled()
        self.prose_hint = prose_hint.enabled()
        self.aliases = resolve_tools(tool_defs, skip_decoys=decoy_description.enabled(), ignore_tokens=self.token_retry)
        # ref -> (tool, arg), learned from notes like ledger.lookup(ref='clue_0'); shared across reconnects.
        # A prose hint names no ref and is stored under "*" (MSQUAD_PROSE_HINT).
        self.hints = hints if hints is not None else {}
        self._token = ""

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None, *args: Any, **kwargs: Any) -> Any:
        served = self.aliases.get(name, name)
        payload = dict(arguments or {})
        tool_def = self._defs.get(served)
        if tool_def is not None:
            payload = map_arguments(payload, tool_def, renamed=served != name)
        result = await self._inner.call_tool(served, payload, *args, **kwargs)
        data = _data(result)
        if self.token_retry and token_retry.refused_for_token(data if data is not None else _error_text(result)):
            retried = await self._retry_with_token(served, payload, tool_def, args, kwargs)
            if retried is not None:
                result = retried
                data = _data(result)
        if data is None:
            return result
        changed = False
        for match in _HINT_RE.finditer(json.dumps(data)):
            tool, arg, ref = match.groups()
            if tool not in self._defs:
                self.hints[ref] = (tool, arg)
        if self.prose_hint:
            for key, value in data.items():
                found = prose_hint.find(value, set(self._defs)) if key != "text" and isinstance(value, str) else None
                if found:
                    self.hints.setdefault("*", found)
        decoded = decode_payload(data)
        if decoded is not data:
            data, changed = decoded, True
        ref = str(data.get("clue_id") or "")
        hint = self.hints.get(ref) or (self.hints.get("*") if self.prose_hint and ref else None)
        if hint and not str(data.get("text") or "").strip():
            tool, arg = hint
            try:
                extra = _data(await self._inner.call_tool(tool, {"agent_id": payload.get("agent_id", ""), arg: ref}))
            except Exception:
                extra = None  # a failed follow-up leaves the clue as the server sent it, as with the arm off
            if extra:
                extra = decode_payload(extra)
                if str(extra.get("text") or "").strip():
                    data, changed = {**data, "text": extra["text"]}, True
        return _reply(data) if changed else result

    async def _retry_with_token(self, served: str, payload: dict[str, Any], tool_def: Any,
                                args: tuple, kwargs: dict) -> Any:
        """MSQUAD_TOKEN_RETRY: open a session, then retry the refused call once with its token."""
        if not self._token:
            issuer = token_retry.find_issuer(self._defs, _props, set(CANONICAL) | set(self.aliases.values()))
            if not issuer or issuer == served:
                return None
            try:
                opened = _data(await self._inner.call_tool(issuer, {"agent_id": payload.get("agent_id", "")}))
            except Exception:
                return None  # the refusal stands, as with the arm off
            self._token = token_retry.extract_token(opened or {})
            if not self._token:
                return None
        arg = token_retry.token_arg(_props(tool_def) if tool_def is not None else [])
        try:
            return await self._inner.call_tool(served, {**payload, arg: self._token}, *args, **kwargs)
        except Exception:
            return None


def with_aliases(tools: list[str], session: AdaptiveSession) -> list[str]:
    """The listed names plus each resolved canonical alias."""
    return list(tools) + [alias for alias in session.aliases if alias not in tools]
