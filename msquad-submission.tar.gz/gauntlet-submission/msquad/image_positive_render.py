"""Generate arm: a positive text-free rendering instruction in place of the repeated text bans.

The live generate prompt says "Absolutely no text ... no lettering, no kanji, no signage words, no logos,
no numbers", and the output still had kanji and lettering on signs (constraints 50). A negated list primes
the model toward the thing it bans. This guard says what the surfaces are instead: unlettered, unbranded,
blank displays. The light sentence (tubes, glow, plain panels) is added only when the request is about light
or lit surfaces, so a daytime scene does not gain neon elements.

Applies only when the request forbids text and does not ask for specific words; an explicit request for
text always keeps the shipped guard. On unless MSQUAD_GENERATE_POSITIVE_RENDER=0 or DEFAULT_ENABLED is
False, so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_GENERATE_POSITIVE_RENDER"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

_UNLETTERED = "All surfaces are unlettered and unbranded; any necessary signs, screens or displays have blank faces."
_SURFACES = f"Generate one image as a single continuous full-frame scene. {_UNLETTERED}"
# A plain, solid or nothing-else request has a backdrop to keep empty; "full-frame scene" would invite scenery it forbids.
_SURFACES_PLAIN = f"Generate one image. {_UNLETTERED}"
_PLAIN_RE = re.compile(
    r"\b(?:plain|solid|blank|flat|white|grey|gray|black|navy|dark|light|pale)\b[^.;\n]{0,20}\bbackground\b|\bnothing else\b",
    re.IGNORECASE,
)
_LIGHT = "Render light as continuous tubes, edge glow and plain colour panels, without glyph-like shapes."

# The request forbids text: the phrases the no-text guard answers to.
_FORBID_RE = re.compile(
    r"\b(no text|without text|without any text|no lettering|no words|text-free|no visible text|no writing)\b",
    re.IGNORECASE,
)
# The request asks for specific words: a quoted phrase (paired quotes only), a reading/saying cue, or an unquoted
# exception to the ban ("no text ..., only the word MENU", "without text except the title SALE"; Fable's ON-flip audit).
# "reading" only after a lettered thing ("a title reading SALE"), so "a reading lamp" still fires.
_QUOTED_RE = re.compile(r"'[^']+'|\"[^\"]+\"|“[^”]+”|‘[^’]+’")
_ASKS_WORDS_RE = re.compile(
    r"\b(reads?|(?:title|sign|label|banner|caption|headline|board|plaque) reading|says|saying|labell?ed|only the words?|(?:except|but) (?:for )?(?:the |a )?(?:title|words?|name|"
    r"caption|headline|label|slogan))\b",
    re.IGNORECASE,
)
# The request is about light or lit surfaces: only then does the light sentence apply.
# Not bare "light" or "lamp": "a bowl of fruit in soft morning light" is no neon scene (combined-arms probe).
_LIGHT_RE = re.compile(r"\b(neon|glow|screen|display|sign|billboard)\b", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def guard_for(request: str) -> str | None:
    """The positive guard when the request forbids text and asks for none, else None (keep the shipped guard)."""
    if not _FORBID_RE.search(request or ""):
        return None
    rest = _FORBID_RE.sub(" ", request)
    if _QUOTED_RE.search(rest) or _ASKS_WORDS_RE.search(rest):
        return None
    surfaces = _SURFACES_PLAIN if _PLAIN_RE.search(request) else _SURFACES
    if _LIGHT_RE.search(request):
        return f"{surfaces} {_LIGHT}"
    return surfaces
