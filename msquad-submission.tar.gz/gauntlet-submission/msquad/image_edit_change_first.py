"""Edit arm: the requested change first, its placement rule beside it, then the notes (astra IM3).

Live image-edit preservation is our biggest loss (84.0). The edit prompt today opens with a generic
guard, then the request, then the notes, then a "Context:" paragraph that repeats the generic
challenge description, with any placement rule appended after all of that. With this arm on, the
prompt is, in order:

1. the request, verbatim (the first line of the rules, where the agent puts the challenge's prompt);
2. ONE placement rule for the change, when one applies: eyes-clear (headwear or eyewear on a person)
   is preferred, otherwise no-occlude;
3. the reference notes, verbatim (the remaining rules lines);
4. one short preservation line;
5. the output size hint.

No "Context:" paragraph when an explicit request exists. The text never depends on a puzzle id or on
the wording of one puzzle. Off unless MSQUAD_EDIT_CHANGE_FIRST=1 or DEFAULT_ENABLED is True; a live
image A/B decides whether it ships.
"""

from __future__ import annotations

import os
import re

from msquad import image_eyes_clear, image_no_occlude

ENV_FLAG = "MSQUAD_EDIT_CHANGE_FIRST"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def placement_rule(request: str) -> str:
    """The one placement rule for the requested change: eyes-clear first, else no-occlude, else ""."""
    return image_eyes_clear.rule_for(request) or image_no_occlude.rule_for(request)


def reorder(prompt: str, rules: str) -> str:
    """The arm-off prompt with the request moved to the front and its placement rule beside it.

    Every other block stays as the arm-off prompt has it, so the Context, the guard and the hard
    constraints are kept. The prompt is returned unchanged when the request is not one of its lines.
    """
    lines = [line.strip() for line in str(rules or "").splitlines() if line.strip()]
    request = lines[0] if lines else ""
    prompt_lines = prompt.split("\n")
    if not request or request not in prompt_lines:
        return prompt
    del prompt_lines[prompt_lines.index(request)]
    body = re.sub(r"\n{3,}", "\n\n", "\n".join(prompt_lines)).strip()
    parts = [request]
    rule = placement_rule(request)
    if rule and rule not in prompt:
        parts.append(rule)
    parts.append(body)
    return "\n\n".join(parts)
