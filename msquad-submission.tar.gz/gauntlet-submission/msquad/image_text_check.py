"""Generate self-check: ask image_analyze whether the picture shows legible text; regenerate once.

The generate judge's constraints axis loses the most points live (mean ~83, worst 38), mostly
for signage and lettering the request said to leave out. Off unless MSQUAD_GENERATE_SELF_CHECK=1
or DEFAULT_ENABLED is set to True here, so it can be A/B tested live and switched on without
env. At most one analyze call and one regeneration, and neither starts with MIN_REMAINING_S
or less left.
"""

from __future__ import annotations

import asyncio
import os
import re
from typing import Any, Awaitable, Callable

ENV_FLAG = "MSQUAD_GENERATE_SELF_CHECK"
# Code default when the env var is unset: flip to True to ship it on without touching the environment.
DEFAULT_ENABLED = False
MIN_REMAINING_S = 60.0
# Each self-check call must finish this long before the guard, so the first image can still be submitted.
CALL_MARGIN_S = 30.0
QUESTION = (
    "Does this image contain any legible text: letters, words, numbers, logos or signage with writing "
    "on signs, screens or labels? Reply with yes or no first."
)
NO_TEXT_PREFIX = (
    "No readable text, no signs with writing, no logos: every sign, screen, label and surface is blank "
    "or shows only abstract light and shapes, with no letters, numbers or symbols. "
)
# A quoted phrase is text the request wants only when a text cue sits beside it ('a sign that reads "OPEN"').
# A quoted style or mood word ('in a "retro" style') does not disable the check.
_QUOTED_RE = re.compile(r"[\"“][^\"”]{1,40}[\"”]|(?<![A-Za-z])['‘][^'’]{1,40}['’](?![A-Za-z])")
_TEXT_CUE_RE = re.compile(
    r"\b(reading|reads?|says?|text|words?|lettering|labell?ed)\b|sign that reads", re.IGNORECASE
)
# "no text", "without any lettering", "free of words", "not a single word": the cue bans text (coordinator on #491).
_NEGATED_BEFORE_RE = re.compile(r"\b(?:no|without|free of|not|never|zero)(?:\s+(?:any|a|single|visible))*\s+$",
                                re.IGNORECASE)
_CUE_WINDOW = 40
_ANSWER_KEYS = ("text", "answer", "analysis", "result", "content", "description")

CallTool = Callable[[str, dict], Awaitable[dict]]


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def says_yes(result: Any) -> bool:
    """True only when the analysis reply starts with "yes" (any case, after quotes or markup)."""
    if not isinstance(result, dict):
        return False
    text = next((str(result[k]) for k in _ANSWER_KEYS if isinstance(result.get(k), str) and result[k].strip()), "")
    return bool(re.match(r"^[\s*_\"'`>#-]*yes\b", text, re.IGNORECASE))


def _asks_for_text(prompt: str) -> bool:
    """True when a quoted phrase sits within a few words of a text cue: the request asks for that text.

    A negated cue ("no text", "without any text", "free of words") bans text instead, so it does not count.
    """
    for quote in _QUOTED_RE.finditer(prompt):
        window = prompt[max(0, quote.start() - _CUE_WINDOW): quote.end() + _CUE_WINDOW]
        for cue in _TEXT_CUE_RE.finditer(window):
            if not _NEGATED_BEFORE_RE.search(window[max(0, cue.start() - 20): cue.start()]):
                return True
    return False


async def recheck_for_text(
    call_tool: CallTool,
    *,
    image_uri: str,
    prompt: str,
    remaining_s: Callable[[], float],
    usable: Callable[[dict], str],
    analyze_args: dict | None = None,
    generate_args: dict | None = None,
    environ: dict | None = None,
    margin_s: float = CALL_MARGIN_S,
) -> tuple[str, str]:
    """Return (image to submit, note). The original image unless a check found text and a retry worked."""
    if not enabled(environ):
        return image_uri, "off"
    if not image_uri or _asks_for_text(prompt or ""):
        return image_uri, "skipped"
    if remaining_s() <= MIN_REMAINING_S:
        return image_uri, "no time to check"
    try:
        analysis = await asyncio.wait_for(
            call_tool("image_analyze", {"image_uri": image_uri, "question": QUESTION, **(analyze_args or {})}),
            max(0.0, remaining_s() - margin_s),
        )
    except asyncio.TimeoutError:
        return image_uri, "analyze timed out; kept the first image"
    except Exception:
        return image_uri, "analyze failed; kept the first image"
    if not says_yes(analysis):
        return image_uri, "no text found"
    if remaining_s() <= MIN_REMAINING_S:
        return image_uri, "text found; no time to regenerate"
    try:
        retry = await asyncio.wait_for(
            call_tool("image_generate", {"prompt": NO_TEXT_PREFIX + (prompt or ""), **(generate_args or {})}),
            max(0.0, remaining_s() - margin_s),
        )
    except asyncio.TimeoutError:
        return image_uri, "text found; regeneration timed out, kept the first image"
    except Exception:
        return image_uri, "text found; regeneration failed, kept the first image"
    retried = usable(retry) if isinstance(retry, dict) else ""
    if not retried:
        return image_uri, "text found; regeneration failed, kept the first image"
    # the retry replaces the first image only when its own check reports no text
    if remaining_s() <= MIN_REMAINING_S:
        return image_uri, "text found; no time to verify the retry, kept the first image"
    try:
        verdict = await asyncio.wait_for(
            call_tool("image_analyze", {"image_uri": retried, "question": QUESTION, **(analyze_args or {})}),
            max(0.0, remaining_s() - margin_s),
        )
    except Exception:
        return image_uri, "text found; retry not verified, kept the first image"
    if says_yes(verdict):
        return image_uri, "text found; retry still shows text, kept the first image"
    return retried, "text found; regenerated once"
