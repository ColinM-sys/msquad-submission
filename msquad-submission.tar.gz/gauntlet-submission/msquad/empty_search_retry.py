"""Arm: when every search query came back empty, retry once with normalized content words.

A question such as "combined length of the two cables in metres" finds nothing in a word-matching
search over "Cable A measures 42 m", so no id reaches docs.get and the answer is a guess. With this
arm on, one more search runs with the question's content words lowercased, stopwords and units dropped and
plurals singularized ("combined length cable"). It fires only when every search was empty, so the
cost is one call when it fires. Off unless MSQUAD_EMPTY_SEARCH_RETRY=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_EMPTY_SEARCH_RETRY"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

STOPWORDS = frozenset({
    "a", "an", "the", "of", "in", "on", "at", "to", "for", "from", "by", "with", "and", "or", "is", "are",
    "was", "were", "be", "what", "which", "who", "whom", "whose", "when", "where", "why", "how", "many",
    "much", "does", "do", "did", "it", "its", "this", "that", "these", "those", "two", "three", "one",
    "answer", "give", "number", "total", "avoid", "please", "there", "their",
})
# Units of measure name the answer's shape, not the document: "metres" never finds "42 m".
UNITS = frozenset({
    "metre", "meter", "kilometre", "kilometer", "centimetre", "centimeter", "millimetre", "millimeter", "mile",
    "foot", "feet", "inch", "yard", "gram", "kilogram", "tonne", "ton", "pound", "ounce", "litre", "liter",
    "gallon", "minute", "hour", "day", "week", "month", "year", "percent", "degree", "dollar",
    "euro", "cent",
})  # not "second", "unit" or "item": "the second bridge" needs them as content words
# Words that are not plurals, and irregular plurals.
INVARIANT = frozenset({"news", "series", "species", "means", "physics", "mathematics", "economics", "politics",
                       "always", "perhaps", "whereas", "various", "previous", "status", "bus", "gas", "lens"})
IRREGULAR = {"people": "person", "children": "child", "men": "man", "women": "woman", "feet": "foot",
             "teeth": "tooth", "mice": "mouse", "geese": "goose", "buses": "bus", "gases": "gas",
             "lenses": "lens", "statuses": "status", "indices": "index", "criteria": "criterion",
             "analyses": "analysis", "crises": "crisis", "data": "data", "knives": "knife", "lives": "life",
             "wives": "wife", "leaves": "leaf", "halves": "half", "shelves": "shelf", "wolves": "wolf",
             "quizzes": "quiz", "heroes": "hero", "potatoes": "potato", "tomatoes": "tomato", "echoes": "echo",
             "vetoes": "veto", "torpedoes": "torpedo", "volcanoes": "volcano", "mosquitoes": "mosquito"}
# -ches words whose singular keeps the e (main's plain -s rule got these right).
CHE_STEMS = frozenset({"cache", "niche", "ache", "headache", "toothache", "backache", "stomachache", "avalanche",
                       "moustache", "mustache", "cliche", "psyche", "quiche", "creche", "panache", "microfiche"})


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def singular(word: str) -> str:
    """A small English singularizer: irregulars, invariants, -ies, -ches/-shes/-xes/-sses/-zzes, then -s."""
    if word in IRREGULAR:
        return IRREGULAR[word]
    if word in INVARIANT or len(word) <= 3:
        return word
    if word.endswith("ies") and len(word) > 4:
        return word[:-3] + "y"
    if word.endswith("zzes"):
        return word[:-2]  # buzzes -> buzz (quizzes is an irregular)
    if word.endswith("ches") and word[:-1] in CHE_STEMS:
        return word[:-1]
    if word.endswith(("ches", "shes", "xes", "sses")):
        return word[:-2]
    if word.endswith("s") and not word.endswith(("ss", "us", "is")):
        return word[:-1]
    return word


def retry_query(text: str) -> str:
    """Content words of ``text``: lowercased, stopwords dropped, singularized, in order, no repeats."""
    out: list[str] = []
    for word in re.findall(r"[a-z0-9]+", str(text or "").lower()):
        if len(word) < 3 or word in STOPWORDS:
            continue
        word = singular(word)
        if word in UNITS:
            continue
        if word not in out:
            out.append(word)
    return " ".join(out)


_NAME_RE = re.compile(r"[A-Z][\w'-]*(?:\s+[A-Z][\w'-]*)*")
# All the extra searches together (the content-word retry and the key nouns) stop after this long.
RETRY_BUDGET_S = 6.0
# Common verbs: a noun search for "have" or "open" lists everything or nothing (Fable on #450).
_VERBS = frozenset({"have", "has", "had", "open", "get", "make", "take", "use", "show", "need", "want", "keep",
                    "give", "find", "run", "put", "set", "say", "see", "come", "become"})


def noun_queries(text: str, limit: int = 3) -> list[str]:
    """One-word-at-a-time searches for when the content-word retry is empty too: the names first
    ("Gull Runner"), then each other content word, singularized ("pier", "depart")."""
    text = str(text or "")
    names: list[str] = []
    for match in _NAME_RE.finditer(text):
        name = match.group(0)
        if match.start() == 0 and name.split()[0].lower() in STOPWORDS:
            name = " ".join(name.split()[1:])  # "Which" starts the question; "What Harbor" keeps "Harbor"
        if name and name not in names:
            names.append(name)
    taken = {singular(w) for n in names for w in re.findall(r"[a-z0-9]+", n.lower())}
    words = [w for w in retry_query(text).split() if w not in taken and w not in _VERBS]
    return (names + words)[:limit]
