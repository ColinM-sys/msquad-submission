"""Edit arm: a stronger preservation guard that frames the edit as local.

Edit is the largest remaining image gap (live ~91 vs generate ~93.5), and preservation is its
weakest judge axis. The shipped guard says "keep everything else unchanged", which the image model
reads as a re-render with the change in it: the low live outputs shift identity, re-light, restyle
or recrop the whole picture. This guard says the edit is local, names what a re-render drifts on
(identity, expression, pose, lighting, crop, colour grade) and forbids the global touch-ups,
except where the requested change is itself one (black and white, watercolour, winter, a new background).

Replaces the edit guard only; generate is untouched. Off unless MSQUAD_EDIT_PRESERVE=1 or
DEFAULT_ENABLED is True, so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_EDIT_PRESERVE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

GUARD = (
    "Edit the provided source image. Change only what the requested change needs; every other "
    "part of the picture must match the source as closely as possible. Keep the "
    "subject's identity, facial features, expression, pose, hair and clothing, the background, the "
    "camera angle, crop, aspect ratio, lighting and colour grade exactly as they are, except where the requested change "
    "itself alters them. Apart from the requested change, do not restyle, re-light, re-render, sharpen, smooth, beautify or recrop the image, and add nothing "
    "the instruction does not ask for."
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def guard_for(request: str) -> str:
    """GUARD, minus the bans the request itself breaks (image_request cues, as in the shipped guard).

    A global edit (black and white, sunset, a season, a painting style) re-lights and restyles the whole
    picture, so lighting, colour grade, "restyle" and "re-light" are not kept; a person removal changes
    the subject, so the subject list is not kept. Any other edit, the live practice one included, gets
    GUARD byte for byte.
    """
    from msquad import image_request

    global_edit = image_request.global_edit(request)
    removal = image_request.removes_subject(request)
    if not global_edit and not removal:
        return GUARD
    # A removal keeps everyone else as they are: "remove the person in the background" must not free the
    # foreground subject (Fable on #430).
    keep = ["the remaining people's identity, facial features, expression, pose, hair and clothing" if removal
            else "the subject's identity, facial features, expression, pose, hair and clothing"]
    keep.append("the background, the camera angle, crop, aspect ratio" + ("" if global_edit else ", lighting and colour grade"))
    if global_edit:
        keep[-1] = keep[-1].replace(", aspect ratio", " and aspect ratio")
    banned = ["re-render", "sharpen", "smooth", "beautify", "recrop"] if global_edit else [
        "restyle", "re-light", "re-render", "sharpen", "smooth", "beautify", "recrop"]
    keep_text = ", ".join(keep)
    return (
        "Edit the provided source image. Change only what the requested change needs; every other "
        "part of the picture must match the source as closely as possible. Keep "
        f"{keep_text} exactly as they are, except where the requested change itself alters them. "
        f"Apart from the requested change, do not {', '.join(banned[:-1])} or {banned[-1]} the image, and add "
        "nothing the instruction does not ask for."
    )
