"""Arm: decode unlabelled clue encodings that layered_decode's English test rejects, and replace the clue.

gym black-box-v2 serves clues encoded with no label. With MSQUAD_LAYERED_DECODE (#299) on, the
logic runs still failed, two ways:

- logic clues are mostly names, so their decodes score low on common-English words:
  "Hotel is somewhere between Juliett and Alpha." (hex) scores 0.28, under MIN_ENGLISH 0.4, and
  "India is somewhere ahead of Alpha." (rot13) 0.33, so neither was decoded;
- a decoded clue keeps its raw text, so the logic solver and the entity guard read "Vaqvn" as a
  person and answered "Golf,India,Foxtrot,Vaqvn,Nycun,Hotel".

With this arm on:

- a decode whose first layer is base64, base32 or hex is accepted when it is clean text (printable,
  has a space, at least 80% letters, digits, spaces and punctuation). These alphabets fail on plain
  text, so a clean decode is not a coincidence;
- a rot13-only decode needs the old 0.25 English bar instead of 0.4, plus the same gain over the raw
  clue. rot13 of an English clue is gibberish, so the gain still rules out plain clues;
- a clue that decodes is replaced by its decoded text, not appended to.

reverse keeps #299's rules. Off unless MSQUAD_UNLABELLED_DECODE=1 or DEFAULT_ENABLED.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_UNLABELLED_DECODE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

STRICT_LAYERS = ("base64", "base32", "hex")
ROT13_MIN_ENGLISH = 0.25
_CLEAN_RE = re.compile(r"[A-Za-z0-9 .,;:'\"!?()\-/+=%&]")


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def clean_text(text: str) -> bool:
    """Printable prose: has a space and at least 80% ordinary characters."""
    if not text or " " not in text.strip() or not text.isprintable():
        return False
    return sum(1 for ch in text if _CLEAN_RE.match(ch)) >= 0.8 * len(text) and any(ch.isalpha() for ch in text)


def accept(decoded: str, layers: list[str], score: float, raw_score: float, min_gain: float) -> bool:
    """The relaxed acceptance for an unlabelled decode (see the module docstring)."""
    if layers and layers[0] in STRICT_LAYERS:
        return clean_text(decoded)
    if layers == ["rot13"]:
        return score >= ROT13_MIN_ENGLISH and score >= raw_score + min_gain
    return False
