"""Generate arm: when text is forbidden, defocus the background so stray glyphs cannot be read.

Live generate loses most on the constraints axis. On the repeated neon-street poster the
constraints score swings 66-94 on one prompt (b65d028, runs #233-#265), and every low output has
shop signs with legible glyphs in a sharp background, while the 94s have the same signs
blurred. The guard and the no-signage arm (#215) both say what to draw; this one says how to
shoot it: subject sharp, background as soft bokeh, so whatever signage the model still draws
is light, not writing. A different lever from #215, and the two can stack.

Fires when the request forbids text (same clause rule as image_no_signage) and is not a scene
whose background is the subject (landscape, skyline, panorama, aerial, map, pattern, flat lay)
or that asks for deep focus. Off unless MSQUAD_GENERATE_DEFOCUS=1 or DEFAULT_ENABLED is True,
so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

from msquad import image_no_signage

ENV_FLAG = "MSQUAD_GENERATE_DEFOCUS"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

RULE = (
    "Camera: shallow depth of field. Keep the main subject tack-sharp and let everything behind "
    "it fall into soft, out-of-focus bokeh, so no background sign, screen or surface is legible."
)

_BACKGROUND_IS_SUBJECT_RE = re.compile(
    r"\b(?:landscapes?|vistas?|panoram\w*|skylines?|aerial|bird'?s[- ]eye|maps?|patterns?|"
    r"flat(?:[- ]lay)?|wide[- ]angle|deep focus|everything in focus|sharp background|sunrise|sunset)\b",
    re.IGNORECASE,
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def applies(request: str) -> bool:
    """True when ``request`` forbids text and its background is not the subject."""
    text = " ".join(str(request or "").split())
    return image_no_signage.applies(text) and not _BACKGROUND_IS_SUBJECT_RE.search(text)


def rule_for(request: str) -> str:
    """The camera rule for ``request``, or "" when it does not apply."""
    return RULE if applies(request) else ""
