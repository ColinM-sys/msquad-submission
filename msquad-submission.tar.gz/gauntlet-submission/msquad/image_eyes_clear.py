"""Edit arm: a hat, cap, helmet or pair of glasses added to a subject must leave the eyes readable.

Live edit on 2026-10-28 lost most on preservation (83.3 over 11 main runs). The saved outputs track it
directly: preservation 68 has the added cap pulled over one eye, 76 over both, while 89 and 88 have a small
cap on top with both eyes clear (tester-live runs 568, 587, 578, 589). MSQUAD_EDIT_NO_OCCLUDE says the same
in general terms ("occlude as little as possible"); this names a visible anchor per item instead: a brim
above the brows, or lenses the eyes show through.

Fires only when the instruction adds headwear or eyewear (from an explicit list) to a person; not for
drinking glasses, "all caps", a car hood or a crown on a tree. The rule yields to the requested change itself
by giving no rule at all when the edit covers the eyes (pulled low or over the eyes, sunglasses, dark or
mirrored lenses, goggles, a visor or mask); the eyewear rule is for clear glasses only.
On unless MSQUAD_EDIT_EYES_CLEAR=0 (or another falsy value) or DEFAULT_ENABLED is False, so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_EDIT_EYES_CLEAR"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

EXCEPT = "except where the requested change itself alters them"
HEAD_RULE = (
    "Eyes clear: the added headwear sits on top of the head with any brim or edge above the eyebrows; "
    f"both eyes, the eyebrows and the face outline stay fully visible and unchanged, {EXCEPT}."
)
GLASSES_RULE = (
    "Eyes clear: the added eyewear rests on the nose and ears at the eyes' natural position; both eyes "
    "stay visible through the lenses, and the eyebrows, eye shape and face outline stay unchanged, "
    f"{EXCEPT}."
)

_ADD_RE = re.compile(r"\b(?:add|adds|adding|give|gives|put|place|wear|wearing|dress|with)\b", re.IGNORECASE)
_HEAD_WORDS = (
    r"hats?|sun ?hats?|caps?|beanies?|helmets?|crowns?|tiaras?|berets?|fedoras?|sombreros?|"
    r"bandanas?|headbands?|hoods?"
)
_EYEWEAR_WORDS = r"(?:eye|reading|sun)?glasses|spectacles|lenses|shades|eyewear|visors?|goggles"
# "without" removes something only when an item follows it ("without his hat"); "without changing his
# face" adds the cap and keeps the face (IM3: a bare "without" disabled the rule).
_NOT_ADD_RE = re.compile(
    rf"\b(?:remove|erase|delete|take off)\b|\bwithout (?:the|his|her|their|its|any|a|an) (?:{_HEAD_WORDS}|{_EYEWEAR_WORDS})\b",
    re.IGNORECASE,
)
_HEAD_RE = re.compile(rf"\b(?:{_HEAD_WORDS})\b", re.IGNORECASE)
_GLASSES_RE = re.compile(r"\b(?:(?:eye|reading)?glasses|spectacles)\b", re.IGNORECASE)
# The requested change itself covers the eyes: the rule would contradict it, so it gives no rule.
# dark/mirrored/tinted/opaque count only on eyewear ("dark glasses", "tinted lenses"); on anything else
# they are a colour or finish ("a dark blue baseball cap", IM3).
_COVERS_EYES_RE = re.compile(
    # A veil, or anything "over his face", covers the eyes too (Fable's coverage set, e05 beekeeper veil).
    r"\b(?:over (?:the|his|her|their|its|both) eyes|over (?:the|his|her|their|its) face|veils?|pulled (?:low|down)|low over|"
    rf"(?:dark|mirrored|tinted|opaque)[\w -]{{0,20}}?\b(?:{_EYEWEAR_WORDS})|"
    r"sunglasses|shades|aviators?|goggles|visors?|masks?|blindfolds?)\b",
    re.IGNORECASE,
)
# Glasses you drink from; "caps" as letter case; hoods that are not clothing.
_NOT_EYEWEAR_RE = re.compile(
    r"\b(?:wine|drinking|champagne|water|beer|cocktail|shot|martini|pint|empty|full)\s+glasses\b",
    re.IGNORECASE,
)
_NOT_HEADWEAR_RE = re.compile(r"\b(?:all caps|caps lock|bottle caps?|hubcaps?|(?:car|engine) hood)\b", re.IGNORECASE)
# The item must go on someone who has eyes.
_PERSON_RE = re.compile(
    r"\b(?:subject|person|people|man|men|woman|women|boy|girl|child|children|kid|baby|couple|model|"
    r"cyclist|rider|player|worker|portrait|face|head|he|she|him|her|his|they|them|their)\b",
    re.IGNORECASE,
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def rule_for(instruction: str) -> str:
    """The eyes-clear rule for an instruction that adds headwear or eyewear to a person, else ""."""
    text = " ".join(str(instruction or "").split())
    if not _ADD_RE.search(text) or _NOT_ADD_RE.search(text) or not _PERSON_RE.search(text):
        return ""
    if _COVERS_EYES_RE.search(text):
        return ""
    if _GLASSES_RE.search(_NOT_EYEWEAR_RE.sub(" ", text)):
        return GLASSES_RULE
    if _HEAD_RE.search(_NOT_HEADWEAR_RE.sub(" ", text)):
        return HEAD_RULE
    return ""
