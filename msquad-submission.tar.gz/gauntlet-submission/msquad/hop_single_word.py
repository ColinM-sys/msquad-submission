"""Arm: the second hop may use a single capitalised name, not only two-word names.

_hop_phrases kept only phrases of two or more words, so a single-word entity ("Nordwind") that the documents
named repeatedly was never followed. With this arm on a word counts when it is 4 or more letters, not a
stopword or weekday or month name, not in the question, and appears 2 or more times across the evidence with
at least one occurrence that is not sentence-initial. Off by default. Off unless MSQUAD_HOP_SINGLE_WORD=1 or
DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_HOP_SINGLE_WORD"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

STOPWORDS = frozenset({
    "The", "This", "That", "Each", "Project", "Team", "There", "These", "Those", "When", "Where", "What",
    "Which", "Who", "How", "Why", "Also", "Then", "Here", "Some", "Many", "Most", "Such", "Other",
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday",
    "January", "February", "March", "April", "June", "July", "August", "September", "October",
    "November", "December", "May",
})
_SENTENCE_START_RE = re.compile(r"(?:^|[.!?]\s+)$")


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def eligible(word: str) -> bool:
    """A capitalised word of 4 or more letters that is not a stopword."""
    return len(word) >= 4 and word not in STOPWORDS


def is_sentence_initial(line: str, start: int) -> bool:
    return bool(_SENTENCE_START_RE.search(line[:start]))
