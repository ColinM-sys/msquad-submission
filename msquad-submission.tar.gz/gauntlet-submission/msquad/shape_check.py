"""Check a structured answer against the shape the challenge describes, then re-ask once.

The challenge carries its shape as text ("Required JSON shape: array of object {order_id: string,
note (optional): string}"), written by gym/arena.py describe_schema. This module reads that text,
checks required keys and simple types, and produces messages in jsonschema's wording.
"""

from __future__ import annotations

import asyncio
import json
import re
from typing import Any

_SHAPE_RE = re.compile(r"Required JSON shape:\s*(.*)", re.IGNORECASE | re.DOTALL)
_TYPES = {
    "string": (str,),
    "integer": (int,),
    "number": (int, float),
    "boolean": (bool,),
}


def _split_top_level(text: str) -> list[str]:
    parts, depth, current = [], 0, []
    for char in text:
        if char in "{[":
            depth += 1
        elif char in "}]":
            depth -= 1
        if char == "," and depth == 0:
            parts.append("".join(current))
            current = []
        else:
            current.append(char)
    if "".join(current).strip():
        parts.append("".join(current))
    return [part.strip() for part in parts if part.strip()]


def parse_shape(text: str) -> dict[str, Any] | None:
    """Return {"array": bool, "fields": {key: (required, type_name)}} for an object shape, else None."""
    match = _SHAPE_RE.search(str(text or ""))
    if not match:
        return None
    body = match.group(1).strip()
    is_array = body.lower().startswith("array of ")
    if is_array:
        body = body[len("array of "):].strip()
    if not body.lower().startswith("object {"):
        return None
    start = body.index("{")
    depth, end = 0, len(body)
    for index in range(start, len(body)):
        if body[index] == "{":
            depth += 1
        elif body[index] == "}":
            depth -= 1
            if depth == 0:
                end = index
                break
    fields: dict[str, tuple[bool, str]] = {}
    for entry in _split_top_level(body[start + 1:end]):
        key_part, _, type_part = entry.partition(":")
        required = "(optional)" not in key_part
        key = key_part.replace("(optional)", "").strip()
        type_name = type_part.strip().split(" ")[0] if type_part.strip() else "any"
        if key:
            fields[key] = (required, type_name)
    return {"array": is_array, "fields": fields}


def check_shape(answer: str, shape: dict[str, Any] | None) -> str:
    """Return "" when the answer matches the shape, else a jsonschema-style error message."""
    if shape is None:
        return ""
    try:
        value = json.loads(answer)
    except ValueError:
        return "answer is not valid JSON"
    if shape["array"]:
        if not isinstance(value, list):
            return "answer is not a JSON array"
        items = value
    else:
        items = [value]
    for item in items:
        if not isinstance(item, dict):
            return "item is not a JSON object"
        for key, (required, type_name) in shape["fields"].items():
            if key not in item:
                if required:
                    return f"'{key}' is a required property"
                continue
            allowed = _TYPES.get(type_name)
            if allowed and (not isinstance(item[key], allowed) or (type_name == "integer" and isinstance(item[key], bool))):
                return f"'{key}' is not of type '{type_name}'"
    return ""


async def reask_once(llm_client: Any, model_name: str, task: str, answer: str, error: str, remaining_s: float, margin_s: float, answer_format: str = "") -> str:
    """One re-ask with the validator error. Returns the corrected answer, or "" when it cannot run or does not validate."""
    budget = remaining_s - margin_s
    if budget <= 0:
        return ""
    messages = [
        {"role": "system", "content": "Reply with one line: ANSWER: <one JSON value>. No prose, no code fences."},
        {"role": "user", "content": f"Task: {task}\nRequired format: {(answer_format or 'JSON, as the task asks')[:1000]}\nPrevious answer: {answer}\nValidator error: {error[:1000]}\nReturn the corrected JSON only."},
    ]
    try:
        response = await asyncio.wait_for(
            asyncio.to_thread(
                llm_client.chat.completions.create,
                model=model_name,
                messages=messages,
                max_tokens=2048,
                temperature=0.0,
            ),
            timeout=budget,
        )
    except (asyncio.TimeoutError, TimeoutError, Exception):
        return ""
    content = str(response.choices[0].message.content or "")
    candidate = re.sub(r"^\s*ANSWER:\s*", "", content.strip(), flags=re.IGNORECASE)
    try:
        value = json.loads(candidate)
    except ValueError:
        return ""
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


async def resolve_shape_answer(
    answer: str,
    *,
    answer_format: str,
    rules: str,
    task: str,
    llm_client: Any,
    model_name: str,
    remaining_s: float,
    margin_s: float,
) -> tuple[str, str]:
    """Return (answer to submit, note). A valid answer is kept; an invalid one gets one re-ask."""
    shape = parse_shape(f"{answer_format}\n{rules}")
    error = check_shape(answer, shape)
    if not error:
        return answer, ""
    shape_source = answer_format if _SHAPE_RE.search(answer_format or '') else rules
    corrected = await reask_once(llm_client, model_name, task, answer, error, remaining_s, margin_s, shape_source)
    if corrected and not check_shape(corrected, shape):
        return corrected, f"re-ask validated ({error})"
    return answer, f"re-ask did not validate ({error})"
