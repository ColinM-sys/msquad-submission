"""Ids to follow with one more docs.search: the chain from the question runs through a code the first document names.

"Which auction house sold the clock catalogued as lot 214?" fetched "Lot 214 ... was sold under sale code S-58",
but the house is named only in "S-58 was conducted by Fennimore & Blythe", which shares no word with the question.
The agent's follow-up searches use capitalised names, not codes, so S-58 was never searched (fresh-mix-2
fm2_ret_idhop_lot, both RC2 and the submitted build). This picks the codes (a letter-and-digit or hyphenated token
such as S-58, T-9902, #A-17, 55-B) in the evidence sentences that share a word with the question and that the
question does not already name, best-matching sentence first. Searching one only fetches documents; the answer
still comes from the model.
"""

from __future__ import annotations

import re

from msquad.evidence_fallback import _texts, _words

# A code: letters then digits ("S-58", "T-9902", "A-17", "KV512"), or digits then letters ("55-B"). Not a bare
# number (years, prices, counts).
_ID_RE = re.compile(r"(?<![\w#.-])#?(?:[A-Za-z]{1,4}-?\d[\w-]*|\d+-[A-Za-z][\w-]*)(?![\w-])")
# Not codes (Fable on the id-hop pre-review): durations and counts ("24-hour", "24-month", "5-star"), versions
# ("v2" of "v2.1") and quarters ("Q3").
_NOT_ID_RE = re.compile(
    r"\d+-(?:hour|day|week|month|year|minute|second|star|step|point|page|part)s?|[vVqQ]\d+",
)


def _query(code: str, sentence: str, start: int) -> str:
    """The bare code; with the two words before it when every token of the code is 2 characters or shorter.

    A word search that drops short tokens finds nothing for "S-58" alone, but under AND search extra words make the
    register document miss ("transfer reference TR-4471"), so the lead words are added only when they must be.
    """
    if any(len(token) > 2 for token in re.findall(r"[A-Za-z0-9]+", code)):
        return code
    lead = re.findall(r"[A-Za-z]+", sentence[:start])[-2:]
    return " ".join(lead + [code])


def ids_to_follow(question: str, evidence_lines: list[str], limit: int = 2) -> list[str]:
    """Search queries for codes in question-related evidence sentences that the question does not name."""
    asked = _words(question)
    named = {m.group(0).lstrip("#").lower() for m in _ID_RE.finditer(str(question or ""))}
    sentences = [s for text in _texts(evidence_lines) for s in re.split(r"(?<=[.!?])\s+", text)]
    ranked = sorted(((len(asked & _words(s)), i, s) for i, s in enumerate(sentences)), key=lambda t: (-t[0], t[1]))
    seen: set[str] = set()
    out: list[str] = []
    for overlap, _, sentence in ranked:
        if not overlap:
            break
        for match in _ID_RE.finditer(sentence):
            code = match.group(0).lstrip("#")
            if _NOT_ID_RE.fullmatch(code) or code.lower() in named or code.lower() in seen:
                continue
            seen.add(code.lower())
            out.append(_query(code, sentence, match.start()))
            if len(out) >= limit:
                return out
    return out
