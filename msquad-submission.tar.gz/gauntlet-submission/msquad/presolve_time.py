"""Math arm: deterministic answers for clock times, durations, decimal hours, unit speeds, weekdays and sig figs.

Each rule reads the question by structure, wherever the parts sit in the sentence: clock times (24-hour or
am/pm), durations (digits or number words, hours and minutes in any order), the operation words (arrive, depart,
break, decimal places, significant figures) and the units. A rule declines when a needed part is missing or
appears more than once, when a word changes the meaning (a second leg, a time zone, lateness, a connection), and
when any digit is left unread. No model text is evaluated: arithmetic is integer minutes, Decimal and datetime.
On unless MSQUAD_PRESOLVE_TIME=0 or DEFAULT_ENABLED is False, so it can be A/B tested. Deterministic: no model call.
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal

ENV_FLAG = "MSQUAD_PRESOLVE_TIME"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

MAX_HOURS = 10_000
MINUTES_PER_DAY = 24 * 60

_WORD_NUMBERS = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
    "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
    "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20, "thirty": 30,
    "forty": 40, "fifty": 50, "sixty": 60,
}
_NUM = r"(?:\d{1,12}(?:\.\d+)?|" + "|".join(sorted(_WORD_NUMBERS, key=len, reverse=True)) + r")"
_HOURS_RE = re.compile(rf"(?<![\w.])({_NUM})\s*(?:hours?|hrs?|h)\b", re.IGNORECASE)
_MINUTES_RE = re.compile(rf"(?<![\w.])({_NUM})[\s-]*(?:minutes?|mins?)\b", re.IGNORECASE)
# A clock needs a colon or an am/pm marker, so a bare "2 h" or "24-hour" is never read as a time.
_CLOCK_RE = re.compile(
    r"(?<![\w:.])(?:(\d{1,2}):(\d{2})\s*(?:(a|p)\.?m\.?)?|(\d{1,2})\s*(a|p)\.?m\.?)(?![\w:])", re.IGNORECASE
)
_ARRIVE_RE = re.compile(r"\b(arrive|arrives|arrival|arriving|finish|finishes|end|ends|land|lands)\b", re.IGNORECASE)
_START_RE = re.compile(
    r"\b(depart|departs|departing|leave|leaves|leaving|start|starts|starting|begin|begins|set off)\b", re.IGNORECASE
)
_DECLINE_RE = re.compile(
    r"\b(zone|late|lateness|early|then|again|also|second|third|connection|change|layover|legs?|stops?|"
    r"waits?|waiting|delays?|delayed|total|each|per|minus|plus|withdraw\w*|deposit\w*|twice|every|"
    r"until|before|average|mean|difference|ago|monthly|daily|weekly)\b",
    re.IGNORECASE,
)
# The question asks for a 12-hour answer: the rules decline (input clocks may still be am/pm).
_TWELVE_HOUR_OUT_RE = re.compile(r"\b12[- ]hours?\b|\bam or pm\b|\bwith am/pm\b", re.IGNORECASE)
_DECIMAL_PLACES_RE = re.compile(rf"\b({_NUM})\s+decimal\s+places?\b", re.IGNORECASE)
_SIG_FIGS_RE = re.compile(rf"\b({_NUM})\s+significant\s+figures?\b|\b({_NUM})\s+s\.f\.", re.IGNORECASE)
_WEEKDAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
_ALLOWED_CLOCK_TOKENS = (r"24-hour\s+hh:mm", r"hh:mm")


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _clean(text: str) -> str:
    return " ".join(str(text or "").split())


def _value(token: str) -> Decimal | None:
    """A digit or number-word token as a Decimal, or None."""
    lowered = token.lower()
    if lowered in _WORD_NUMBERS:
        return Decimal(_WORD_NUMBERS[lowered])
    try:
        return Decimal(token)
    except Exception:
        return None


def _mask(text: str, spans: list[tuple[int, int]]) -> str:
    chars = list(text)
    for start, end in spans:
        for index in range(start, end):
            chars[index] = " "
    return "".join(chars)


def _clocks(text: str) -> list[tuple[int, tuple[int, int]]] | None:
    """Every clock time as (minutes after midnight, span), or None when one is out of range."""
    found = []
    for match in _CLOCK_RE.finditer(text):
        if match.group(1) is not None:
            hour, minute, half = int(match.group(1)), int(match.group(2)), match.group(3)
        else:
            hour, minute, half = int(match.group(4)), 0, match.group(5)
        if minute > 59:
            return None
        if half:
            if not 1 <= hour <= 12:
                return None
            hour = hour % 12 + (12 if half.lower() == "p" else 0)
        elif hour > 23:
            return None
        found.append((hour * 60 + minute, match.span()))
    return found


def _durations(text: str) -> tuple[Decimal, list[tuple[int, int]]] | None:
    """Total minutes of the hour and minute phrases, with their spans. None when a unit repeats or is invalid."""
    hours = list(_HOURS_RE.finditer(text))
    minutes = list(_MINUTES_RE.finditer(text))
    if len(hours) > 1 or len(minutes) > 1:
        return None
    total = Decimal(0)
    spans = []
    for match in hours:
        value = _value(match.group(1))
        if value is None or value > MAX_HOURS or value != value.to_integral_value():
            return None
        total += value * 60
        spans.append(match.span())
    for match in minutes:
        value = _value(match.group(1))
        if value is None or value > 59 or value != value.to_integral_value():
            return None
        total += value
        spans.append(match.span())
    return total, spans


def _numbers_are_read(masked: str, allowed: tuple[str, ...] = ()) -> bool:
    """No digit is left unread once the rule has taken its parts and any allowed fixed token."""
    for token in allowed:
        masked = re.sub(token, " ", masked, flags=re.IGNORECASE)
    return re.search(r"\d", masked) is None


def _places(text: str) -> tuple[int, tuple[int, int]] | None:
    matches = list(_DECIMAL_PLACES_RE.finditer(text))
    if len(matches) != 1:
        return None
    value = _value(matches[0].group(1))
    if value is None or value != value.to_integral_value() or value > 6:
        return None
    return int(value), matches[0].span()


def _clock_plus_duration(text: str) -> str | None:
    """One start clock, one duration and an arrival: the clock time the arrival lands on, in 24-hour HH:MM."""
    if _DECLINE_RE.search(text) or _TWELVE_HOUR_OUT_RE.search(text):
        return None
    clocks = _clocks(text)
    durations = _durations(text)
    if not clocks or len(clocks) != 1 or durations is None or not _ARRIVE_RE.search(text):
        return None
    if not _START_RE.search(text):
        return None
    total, duration_spans = durations
    if total <= 0 or total > MAX_HOURS * 60:
        return None
    start, clock_span = clocks[0]
    masked = _mask(text, [clock_span, *duration_spans])
    if not _numbers_are_read(masked, _ALLOWED_CLOCK_TOKENS):
        return None
    end = (start + int(total)) % MINUTES_PER_DAY
    return f"{end // 60:02d}:{end % 60:02d}"


def _span_minus_break(text: str) -> str | None:
    """Two clock times bounding a shift, one unpaid break, and the hours worked to a stated number of places."""
    if _DECLINE_RE.search(text) or "break" not in text.lower() or "hour" not in text.lower():
        return None
    if re.search(r"(?<!un)paid", text, re.IGNORECASE):
        return None
    clocks = _clocks(text)
    durations = _durations(text)
    places = _places(text)
    if not clocks or len(clocks) != 2 or durations is None or places is None:
        return None
    (start, start_span), (end, end_span) = clocks
    total_break, duration_spans = durations
    if total_break <= 0:
        return None
    worked = end - start - int(total_break)
    if worked <= 0:
        return None  # an overnight shift or a break longer than the shift: decline
    decimals, places_span = places
    masked = _mask(text, [start_span, end_span, places_span, *duration_spans])
    if not _numbers_are_read(masked, _ALLOWED_CLOCK_TOKENS):
        return None
    hours = Decimal(worked) / Decimal(60)
    return str(hours.quantize(Decimal(1).scaleb(-decimals), rounding=ROUND_HALF_UP))


_SPEED_RE = re.compile(
    rf"(?<![\w.])({_NUM})\s*(?:km/h|kmh|kph|kilomet(?:re|er)s? per hour|km per hour)\b", re.IGNORECASE
)
_TARGET_WORDS_RE = re.compile(r"\b(?:metres|meters)\s+per\s+second\b", re.IGNORECASE)
_TARGET_UNIT_RE = re.compile(r"\bm/s\b", re.IGNORECASE)


def _speed_to_metres_per_second(text: str) -> str | None:
    """One speed in km/h, a metres-per-second target, and the places the answer rounds to."""
    if _TWELVE_HOUR_OUT_RE.search(text) or re.search(r"\b(late|zone|then|again)\b", text, re.IGNORECASE):
        return None
    speeds = list(_SPEED_RE.finditer(text))
    # "metres per second" names the target; "m/s" alone is the target only when the words are absent.
    targets = list(_TARGET_WORDS_RE.finditer(text)) or list(_TARGET_UNIT_RE.finditer(text))
    places = _places(text)
    if len(speeds) != 1 or len(targets) != 1 or places is None:
        return None
    if speeds[0].start() > targets[0].start():
        return None  # a m/s value stated first and converted to km/h is the reverse question: decline
    value = _value(speeds[0].group(1))
    if value is None:
        return None
    decimals, places_span = places
    masked = _mask(text, [speeds[0].span(), targets[0].span(), places_span])
    if not _numbers_are_read(masked):
        return None
    rounded = (value / Decimal("3.6")).quantize(Decimal(1).scaleb(-decimals), rounding=ROUND_HALF_UP)
    return f"{rounded} m/s" if re.search(r"\bunit\b", text, re.IGNORECASE) else str(rounded)


_MASS_RE = re.compile(rf"(?<![\w.])({_NUM})\s*(?:kg|kilograms?|kilogram)\b", re.IGNORECASE)
_GRAM_RE = re.compile(r"\bgrams?\b|\bg\b", re.IGNORECASE)


def _kilograms_to_grams_sig_figs(text: str) -> str | None:
    """One mass in kg, a grams target after it, and the significant figures the answer rounds to."""
    if _TWELVE_HOUR_OUT_RE.search(text) or re.search(r"\b(late|zone|then|again)\b", text, re.IGNORECASE):
        return None
    masses = list(_MASS_RE.finditer(text))
    sig_matches = list(_SIG_FIGS_RE.finditer(text))
    grams = list(_GRAM_RE.finditer(text))
    if len(masses) != 1 or len(sig_matches) != 1 or not grams:
        return None
    if max(match.start() for match in grams) < masses[0].end():
        return None  # the grams target must come after the mass
    sig = _value(sig_matches[0].group(1) or sig_matches[0].group(2))
    if sig is None or sig != sig.to_integral_value() or not 1 <= sig <= 12:
        return None
    value = _value(masses[0].group(1))
    if value is None:
        return None
    converted = value * 1000
    if converted == 0:
        return None
    masked = _mask(text, [masses[0].span(), sig_matches[0].span()])
    if not _numbers_are_read(masked):
        return None
    sig = int(sig)
    rounded = converted.quantize(Decimal(1).scaleb(converted.adjusted() - sig + 1), rounding=ROUND_HALF_UP)
    if rounded.adjusted() != converted.adjusted():
        # Rounding carried into a new leading digit (9.9999 -> 10.0): the places follow the new digit.
        rounded = converted.quantize(Decimal(1).scaleb(rounded.adjusted() - sig + 1), rounding=ROUND_HALF_UP)
    return format(rounded, "f")


_DATE_RE = re.compile(r"\b(\d{1,2}\s+[A-Za-z]+\s+\d{4}|\d{4}-\d{2}-\d{2})\b")
_DAY_ZERO_RE = re.compile(r"\bday\s+(?:0|zero)\b", re.IGNORECASE)
_OFFSET_RE = re.compile(rf"(?<![\w.])({_NUM})\s+days?\s+(?:later|after)\b", re.IGNORECASE)
_NAMED_DAY_RE = re.compile(r"\b(" + "|".join(_WEEKDAYS) + r")\b", re.IGNORECASE)


def _parse_date(text: str):
    for fmt in ("%Y-%m-%d", "%d %B %Y", "%d %b %Y"):
        try:
            return datetime.strptime(re.sub(r"\s+", " ", text.strip()), fmt).date()
        except ValueError:
            continue
    return None


def _weekday_offset(text: str) -> str | None:
    """A date stated as day 0, a count of days later, and the weekday asked for."""
    if not re.search(r"\bweekday\b|\bday of the week\b", text, re.IGNORECASE):
        return None
    dates = list(_DATE_RE.finditer(text))
    zeros = list(_DAY_ZERO_RE.finditer(text))
    offsets = list(_OFFSET_RE.finditer(text))
    if len(dates) != 1 or len(zeros) != 1 or len(offsets) != 1:
        return None
    day = _parse_date(dates[0].group(1))
    offset = _value(offsets[0].group(1))
    if day is None or offset is None or offset != offset.to_integral_value() or offset > MAX_HOURS:
        return None
    named = list(_NAMED_DAY_RE.finditer(text))
    if len(named) > 1 or (named and named[0].group(1).casefold() != day.strftime("%A").casefold()):
        return None
    spans = [dates[0].span(), zeros[0].span(), offsets[0].span()]
    if named:
        spans.append(named[0].span())
    if not _numbers_are_read(_mask(text, spans)):
        return None
    return (day + timedelta(days=int(offset))).strftime("%A")


_RULES = (_clock_plus_duration, _span_minus_break, _speed_to_metres_per_second, _kilograms_to_grams_sig_figs,
          _weekday_offset)


def presolve_time(description: str, rules: str = "") -> str | None:
    """The bare answer when one rule reads the question, else None."""
    text = _clean(f"{description} {rules}")
    if not text:
        return None
    for rule in _RULES:
        answer = rule(text)
        if answer is not None:
            return answer
    return None


def presolve_time_challenge(challenge_type: str, description: str, rules: str = "") -> str | None:
    """presolve_time for math challenges only; every other type goes to the model."""
    if "math" not in str(challenge_type or "").casefold():
        return None
    return presolve_time(description or "", rules or "")
