"""Arm: when a table resolves the entity and the asked attribute is not one of its columns, search for the entity.

"What is the phone extension of the manager of the depot with the fewest March returns?" fetched a depot table whose
row gives the manager (Rhiannon Dale), but the extension is only in a separate "Extensions" document that shares no
word with the question; RC3 answered "cannot be determined" and main answered the manager's name (fresh-mix-4
fm4_ret_table_hop). With this arm on, a question that asks for a contact-style attribute (extension, room, phone,
email, ...) of the row a superlative picks (fewest, most, highest, ...) in a fetched pipe table, where no column is
that attribute, gets one more docs.search for the picked entity's name. The search only fetches documents; the
answer still comes from the model. The query is the bare name: under an all-words search an added attribute word
("extension" vs the title "Extensions") would make the document miss.
On by default since batch24 (arm-ON rule: 0 answers changed on 5 normal modes; fresh-mix-4 18->19/20); MSQUAD_TABLE_HOP=0 turns it off.
"""

from __future__ import annotations

import os
import re

from msquad.evidence_fallback import _texts

ENV_FLAG = "MSQUAD_TABLE_HOP"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

_ATTRIBUTE_RE = re.compile(
    r"\b(extension|ext|room|office|desk|phone|telephone|mobile|email|e-mail|address|fax|locker|pager)s?\b",
    re.IGNORECASE)
_MIN_RE = re.compile(r"\b(fewest|least|lowest|smallest|minimum|min|shortest|cheapest)\b", re.IGNORECASE)
_MAX_RE = re.compile(r"\b(most|highest|largest|biggest|greatest|maximum|max|longest|top)\b", re.IGNORECASE)
_WORD_RE = re.compile(r"[a-z]+")
_NUMBER_RE = re.compile(r"^-?\d[\d,]*(?:\.\d+)?$")


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _tables(text: str) -> list[list[list[str]]]:
    """Pipe tables in a document: runs of 2+ lines with 2+ '|' each, split into stripped cells."""
    tables, run = [], []
    for line in str(text).splitlines() + [""]:
        if line.count("|") >= 2 or (line.count("|") >= 1 and run and len(line.split("|")) == len(run[0])):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):  # markdown separator row
                run.append(cells)
            continue
        if len(run) >= 3:
            tables.append(run)
        run = []
    return tables


def _words(text: str) -> set[str]:
    return set(_WORD_RE.findall(str(text).lower()))


def _stems(text: str) -> set[str]:
    """Words of 4+ letters cut to their first 5, so "defect" meets the column "Defects"."""
    return {w[:5] for w in _WORD_RE.findall(str(text).lower()) if len(w) >= 4}


def _pick(question: str, table: list[list[str]]) -> str:
    """The entity the question's superlative picks in this table, or ''."""
    header, rows = table[0], [r for r in table[1:] if len(r) == len(table[0])]
    asked = _stems(question)
    if not rows or _words(" ".join(header)) & {m.lower() for m in _ATTRIBUTE_RE.findall(question)}:
        return ""  # the attribute is a column: the table answers it directly
    numeric = [i for i in range(len(header)) if all(_NUMBER_RE.match(r[i].replace(" ", "")) for r in rows)]
    scored = sorted(((len(_stems(header[i]) & asked), i) for i in numeric), reverse=True)
    if not scored or scored[0][0] == 0:
        return ""
    col = scored[0][1]
    values = [float(r[col].replace(",", "").replace(" ", "")) for r in rows]
    want_min = bool(_MIN_RE.search(question)) and not _MAX_RE.search(question)
    target = min(values) if want_min else max(values)
    if values.count(target) != 1:
        return ""  # a tie picks no one
    row = rows[values.index(target)]
    # A named text column the question mentions ("the manager of the depot") holds the entity; else the row key.
    text_cols = [i for i in range(len(header)) if i not in numeric]
    named = [i for i in text_cols[1:] if _stems(header[i]) & asked]
    entity = row[named[0]] if named else (row[text_cols[0]] if text_cols else "")
    return entity if re.search(r"[A-Za-z]", entity) else ""


def entities_to_follow(question: str, evidence_lines: list[str], limit: int = 1) -> list[str]:
    """Search queries (the bare entity name) for the row a superlative picks in a fetched table, when the asked
    attribute is not a column. Empty when the arm is off or nothing qualifies."""
    if not enabled() or not _ATTRIBUTE_RE.search(str(question or "")):
        return []
    if not (_MIN_RE.search(question) or _MAX_RE.search(question)):
        return []
    out: list[str] = []
    for text in _texts(evidence_lines):
        for table in _tables(text):
            entity = _pick(question, table)
            if entity and entity not in out and entity.lower() not in str(question).lower():
                out.append(entity)
                if len(out) >= limit:
                    return out
    return out
