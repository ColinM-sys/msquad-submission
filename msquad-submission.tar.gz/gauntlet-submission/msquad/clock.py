"""Remaining-time reader that survives a renamed or missing clock tool.

The clock tool is found from the live tool list (name or description mentions
time, clock, remaining or deadline) and called with ``agent_id`` only. When no
such tool exists, when its call fails, or when its reply has no usable number,
the reader falls back to a local clock started at registration.
"""

from __future__ import annotations

import time
from typing import Any

CLOCK_HINTS = ("time", "clock", "remaining", "deadline")
# Names that cost, change state or need more input than agent_id: never a clock.
CLOCK_BLOCKS = ("submit", "broadcast", "save", "edit", "generate", "analy", "delete", "image", "search", "challenge")
PREFERRED_CLOCK = "arena.time_remaining"


def _name_schema_description(tool_def: Any) -> tuple[str, dict[str, Any], str]:
    if isinstance(tool_def, dict):
        return (
            str(tool_def.get("name") or ""),
            dict(tool_def.get("inputSchema") or {}),
            str(tool_def.get("description") or ""),
        )
    return (
        str(getattr(tool_def, "name", "") or ""),
        dict(getattr(tool_def, "inputSchema", None) or {}),
        str(getattr(tool_def, "description", "") or ""),
    )


def find_clock_tool(tool_defs: list[Any] | None) -> str | None:
    """The live clock tool's name, or None when discovery shows none."""
    if not tool_defs:
        return None
    by_name: list[str] = []
    by_description: list[str] = []
    for tool_def in tool_defs:
        name, schema, description = _name_schema_description(tool_def)
        if not name:
            continue
        lowered = name.lower()
        if any(block in lowered for block in CLOCK_BLOCKS):
            continue
        if not any(hint in lowered or hint in description.lower() for hint in CLOCK_HINTS):
            continue
        required = set(schema.get("required") or [])
        if required - {"agent_id"}:
            continue
        if any(hint in lowered for hint in CLOCK_HINTS):
            by_name.append(name)
        else:
            by_description.append(name)
    candidates = by_name + by_description
    if PREFERRED_CLOCK in candidates:
        return PREFERRED_CLOCK
    return candidates[0] if candidates else None


def read_remaining_s(payload: Any) -> float | None:
    """Seconds left from a clock reply, or None when no usable number is present."""
    if not isinstance(payload, dict):
        return None
    value = payload.get("time_remaining_s")
    if value is None:
        for key, candidate in payload.items():
            if "remaining" in str(key).lower() and isinstance(candidate, (int, float)):
                value = candidate
                break
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return max(0.0, float(value))


class ClockReader:
    """Seconds left on the challenge clock, from the live tool or a local clock."""

    def __init__(self, mcp_client: Any, agent_id: str, tool_defs: list[Any] | None, time_limit_s: float = 60.0) -> None:
        self._mcp = mcp_client
        self._agent_id = agent_id
        self._clock_tool = find_clock_tool(tool_defs)
        self.time_limit_s = float(time_limit_s or 60.0)
        self.started_at = time.monotonic()

    @property
    def clock_tool(self) -> str | None:
        return self._clock_tool

    def local_remaining(self) -> float:
        return max(0.0, self.time_limit_s - (time.monotonic() - self.started_at))

    async def remaining(self) -> float:
        """Live reading when the clock tool answers with a number, else the local clock."""
        if self._clock_tool is None:
            return self.local_remaining()
        try:
            reply = await self._mcp.call_tool(self._clock_tool, {"agent_id": self._agent_id})
        except Exception:
            return self.local_remaining()
        value = read_remaining_s(_as_dict(reply))
        return self.local_remaining() if value is None else value


def _as_dict(reply: Any) -> Any:
    if isinstance(reply, dict):
        return reply
    text = getattr(reply, "text", None)
    if isinstance(text, str):
        import json

        try:
            return json.loads(text)
        except ValueError:
            return None
    return None
