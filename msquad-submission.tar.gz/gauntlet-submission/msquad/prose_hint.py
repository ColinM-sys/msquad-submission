"""Arm: follow a hint written in prose to an unlisted tool (tool_adapt).

gym black-box-v2 archives the first clue and says only, in arena.clues.list's note: "The
ledger.lookup service can still read it back if you hand it that clue's id in its ref field."
tool_adapt follows machine hints (ledger.lookup(ref='clue_0')), so the archived clue stayed empty.

With this arm on, any reply text (except a clue's own "text") that names a dotted tool not in the
tool list is remembered with the argument the prose names ("in its ref field", "as its id
parameter"; "ref" when none), and an empty or archived clue is then read from that tool with the
clue's own id. No mention, no extra call. Off unless MSQUAD_PROSE_HINT=1 or DEFAULT_ENABLED.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_PROSE_HINT"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

_TOOL_NAME_RE = re.compile(r"\b([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+)\b")
_ARG_RE = re.compile(
    r"\b(?:its|the|in|as|via)\s+[`'\"]?([a-z_][a-z0-9_]*)[`'\"]?\s+(?:field|argument|parameter|arg)\b", re.IGNORECASE
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


# A dotted name that is a file or a domain is never a tool: a note naming "answer_rules.md" made the
# arm call it (Fable on #302).
_NOT_TOOL_SUFFIXES = {
    "md", "txt", "json", "py", "csv", "pdf", "html", "htm", "yaml", "yml", "xml", "png", "jpg", "jpeg", "gif",
    "log", "js", "ts", "zip", "tar", "gz", "docx", "xlsx", "com", "org", "net", "io", "ai", "dev", "gov", "edu",
    "co", "uk", "us", "app", "info",
}


def _framed(text: str, name: str) -> bool:
    """The text presents ``name`` as a tool: "the NAME service/tool/endpoint", "call/use/query NAME"."""
    n = re.escape(name)
    return bool(re.search(
        rf"\b{n}\s+(?:service|tool|endpoint|api)\b|\b(?:call|use|query|ask|invoke)\s+(?:the\s+)?{n}\b",
        text, re.IGNORECASE))


# Bounds: each candidate costs one search of the text, so a long text full of distinct dotted
# names was quadratic (165 KB: 68 s; Fable on #317). Hint notes are short.
SCAN_CHARS = 20_000
MAX_CANDIDATES = 20


def find(text: str, listed: set[str]) -> tuple[str, str] | None:
    """(tool, arg) for the first unlisted dotted name the text frames as a service or tool, or None."""
    text = (text or "")[:SCAN_CHARS]
    candidates: list[str] = []
    for t in _TOOL_NAME_RE.findall(text):
        if (t in candidates or t in listed or t.startswith("arena.") or len(t) < 5  # not "e.g"
                or t.rsplit(".", 1)[-1].lower() in _NOT_TOOL_SUFFIXES):
            continue
        candidates.append(t)
        if len(candidates) >= MAX_CANDIDATES:
            break
    tools = [t for t in candidates if _framed(text, t)]
    if not tools:
        return None
    arg = _ARG_RE.search(text)
    return tools[0], (arg.group(1) if arg else "ref")
