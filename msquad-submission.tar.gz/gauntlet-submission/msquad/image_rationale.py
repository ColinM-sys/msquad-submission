"""Edit arm: the submit_edit rationale as a checklist built from the instruction's own nouns.

Live edit scores compliance_reporting (mean 87.2 over 89 flash-lite runs, range 40-95) and the
submit always carried the fixed "simple_agent dynamic image flow". #186 restated the instruction
and notes as prose plus a generic preserved list (subject identity, pose, ...); live it tied.
This arm reports item by item instead: one line for the requested change, one per element the
instruction or notes name to preserve, one per thing they say to avoid, each with its status,
and only elements the challenge itself names.

Off unless MSQUAD_EDIT_RATIONALE=1 or DEFAULT_ENABLED is True, so it can be A/B tested.
Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_EDIT_RATIONALE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False
FALLBACK = "simple_agent dynamic image flow"
MAX_CHARS = 450

# "..., keeping the rest unchanged" / "while preserving her face": the part after is a keep list.
# (?:(?<!\s)|(?=\S)) on the leading-whitespace patterns: a match starts at a non-space or at the first
# whitespace of a run, the only places leftmost matching could start one (a leading \s* absorbs the rest
# of a run). Without it every space in a long run rescanned to its end (200 KB: >5 s, #318's timing
# test). The splits are unchanged.
_KEEP_SPLIT_RE = re.compile(
    r"(?:(?<!\s)|(?=\S))\s*(?:,\s*)?\b(?:while|and)?\s*(?:keep|keeping|preserve|preserving|maintain|maintaining|leave|leaving)\b\s*",
    re.IGNORECASE,
)
_KEEP_LEAD_RE = re.compile(r"^(?:preserve|keep|maintain|retain|leave)\s+", re.IGNORECASE)
_AVOID_LEAD_RE = re.compile(r"^(?:avoid|do not add|don't add|do not|don't|no)\s+", re.IGNORECASE)
_TRAIL_RE = re.compile(r"(?<!\s)\s+(?:unchanged|untouched|intact|as (?:is|they are|it is)|the same|exactly)$", re.IGNORECASE)
# "leave no outline, shadow or trace of him": a keep lead followed by a negation asks for absence, so every
# item of that list is a restriction, not something to preserve.
_NEG_LEAD_RE = re.compile(r"^(?:no|without(?:\s+any)?|nothing\s+of|none\s+of)\s+", re.IGNORECASE)
# "Keep the driver, no reflections, the road": a determiner ends a carried negation.
_DETERMINER_RE = re.compile(r"^(?:the|a|an|his|her|its|their|our|my|your|both|every|all|each)\s", re.IGNORECASE)
# "the sign text must read exactly OPEN": an exact-text requirement with no keep or avoid lead.
_REQUIRE_RE = re.compile(r"\b(?:must|should)\s+(?:read|say|show|spell)\b", re.IGNORECASE)
# Each alternative owns its leading whitespace: "\s*" followed by "\s+and" backtracked over the whole run.
_LIST_SPLIT_RE = re.compile(r"(?:(?<!\s)|(?=\S))(?:\s*,\s*(?:and\s+|or\s+)?|\s+(?:and|or)\s+)\s*", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _clean(text: str) -> str:
    return " ".join(str(text or "").split()).strip(" .;:,")


def _items(text: str) -> list[str]:
    out = []
    for piece in _LIST_SPLIT_RE.split(_TRAIL_RE.sub("", _clean(text))):
        for part in _colon_split(piece):
            part = _TRAIL_RE.sub("", _clean(part))
            if part and part.lower() not in {item.lower() for item in out}:
                out.append(part)
    return out


def _colon_split(piece: str) -> list[str]:
    """"the man recognisable: same face" is two items, "the following: the dog" is just "the dog", and
    "the ratio: 16:9" stays whole."""
    left, sep, right = piece.partition(": ")
    if not sep or any(ch.isdigit() for ch in right):
        return [piece]
    if left.lower().split()[-1:] in (["following"], ["these"], ["below"]):
        return [right]
    return [left, right]


def _keep_or_avoid(text: str, keep: list[str], avoid: list[str]) -> None:
    """Add the items of a keep clause to ``keep``; a negated item ("no outline, shadow or trace", "the wall,
    without any new objects") sends it and the bare items after it to ``avoid``, until an item that opens
    with a determiner ("no reflections, the road") starts a new kept element."""
    negated = False
    for item in _items(text):
        if _NEG_LEAD_RE.match(item):
            negated, item = True, _NEG_LEAD_RE.sub("", item)
        elif negated and _DETERMINER_RE.match(item):
            negated = False
        if item:
            (avoid if negated else keep).append(item)


def _sentences(text: str) -> list[str]:
    return [s for s in (_clean(s) for s in re.split(r"(?<=[.;!])\s+", str(text or ""))) if s]


def checklist(instruction: str, notes: str) -> tuple[str, list[str], list[str], list[str]]:
    """(the requested change, the elements to preserve, the things to avoid, exact requirements), from the text."""
    head, *rest = _KEEP_SPLIT_RE.split(_clean(instruction), maxsplit=1)
    change = _clean(head)
    keep: list[str] = []
    avoid: list[str] = []
    require: list[str] = []
    if rest:
        _keep_or_avoid(rest[0], keep, avoid)
    for sentence in _sentences(notes):
        if _KEEP_LEAD_RE.match(sentence):
            _keep_or_avoid(_KEEP_LEAD_RE.sub("", sentence), keep, avoid)
        elif _AVOID_LEAD_RE.match(sentence):
            avoid += _items(_AVOID_LEAD_RE.sub("", sentence))
        elif _REQUIRE_RE.search(sentence):
            require.append(sentence[:1].upper() + sentence[1:])
    seen: set[str] = set()
    keep = [k for k in keep if not (k.lower() in seen or seen.add(k.lower()))]
    return change, keep, avoid, require


def build(instruction: str, notes: str) -> str:
    """The compliance checklist for an edit, or FALLBACK when there is no instruction."""
    change, keep, avoid, require = checklist(instruction, notes)
    if not change:
        return FALLBACK
    # Neutral wording (astra IM6): the rationale restates the request; it never claims the change was
    # made or that something was kept, which nothing here has checked.
    lines = [f"Requested change: {change}."]
    lines += [f"Required preservation: {item}." for item in keep]
    lines += [f"Restriction: {item}." for item in avoid]
    lines += [f"Requirement: {item}." for item in require]
    text, out = "", []
    for line in lines:  # whole lines only, so the cap never cuts an item in half
        if len(text) + len(line) + 1 > MAX_CHARS:
            break
        out.append(line)
        text = " ".join(out)
    return text or _cut_words(lines[0])


def _cut_words(line: str) -> str:
    """``line`` cut to MAX_CHARS at a word boundary, ending in an ellipsis."""
    head = line[: MAX_CHARS - 1]
    if " " in head:
        head = head.rsplit(" ", 1)[0]
    return head.rstrip(" ,;:-") + "…"


def rationale_for(challenge, environ: dict | None = None) -> str:
    """The submit rationale for ``challenge``: the checklist on an enabled edit, else FALLBACK."""
    if not enabled(environ) or not getattr(challenge, "input_image_uri", None):
        return FALLBACK
    try:
        return build(getattr(challenge, "prompt", "") or "", getattr(challenge, "reference_notes", "") or "")
    except Exception:
        return FALLBACK
