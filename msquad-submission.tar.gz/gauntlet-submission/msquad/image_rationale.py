"""Edit arm: the submit_edit rationale as a checklist built from the instruction's own nouns.

Live edit scores compliance_reporting (mean 87.2 over 89 flash-lite runs, range 40-95) and the
submit always carried the fixed "simple_agent dynamic image flow". #186 restated the instruction
and notes as prose plus a generic preserved list (subject identity, pose, ...); live it tied.
This arm reports item by item instead: one line for the requested change, one per element the
instruction or notes name to preserve, one per thing they say to avoid, each with its status,
and only elements the challenge itself names.

Off unless MSQUAD_EDIT_RATIONALE=1 or DEFAULT_ENABLED is True, so it can be A/B tested.
Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_EDIT_RATIONALE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False
FALLBACK = "simple_agent dynamic image flow"
MAX_CHARS = 450

# "..., keeping the rest unchanged" / "while preserving her face": the part after is a keep list.
_KEEP_SPLIT_RE = re.compile(
    r"\s*(?:,\s*)?\b(?:while|and)?\s*(?:keep|keeping|preserve|preserving|maintain|maintaining|leave|leaving)\b\s*",
    re.IGNORECASE,
)
_KEEP_LEAD_RE = re.compile(r"^(?:preserve|keep|maintain|retain|leave)\s+", re.IGNORECASE)
_AVOID_LEAD_RE = re.compile(r"^(?:avoid|do not add|don't add|do not|don't|no)\s+", re.IGNORECASE)
_TRAIL_RE = re.compile(r"\s+(?:unchanged|untouched|intact|as (?:is|they are|it is)|the same)$", re.IGNORECASE)
_LIST_SPLIT_RE = re.compile(r"\s*(?:,\s*(?:and\s+|or\s+)?|\s+and\s+|\s+or\s+)\s*", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _clean(text: str) -> str:
    return " ".join(str(text or "").split()).strip(" .;:,")


def _items(text: str) -> list[str]:
    out = []
    for part in _LIST_SPLIT_RE.split(_TRAIL_RE.sub("", _clean(text))):
        part = _TRAIL_RE.sub("", _clean(part))
        if part and part.lower() not in {item.lower() for item in out}:
            out.append(part)
    return out


def _sentences(text: str) -> list[str]:
    return [s for s in (_clean(s) for s in re.split(r"(?<=[.;!])\s+", str(text or ""))) if s]


def checklist(instruction: str, notes: str) -> tuple[str, list[str], list[str]]:
    """(the requested change, the elements to preserve, the things to avoid), all from the text."""
    head, *rest = _KEEP_SPLIT_RE.split(_clean(instruction), maxsplit=1)
    change = _clean(head)
    keep = _items(rest[0]) if rest else []
    avoid: list[str] = []
    for sentence in _sentences(notes):
        if _KEEP_LEAD_RE.match(sentence):
            keep += _items(_KEEP_LEAD_RE.sub("", sentence))
        elif _AVOID_LEAD_RE.match(sentence):
            avoid += _items(_AVOID_LEAD_RE.sub("", sentence))
    seen: set[str] = set()
    keep = [k for k in keep if not (k.lower() in seen or seen.add(k.lower()))]
    return change, keep, avoid


def build(instruction: str, notes: str) -> str:
    """The compliance checklist for an edit, or FALLBACK when there is no instruction."""
    change, keep, avoid = checklist(instruction, notes)
    if not change:
        return FALLBACK
    lines = [f"Change applied: {change} - done."]
    lines += [f"Preserved: {item} - unchanged from the source." for item in keep]
    lines += [f"Avoided: {item} - none added." for item in avoid]
    text, out = "", []
    for line in lines:  # whole lines only, so the cap never cuts an item in half
        if len(text) + len(line) + 1 > MAX_CHARS:
            break
        out.append(line)
        text = " ".join(out)
    return text or _cut_words(lines[0])


def _cut_words(line: str) -> str:
    """``line`` cut to MAX_CHARS at a word boundary, ending in an ellipsis."""
    head = line[: MAX_CHARS - 1]
    if " " in head:
        head = head.rsplit(" ", 1)[0]
    return head.rstrip(" ,;:-") + "…"


def rationale_for(challenge, environ: dict | None = None) -> str:
    """The submit rationale for ``challenge``: the checklist on an enabled edit, else FALLBACK."""
    if not enabled(environ) or not getattr(challenge, "input_image_uri", None):
        return FALLBACK
    try:
        return build(getattr(challenge, "prompt", "") or "", getattr(challenge, "reference_notes", "") or "")
    except Exception:
        return FALLBACK
