"""Run the logic solver over gym/puzzles/logic_*.json and report coverage.

    python -m msquad.check_puzzles
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from msquad.logic_solver import parse_puzzle, solve_logic_puzzle  # noqa: E402

PUZZLE_DIR = REPO_ROOT / "gym" / "puzzles"


def check_all() -> list[dict]:
    rows = []
    for path in sorted(PUZZLE_DIR.glob("logic_*.json")):
        puzzle = json.loads(path.read_text(encoding="utf-8"))
        clues = [clue["text"] for clue in puzzle["clues"]]
        parsed = parse_puzzle(puzzle["challenge_text"], clues)
        started = time.perf_counter()
        answer = solve_logic_puzzle(puzzle["challenge_text"], clues)
        elapsed_ms = (time.perf_counter() - started) * 1000
        rows.append(
            {
                "id": puzzle["id"],
                "difficulty": puzzle["difficulty"],
                "clues": len(clues),
                "parsed": len(clues) if parsed is not None else 0,
                "answered": answer is not None,
                "correct": answer == puzzle["expected_answer"],
                "ms": round(elapsed_ms, 1),
            }
        )
    return rows


def main() -> None:
    rows = check_all()
    print(f"{'id':<16}{'diff':<8}{'clues':>6}{'parsed':>8}{'answered':>10}{'correct':>9}{'ms':>9}")
    for r in rows:
        print(f"{r['id']:<16}{r['difficulty']:<8}{r['clues']:>6}{r['parsed']:>8}{str(r['answered']):>10}{str(r['correct']):>9}{r['ms']:>9}")
    total_clues = sum(r["clues"] for r in rows)
    parsed_clues = sum(r["parsed"] for r in rows)
    print(f"\nparsed puzzles: {sum(1 for r in rows if r['parsed'] == r['clues'])}/{len(rows)}")
    print(f"clue coverage: {parsed_clues}/{total_clues}")
    print(f"answered: {sum(r['answered'] for r in rows)}/{len(rows)}, correct: {sum(r['correct'] for r in rows)}/{len(rows)}")


if __name__ == "__main__":
    main()
