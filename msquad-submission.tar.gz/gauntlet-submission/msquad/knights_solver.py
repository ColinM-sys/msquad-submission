"""Knights and knaves: each islander is a knight (always tells the truth) or a knave (always lies).

Each islander makes one statement. The solver parses the four statement forms used by the gym
("X is a knight.", "X is a knave.", "X and Y are the same kind.", "X and Y are different kinds."),
enumerates every knight/knave assignment, and answers only when exactly one assignment is consistent
with every statement. Anything unparsed, inconsistent with the header, or not unique returns None.
"""

from __future__ import annotations

import itertools
import re

_HEADER = re.compile(r"\b(two|three|four|five|six|seven|eight|\d+) (?:islanders|inhabitants)\b([^.]*)\.", re.IGNORECASE)
_COUNTS = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8}
_SAYS = re.compile(r"^([A-H]) says: \"(.*)\"$")
_IS = re.compile(r"^([A-H]) is a (knight|knave)\.?$")
_SAME = re.compile(r"^([A-H]) and ([A-H]) are the same kind\.?$")
_DIFF = re.compile(r"^([A-H]) and ([A-H]) are different kinds\.?$")


def _letters(challenge_text: str) -> list[str] | None:
    m = _HEADER.search(challenge_text)
    if not m:
        return None
    count_text = m.group(1).lower()
    count = _COUNTS.get(count_text, None) if not count_text.isdigit() else int(count_text)
    letters = re.findall(r"\b[A-H]\b", m.group(2))
    if count is None or len(letters) != count or len(set(letters)) != len(letters):
        return None
    return sorted(letters)


def _statement(text: str, letters: list[str]):
    """Return a predicate over {letter: is_knight}, or None when the statement is not in the grammar."""
    text = text.strip()
    m = _IS.match(text)
    if m and m.group(1) in letters:
        x, kind = m.group(1), m.group(2) == "knight"
        return lambda t: t[x] == kind
    m = _SAME.match(text)
    if m and m.group(1) in letters and m.group(2) in letters:
        x, y = m.group(1), m.group(2)
        return lambda t: t[x] == t[y]
    m = _DIFF.match(text)
    if m and m.group(1) in letters and m.group(2) in letters:
        x, y = m.group(1), m.group(2)
        return lambda t: t[x] != t[y]
    return None


def solve_knights(challenge_text: str, clues: list[str]) -> str | None:
    """Return "A=knight,B=knave,..." (alphabetical) for the unique consistent assignment, else None."""
    letters = _letters(challenge_text)
    if letters is None:
        return None
    if "=knight" not in challenge_text and "knight|knave" not in challenge_text:
        return None
    speakers: list[str] = []
    checks = []
    for clue in clues:
        m = _SAYS.match(clue.strip())
        if not m:
            return None
        speaker, statement = m.group(1), m.group(2)
        if speaker not in letters:
            return None
        pred = _statement(statement, letters)
        if pred is None:
            return None
        speakers.append(speaker)
        checks.append((speaker, pred))
    if sorted(speakers) != letters:
        # Every islander must make exactly one statement.
        return None
    solutions = []
    for kinds in itertools.product([True, False], repeat=len(letters)):
        truth = dict(zip(letters, kinds))
        ok = True
        for speaker, pred in checks:
            said_true = pred(truth)
            # A knight's statement is true; a knave's statement is false.
            if said_true != truth[speaker]:
                ok = False
                break
        if ok:
            solutions.append(truth)
            if len(solutions) > 1:
                return None
    if len(solutions) != 1:
        return None
    truth = solutions[0]
    return ",".join(f"{x}={'knight' if truth[x] else 'knave'}" for x in letters)
