"""Text arm: skip the live clock read before the submit when the synced local clock has plenty left.

Live logic "solve + finalize" is a flat ~530 ms (median 523.5 over 24 runs, daily-330..377) while the
solver itself answers in 0 ms. Profiling the stage in the gym's live-latency-logic mode (seeds
91-95) puts all of it in one call: ``await clock.remaining()``, the arena.time_remaining MCP read
before the submit. The budget was already synced to the server clock at the tool stage, so with
more than LOCAL_OK_ABOVE_S left the read only confirms what ``Budget.deadline_left()`` says. Near
the deadline the live read is kept.

Off unless MSQUAD_FINALIZE_LOCAL_CLOCK=1 or DEFAULT_ENABLED is True, so it can be A/B tested.
"""

from __future__ import annotations

import os
from typing import Any

ENV_FLAG = "MSQUAD_FINALIZE_LOCAL_CLOCK"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

# Below this many seconds left the live clock is read as before (submit-early and time-warning
# decisions start at 15 s).
LOCAL_OK_ABOVE_S = 20.0


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


async def finalize_remaining(clock: Any, budget: Any) -> float:
    """Seconds left for the submit decisions: the synced budget when well clear, else a live read."""
    if enabled() and budget is not None:
        left = budget.deadline_left()
        if left > LOCAL_OK_ABOVE_S:
            return left
    return await clock.remaining()
