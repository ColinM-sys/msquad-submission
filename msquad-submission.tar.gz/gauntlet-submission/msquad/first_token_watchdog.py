"""Arm: give up on a streamed solve that sends no first token within N s, and retry once on the fastest model.

In gym runs, retrieval_easy_01 failed four times the same way: the solve call landed on an upstream that
was queued behind other work, sent nothing for ~42 s, timed out at llm_timeout (remaining - margin),
and left too little time for solve_with_model_fallback's second model, so "unknown" was submitted.
The live organizer proxy could stall the same way on one model.

With this arm on, the streamed solve's read timeout is capped at FIRST_TOKEN_S (httpx applies it to
waiting for the response headers and for each chunk, so a stream that keeps sending tokens, reasoning
included, never trips it, however long it runs). A timeout before the first token raises
FirstTokenTimeout: no same-model create retry, no same-model non-streaming fallback.
solve_with_model_fallback then retries once on the fastest roster model, inside its existing deadline
guards (the long path's llm_timeout is remaining - margin; the short path is wait_for(remaining -
submit margin)), so the submit is never pushed late.

FIRST_TOKEN_S = 20 s. Live data (tester-live, 559 daily runs): the only model that streamed a solve was
gemini-3.6-flash, n = 76, total streamed time p50 7.7 s, p90 11.6 s, p99 = max 17.9 s. The total bounds
time-to-first-token from above, and the logs show thinking tokens arriving within seconds, so 20 s
is p99 + margin. No other roster model has live streaming data; MSQUAD_FIRST_TOKEN_S overrides N.
Off unless MSQUAD_FIRST_TOKEN_WATCHDOG=1 or DEFAULT_ENABLED.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_FIRST_TOKEN_WATCHDOG"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

FIRST_TOKEN_S = 20.0


class FirstTokenTimeout(TimeoutError):
    """A streamed solve sent no first token within first_token_s()."""


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def first_token_s(environ: dict | None = None) -> float:
    value = str((environ if environ is not None else os.environ).get("MSQUAD_FIRST_TOKEN_S", "")).strip()
    try:
        return float(value) if value else FIRST_TOKEN_S
    except ValueError:
        return FIRST_TOKEN_S


def stream_timeout(total_s: float):
    """httpx timeout for the streamed solve: the overall budget, with each read capped at first_token_s()."""
    import httpx

    return httpx.Timeout(total_s, read=min(total_s, first_token_s()))


def is_timeout(exc: BaseException) -> bool:
    import httpx
    import openai

    return isinstance(exc, (openai.APITimeoutError, httpx.TimeoutException))
