"""Arm: run the post-register modality lookup while the tools are re-listed (scored "modality" stage).

After register the agent re-lists its tools (list_tools + list_tool_defs, two MCP round trips) and only
then calls detect_modality, whose session lookup is a separate HTTP round trip. Both are on the scored
clock (live "modality" stage median 515 ms). With this arm on they run at the same time: detect_modality
runs on the tool list known before register while the re-list is in flight, and if the re-listed tools
differ, it runs again on the new list. So the modality is always the one the serial path would give,
and the re-list itself is never skipped (a tool can appear after register, #330). Off unless
MSQUAD_MODALITY_OVERLAP=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import asyncio
import os
from typing import Any, Awaitable, Callable

ENV_FLAG = "MSQUAD_MODALITY_OVERLAP"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


async def relist_and_detect(
    relist: Callable[[], Awaitable[tuple[list[str], list[Any]]]],
    detect_in_thread: Callable[[list[str]], Awaitable[str]],
    known_tools: list[str],
) -> tuple[list[str], list[Any], str]:
    """(tools, tool_defs, modality): the re-list and a detect on ``known_tools`` at once; detect again
    on the re-listed tools only when they differ, so the result equals the serial path's."""
    (tools, tool_defs), modality = await asyncio.gather(relist(), detect_in_thread(list(known_tools)))
    # As sets: the same tools in another order (or listed twice) need no second detect (Fable on #347).
    if set(tools) != set(known_tools):
        modality = await detect_in_thread(list(tools))
    return tools, tool_defs, modality
