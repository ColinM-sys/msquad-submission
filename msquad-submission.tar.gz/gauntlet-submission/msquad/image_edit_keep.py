"""Edit arm: restate what must stay identical as an explicit list.

Edit loses most on the preservation axis (live mean ~82-88). Every edit's reference notes
name what to keep ("Keep his face, expression, crossed arms, grey sweater and the plain
background unchanged"), but inside one sentence of prose. As a list, each item is a
separate requirement the image model is less likely to drop.

Off unless MSQUAD_EDIT_KEEPLIST=1 or DEFAULT_ENABLED is True, so it can be A/B tested.
Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_EDIT_KEEPLIST"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

# "Keep A, B and C unchanged" / "Preserve facial features, camera angle, and background." /
# "Keep the composition, framing and every detail; ...": the list runs to "unchanged" or the clause end.
_KEEP_RE = re.compile(
    r"\b(?:keep|preserve|maintain)\s+(?P<items>[^;.:]+?)\s*"
    r"(?:\b(?:unchanged|exactly as (?:it is|they are)|as (?:it is|they are)|intact|the same)\b|[;.:]|$)",
    re.IGNORECASE,
)
# (?:(?<!\s)|(?=\S)): a match starts at a non-space or at the first whitespace of a run, the only places
# leftmost matching could start one (a leading \s* absorbs the rest of a run). Without it every space in
# a long run rescanned to its end (200 KB: >5 s, #318's timing test). The splits are unchanged.
_SPLIT_RE = re.compile(r"(?:(?<!\s)|(?=\S))\s*(?:,|;|\band\b)\s*", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def keep_items(notes: str) -> list[str]:
    """The things the notes say to keep, in order, without duplicates."""
    text = " ".join(str(notes or "").split())
    items: list[str] = []
    for match in _KEEP_RE.finditer(text):
        for part in _SPLIT_RE.split(match.group("items")):
            part = re.sub(r"^(?:the|both|all|same)\s+", "", part.strip(), flags=re.IGNORECASE).strip(" .")
            if part and part.lower() not in {i.lower() for i in items}:
                items.append(part)
    return items


def keep_list(instruction: str, notes: str) -> str:
    """The edit checklist, or "" when the notes name nothing to keep."""
    items = keep_items(notes)
    if not items:
        return ""
    change = " ".join(str(instruction or "").split()).rstrip(" .")
    lines = [f"- Change only what this asks: {change}" if change else "- Change only what the instruction asks"]
    lines += [f"- Must stay identical: {item}" for item in items]
    lines.append("- Same framing, size and camera angle as the source")
    return "Edit checklist (every item must hold in the final image):\n" + "\n".join(lines)
