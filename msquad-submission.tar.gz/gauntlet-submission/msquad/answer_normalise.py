"""Text arm: fix two answer-format slips the exact judge rejects.

Gym regression check 67941e4 vs eaf31fb (seed 42 / 1234): the local model answered
ho_fx_01 "1,350" for "integer dollars" (expected 1350) and joined names as "Orenco,Metals".
Both are formatting flips of a right answer.

- A bare number with thousands separators loses them ("1,350" -> "1350"), unless the format
  asks for separators, shows a grouped number in its own example ("formatted like 12,500"), or
  asks for a comma-separated list or two values separated by a comma.
- A list whose format asks for one space after each comma gets the missing spaces
  ("Orenco,Metals" -> "Orenco, Metals"). Formats that say "no spaces", or state no spacing,
  are left alone.

Off unless MSQUAD_ANSWER_NORMALISE=1 or DEFAULT_ENABLED is True, so it can be A/B tested.
Deterministic: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_ANSWER_NORMALISE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

_GROUPED_NUMBER_RE = re.compile(r"^-?\d{1,3}(?:,\d{3})+(?:\.\d+)?$")
_KEEPS_SEPARATORS_RE = re.compile(
    r"thousands? separator|with commas|comma-separated|comma separated|\blist\b"
    r"|separated by (?:a )?commas?|commas? between"
    r"|\b\d{1,3}(?:,\d{3})+\b",  # the format's own example is grouped: "formatted like 12,500"
    re.IGNORECASE,
)
_SPACED_LIST_RE = re.compile(r"comma[- ]separated.*\bspace after\b|\bspace after (each|every) comma\b", re.IGNORECASE)
_NO_SPACES_RE = re.compile(r"\bno spaces?\b(?! elsewhere)", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def normalise(answer: str, answer_format: str, environ: dict | None = None) -> str:
    """``answer`` with the two slips fixed when the arm is on; otherwise unchanged."""
    text = str(answer or "")
    if not enabled(environ):
        return text
    fmt = str(answer_format or "")
    stripped = text.strip()
    if _GROUPED_NUMBER_RE.match(stripped) and not _KEEPS_SEPARATORS_RE.search(fmt):
        return stripped.replace(",", "")
    if _SPACED_LIST_RE.search(fmt) and not _NO_SPACES_RE.search(fmt) and re.search(r",\S", stripped):
        return re.sub(r",\s*", ", ", stripped)
    return text
