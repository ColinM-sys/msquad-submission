"""Arm: the modality session lookup reuses register's warm keep-alive connection.

McpArenaClient.detect_modality reads /api/session/{agent_id} with urllib, a new TCP+TLS
connection on the live clock (~0.18 s in the daily-364 probe; register gives no challenge_type,
so the lookup is needed). HttpArenaClient keeps one requests.Session, already connected by
register: the same GET over it skips the handshake.

Off unless MSQUAD_MODALITY_WARM=1 or DEFAULT_ENABLED is True, so it can be A/B tested. Any
failure, or an answer without a text/image challenge_type, falls back to the original lookup.
"""

from __future__ import annotations

import os
from typing import Any
from urllib.parse import quote

from arena_clients.mcp_client import SESSION_LOOKUP_TIMEOUT_S, McpArenaClient

ENV_FLAG = "MSQUAD_MODALITY_WARM"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _warm_session_type(http_client: Any, agent_id: str) -> str:
    """The session's challenge_type read over the client's keep-alive session, or ""."""
    session = getattr(http_client, "_session", None)
    api_base = str(getattr(http_client, "api_base", "") or "")
    if session is None or not api_base or not agent_id:
        return ""
    headers = {"Accept": "application/json"}
    api_key = getattr(http_client, "api_key", None)
    if api_key:
        headers["X-Arena-API-Key"] = api_key
    try:
        response = session.get(
            f"{api_base.rstrip('/')}/api/session/{quote(agent_id, safe='')}",
            headers=headers,
            timeout=SESSION_LOOKUP_TIMEOUT_S,
        )
        if response.status_code >= 400:
            return ""
        payload = response.json()
    except Exception:
        return ""
    value = str((payload or {}).get("challenge_type") or "").lower() if isinstance(payload, dict) else ""
    return value if value in {"text", "image"} else ""


def detect_modality(
    http_client: Any, tools: list[str], agent_id: str, fallback=None, environ: dict | None = None
) -> str:
    """``fallback`` (McpArenaClient.detect_modality), with the session lookup on the warm connection when enabled."""
    if enabled(environ):
        session_type = _warm_session_type(http_client, agent_id)
        if session_type:
            return session_type
    return (fallback or McpArenaClient.detect_modality)(tools, agent_id=agent_id)
