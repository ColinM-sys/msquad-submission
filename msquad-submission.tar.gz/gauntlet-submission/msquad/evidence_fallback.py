"""Arm: when the solve call fails, answer from the tool evidence instead of echoing the question.

A timed-out solve left no reply, so the last-resort fallback built an answer from the challenge text
("Which, Gull Runner") although docs.get had already returned "The Gull Runner departs from Pier 3".
With this arm on, the fallback first takes the evidence sentence that shares the most content words with
the question, and from it the first capitalised or numeric phrase that adds something the question does
not say ("Pier 3"): first one holding the noun a which/what question asks for, then one inside the
sentence, then the word that starts it, and last one that only extends the question's own entity. With no such phrase it falls through to the old fallback. No model call.
Off unless MSQUAD_EVIDENCE_FALLBACK=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import json
import os
import re

ENV_FLAG = "MSQUAD_EVIDENCE_FALLBACK"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

_STOP = frozenset({
    "the", "a", "an", "of", "in", "on", "at", "to", "for", "from", "by", "with", "and", "or", "is", "are",
    "was", "were", "what", "which", "who", "when", "where", "how", "does", "did", "do", "it", "this", "that",
})
# A run of capitalised words and numbers, e.g. "Pier 3", "Gull Runner", "07:40", "42".
_PHRASE_RE = re.compile(r"(?:[A-Z][\w'-]*|\d[\d:.,]*)(?:\s+(?:[A-Z][\w'-]*|\d[\d:.,]*))*")


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def _words(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in _STOP}


def _texts(evidence_lines: list[str]) -> list[str]:
    """The document text in each evidence line ("docs.get: {json}"), or the raw line when it is not JSON."""
    out: list[str] = []
    for line in evidence_lines or []:
        body = str(line).split(": ", 1)[-1]
        try:
            data = json.loads(body)
        except (ValueError, RecursionError):
            out.append(body)
            continue
        items = data.get("results") if isinstance(data, dict) and isinstance(data.get("results"), list) else [data]
        for item in items:
            if isinstance(item, dict) and isinstance(item.get("text"), str):
                out.append(item["text"])
    return out


_NUMBER_FORMAT_RE = re.compile(r"^\s*(?:integer|number|decimal|numeric|float|count)\b", re.IGNORECASE)
_NUMBER_QUESTION_RE = re.compile(r"\bhow\s+(?:many|much|long|far|old|tall|high|deep|wide)\b", re.IGNORECASE)


def expects_number(question: str, answer_format: str = "") -> bool:
    """True when the format starts with a number word or the question asks how many/much/long/... (Fable C2)."""
    return bool(_NUMBER_FORMAT_RE.search(str(answer_format or "")) or _NUMBER_QUESTION_RE.search(str(question or "")))


def answer_from_evidence(question: str, evidence_lines: list[str], answer_format: str = "") -> str:
    """A short answer read from the evidence sentence closest to ``question``, or "" when none stands out.

    When a number is expected, only a phrase with a digit in it can answer: a name in the same sentence
    ("captained by Mara Venn, carried 42 crates") is not a count.
    """
    asked = _words(question)
    if not asked:
        return ""
    best, best_overlap = "", 0
    for text in _texts(evidence_lines):
        for sentence in re.split(r"(?<=[.!?])\s+", text):
            overlap = len(asked & _words(sentence))
            if overlap > best_overlap:
                best, best_overlap = sentence, overlap
    # A run at the sentence start is capitalised only because it starts the sentence ("However",
    # "Since 2019"): it is a last choice, after every run inside the sentence.
    # Tiers: a run holding the asked noun ("which pier" -> "Pier 3"); then runs inside the sentence; then
    # the sentence-initial run; last, runs that only extend the question's own entity ("Gull Runner II").
    noun = asked_noun(question)
    numeric = expects_number(question, answer_format)
    named, inside, initial, extends = [], [], [], []
    numbers: list[tuple[int, str]] = []
    for match in _PHRASE_RE.finditer(best):
        phrase = match.group(0).strip(" .,")
        words = _words(phrase)
        if not words - asked:
            continue
        if re.fullmatch(r"\d[\d:.,]*", phrase):
            numbers.append((match.start(), phrase))
        if numeric and not re.search(r"\d", phrase):
            continue
        if noun and noun in words:
            named.append(phrase)
        elif words & asked:
            extends.append(phrase)
        elif not best[:match.start()].strip():
            initial.append(phrase)
        else:
            inside.append(phrase)
    picked = _pick_number(question, best, numbers, noun, numeric) if len(numbers) > 1 or noun == "year" else ""
    answer = picked or (named or inside or initial or extends or [""])[0]
    if answer and noun and not numeric and noun not in _NUMERIC_NOUNS and _ID_TOKEN_RE.fullmatch(answer):
        return _hop_through_id(answer, best, noun, evidence_lines) or answer
    return answer


# "Which supplier ...?" answered by an id ("88" of batch 88-17, "KV-512", "W77"): the name is in another sentence that
# names the same id and the asked noun ("88-17: supplier Orenco Metals"; trigger-stall retrieval_hard_01).
_ID_TOKEN_RE = re.compile(r"[A-Za-z]{0,4}-?\d[\w-]*")
_NUMERIC_NOUNS = frozenset({
    "year", "number", "date", "time", "day", "month", "floor", "level", "room", "gate", "platform", "page", "version",
    "score", "size", "age", "count", "amount", "price", "total", "percentage", "rate", "temperature", "height", "weight",
})
_NAME_AFTER_RE = re.compile(r"[A-Z][\w'-]*(?:\s+[A-Z][\w'-]*)*")


def _hop_through_id(answer: str, best: str, noun: str, evidence_lines: list[str]) -> str:
    """The capitalised name after ``noun`` in another sentence holding the full id ``answer`` came from, or ""."""
    ids = {m.group(0) for m in _ID_TOKEN_RE.finditer(best) if m.group(0) == answer or m.group(0).startswith(answer + "-")}
    if not ids:
        return ""
    # The id already names the asked thing ("The X200 model was recalled", "flight UA123"): it is the answer (Fable on #464).
    for id_ in ids:
        if re.search(rf"\b{re.escape(noun)}\s+{re.escape(id_)}(?![\w-])|(?<![\w-]){re.escape(id_)}\s+{re.escape(noun)}\b", best, re.I):
            return ""
    # The name must follow the noun directly ("supplier Orenco Metals", "supplier: Orenco Metals"), not appear anywhere after it.
    # Only the noun ignores case: a global re.I would let the name run on into lowercase words (Fable on #464).
    name_re = re.compile(rf"\b(?i:{re.escape(noun)})\b\s*:?\s*({_NAME_AFTER_RE.pattern})")
    for text in _texts(evidence_lines):
        for sentence in re.split(r"(?<=[.!?])\s+", text):
            if sentence == best:
                continue
            tokens = set(_ID_TOKEN_RE.findall(sentence))
            if not ids & tokens:
                continue
            name = name_re.search(sentence)
            if name:
                return name.group(1).strip(" .,")
    return ""


_YEAR_RE = re.compile(r"(?:1[5-9]|20)\d\d")
_COUNT_NOUN_RE = re.compile(r"\bhow\s+(?:many|much)\s+([a-z]+)", re.IGNORECASE)


def _pick_number(question: str, sentence: str, numbers: list[tuple[int, str]], noun: str, numeric: bool) -> str:
    """Which of several numbers in the sentence answers (Fable on #453), or "" to keep the usual pick.

    A year question takes the four-digit year. A count takes the number nearest the counted noun ("has 42 floors").
    Any other number question skips years when another number is there ("spans 310 m", not "finished in 1998").
    """
    years = [p for _, p in numbers if _YEAR_RE.fullmatch(p)]
    if noun == "year":
        return years[0] if years else ""
    if not numeric:
        return ""
    count = _COUNT_NOUN_RE.search(str(question or ""))
    if count:
        stem = count.group(1).lower().rstrip("s")[:5]
        spots = [m.start() for m in re.finditer(rf"\b{re.escape(stem)}", sentence, re.IGNORECASE)]
        if spots:
            return min(numbers, key=lambda n: min(abs(n[0] - s) for s in spots))[1]
    others = [p for _, p in numbers if p not in years]
    return others[0] if years and others else ""


def asked_noun(question: str) -> str:
    """The noun a which/what question asks for: "Which pier ..." -> "pier", "In which year ..." -> "year"."""
    match = re.search(r"\b(?:which|what)\s+([a-z]+)", str(question or "").lower())
    if not match or match.group(1) in _STOP or match.group(1) in {"is", "was", "are", "were"}:
        return ""
    return match.group(1)
