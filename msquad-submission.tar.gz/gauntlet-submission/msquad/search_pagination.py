"""Arm: follow a search reply's continuation field to its next page, at most two extra pages.

A search reply can carry a cursor for the rest of its results (nextCursor, next_cursor, cursor, next_page),
and the search loop ignored it. With this arm on, a continuation value gets the same call again with
``cursor`` set to it, stopping on a repeated cursor, a null value, or when the stage time is up. Off by
default. Off unless MSQUAD_SEARCH_PAGINATION=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_SEARCH_PAGINATION"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True
MAX_EXTRA_PAGES = 2

_CONTINUATION_RE = re.compile(
    r'"(?:nextCursor|next_cursor|cursor|next_page)"\s*:\s*"([^"]+)"'
)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def next_cursor(reply: str) -> str:
    """The continuation value in a search reply, or "" when there is none (a null is not a value)."""
    match = _CONTINUATION_RE.search(reply or "")
    return match.group(1) if match else ""
