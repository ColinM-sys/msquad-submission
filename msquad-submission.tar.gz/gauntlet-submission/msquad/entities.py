"""Entity checks for logic answers.

Hard-mode gym puzzles add distractor clues drawn from other puzzles, so a clue
can name a person who is not in this challenge (for example "Hotel is in slot 5."
in logic_medium_05). A solver that trusts such a clue submits an answer with an
outsider in it. These helpers read the challenge's own entity list and flag
answers that name anyone else.
"""

from __future__ import annotations

import re

_LIST_IN_PARENS = re.compile(r"\(([^()]+)\)")
# Skip the re-solve unless this many seconds remain on the clock.
RESOLVE_MIN_REMAINING_S = 20.0


def entities_from_challenge(challenge_text: str) -> list[str]:
    """Names listed in parentheses in the challenge text, e.g. "(Bravo, Delta, Golf)".

    Returns an empty list when the text does not list its entities, in which case
    no answer is rejected.
    """
    match = _LIST_IN_PARENS.search(challenge_text or "")
    if not match:
        return []
    names = [part.strip() for part in match.group(1).split(",")]
    return [name for name in names if name and " " not in name]


def outside_names(answer: str, entities: list[str]) -> list[str]:
    """Comma-separated answer names that are not in the challenge's entity list."""
    if not entities:
        return []
    allowed = {name.casefold() for name in entities}
    # "Name:colour" and "Name=role" items are checked on the name side only.
    names = [re.split(r"[:=]", part, maxsplit=1)[0].strip() for part in (answer or "").split(",")]
    return [name for name in names if name and name.casefold() not in allowed]


def entity_note(entities: list[str]) -> str:
    """Prompt line that restates the only people in this puzzle."""
    people = ", ".join(entities)
    return (
        f"Only these people are in this puzzle: {people}. "
        "Ignore any clue about anyone else; it does not apply here."
    )


_LITERAL_EMPTY = frozenset({"[]", "{}", "()"})


def is_placeholder(answer: str) -> bool:
    """Empty, or no letters or digits at all (for example "-" from a token-limit stop).

    A literal empty value such as [] or {} is a real answer, not a placeholder.
    """
    text = (answer or "").strip()
    if text in _LITERAL_EMPTY:
        return False
    return not re.search(r"\w", text)


def is_code_task(challenge_type: str) -> bool:
    """True only when the server's challenge type is code (never inferred from the text)."""
    return str(challenge_type or "").strip().lower() == "code"


def accepts_literal_empty(challenge_type: str, answer: str) -> bool:
    """A code answer may be a literal empty value such as [] (its correct repr); logic answers may not."""
    return is_code_task(challenge_type) and str(answer or "").strip() in _LITERAL_EMPTY


def needs_resolve(task: str, answer: str, outsiders: list, challenge_type: str) -> bool:
    """Re-solve only logic/names answers: an empty answer or a name outside the puzzle.

    Gated on the challenge type, so a logic puzzle that mentions "secret code" still re-solves.
    """
    if task != "logic" or is_code_task(challenge_type):
        return False
    return bool(outsiders) or is_placeholder(answer)

