"""Numeric constraint puzzles: each named person has an integer value (an age, a score, a count) in a
bounded domain. Clues give differences, sums, orderings, and fixed values. The solver parses every clue,
brute-forces every assignment in the domain, and answers the question only when exactly one assignment
satisfies all clues. Anything unparsed, out of range, not unique, or not answerable returns None.
"""

from __future__ import annotations

import itertools
import re
import time

from msquad.logic_solver import SEARCH_BUDGET_S, _entities

_DOMAIN = re.compile(r"(?:from|between) (\d+) (?:to|and) (\d+)", re.IGNORECASE)
_QUESTION_OLDEST = re.compile(r"who is the (oldest|youngest|tallest|shortest|largest|smallest)\?", re.IGNORECASE)
_QUESTION_VALUE = re.compile(r"what is (\w+)'s (?:age|score|count|value)\?", re.IGNORECASE)


def _clue_predicate(text: str, names: list[str]):
    """Return a predicate over {name: int}, or None when the clue is outside the grammar."""
    canon = {n.lower(): n for n in names}
    name_re = "(" + "|".join(re.escape(n) for n in sorted(names, key=len, reverse=True)) + ")"
    t = re.sub(r"\s+", " ", text).strip().rstrip(".")
    m = re.fullmatch(name_re + r" is (\d+) years? (older|younger) than " + name_re, t, re.IGNORECASE)
    if m:
        x, k, way, y = canon[m.group(1).lower()], int(m.group(2)), m.group(3).lower(), canon[m.group(4).lower()]
        return (lambda v: v[x] == v[y] + k) if way == "older" else (lambda v: v[x] == v[y] - k)
    m = re.fullmatch(name_re + r" is (older|younger|taller|shorter|larger|smaller) than " + name_re, t, re.IGNORECASE)
    if m:
        x, way, y = canon[m.group(1).lower()], m.group(2).lower(), canon[m.group(3).lower()]
        more = way in ("older", "taller", "larger")
        return (lambda v: v[x] > v[y]) if more else (lambda v: v[x] < v[y])
    m = re.fullmatch(r"the sum of " + name_re + r"'s and " + name_re + r"'s (?:ages|scores|counts|values) is (\d+)",
                     t, re.IGNORECASE)
    if m:
        x, y, total = canon[m.group(1).lower()], canon[m.group(2).lower()], int(m.group(3))
        return lambda v: v[x] + v[y] == total
    m = re.fullmatch(name_re + r" is (\d+)(?: years old)?", t, re.IGNORECASE)
    if m:
        x, k = canon[m.group(1).lower()], int(m.group(2))
        return lambda v: v[x] == k
    m = re.fullmatch(name_re + r" and " + name_re + r" are the same age", t, re.IGNORECASE)
    if m:
        x, y = canon[m.group(1).lower()], canon[m.group(2).lower()]
        return lambda v: v[x] == v[y]
    return None


def solve_numeric(challenge_text: str, clues: list[str]) -> str | None:
    """Return the answer to the question when exactly one assignment in the domain fits every clue."""
    deadline = time.perf_counter() + SEARCH_BUDGET_S
    found = _entities(challenge_text)
    if found is None:
        return None
    names, _groups = found
    domain = _DOMAIN.search(challenge_text)
    if domain is None:
        return None
    lo, hi = int(domain.group(1)), int(domain.group(2))
    if hi < lo or hi - lo > 200:
        return None
    preds = []
    for clue in clues:
        pred = _clue_predicate(clue, names)
        if pred is None:
            return None
        preds.append(pred)
    question_oldest = _QUESTION_OLDEST.search(challenge_text)
    question_value = _QUESTION_VALUE.search(challenge_text)
    if question_oldest is None and question_value is None:
        return None
    solutions = []
    values = range(lo, hi + 1)
    for combo in itertools.product(values, repeat=len(names)):
        if time.perf_counter() > deadline:
            return None
        v = dict(zip(names, combo))
        if all(p(v) for p in preds):
            solutions.append(v)
            if len(solutions) > 1:
                return None
    if len(solutions) != 1:
        return None
    v = solutions[0]
    if question_value is not None:
        who = question_value.group(1)
        canon = {n.lower(): n for n in names}
        if who.lower() not in canon:
            return None
        return str(v[canon[who.lower()]])
    kind = question_oldest.group(1).lower()
    if kind in ("oldest", "tallest", "largest"):
        target = max(v.values())
    else:
        target = min(v.values())
    winners = [n for n in names if v[n] == target]
    return winners[0] if len(winners) == 1 else None
