"""Arm: when a tool refuses a call for a missing token, open a session and retry once (tool_adapt).

gym black-box-v2 gates kb.query (docs.search) behind a handle that only kb.session hands out. The
extra required "token" argument also broke tool_adapt's schema match (two arguments, docs.search
has one), so docs.search never resolved and every retrieval run missed kb.query and kb.open.

With this arm on, token-like arguments (token, handle, session, ...) do not count when matching a
schema; and a call refused for a missing token/auth/session calls the listed tool that opens a
session (no arguments but agent_id; named or described as session/token/auth/login/handle), reads
the token from its reply, and retries the refused call once with it. No refusal, no extra call.
Off unless MSQUAD_TOKEN_RETRY=1 or DEFAULT_ENABLED.
"""

from __future__ import annotations

import os
import re
from typing import Any

ENV_FLAG = "MSQUAD_TOKEN_RETRY"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

TOKEN_ARGS = {"token", "handle", "session", "session_id", "session_handle", "auth", "access_token", "api_token"}
# A refusal for missing auth, not any error naming a session ("session expired" is not one; Fable on #302).
_REFUSED_RE = re.compile(
    r"\b(unauthori[sz]ed|forbidden|unauthenticated|not authenticated)\b"
    r"|\b(missing|required|invalid|needs?|requires?)\b[^.]{0,40}\b(token|auth\w*|credentials?|handle|api[_ ]?key)\b"
    r"|\b(token|auth\w*|credentials?|handle|api[_ ]?key)\b[^.]{0,40}\b(missing|required|invalid)\b",
    re.IGNORECASE,
)
_ISSUER_RE = re.compile(r"\b(session|token|auth\w*|login|handle|sign[- ]?in)\b", re.IGNORECASE)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def is_token_arg(name: str) -> bool:
    return name.lower() in TOKEN_ARGS


def refused_for_token(data: dict[str, Any]) -> bool:
    error = data.get("error")
    if isinstance(error, dict):
        from msquad import token_structured

        # MSQUAD_TOKEN_STRUCTURED (astra W): {"error": {"code", "message"}} is a refusal too.
        if token_structured.enabled():
            error = token_structured.error_text(error)
    return isinstance(error, str) and bool(_REFUSED_RE.search(error))


def find_issuer(tool_defs: dict[str, Any], props_of, exclude: set[str] = frozenset()) -> str:
    """The listed tool that opens a session: no arguments but agent_id, named or described as such.

    Never an arena.* tool or one in ``exclude`` (the canonical tools and what they resolved to):
    calling arena.get_challenge to "open a session" restarts nothing useful (Fable on #302).
    """
    for name, tool_def in tool_defs.items():
        if name.startswith("arena.") or name in exclude or props_of(tool_def):
            continue
        text = f"{name.replace('.', ' ').replace('_', ' ')} {getattr(tool_def, 'description', '') or ''}"
        if _ISSUER_RE.search(text):
            return name
    return ""


def extract_token(data: dict[str, Any]) -> str:
    for key in ("token", "handle", "session", "session_id", "session_handle", "access_token", "auth"):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def token_arg(props: list[str]) -> str:
    """The declared token-like argument, or "token" when the schema names none."""
    return next((p for p in props if is_token_arg(p)), "token")
