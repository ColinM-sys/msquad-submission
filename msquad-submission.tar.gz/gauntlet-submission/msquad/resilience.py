"""Live-event resilience for the Msquad Gauntlet agent.

The organizer's sandbox drops connections, lags the LLM proxy, and loses
responses. This module keeps one agent identity alive through that:

- register once, then resume the existing session after GO;
- recreate the MCP (SSE) client after a disconnect, rediscover tools, and
  continue the same session;
- retry a submit with the identical answer when its response was lost, and
  treat a 409 as "the first answer stands";
- retry 429 and 5xx responses with jittered backoff inside a time budget.

The agent calls these helpers through small hooks in
`examples/python_simple/agent.py`. Nothing here changes the arena contract.
"""

from __future__ import annotations

import asyncio
import random
import re
import threading
import time
from typing import Any, Callable, TypeVar

from arena_clients.http_client import (
    ArenaAPIError,
    ArenaConnectionError,
    HttpArenaClient,
    SessionInfo,
    SubmitResult,
)
from arena_clients.mcp_client import McpArenaClient, McpArenaError
from arena_clients.proxy_headers import build_proxy_headers

from msquad import tool_adapt

T = TypeVar("T")

# Retry budget per operation. The event's time limits are measured in
# minutes; a stuck call should give up well before a round is over.
DEFAULT_BUDGET_S = 120.0
# Closing the MCP session waits at most this long (on reconnect and at exit).
CLOSE_TIMEOUT_S = 3.0
# A submit waits on the arena's judge, so it gets far more than the kit's 30 s read timeout.
SUBMIT_TIMEOUT_S = 120.0
BACKOFF_BASE_S = 0.5
BACKOFF_CAP_S = 8.0
TRANSIENT_STATUS = frozenset({429, *range(500, 600)})
# Calls that only read challenge state, so replaying them after a reconnect is safe.
READ_ONLY_CALLS = frozenset({
    "list_tools", "list_tool_defs", "get_challenge", "get_image_challenge",
    "list_clues", "get_clue", "get_all_clue_texts", "time_remaining",
})


# Programming errors are never retried: they would only burn the budget.
PROGRAMMING_ERRORS = (AttributeError, TypeError, KeyError, AssertionError, NotImplementedError)


class RegistrationTerminal(RuntimeError):
    """Registration is closed for this round. Do not retry."""


def backoff_delay(attempt: int, rng: Callable[[], float] = random.random) -> float:
    """Full-jitter exponential backoff: uniform in [0, min(cap, base * 2**attempt)]."""
    return rng() * min(BACKOFF_CAP_S, BACKOFF_BASE_S * (2**attempt))


def is_transient(exc: BaseException) -> bool:
    """True for failures that a later identical request may clear."""
    if is_registration_too_late(exc):
        return False
    if isinstance(exc, ArenaAPIError):
        return exc.status_code in TRANSIENT_STATUS
    # ValueError covers a response whose body was cut off mid-JSON.
    return isinstance(exc, (ArenaConnectionError, OSError, TimeoutError, ValueError))


def is_registration_too_late(exc: BaseException) -> bool:
    """`register()` wraps the 409 as ArenaConnectionError; the code lives on __cause__."""
    cause = exc.__cause__ if isinstance(exc, ArenaConnectionError) else None
    return isinstance(cause, ArenaAPIError) and cause.code == "registration_too_late"


_TRANSIENT_TOOL_TEXT = re.compile(r"transient|please retry|(?<!\d)5\d\d(?!\d)", re.IGNORECASE)


def is_transient_tool_error(exc: BaseException) -> bool:
    """A tool error the server marks as retryable (upstream 5xx or 'transient'); not a protocol code."""
    return isinstance(exc, McpArenaError) and not exc.code and bool(_TRANSIENT_TOOL_TEXT.search(str(exc)))


def is_not_image_challenge(exc: BaseException) -> bool:
    return isinstance(exc, McpArenaError) and exc.code == "not_image_challenge"


def proxy_headers(agent_id: str, usage_scope: str | None) -> dict[str, str]:
    """X-Agent-ID and X-Round-ID for every proxy call. Round ID is set when the server gave one."""
    return build_proxy_headers(agent_id=agent_id, usage_scope=usage_scope)


def retry_sync(
    fn: Callable[[], T],
    *,
    label: str,
    budget_s: float = DEFAULT_BUDGET_S,
    sleep: Callable[[float], None] = time.sleep,
    clock: Callable[[], float] = time.monotonic,
) -> T:
    """Call `fn` until it succeeds, fails non-transiently, or the budget runs out."""
    deadline = clock() + budget_s
    attempt = 0
    while True:
        try:
            return fn()
        except Exception as exc:
            remaining = deadline - clock()
            if not is_transient(exc) or remaining <= 0:
                raise
            delay = min(backoff_delay(attempt), remaining)
            print(f"   {label}: transient failure ({exc}); retry {attempt + 1} in {delay:.1f}s", flush=True)
            sleep(delay)
            attempt += 1


def register_or_resume(
    http: HttpArenaClient,
    agent_id: str,
    agent_name: str,
    *,
    budget_s: float = DEFAULT_BUDGET_S,
) -> SessionInfo:
    """Register once per round. An existing session (a restart after GO) is resumed, not re-registered.

    Lobby waiting lives in `HttpArenaClient.register()`. `registration_too_late`
    is terminal and raises `RegistrationTerminal`.
    """
    try:
        existing = http.get_session(agent_id)
    except (ArenaAPIError, ArenaConnectionError):
        existing = None  # no session yet (or unreadable): fall through to registration
    if isinstance(existing, dict) and existing.get("session_id"):
        print(f"   Resuming existing session {existing['session_id']} (no re-registration)", flush=True)
        return SessionInfo(
            session_id=existing["session_id"],
            agent_id=existing.get("agent_id", agent_id),
            agent_name=existing.get("agent_name", agent_name),
            status=existing.get("status", ""),
            started_at=existing.get("started_at", 0.0),
        )
    try:
        return retry_sync(lambda: http.register(agent_id, agent_name), label="register", budget_s=budget_s)
    except Exception as exc:
        if is_registration_too_late(exc):
            raise RegistrationTerminal(
                "Registration closed for this round (registration_too_late). Register in the next lobby."
            ) from exc
        raise


def submit_resilient(
    http: HttpArenaClient,
    agent_id: str,
    answer: str,
    client_metrics: dict[str, Any] | None = None,
    challenge_type: str | None = None,
    *,
    budget_s: float = DEFAULT_BUDGET_S,
) -> SubmitResult:
    """Submit `answer`. A lost or timed-out response is recovered without replacing the answer.

    After any failed attempt the session is read back first. If the first
    submission already landed, its receipt is returned and nothing is resent.
    Otherwise the identical answer is retried. On 409 the first submission is
    official: return its receipt instead of trying to replace it.
    """
    # Clients without a read timeout (test doubles) are used as-is.
    previous_timeout = getattr(http, "timeout", None)
    if previous_timeout is not None:
        http.timeout = max(previous_timeout, SUBMIT_TIMEOUT_S)
    failed_once = False

    def attempt() -> SubmitResult:
        nonlocal failed_once
        if failed_once:
            landed = _landed_receipt(http, agent_id)
            if landed is not None:
                return landed
        kwargs: dict[str, Any] = {"client_metrics": client_metrics}
        if challenge_type is not None:
            kwargs["challenge_type"] = challenge_type
        try:
            return http.submit(agent_id, answer, **kwargs)
        except ArenaAPIError as exc:
            if exc.status_code != 409:
                raise
            return original_receipt(http, agent_id)
        except Exception:
            failed_once = True
            raise

    try:
        return retry_sync(attempt, label="submit", budget_s=budget_s)
    finally:
        if previous_timeout is not None:
            http.timeout = previous_timeout


def _landed_receipt(http: HttpArenaClient, agent_id: str) -> SubmitResult | None:
    """Return the first submission's receipt if the server already recorded one, else None."""
    try:
        session = http.get_session(agent_id)
    except (ArenaAPIError, ArenaConnectionError):
        return None  # cannot tell: the identical-answer resend is the safe path
    if session.get("status") != "submitted" and not session.get("submission"):
        return None
    return original_receipt(http, agent_id)


def original_receipt(http: HttpArenaClient, agent_id: str) -> SubmitResult:
    """Build the receipt of the first recorded submission from the session."""
    session = http.get_session(agent_id)
    submission = session.get("submission") or {}
    return SubmitResult(
        accepted=bool(submission.get("accepted", session.get("accepted", False))),
        agent_id=agent_id,
        answer=str(submission.get("answer", session.get("answer", ""))),
        score=session.get("score"),
        status=str(session.get("status", "")),
    )


class ResilientMcp:
    """`McpArenaClient` that reconnects on transport loss and keeps the same agent session.

    Use as `async with ResilientMcp(url, agent_id=...) as mcp:`. Any awaitable
    method of `McpArenaClient` is available on the wrapper. Protocol errors
    (`McpArenaError`, including `locked` and `not_image_challenge`) are not
    retried here; the caller handles them.
    """

    def __init__(self, mcp_url: str, *, agent_id: str, budget_s: float = DEFAULT_BUDGET_S) -> None:
        self._mcp_url = mcp_url
        self._agent_id = agent_id
        self._budget_s = budget_s
        self._client: McpArenaClient | None = None
        self.tools: list[str] = []
        self.tool_defs: list[Any] = []
        self._tool_hints: dict[str, tuple[str, str]] = {}  # tool_adapt: kept across reconnects
        self.reconnects = 0
        # Calls in flight on the shared session: a failing call drops the connection only when it
        # is the last one, so a background call's transport error cannot kill a concurrent call.
        self._inflight = 0
        # Set once the challenge clock is known: retries never run past it (cap_retries_until).
        self._retry_until: float | None = None

    def set_budget(self, budget_s: float) -> None:
        """Change the reconnect / read-only retry budget (the early connect uses a short one)."""
        self._budget_s = budget_s

    def cap_retries_until(self, monotonic_deadline: float) -> None:
        """Stop reconnecting and retrying read-only calls at ``monotonic_deadline``.

        The default budget (DEFAULT_BUDGET_S, 120 s) is longer than a challenge (45-60 s): a
        dropped connection while reading clues kept retrying past the deadline, so the answer
        was late or never sent. The agent caps it at challenge receipt.
        """
        if self._retry_until is None or monotonic_deadline < self._retry_until:
            self._retry_until = monotonic_deadline

    def _retry_deadline(self) -> float:
        deadline = time.monotonic() + self._budget_s
        return deadline if self._retry_until is None else min(deadline, self._retry_until)

    async def __aenter__(self) -> "ResilientMcp":
        await self._connect_with_retry()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self._close()

    async def _close(self) -> None:
        client, self._client = self._client, None
        if client is not None:
            # Bounded in THIS task: the SSE client's anyio cancel scope must exit in the task that
            # entered it (Fable on #258), and a close that never returns held the process open
            # after the submit (image hang audit F-B). asyncio.timeout raises TimeoutError here.
            try:
                async with asyncio.timeout(CLOSE_TIMEOUT_S):
                    await client.__aexit__(None, None, None)
            except Exception:
                pass

    async def drop(self) -> None:
        """Close the session (bounded); the next call connects a fresh one."""
        await self._close()

    async def reopen(self) -> None:
        """Close the session and connect a fresh one (tools rediscovered), within the retry budget."""
        await self._close()
        self.reconnects += 1
        await self._connect_with_retry()

    async def _connect(self) -> None:
        client = await McpArenaClient(self._mcp_url).__aenter__()
        self._client = client
        # Rediscover tools on every connection; the server decides what is available.
        self.tools = await client.list_tools()
        self.tool_defs = await client.list_tool_defs()
        inner = getattr(client, "_session", None)
        if tool_adapt.enabled() and inner is not None:
            # black-box server: canonical names and arguments resolve to what it lists (arm, off by default)
            session = tool_adapt.AdaptiveSession(inner, self.tool_defs, self._tool_hints)
            client._session = session
            self.tools = tool_adapt.with_aliases(self.tools, session)

    async def _connect_with_retry(self) -> None:
        deadline = self._retry_deadline()
        attempt = 0
        while True:
            try:
                await self._connect()
                return
            except (asyncio.CancelledError, *PROGRAMMING_ERRORS):
                raise
            except Exception as exc:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise
                await self._close()
                delay = min(backoff_delay(attempt), remaining)
                print(f"   MCP connect failed ({exc}); retry in {delay:.1f}s", flush=True)
                await asyncio.sleep(delay)
                attempt += 1

    async def _call(self, name: str, args: tuple, kwargs: dict) -> Any:
        self._inflight += 1
        try:
            return await self._call_tracked(name, args, kwargs)
        finally:
            self._inflight -= 1

    async def _drop_connection(self, failed_on: Any, *, others_may_share: bool) -> None:
        # Only the client the call failed on is dropped: a sibling that already reconnected keeps
        # its new client. A failed tool call (not replayed) also leaves the connection to any call
        # still in flight on it, so a background call's transport error cannot kill the image call.
        if self._client is not failed_on:
            return
        if others_may_share and self._inflight > 1:
            return
        await self._close()

    async def _call_tracked(self, name: str, args: tuple, kwargs: dict) -> Any:
        if name not in READ_ONLY_CALLS:
            # Writes and tool calls are not replayed. Drop the dead connection so the
            # next call reconnects, and let the caller's own failure handling run.
            client = None
            try:
                if self._client is None:
                    await self._connect_with_retry()
                client = self._client
                return await getattr(client, name)(*args, **kwargs)
            except (McpArenaError, asyncio.CancelledError):
                raise
            except Exception:
                await self._drop_connection(client, others_may_share=True)
                raise
        deadline = self._retry_deadline()
        attempt = 0
        while True:
            client = None
            try:
                if self._client is None:
                    await self._connect_with_retry()
                client = self._client
                return await getattr(client, name)(*args, **kwargs)
            except McpArenaError as exc:
                # A read-only tool error that says "retry" (an upstream 5xx) is transient;
                # protocol errors such as "locked" are not.
                if not is_transient_tool_error(exc) or time.monotonic() >= deadline:
                    raise
                delay = min(backoff_delay(attempt), max(0.0, deadline - time.monotonic()))
                print(f"   MCP {name} transient tool error ({exc}); retry in {delay:.1f}s", flush=True)
                await asyncio.sleep(delay)
                attempt += 1
            except (asyncio.CancelledError, *PROGRAMMING_ERRORS):
                raise
            except Exception as exc:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise
                self.reconnects += 1
                delay = min(backoff_delay(attempt), remaining)
                print(f"   MCP {name} lost ({exc}); reconnect {self.reconnects} in {delay:.1f}s", flush=True)
                await self._drop_connection(client, others_may_share=False)
                await asyncio.sleep(delay)
                attempt += 1

    def __getattr__(self, name: str) -> Callable[..., Any]:
        if name.startswith("_"):
            raise AttributeError(name)

        async def call(*args: Any, **kwargs: Any) -> Any:
            return await self._call(name, args, kwargs)

        return call


# While register waits for the lobby, the MCP session opened before it is pinged this often, so
# an idle SSE connection is not dropped by a proxy; the wait itself runs off the event loop.
LOBBY_KEEPALIVE_S = 10.0
LOBBY_PING_TIMEOUT_S = 5.0
# A session that failed its ping is reopened during the wait (off the clock), within this bound.
LOBBY_REOPEN_TIMEOUT_S = 15.0


async def _until_done_or(step, timeout_s: float, outcome: asyncio.Future) -> bool | None:
    """Run ``step()`` until it finishes, ``timeout_s`` passes or ``outcome`` (register) completes.

    True: it finished without error. False: it failed or timed out. None: register returned
    first - the step is cancelled at once, so nothing waits on it once the live clock runs.
    """
    task = asyncio.ensure_future(step())
    done, _ = await asyncio.wait({task, outcome}, timeout=timeout_s, return_when=asyncio.FIRST_COMPLETED)
    if task in done:
        return task.exception() is None
    task.cancel()
    task.add_done_callback(lambda t: t.cancelled() or t.exception())
    return None if outcome.done() else False


async def register_waiting(
    http: HttpArenaClient, agent_id: str, agent_name: str, mcp: "ResilientMcp | None" = None
) -> tuple[SessionInfo, float]:
    """register_or_resume without blocking the event loop; returns ``(session, waited_s)``.

    HttpArenaClient.register sleeps (up to ARENA_REGISTRATION_TIMEOUT_S, 600 s) while the lobby
    is closed. Run inline it froze the loop, and the MCP session opened before registering sat
    idle the whole time. Here it runs on a daemon thread; meanwhile ``mcp`` is pinged every
    LOBBY_KEEPALIVE_S (a read-only list_tools), and a session whose ping failed is reopened
    during the wait, still off the clock. Every ping and reopen is raced against register:
    when it returns (the live clock starts), the step is cancelled at once (second Fable review
    of #285). A session left mid-ping or mid-reopen at that point is dropped, so the first call
    after register connects fresh instead of meeting a half-open stream.
    """
    loop = asyncio.get_running_loop()
    outcome: asyncio.Future = loop.create_future()
    finished_at: list[float] = []

    def deliver(result) -> None:
        if not outcome.done():
            finished_at.append(time.monotonic())
            outcome.set_result(result)

    def run() -> None:
        try:
            result = (register_or_resume(http, agent_id, agent_name), None)
        except BaseException as exc:  # handed to the awaiting task, re-raised there
            result = (None, exc)
        try:
            loop.call_soon_threadsafe(deliver, result)
        except RuntimeError:  # the loop closed (the agent was cancelled): nothing left to tell
            pass

    started = time.monotonic()
    threading.Thread(target=run, name="register", daemon=True).start()
    unsettled = False  # a ping or reopen was cut off by register returning
    while not outcome.done():
        await asyncio.wait({outcome}, timeout=LOBBY_KEEPALIVE_S)
        if outcome.done() or mcp is None:
            continue
        pinged = await _until_done_or(mcp.list_tools, LOBBY_PING_TIMEOUT_S, outcome)
        if pinged is False:
            print("   MCP keepalive during the lobby wait failed; reopening the session", flush=True)
            pinged = await _until_done_or(mcp.reopen, LOBBY_REOPEN_TIMEOUT_S, outcome)
        unsettled = pinged is None
    session, error = outcome.result()
    if error is not None:
        raise error
    if mcp is not None and unsettled:
        await mcp.drop()  # bounded (CLOSE_TIMEOUT_S); the next call reconnects
    return session, finished_at[0] - started


async def resolve_modality(mcp: ResilientMcp, modality: str, agent_id: str) -> tuple[str, list[str]]:
    """Confirm an image assignment before the image path runs.

    On `not_image_challenge` the authoritative heat is text: rediscover tools
    and return "text". Do not keep probing the image tool.
    """
    if modality != "image":
        return modality, mcp.tools
    try:
        await mcp.get_image_challenge(agent_id)
    except McpArenaError as exc:
        if is_not_image_challenge(exc):
            print("   Server says this heat is text; rediscovering tools.", flush=True)
            return "text", await mcp.list_tools()
    return modality, mcp.tools
