"""Arm: cap the post-register modality lookup so a slow session API cannot hold the challenge fetch.

detect_modality reads /api/session (10 s x 2 attempts) and then /api/competition (5 s) with blocking
urllib calls. Run inline on the event loop, a stalled session API froze the loop for up to 25 s after
register, on the scored clock, before get_challenge was even asked (fuzz case a8: fetch at t=45 s).
With this arm on, the lookup runs on a daemon thread, so the loop stays responsive. When exactly one of
the two get_challenge tools is listed, it is awaited for at most CAP_S, and a lookup that does not answer
in time is replaced by the tool set, which names the modality on its own. When both are listed (every
live heat, text and image), the lookup is awaited to the end: a slow lookup still answers live (max
5.03 s over 399 runs) and the tool set would say "text" for an image heat (Fable review of #507). A
lookup that answers gives exactly the old result. On by default; set MSQUAD_MODALITY_CAP=0 to run the
lookup inline as before.
"""

from __future__ import annotations

import asyncio
import os
from typing import Awaitable, Callable

ENV_FLAG = "MSQUAD_MODALITY_CAP"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True
# The live session lookup answers in ~0.2 s (p99); 3 s leaves room for a slow-but-alive API.
CAP_S = 3.0


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def tool_set_modality(tools: list[str]) -> str:
    """The tool-set heuristic that ends McpArenaClient.detect_modality (mcp_client.py), with no network."""
    tool_set = set(tools)
    has_text = "arena.get_challenge" in tool_set
    has_image = "arena.image.get_challenge" in tool_set
    if has_image and not has_text:
        return "image"
    return "text"


def tools_are_unambiguous(tools: list[str]) -> bool:
    """Exactly one of the two get_challenge tools is listed, so the tool set alone names the modality."""
    tool_set = set(tools)
    return ("arena.get_challenge" in tool_set) != ("arena.image.get_challenge" in tool_set)


IMAGE_TOOL = "arena.image.get_challenge"


def fallback_modality(tools: list[str], image_guess: bool = False) -> str:
    """The modality when no lookup answered. With ``image_guess`` (MSQUAD_MODALITY_SWITCH on): "image"
    whenever the image fetch is listed, since the image fetch now turns a text heat's not_image_challenge
    into the text path; a "text" guess has no such way back. Without it: the tool-set heuristic."""
    if image_guess and IMAGE_TOOL in set(tools):
        return "image"
    return tool_set_modality(tools)


def lookup_tools(tools: list[str], image_guess: bool = False) -> list[str]:
    """The tool list handed to detect_modality, whose last step (both lookups failed) reads the tools.

    With ``image_guess`` and the image fetch listed it gets that tool alone, so a failed lookup ends in
    "image". A lookup that answers never reads the tools, so its result is unchanged.
    """
    if image_guess and IMAGE_TOOL in set(tools):
        return [IMAGE_TOOL]
    return list(tools)


async def capped_detect(
    detect_in_thread: Callable[[], Awaitable[str]], tools: list[str], cap_s: float = CAP_S, image_guess: bool = False
) -> str:
    """``detect_in_thread()``'s modality if it answers within ``cap_s``, else the tool-set modality.

    asyncio.wait, not wait_for: wait_for waits for the cancelled call to unwind. The thread itself
    is a daemon and is left to finish on its own.
    """
    task = asyncio.ensure_future(detect_in_thread())
    if not tools_are_unambiguous(tools):
        # Both challenge tools listed (every live heat, text or image): the tool set cannot tell them
        # apart, so the lookup is awaited to the end, as before; it only no longer blocks the loop.
        return await task
    done, _ = await asyncio.wait({task}, timeout=max(0.0, cap_s))
    if task in done and task.exception() is None:
        return task.result()
    if task in done:
        print(f"   ⚠️  modality lookup failed ({task.exception()!r}); using the tool set", flush=True)
    else:
        task.cancel()
        print(f"   ⚠️  modality lookup did not answer in {cap_s:.0f}s; using the tool set", flush=True)
    return fallback_modality(tools, image_guess)
