"""Per-stage wall-clock marks for one agent run (log only, no behaviour change).

Live runs that need no model call still take 12-15 s against about 1 s in the local
gym. Each mark prints the time since the previous mark and since the timer started,
and the marks go into the run record, so a live run shows where the fixed time goes.
"""

from __future__ import annotations

import time


class StageTimer:
    def __init__(self, clock=time.monotonic) -> None:
        self._clock = clock
        self._start = clock()
        self._last = self._start
        self.marks: list[dict[str, float | str]] = []

    def mark(self, stage: str) -> None:
        """Record ``stage`` as finished now and print one timing line. Never raises."""
        try:
            now = self._clock()
            step_ms = round((now - self._last) * 1000, 1)
            total_ms = round((now - self._start) * 1000, 1)
            self._last = now
            self.marks.append({"stage": stage, "step_ms": step_ms, "total_ms": total_ms})
            print(f"   ⏱  {stage}: +{step_ms:.0f} ms (t={total_ms:.0f} ms)", flush=True)
        except Exception:
            pass
