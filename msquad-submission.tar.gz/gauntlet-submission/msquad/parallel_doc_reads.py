"""Arm: read the selected document ids concurrently instead of one after another (astra P).

The retrieval tool stage fetches up to three ids from docs.get, each awaited before the next starts, so
three reads cost three round trips. With this arm on they run at once and their evidence lines keep
the id order, so the solve prompt is the same text. Each read still has its own timeout and a failed
read is skipped, as before. Off by default: concurrent calls can meet a server's rate limit, so it
ships only after a live check. Off unless MSQUAD_PARALLEL_DOC_READS=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import asyncio
import os
from typing import Any, Awaitable, Callable

ENV_FLAG = "MSQUAD_PARALLEL_DOC_READS"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


async def read_all(ids: list[str], read: Callable[[str], Awaitable[Any]]) -> list[Any]:
    """read(id) for every id at once; results in id order, an exception in place of a failed read."""
    return list(await asyncio.gather(*(read(doc_id) for doc_id in ids), return_exceptions=True))
