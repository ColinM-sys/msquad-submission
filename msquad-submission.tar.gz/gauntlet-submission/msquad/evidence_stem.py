"""Arm: the evidence window also matches inflections of the question's content words.

evidence_window scores a sentence by the question words it repeats exactly, so "Which company repaired the corroded
valve?" missed "corrosion ... the repair was carried out by Penrose Valves" (fresh-mix-3 fm3_ret_longdoc): every
section tied on "valve" and the window kept the early ones, a decoy among them. With this arm on, a lowercase
content word of the question also matches a word sharing its first STEM_CHARS letters (corroded/corrosion,
repaired/repair, valves/valve, batteries/battery). An exact match scores 2 and a stem-only match 1, so a sentence
that ranks on exact words today never loses to one that only shares stems with the question.
Names (capitalised question words) and numbers are never stemmed. Deterministic, set lookups only.
On by default since batch23 (arm-ON rule 10/10 modes); MSQUAD_EVIDENCE_STEM=0 turns it off.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_EVIDENCE_STEM"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True

STEM_CHARS = 5
_WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9'-]*")


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def stem(word: str) -> str:
    """The first STEM_CHARS letters of a lowercased word; a shorter word is its own stem (matches exactly)."""
    low = word.lower()
    return low[:STEM_CHARS] if len(low) >= STEM_CHARS else "=" + low


def stem_terms(question: str, stop: frozenset = frozenset()) -> frozenset:
    """Stems of the question's lowercase content words (names and numbers excluded)."""
    out = set()
    for word in _WORD_RE.findall(str(question or "")):
        if word[:1].islower() and len(word) >= STEM_CHARS and word.lower() not in stop:
            out.add(stem(word))
    return frozenset(out)
