"""Arm: an answer recovered from the tool evidence survives the final pass (astra E).

When the primary reply has no usable answer, the solve asks the model to answer from the tool evidence
(_derive_answer_from_evidence). That sets ``answer`` but leaves ``raw_content`` as the primary reply,
and main() finalizes the raw reply again later and takes that result, so the recovered answer was lost
("No conclusion yet" was finalized instead of "42"). With this arm on, a successful recovery also
replaces the raw reply with "ANSWER: <recovered>", so the final pass reads the recovered answer.
Off unless MSQUAD_KEEP_EVIDENCE_ANSWER=1 or DEFAULT_ENABLED is True.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_KEEP_EVIDENCE_ANSWER"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def raw_for(recovered: str, raw_content: str) -> str:
    """The raw reply the final pass should read: the recovered answer when the arm is on."""
    if enabled() and str(recovered or "").strip():
        return f"ANSWER: {str(recovered).strip()}"
    return raw_content
