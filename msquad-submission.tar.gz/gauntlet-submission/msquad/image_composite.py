"""Edit arm: keep the source's own pixels outside the region the edit changed.

Live edit loses most on preservation (median 86 over 52 tester-live edit runs, low 72). The
outputs are the input's size, but the image model re-renders the whole picture: a uniform
darkening (red and green about -7/255) and small drift next to the edit (the face under an
added cap, the hair beside it), and those cells track lower preservation (r -0.2 to -0.4).
Compositing the edit onto the source outside a feathered change mask keeps the edit and
puts every untouched pixel back exactly.

Skipped (the edit is returned as is) when the change covers most of the picture (a restyle or
a re-framed scene, where a mask would cut the edit) or almost none of it (nothing to protect).
Off unless MSQUAD_EDIT_COMPOSITE=1 or DEFAULT_ENABLED is True, so it can be A/B tested.
Deterministic, local: no model call.
"""

from __future__ import annotations

import os
import re

ENV_FLAG = "MSQUAD_EDIT_COMPOSITE"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = False

CHANGE_THRESHOLD = 24  # mean |RGB difference| (0-255), after smoothing, that counts as edited
SMOOTH_PX = 5  # box blur before thresholding, so JPEG noise and single pixels do not count
GROW_PX = 15  # the mask grows this far past the change, so the edit's own edges are kept
FEATHER_PX = 6  # soft edge between edit and source: no visible seam
MIN_FRACTION = 0.002  # less than this changed: nothing to protect
MAX_FRACTION = 0.6  # more than this changed: a whole-image edit, left alone
# A faint change over most of the picture is a global edit too (a brighten, a tint): measured at
# this lower threshold. Live cap edits cover 19-24% at it (52 tester-live runs), far below 0.6.
GLOBAL_THRESHOLD = 8

# Instructions that change the whole picture's colour, tone, style, weather or season (Fable on
# #279: a grayscale edit came out kept in 18% of the image, a brighten patchy at 29%).
_GLOBAL_RE = re.compile(
    r"\b(?:black\s*(?:and|&)\s*white|b\s*/\s*w|gr[ae]y\s*scale|monochrome|sepia|desaturat\w*|"
    r"bright(?:en|er|ness)|dark(?:en|er)|tint\w*|contrast|saturat\w*|exposure|colou?r\s*grad\w*|"
    r"filter|style|painting|watercolou?r|oil\s*paint\w*|sketch|cartoon|anime|illustration|vintage|"
    r"snow\w*|winter|autumn|fall\s*foliage|summer|spring|rain\w*|fog\w*|weather|season\w*|"
    r"night\w*|sunset|sunrise|golden\s*hour)\b",
    re.IGNORECASE,
)


# Markers of an edit scoped to one thing: an add/remove verb up front, "only", or an owner
# ("the car's", "her dress"). A whole-image edit names the photo, the scene or nothing.
_LOCAL_RE = re.compile(
    r"^\s*(?:add|give|put|place|hang|print|attach|insert|draw|remove|erase|delete)\b|\bonly\b|\w'\w?s\b"
    r"|\b(?:his|her|their|its)\b",
    re.IGNORECASE,
)


_WHOLE_RE = re.compile(r"\b(?:photo|image|picture|scene|whole|entire|everything|overall)\b", re.IGNORECASE)


def is_global_instruction(instruction: str) -> bool:
    """True when the edit instruction asks for a whole-image change (colour, tone, style, weather).

    A global word inside a local edit ("a rain jacket", "the car's headlights brighter", "snow on
    the roof only") does not count: the edit adds or changes one named thing.
    """
    text = str(instruction or "")
    if not _GLOBAL_RE.search(text):
        return False
    return bool(_WHOLE_RE.search(text)) or not _LOCAL_RE.search(text)


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def change_mask(source, edited):
    """The feathered mask (mode "L", 255 = edited) of where ``edited`` differs from ``source``."""
    from PIL import ImageChops, ImageFilter

    diff = ImageChops.difference(source.convert("RGB"), edited.convert("RGB")).convert("L")
    diff = diff.filter(ImageFilter.BoxBlur(SMOOTH_PX))
    mask = diff.point(lambda v: 255 if v >= CHANGE_THRESHOLD else 0)
    mask = mask.filter(ImageFilter.MaxFilter(2 * GROW_PX + 1))
    return mask.filter(ImageFilter.GaussianBlur(FEATHER_PX))


def _fraction(source, edited, threshold: int) -> float:
    from PIL import ImageChops, ImageFilter

    diff = ImageChops.difference(source, edited).convert("L").filter(ImageFilter.BoxBlur(SMOOTH_PX))
    histogram = diff.point(lambda v: 255 if v >= threshold else 0).histogram()
    return histogram[255] / float(source.size[0] * source.size[1])


def composite(source, edited, instruction: str = ""):
    """``edited`` at the source's size, with the source's pixels outside the changed region.

    Returns ``(image, note)``; the image is the resized edit unchanged when the arm's skip rules
    apply. ``note`` says which (for the run log).
    """
    from PIL import Image

    source = source.convert("RGB")
    edited = edited.convert("RGB")
    if edited.size != source.size:
        edited = edited.resize(source.size, Image.LANCZOS)
    if is_global_instruction(instruction):
        return edited, "skipped (a whole-image instruction)"
    if _fraction(source, edited, GLOBAL_THRESHOLD) > MAX_FRACTION:
        return edited, "skipped (a faint change over most of the image: a global edit)"
    mask = change_mask(source, edited)
    histogram = mask.point(lambda v: 255 if v >= 128 else 0).histogram()
    fraction = histogram[255] / float(source.size[0] * source.size[1])
    if fraction < MIN_FRACTION:
        return edited, f"skipped (changed {fraction:.1%})"
    if fraction > MAX_FRACTION:
        return edited, f"skipped (changed {fraction:.0%}: whole-image edit)"
    return Image.composite(edited, source, mask), f"edit kept in {fraction:.0%} of the image, source elsewhere"
