"""Try the next roster model once when a solve call fails.

Main retries the same model for transient proxy errors (rate limit, timeout, 5xx).
A non-transient failure such as HTTP 400 invalid_request_error is not retried there, so
the agent fell straight back to an empty answer. This helper gives that case one attempt
on the next ranked model, while enough time remains.
"""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable, TypeVar

from msquad.resilience import PROGRAMMING_ERRORS

T = TypeVar("T")


def next_model(ranked_models: list[str], current: str) -> str:
    """The first ranked model after ``current``, or "" when there is none."""
    if current in ranked_models:
        after = [model for model in ranked_models[ranked_models.index(current) + 1 :] if model != current]
        if after:
            return after[0]
    others = [model for model in ranked_models if model != current]
    return others[0] if others else ""


async def solve_with_model_fallback(
    solve: Callable[[str], Awaitable[T]],
    ranked_models: list[str],
    model_name: str,
    remaining_s: Callable[[], float],
    min_remaining_s: float,
    fastest: Callable[[str], str] | None = None,
    short_min_s: float = 12.0,
    submit_margin_s: float = 8.0,
) -> tuple[str, T]:
    """Run ``solve(model)``; on failure, run it once on the next model if time allows.

    Returns (model_used, result). Re-raises the first error when no retry is possible.
    """
    try:
        return model_name, await solve(model_name)
    except PROGRAMMING_ERRORS:
        # A bug in our code is not a proxy failure: never retry it, never swallow it.
        raise
    except Exception as exc:
        retry = next_model(ranked_models, model_name)
        remaining = remaining_s()
        if retry and remaining > min_remaining_s:
            print(f"   ⚠️  {model_name} failed ({exc}); retrying once with {retry}.")
            return retry, await solve(retry)
        # Short deadline: one retry on the fastest roster model, cut off before the
        # submit margin, so the answer can never arrive late.
        fast = fastest(model_name) if fastest else ""
        if not fast or not (short_min_s <= remaining < min_remaining_s):
            raise
        budget = remaining - submit_margin_s
        if budget <= 0:
            raise
        print(f"   ⚠️  {model_name} failed ({exc}); short deadline, retrying once with {fast} within {budget:.1f}s.")
        return fast, await asyncio.wait_for(solve(fast), timeout=budget)
