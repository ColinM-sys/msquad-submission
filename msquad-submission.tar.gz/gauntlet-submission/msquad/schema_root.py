"""Arm: a schema is read from its top-level object, not from a branch nested inside it.

_schema_from_text scanned every "{", so a root schema with no "properties" (a $defs or allOf schema) gave
the first nested object that had properties, a branch, as the root. With this arm on, the text inside a
top-level JSON object that decodes is not scanned again, and a top-level object with "type": "object" or
"required" but no "properties" is returned as the root. On by default. Off only when MSQUAD_SCHEMA_ROOT=0 or
DEFAULT_ENABLED is False.
"""

from __future__ import annotations

import os

ENV_FLAG = "MSQUAD_SCHEMA_ROOT"
# Code default when the env var is unset: flip to True to ship it on without the environment.
DEFAULT_ENABLED = True


def enabled(environ: dict | None = None) -> bool:
    value = str((environ if environ is not None else os.environ).get(ENV_FLAG, "")).strip().lower()
    if not value:
        return DEFAULT_ENABLED
    return value in {"1", "true", "yes", "on"}


def is_root_without_properties(value: object) -> bool:
    """A top-level schema object that describes an object or lists required keys but has no properties."""
    if not isinstance(value, dict) or "properties" in value:
        return False
    return value.get("type") == "object" or "required" in value
